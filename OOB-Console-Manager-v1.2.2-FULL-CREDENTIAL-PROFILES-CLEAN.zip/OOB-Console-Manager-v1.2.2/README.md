# OOB Console Manager v1.2.0

**Full Web Control Center + Production Data Hardening**

OOB Console Manager là công cụ CLI Python để quản lý và truy cập an toàn các OOB Console Server. Phiên bản hiện tại tập trung vào Cisco terminal server và Vertiv Avocent ACS800/8000, xây dựng inventory console, phát hiện thay đổi, kiểm tra line đang rảnh/bận trước khi mở console, xác minh danh tính thiết bị phía sau và lưu audit đầy đủ.

> Bản này vẫn là công cụ vận hành có kiểm soát, không phải hệ thống tự động reboot/config hàng loạt. Main Menu v1.2.0 chỉ còn 5 workflow để dễ dùng; toàn bộ chức năng menu 1..18 cũ vẫn còn trong các submenu. Workflow [5] CẬP NHẬT OOB là write operation có kiểm soát.

---

## 0. Web Control Center đầy đủ

Bản v1.2.0 có giao diện web dùng chung toàn bộ core và database với CLI: Dashboard, OOB CRUD, Test SSH, Scan, Quick A/B, Full Inventory, Browser Console, Task Center, Inventory/History/Audit, backup/export/settings và database health.

Cài web dependency:

```bash
python -m pip install -r requirements-web.txt
```

Chạy Windows:

```powershell
.\run_web_windows.ps1
```

Chạy Linux:

```bash
./run_web_linux.sh
```

Mặc định mở `http://127.0.0.1:5000`. Web không có mật khẩu mặc định; xem hướng dẫn đầy đủ tại `WEB_MANAGER_V1.2.0.md` và checklist `WEB_UAT_V1.2.0.md`. CLI vẫn chạy bình thường qua `run_windows.bat`, `run_linux.sh` hoặc `python main.py`.

---

## 1. Chạy nhanh trên Windows

### Yêu cầu duy nhất phải cài trước

- Windows 10/11 hoặc Windows Server tương đương.
- **Python 3.10 trở lên**. Khuyến nghị Python 3.12 hoặc 3.13.
- Máy có thể truy cập OOB qua TCP/SSH.
- Internet/proxy cho phép pip tải package ở lần chạy đầu, hoặc dependency đã được cài sẵn.

### Cách dễ nhất

1. Giải nén ZIP vào thư mục có quyền ghi, ví dụ:

```text
D:\OOB-Console-Manager-v1.2.0
```

2. Double-click:

```text
run_windows.bat
```

Launcher sẽ tự:

```text
kiểm tra Python >= 3.10
        ↓
tạo .venv nếu chưa có
        ↓
cài paramiko + colorama nếu thiếu
        ↓
chạy main.py --check
        ↓
mở main.py
```

Không nên đặt project trong `C:\Program Files` vì tool cần ghi database, log, backup, export và session log.

### Chạy bằng PowerShell

```powershell
cd D:\OOB-Console-Manager-v1.2.0
.\run_windows.bat
```

Hoặc sau khi `.venv` đã tồn tại:

```powershell
.\.venv\Scripts\python.exe main.py --check
.\.venv\Scripts\python.exe main.py
```

---

## 2. Chạy nhanh trên Linux

```bash
cd /path/to/OOB-Console-Manager-v1.2.0
chmod +x run_linux.sh
./run_linux.sh
```

Launcher sẽ tự tạo `.venv`, cài dependency nếu thiếu, kiểm tra môi trường rồi mở tool.

---

## 3. Dependency runtime

Bản release khóa dependency để hành vi triển khai ổn định hơn:

```text
paramiko==3.5.1
colorama==0.4.6
```

Paramiko 3.x được giữ có chủ đích để tăng khả năng tương thích với một số OOB Cisco/SSH legacy. Không tự nâng Paramiko major version trên máy production trước khi UAT lại thiết bị thật.

Test development nằm trong:

```text
requirements-dev.txt
```

---

## 4. Kiểm tra trước khi dùng thiết bị thật

```powershell
.\.venv\Scripts\python.exe main.py --version
.\.venv\Scripts\python.exe main.py --check
```

Kỳ vọng:

```text
OOB Console Manager CLI 1.2.0
[OK] Python >= 3.10
[OK] Thư viện
[OK] Profiles
[OK] Cơ sở dữ liệu (read-only)
```

Nếu DB chưa tồn tại, `--check` chỉ báo DB sẽ được tạo/migrate khi chạy chương trình; lệnh check không tự migrate DB.

---

## 5. Tool hiện hỗ trợ gì?

### OOB vendor

- Cisco IOS terminal/OOB server.
- Vertiv Avocent ACS800/ACS8000 CLI.

### Cisco OOB

- NORMAL_CLI (`hostname#` / `hostname>`).
- AUTO_MENU account.
- Parse `menu ... text` + `menu ... command`.
- Reverse Telnet target.
- `show line` + `show users` để đánh giá trạng thái line.
- Live mapping verification trước khi connect.
- Enable mode có state-driven timeout.

### Vertiv ACS800/8000

- Management SSH CLI.
- Tự chuyển từ root shell sang `cli` khi cần.
- `cd access` → `show` để lấy Name / Port / Type / Status.
- `active_sessions` để enrich BUSY session.
- `connect <port_name>`.
- Serial-port authentication password riêng.
- **DIRECT_SSH_PORT_NAME** đã hỗ trợ từ v1.1.19+ sau management safety-check.

### Downstream identity

Tool có read-only identity workflow cho:

- Cisco.
- Juniper.
- Huawei.

Có thể thu thập/chuẩn hóa:

```text
hostname thật
vendor
platform/model
serial number
software version
```

### Audit / safety

- Snapshot + baseline.
- Raw evidence.
- Provenance tới command/dòng nguồn.
- Quality Gate.
- Change detection.
- Mapping stale detection.
- Operation lease/heartbeat lock trong cùng SQLite DB.
- BUSY / BUSY_UNKNOWN_USER / UNKNOWN fail-closed.
- Override UNKNOWN bắt buộc lý do.
- Session recording.
- Local unread change/identity alert.
- Credential secret redaction nhưng giữ operator username cho audit.
- Controlled alias reconciliation.

---

## 6. Main Menu v1.2.0 - Operator đơn giản

```text
[1] OOB & SCAN
    Scan + so sánh Device A/B là workflow chính
    Mapping-only chỉ dùng khi cần kiểm tra inventory OOB

[2] TÌM & KẾT NỐI THIẾT BỊ
    Xem target, smart search, mở manual console

[3] IDENTITY NÂNG CAO
    Full identity là chức năng nâng cao, tách khỏi Quick A/B

[4] INVENTORY & LỊCH SỬ
    Current/today/by-date inventory, changes, scan/connection history, CSV

[5] CẬP NHẬT OOB
    Xem mismatch và đồng bộ alias/name OOB có kiểm soát

[C] Credential phiên làm việc (RAM only)
    Dùng chung / theo vendor; password tự mất khi thoát tool

[A] Nâng cao / Backup / Settings / Database Health
[H] Hướng dẫn
[0] Thoát
```

Trong submenu `OOB & SCAN`, thao tác thường dùng là:

```text
Scan OOB mới nhất
   ↓
Device A = alias/mapping OOB
   ↓
Live verify port AVAILABLE
   ↓
Mở đúng console path
   ↓
Device B = hostname từ banner/prompt thật
   ↓
MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR
```

Quick A/B **không** đi qua full identity discovery, không hỏi downstream username/password,
không chạy `show version`/`show inventory`, không tự clear line và không tự sửa alias.

Không có `cls`/`clear`: CLI giữ output để operator scroll lên dò SSH, scan và lỗi trước đó.
Các chức năng nâng cao vẫn còn, nhưng không nằm trên đường đi của Quick A/B.

---

## 7. Workflow tổng thể

### Workflow chính: Scan + so sánh Device A/B

```text
Add OOB
   ↓
Test TCP/SSH
   ↓
Fresh Scan OOB
   ↓
Parse + Quality Gate
   ↓
Device A (mapping/alias hiện tại)
   ↓
Live safety check ngay trước connect
   ├─ BUSY / UNKNOWN / STALE → SKIP/ERROR
   ↓ AVAILABLE + confident
Open exact console path
   ↓
Read banner/prompt only
   ├─ hostname thấy ngay → stop
   ├─ serial im lặng → Cisco tối đa 2 Enter có delay; Vertiv theo state riêng
   └─ login/Username/Password không có hostname → NO_HOSTNAME
   ↓
Device B (hostname thật)
   ↓
Normalize + compare
   ↓
MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR
```

### Full Identity chỉ dùng khi operator chủ động cần thêm thông tin

```text
Target đã được xác minh an toàn
   ↓
Full Identity workflow riêng
   ↓
Downstream credential (nếu thực sự cần)
   ↓
Read-only hostname/model/serial/version
```

Full Identity không được gọi ngầm từ Scan + so sánh A/B.

---

## 8. Cisco workflow

### Scan NORMAL_CLI

```text
SSH Cisco OOB
   ↓
Detect hostname# / hostname>
   ↓
Enable nếu cần
   ↓
terminal length 0
terminal width 512
   ↓
show running-config | include ^menu
(fallback show run | i ^menu)
   ↓
parse menu text + menu command
   ↓
show line
show users
   ↓
resolve AVAILABLE / BUSY / UNKNOWN
```

### Connect

Tool không tin baseline cũ một cách mù quáng. Trước khi gửi Telnet, tool đọc lại runtime mapping và so sánh:

```text
menu name
menu item
alias
protocol
host
port
command
```

Nếu khác baseline → BLOCK.

Nếu line BUSY → BLOCK tuyệt đối.

Nếu UNKNOWN → block mặc định. AUTO_MENU có thể override thủ công nhưng bắt buộc nhập lý do audit.

---

## 9. Vertiv workflow

### Discovery

```text
SSH ACS management
   ↓
ACS CLI hoặc root shell → cli
   ↓
cd /
cd access
show
   ↓
Name / Port / Type / Status
   ↓
Idle       → AVAILABLE
In-Use     → BUSY_UNKNOWN_USER
   ↓
active_sessions nếu cần
```

### CLI_CONNECT

```text
management safety-check
   ↓
cd access / show
   ↓
target phải đúng alias + port + AVAILABLE
   ↓
connect <port_name>
   ↓
serial-port Password? (nếu có)
   ↓
downstream console
```

### DIRECT_SSH_PORT_NAME

```text
management safety-check trước
   ↓
target phải AVAILABLE
   ↓
SSH lần 2 bằng username:port_name@ACS
   ↓
downstream console
```

Direct SSH không phải fallback tự động. Operator phải chủ động chọn mode.

---

## 10. Các trạng thái quan trọng

| Trạng thái | Ý nghĩa | Hành vi |
|---|---|---|
| AVAILABLE | Có bằng chứng line/port đang rảnh | Có thể tiếp tục |
| BUSY | Có session đang sử dụng | BLOCK |
| BUSY_UNKNOWN_USER | Biết đang bận nhưng chưa xác định user | BLOCK |
| UNKNOWN | Không đủ bằng chứng | BLOCK mặc định |
| INCOMPLETE | Mapping thiếu dữ liệu cốt lõi | Không dùng làm actionable baseline |
| PARTIAL | Scan/identity thiếu một phần evidence | Giữ evidence, không tin mù quáng |
| REJECTED | Quality Gate không đạt | Không thay trusted baseline |
| STALE | OOB/profile đã thay đổi sau baseline | Bắt buộc scan lại |

---

## 10.1 Credential phiên làm việc v1.1.31

Để tránh nhập cùng username/password nhiều lần, CLI có menu `[C]`. Credential
được giữ **chỉ trong RAM của process hiện tại** theo thứ tự ưu tiên:

```text
OOB override -> vendor (Cisco/Vertiv) -> SESSION DEFAULT -> hỏi operator
```

`default_username` của OOB được lưu trong SQLite vì đây là metadata vận hành,
không phải secret. Password, Cisco enable password, Vertiv serial-port password
và downstream password không được lưu vào `oob_devices`, export hay config file.

`Scan All` nếu credential session đã phủ toàn bộ OOB sẽ chạy ngay không hỏi lại.
Nếu chưa có credential, operator chọn dùng một bộ chung, theo vendor, hoặc nhập
riêng từng OOB. Khi chỉ một OOB bị `SSH_AUTHENTICATION_FAILED`/Cisco enable auth
fail, tool cho phép nhập credential riêng để retry đúng OOB đó, skip, hoặc hủy batch.
Credential override chỉ được giữ trong RAM sau khi retry không còn lỗi auth và
không làm thay đổi credential chung của các OOB tiếp theo.

## 11. Credential model

Tool phân biệt:

```text
1. OOB management credential
2. Vertiv serial-port authentication credential
3. Downstream device credential
4. Vertiv Direct SSH credential (có thể khác management account)
```

Password/token/secret không được lưu vào database audit.

Operator username **được giữ** để trả lời câu hỏi “ai đã thực hiện operation nào”.

Không lưu credential vào source/profile JSON.

---

## 12. Session recording

Console interactive ghi tại:

```text
session_logs/YYYY-MM-DD/conn_<connection_id>_<target>.log
```

Log gồm timestamp, input/output và local event. Input được nhận diện là secret sau các prompt Password/Passphrase/PIN/Secret sẽ được redact.

Session log vẫn là dữ liệu nhạy cảm và cần được bảo vệ như audit log nội bộ.

Thoát interactive console bằng:

```text
Ctrl+]
```

sau đó chọn `quit` hoặc `resume`.

---

## 13. Controlled Reconciliation – Menu 17

Menu 17 là **write operation** và chỉ dành cho trường hợp đã xác minh đây là thay đổi hợp lệ, ví dụ RMA/thay router nhưng vẫn giữ đúng physical console path.

Điều kiện chính:

```text
Identity = ACCEPTED
Mapping = VALID
Actual hostname != configured alias
Target = AVAILABLE
Ticket ID bắt buộc
Reason bắt buộc
Operator xác nhận alias mới
```

### Cisco

Chỉ đổi `menu <name> text <item> ...` trên đúng menu item. Không tự đổi Telnet host/port/line.

Sau write tool read-back, save startup config, verify và bắt buộc rescan.

### Vertiv

Chỉ đổi `port_name` trên đúng `/ports/serial_ports/<N>/cas`, commit, read-back rồi rescan.

Không tự đổi serial port number, SSH/Telnet alias, CAS protocol.

**Không dùng menu 17 để hợp thức hóa cáp bị cắm nhầm.**

---

## 14. Database và file runtime

```text
data/oob_manager.db          SQLite database
data/ssh_known_hosts         SSH TOFU host-key store
logs/                        application logs
session_logs/                interactive console recordings
backups/                     SQLite backups
exports/                     audit CSV exports
profiles/                    Cisco/Vertiv profile
```

Database schema hiện tại: **v16**.

SQLite phù hợp cho pilot/single-machine. Nếu nhiều operator trên nhiều PC cùng dùng, cần chuyển sang shared DB như PostgreSQL để baseline/locks trở thành dữ liệu dùng chung.

---

## 15. Backup và export

Menu 12 dùng SQLite backup API, integrity check và SHA-256 companion file.

Settings → Export tạo bộ CSV audit gồm inventory, scans, mapping, changes, connections, identity và reconciliation history.

Từ v1.1.31 output được tổ chức để chạy nhiều lần/ngày không bị rối:

```text
exports/YYYY-MM-DD/latest/current_inventory.csv
exports/YYYY-MM-DD/daily/daily_inventory_YYYY-MM-DD.csv
exports/YYYY-MM-DD/runs/HHMMSS_scan-ID_OOB/
exports/YYYY-MM-DD/advanced/full_HHMMSS/
session_logs/YYYY-MM-DD/
backups/YYYY-MM-DD/
```

`latest` và `daily` là view tiện dụng; mỗi thư mục `runs/` và `advanced/full_*` là artifact riêng, không ghi đè lần chạy trước.

### Vertiv port In-Use - hướng dẫn thủ công

Khi live-check xác minh serial port đang `In-Use`, tool **không tự kill session**. Hướng dẫn hiển thị theo command set ACS800/8000 đã đối chiếu:

```text
cd active_sessions
show
# xác định đúng target_name và session ID
kill_session <session_id>
cd /
cd access
show
connect <port_name>
```

Chỉ dùng `kill_session` khi account được phân quyền và đã xác nhận session đó không còn người đang xử lý. Các lệnh kiểu `disconnect port5` hoặc `show ports status` không được tool khuyến nghị vì không khớp workflow command reference ACS800/8000 đã xác minh.

---

## 16. Cấu trúc project

```text
OOB-Console-Manager-v1.2.0/
├── main.py
├── run_windows.bat
├── run_linux.sh
├── requirements.txt
├── requirements-dev.txt
├── README.md
├── CHUC_NANG_WORKFLOW_HUONG_PHAT_TRIEN.md
├── profiles/
│   ├── cisco.json
│   └── vertiv.json
├── oob_manager/
│   ├── cli/
│   ├── database/
│   ├── downstream/
│   ├── models/
│   ├── networking/
│   ├── services/
│   ├── utils/
│   └── vendors/
├── tests/
├── data/
├── logs/
├── session_logs/
├── backups/
└── exports/
```

---

## 17. Testing source

Development test:

```bash
python -m pip install -r requirements-dev.txt
pytest -q
```

Release này được đóng gói sau khi:

```text
Python compileall : PASS
Pytest            : 380 PASS / 0 FAIL
Version           : 1.2.0
Schema            : v18
```

Unit/regression test không thay thế physical-device UAT. Trước production cần xác nhận đúng firmware Cisco/Vertiv, AAA policy, SSH algorithm và Windows terminal của môi trường thật.

---

## 18. Những thứ cố tình CHƯA tự động hóa

- Không tự kick/clear console session.
- Không tự reboot/power-cycle thiết bị.
- Không chạy generic configuration command xuống router/switch.
- Không tự sửa mapping khi chỉ mới phát hiện mismatch.
- Không tự login hàng loạt vào toàn bộ production downstream.
- Chưa có PDU mapping.
- Chưa có NetBox/CMDB/NMS synchronization.
- Chưa có scheduler tự scan theo giờ/ngày.
- Chưa có webhook/Email/Teams/Slack/Zalo alert.
- Web hiện có RBAC local viewer/operator/admin; chưa có centralized PostgreSQL/SSO/LDAP.
- Chưa hỗ trợ Opengear/Raritan/Nokia/ZTE OOB parser.

Xem roadmap chi tiết trong `CHUC_NANG_WORKFLOW_HUONG_PHAT_TRIEN.md`.

---


## 18.1. Inventory / CSV đơn giản

Vào `[4] INVENTORY & LỊCH SỬ`:

- Inventory hiện tại.
- Inventory hôm nay.
- Chọn ngày `DD/MM/YYYY` hoặc `YYYY-MM-DD`.
- Xem mapping changes, scan history và connection history.
- Xuất `current_inventory.csv` hoặc `daily_inventory_YYYY-MM-DD.csv`.
- Full audit export vẫn nằm trong `[A] Nâng cao`.

Daily inventory dùng **scan mapping ACCEPTED mới nhất của từng OOB trong ngày**. Identity lịch sử lấy từ identity snapshot phù hợp, không gắn current identity ngược vào quá khứ.

## 18.2. HELP trong CLI

Tại Main Menu hoặc submenu có thể nhập `H`, `HELP` hoặc `?`. Sau mỗi màn hình kết quả, nhập `H` thay vì Enter để xem giải thích theo ngữ cảnh. HELP chỉ hiển thị tài liệu, không gửi command tới thiết bị.

## 19. Checklist UAT thiết bị thật

Checklist CLI hardening nằm trong `UAT_V1.1.37.md`; checklist web đầy đủ nằm trong `WEB_UAT_V1.2.0.md`. Với workflow hằng ngày chỉ cần ưu tiên các case A/B sau.

### Cisco Quick A/B

- Add OOB + test SSH.
- Fresh scan menu mapping.
- Verify `show line` + `show users` và AVAILABLE/BUSY/UNKNOWN đúng thực tế.
- AVAILABLE: reverse Telnet đúng `target_host:target_port`, lấy hostname Device B rồi dừng.
- Prompt kiểu `[vrf:none] root@HOST:~#` phải lấy đúng `HOST`.
- BUSY/UNKNOWN phải `SKIP/ERROR`, không reverse Telnet.
- `Connection refused` trong Quick A/B chỉ `SKIP/ERROR`; **không** hỏi clear line.
- Console im lặng có tối đa hai wake Enter theo state machine; không hostname thì `NO_HOSTNAME`.

### Vertiv Quick A/B

- Add ACS management SSH; root-shell → `cli` nếu firmware trả root shell.
- Scan `cd access` + `show`; Idle/In-Use phải phản ánh đúng màn hình ACS thật.
- AVAILABLE: live `access/show` → `connect <port_name>` → lấy Device B rồi dừng.
- In-Use phải `SKIP/ERROR`, không connect/kill session.
- Prompt ACS có BEL/C0 không được tái hiện timeout giả.
- Port yêu cầu port-auth password phải `SKIP/ERROR`, không hỏi credential phụ trong batch.

### Advanced/manual - chỉ test khi thực sự dùng

- Manual Console + `Ctrl+]`.
- Full Identity read-only hostname/model/serial/version.
- Controlled Cisco Clear-Line trên line lab/non-critical, có Y/N + reason + hậu kiểm.
- Vertiv `active_sessions`/DIRECT_SSH_PORT_NAME/port-auth workflow riêng.
- Controlled reconciliation alias OOB.

Các advanced workflow trên **không nằm trong đường đi Quick A/B**.

### Menu 17

Không dùng lần đầu trên PE/Core production. Chỉ test trên OOB lab/non-critical sau khi toàn bộ read-only/console path đã PASS.

---

## 20. Troubleshooting nhanh

### Không tìm thấy Python

Cài Python 3.10+, khuyến nghị 3.12/3.13 và bật `Add Python to PATH`.

### pip không tải được dependency

Kiểm tra Internet, proxy, private PyPI hoặc chuẩn bị wheel offline trước khi vào môi trường cách ly.

### PuTTY SSH được nhưng tool không SSH được

Kiểm tra SSH negotiation/algorithm, AAA challenge/MFA, host key và log. Một số thiết bị quá cũ có crypto legacy đặc thù vẫn cần UAT/profile riêng.

### Tool báo mapping STALE

Scan lại OOB. Không bypass STALE.

### Tool báo UNKNOWN

Không coi UNKNOWN là AVAILABLE. Kiểm tra quyền `show line/show users`, output thực tế hoặc AUTO_MENU account.

### Tool báo BUSY

Không override. Xác minh session ngoài tool.

### Cisco reverse Telnet báo `Connection refused by remote host`

Từ v1.1.22, tool chỉ đề xuất `clear line <N>` khi tất cả điều kiện an toàn đều đạt: NORMAL_CLI, line suy ra từ reverse-Telnet được `show line` xác nhận, và hậu kiểm `show line/show users` vẫn chứng minh line `AVAILABLE`. Tool hiển thị Y/N, bắt buộc lý do audit, xử lý `[confirm]`, hậu kiểm lại line và retry Telnet đúng **một lần**. BUSY/UNKNOWN hoặc line không xác minh được sẽ bị block và không có nút clear.

---

## 21. Nguyên tắc vận hành

1. Read-before-write.
2. Runtime verify trước action.
3. BUSY fail-closed.
4. UNKNOWN fail-closed, trừ manual AUTO_MENU override có lý do.
5. Không tin snapshot lỗi để thay baseline tốt.
6. Không lưu secret.
7. Mọi write reconciliation phải có ticket + reason + read-back + rescan.
8. Physical-device UAT luôn là bước cuối trước production.

---

## 22. Lịch sử hardening gần nhất

- **v1.1.19**: Real Device I/O Hardening, state-driven SSH/prompt, Vertiv Direct SSH Port Name.
- **v1.1.20**: Local Audit & Safety Hardening, giữ operator username, bắt buộc lý do override UNKNOWN, local alert và session recording.
- **v1.1.21**: Controlled OOB Reconciliation, alias-only write có phê duyệt + read-back + rescan.
- **v1.1.22**: CLI UX cleanup + Controlled Cisco Clear-Line Recovery khi reverse Telnet trả `Connection refused`; chỉ offer khi line được xác minh AVAILABLE, bắt buộc operator xác nhận + lý do, clear tối đa một lần rồi retry Telnet đúng một lần.
- **v1.1.23**: Daily Review theo ngày, `inventory_summary.csv` đơn giản, `daily_inventory_YYYY-MM-DD.csv`, lệnh `H/HELP/?` và HELP theo từng màn hình; không thay đổi core Cisco/Vertiv connection logic.
- **v1.1.24**: UI/UX patch: menu compact, màu trạng thái, bảng dễ đọc và cảnh báo Manual Console.
- **v1.1.25**: Simplified Operator CLI: bỏ hoàn toàn screen clear, gom 18 chức năng cũ vào 5 workflow + Advanced, thêm smart token search (`bras-HCM` ≈ `HCM-BRAS`) và current inventory CSV đơn giản; không thay đổi Cisco/Vertiv/clear-line/reconciliation core.
- **v1.1.26**: Data Organization & History Management: output theo `latest/daily/runs/advanced`, per-scan artifact không ghi đè, session log/backup chia theo ngày, tìm lịch sử target kể cả target không còn current, xem snapshot theo Scan ID; thêm hướng dẫn thủ công Vertiv `active_sessions -> kill_session <session_id>` khi port In-Use. Tool không tự kill session Vertiv.
- **v1.1.27**: Final UAT Stability: launcher ép đúng dependency pin, tự tạo lại `.venv` sai Python, Cisco Connection Test xác minh privileged EXEC, hỗ trợ `enable` không password, và Vertiv không còn hỏi Enable password không dùng.
- **v1.1.28**: Batch Cancellation Hardening: Ctrl+C khi nhập credential trong Scan All dừng toàn bộ batch, không tạo scan giả và hiển thị summary completed/skipped rõ ràng.
- **v1.1.29**: Session Credential UX: credential RAM-only dùng chung/theo vendor/OOB override, lưu default username (không lưu password), Scan All không hỏi lại khi đã đủ credential và hỗ trợ retry riêng OOB bị auth fail.

- **v1.1.30**: Session Credential Stability: không cache credential retry chưa được xác minh; Add OOB không còn test bằng session username khác với username operator vừa nhập.

- **v1.1.31**: CLI Form Resilience: Update OOB retry tại field cho Vendor/Enabled, Add OOB giữ form khi Test Connection fail và có recovery menu, hard-delete trim khoảng trắng ngoài tên xác nhận, runtime CLI dùng câu trung tính cho môi trường nhiều operator.
- **v1.1.32**: Real Device Connection Stability: Vertiv bỏ C0/BEL control byte khi nhận prompt ACS800/8000, Connection Test chỉ xác minh TCP/SSH/interactive shell/ACS CLI và không chạy inventory, Scan đi trực tiếp `cd access -> show` từ root CLI để tránh `cd /` no-op gây prompt timeout trên firmware/profile thực tế.
- **v1.1.33**: Quick Cable Verification Stability: nhận đúng hostname từ prompt thực tế như `root@HOST:~#`, `[vrf:none] root@HOST:~#`, IOS-XR `RP/...:HOST#`; normalize ANSI/BEL/C0; Quick A/B ưu tiên passive-read rồi chỉ gửi tối đa một Enter khi console im lặng; Vertiv Quick A/B cho phép silent serial đi tới hostname probe nhưng full identity vẫn fail-closed; bỏ `cd access` lặp sau live access/show trước `connect <port_name>`.
- **v1.1.34**: A/B-only simplification: fresh scan trước probe, không downstream login/show command, BUSY/UNKNOWN fail-closed, CSV đủ MATCH/MISMATCH/NO_HOSTNAME/SKIP-ERROR và Cisco reverse-Telnet wake fix.


## v1.1.34 - A/B Scan Simplification

Mục tiêu version này được ưu tiên theo vận hành thực tế, vì vậy bounded multi-OOB được dời sang version sau.

- Quick A/B tách hoàn toàn khỏi `DeviceIdentityService.discover()`; không tạo full-identity run, không cần downstream credential và không chạy downstream `show` command.
- Mọi thao tác A/B từ menu đều thực hiện **fresh scan trước**, không dùng current mapping cũ một cách mù quáng.
- Cisco Quick A/B: Device A/endpoint lấy từ scan ACCEPTED; ngay trước connect chỉ live-check `show line` + `show users`, sau đó gửi đúng reverse-Telnet endpoint đã parse và chỉ đọc hostname Device B. Không chạy lại menu config cho từng target.
- Cisco `connection refused` trong batch chỉ trả `SKIP/ERROR`; không mở controlled clear-line workflow, tránh hỏi operator nhiều lần. Manual Console vẫn giữ clear-line có kiểm soát như cũ.
- Vertiv Quick A/B: `access/show` live-verify port-name + Idle, sau đó `connect <port_name>` đúng một lần; không `cd access` lặp và không direct-SSH. Nếu SSO bị tắt và ACS hiện `Password:`, tool hỏi một policy serial-auth đúng một lần cho batch (password riêng, explicit reuse OOB password, hoặc skip). Sau xác thực thành công, tool nhấn Enter để vào console downstream và chỉ lấy Device B từ banner/prompt.
- Console downstream không login. Có hostname ở banner/prompt thì dừng ngay; Cisco reverse-Telnet có thể wake tối đa 2 Enter có delay, Vertiv giữ logic riêng theo state.
- Cisco guard chống false-positive: transcript `Trying/Open` nhưng cuối cùng quay lại đúng OOB prompt sẽ **không** bị lấy hostname OOB làm Device B.
- Mọi mapping trong fresh scan đều có một dòng A/B: BUSY/UNKNOWN/INCOMPLETE được ghi `SKIP/ERROR` thay vì biến mất; CSV được sắp đúng thứ tự target của fresh scan.
- Vertiv Scan chỉ đọc `active_sessions` khi `access/show` thực sự có port `In-Use`; nếu toàn bộ port `idle` thì bỏ lệnh phụ này để giảm navigation/show không cần thiết. Quick A/B không đọc `active_sessions` vì BUSY vẫn phải block dù biết hay không biết username.
- Kết quả operator chỉ còn 4 nhóm: `MATCH`, `MISMATCH`, `NO_HOSTNAME`, `SKIP/ERROR`. CSV A/B bỏ các cột full-identity/clear-line không liên quan.
- Regression của v1.1.34: **336/336 test pass**; nhóm lỗi lịch sử trọng tâm **121/121 pass** (Cisco/Vertiv real-device, Quick A/B, credential, cancellation, pre-connect hardening).
- Database hiện tại audit read-only: SQLite integrity OK và 0 semantic data-quality issue trên DB đóng gói.

v1.1.35 tiếp tục hardening Quick A/B history/banner; bounded multi-OOB vẫn chưa được bật để tránh làm yếu fail-closed safety.



## v1.2.0 - Production Data Hardening

- Cisco Quick A/B đọc lại exact runtime menu mapping ngay trước mỗi reverse-Telnet, sau đó mới live-check `show line/show users`.
- Runtime menu/item, alias, protocol và endpoint đổi sẽ bị fail-closed; không gửi Telnet tới endpoint stale.
- Sửa `target_alias` trong Quick A/B history và đánh dấu batch có `NO_HOSTNAME` là `PARTIAL`.
- Inventory hiển thị Device A/B, vendor, model, serial, version, identity quality/source và lỗi thu thập.
- Dữ liệu Full Identity `PARTIAL/FAILED` gần nhất được hiển thị dưới `LATEST_OBSERVED`, nhưng không ghi đè identity `ACCEPTED`.
- Thêm `Batch Full Inventory một OOB`: fresh scan, COMPLETE+AVAILABLE only, discovery tuần tự và commit từng target.
- Thêm `web_dashboard.py` read-only, bắt buộc password môi trường, bind localhost mặc định và không có action API.
- FULL release đóng theo whitelist, không chứa DB/known-hosts/log/session/export/backup runtime.
- Kết quả kiểm thử: **369/369 PASS**; dashboard HTTP smoke PASS; SQLite integrity OK, foreign-key violations 0.
- Schema v18 lưu audit per-port: runtime mapping verification và live-state evidence ngay trước console access.
- Data audit kiểm tra logic Quick A/B run/result (counter, status, Device B, AVAILABLE/confident, verification code/time và JSON evidence).

## v1.1.35 - Quick A/B History + Banner Hardening

- Giữ nguyên fail-closed BUSY/UNKNOWN, không clear-line, không downstream login/show command.
- Hỗ trợ FreeBSD/Linux/NetBSD/OpenBSD serial banner và wake tối đa 2 Enter có delay.
- Quick A/B ghi DB ngay sau từng port: MATCH/MISMATCH/NO_HOSTNAME/SKIP-ERROR.
- Inventory hiện tại và inventory theo ngày ưu tiên Device B mới nhất, nhưng Full Identity model/serial/version vẫn tách riêng.
- Thêm menu Lịch sử Quick A/B và full export `cable_check_runs.csv` / `cable_check_results.csv`.
- Kết quả kiểm thử v1.1.35: **359/359 PASS** (chạy theo 3 nhóm để tránh timeout của runner).
