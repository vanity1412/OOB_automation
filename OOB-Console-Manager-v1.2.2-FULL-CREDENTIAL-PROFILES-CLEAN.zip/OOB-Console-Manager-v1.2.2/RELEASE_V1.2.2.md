# OOB Monitor Web v1.2.2 — Persistent Credential Profiles

## Mục tiêu
- Quản lý tập trung nhiều OOB Cisco/Vertiv có IP khác nhau nhưng dùng chung credential.
- Tìm OOB theo alias/IP/vendor rồi chạy Test SSH, Scan, Quick A/B, Full Identity, Console và Reconciliation từ web.
- Không lưu password plaintext.

## Credential Profile
- Một profile gồm: name, vendor scope, username, password, Cisco enable password, notes, enabled.
- Một profile có thể được gán cho nhiều OOB.
- Thứ tự resolve: credential RAM theo OOB/vendor/default trước; nếu không có thì dùng persistent profile đã gán.
- Windows dùng DPAPI Current User. DB chỉ lưu ciphertext Base64 và provider metadata.
- DB copy sang Windows user khác không giải mã được.
- Linux/macOS chỉ cho lưu khi có OOB_CREDENTIAL_MASTER_KEY; mã hóa AES-256-GCM.

## Push / Reconciliation
- Không cung cấp ô chạy lệnh cấu hình tùy ý.
- Chỉ dùng controlled reconciliation hiện có: preview, diff, ticket, reason, apply, re-verify, audit, rollback attempt.
- Vertiv mapping push vẫn fail-closed cho tới khi có adapter/command chính thức được kiểm thử trên thiết bị thật.

## Database
- Schema 19.
- Thêm credential_profiles.
- Thêm oob_devices.credential_profile_id.
- Migration idempotent, không mất inventory/history hiện có.

## Test
- 384/384 PASS.
- SQLite integrity_check=ok.
- foreign_key_check=0.
- API smoke: create profile, assign OOB, list, health.
