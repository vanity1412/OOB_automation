#!/usr/bin/env bash
set -euo pipefail
if [[ -z "${OOB_WEB_ADMIN_PASSWORD:-}" ]]; then
  read -rsp "OOB web admin password: " OOB_WEB_ADMIN_PASSWORD; echo
  export OOB_WEB_ADMIN_PASSWORD
fi
if [[ -z "${OOB_WEB_SECRET:-}" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    OOB_WEB_SECRET="$(openssl rand -hex 48)"
  else
    OOB_WEB_SECRET="$(python - <<'PY'
import secrets
print(secrets.token_hex(48))
PY
)"
  fi
  export OOB_WEB_SECRET
  echo "Generated an in-memory OOB_WEB_SECRET for this run."
fi
export OOB_WEB_HOST="${OOB_WEB_HOST:-127.0.0.1}"
export OOB_WEB_PORT="${OOB_WEB_PORT:-5000}"
python web_app.py
