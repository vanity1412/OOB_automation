"""Migration SQLite idempotent cho OOB Console Manager."""
from __future__ import annotations

import hashlib
import sqlite3

from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.schema import SCHEMA_SQL, SCHEMA_VERSION
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import sanitize_text


class MigrationManager:
    """Tạo schema mới và nâng cấp database cũ mà không làm mất dữ liệu."""

    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def migrate(self) -> None:
        statements = [
            statement.strip() for statement in SCHEMA_SQL.split(";") if statement.strip()
        ]
        table_statements = [
            statement
            for statement in statements
            if not statement.upper().startswith("CREATE INDEX")
        ]
        index_statements = [
            statement
            for statement in statements
            if statement.upper().startswith("CREATE INDEX")
        ]
        with self.db.transaction() as conn:
            for statement in table_statements:
                conn.execute(statement)
            self._migrate_v2(conn)
            self._migrate_v3(conn)
            self._migrate_v4(conn)
            self._migrate_v5(conn)
            self._migrate_v6(conn)
            self._migrate_v7(conn)
            self._migrate_v8(conn)
            self._migrate_v9(conn)
            self._migrate_v10(conn)
            self._migrate_v11(conn)
            self._migrate_v12(conn)
            self._migrate_v13(conn)
            self._migrate_v14(conn)
            self._migrate_v15(conn)
            self._migrate_v16(conn)
            self._migrate_v17(conn)
            self._migrate_v18(conn)
            self._migrate_v19(conn)
            for statement in index_statements:
                conn.execute(statement)
            self._recreate_audit_views(conn)
            conn.execute(
                "INSERT OR IGNORE INTO schema_versions(version, applied_at) VALUES (?, ?)",
                (SCHEMA_VERSION, to_db(utc_now())),
            )
            conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")

    def _migrate_v2(self, conn: sqlite3.Connection) -> None:
        self._add_column_if_missing(conn, "console_snapshots", "target_id", "INTEGER")
        scan_columns = {
            "complete_count": "INTEGER NOT NULL DEFAULT 0",
            "complete_ratio": "REAL NOT NULL DEFAULT 0",
            "change_count": "INTEGER NOT NULL DEFAULT 0",
        }
        for column_name, definition in scan_columns.items():
            self._add_column_if_missing(conn, "scan_runs", column_name, definition)

        connection_columns = {
            "target_alias": "TEXT NOT NULL DEFAULT ''",
            "target_host": "TEXT NOT NULL DEFAULT ''",
            "target_port": "INTEGER NOT NULL DEFAULT 0",
            "menu_name": "TEXT NOT NULL DEFAULT ''",
            "menu_item": "INTEGER",
        }
        for column_name, definition in connection_columns.items():
            self._add_column_if_missing(
                conn, "connection_history", column_name, definition
            )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_snapshots_target ON console_snapshots(target_id)"
        )

    def _migrate_v3(self, conn: sqlite3.Connection) -> None:
        oob_columns = {
            "connection_revision": "INTEGER NOT NULL DEFAULT 1",
            "baseline_revision": "INTEGER NOT NULL DEFAULT 1",
            "baseline_stale_reason": "TEXT NOT NULL DEFAULT ''",
            "baseline_stale_at": "TEXT",
        }
        for column_name, definition in oob_columns.items():
            self._add_column_if_missing(conn, "oob_devices", column_name, definition)

        self._add_column_if_missing(
            conn, "scan_runs", "connection_revision", "INTEGER NOT NULL DEFAULT 1"
        )
        mapping_quality_added = self._add_column_if_missing(
            conn,
            "scan_runs",
            "mapping_quality",
            "TEXT NOT NULL DEFAULT 'REJECTED'",
        )
        baseline_updated_added = self._add_column_if_missing(
            conn,
            "scan_runs",
            "baseline_updated",
            "INTEGER NOT NULL DEFAULT 0",
        )

        if mapping_quality_added:
            conn.execute(
                """
                UPDATE scan_runs
                SET mapping_quality = CASE
                    WHEN status='SUCCESS' THEN 'ACCEPTED'
                    WHEN status='PARTIAL' THEN 'PARTIAL'
                    ELSE 'REJECTED'
                END
                """
            )
        if baseline_updated_added:
            conn.execute(
                """
                UPDATE scan_runs
                SET baseline_updated = CASE WHEN status='SUCCESS' THEN 1 ELSE 0 END
                """
            )

        target_state_confident_added = self._add_column_if_missing(
            conn,
            "console_targets",
            "state_confident",
            "INTEGER NOT NULL DEFAULT 0",
        )
        self._add_column_if_missing(
            conn,
            "console_snapshots",
            "state_confident",
            "INTEGER NOT NULL DEFAULT 0",
        )

        if target_state_confident_added:
            conn.execute(
                """
                UPDATE console_targets
                SET state='UNKNOWN', session_user=''
                WHERE state_confident=0 AND state <> 'INCOMPLETE'
                """
            )

    def _migrate_v4(self, conn: sqlite3.Connection) -> None:
        scan_snapshot_columns = {
            "oob_name_at_scan": "TEXT NOT NULL DEFAULT ''",
            "oob_host_at_scan": "TEXT NOT NULL DEFAULT ''",
            "oob_ssh_port_at_scan": "INTEGER NOT NULL DEFAULT 0",
            "vendor_at_scan": "TEXT NOT NULL DEFAULT ''",
            "connection_mode_at_scan": "TEXT NOT NULL DEFAULT ''",
            "device_type_at_scan": "TEXT NOT NULL DEFAULT ''",
            "profile_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "config_snapshot_source": "TEXT NOT NULL DEFAULT 'LIVE_CAPTURE'",
        }
        scan_snapshot_added = False
        for name, definition in scan_snapshot_columns.items():
            scan_snapshot_added = (
                self._add_column_if_missing(conn, "scan_runs", name, definition)
                or scan_snapshot_added
            )
        if scan_snapshot_added:
            conn.execute(
                """
                UPDATE scan_runs
                SET oob_name_at_scan=COALESCE((SELECT o.name FROM oob_devices o WHERE o.id=scan_runs.oob_id), ''),
                    oob_host_at_scan=COALESCE((SELECT o.host FROM oob_devices o WHERE o.id=scan_runs.oob_id), ''),
                    oob_ssh_port_at_scan=COALESCE((SELECT o.ssh_port FROM oob_devices o WHERE o.id=scan_runs.oob_id), 0),
                    vendor_at_scan=COALESCE((SELECT o.vendor FROM oob_devices o WHERE o.id=scan_runs.oob_id), ''),
                    connection_mode_at_scan=COALESCE((SELECT o.connection_mode FROM oob_devices o WHERE o.id=scan_runs.oob_id), ''),
                    device_type_at_scan=COALESCE((SELECT o.device_type FROM oob_devices o WHERE o.id=scan_runs.oob_id), ''),
                    config_snapshot_source='BACKFILLED_CURRENT'
                """
            )

        raw_columns = {
            "is_core": "INTEGER NOT NULL DEFAULT 0",
            "redaction_applied": "INTEGER NOT NULL DEFAULT 0",
            "stored_output_sha256": "TEXT NOT NULL DEFAULT ''",
            "stored_output_length": "INTEGER NOT NULL DEFAULT 0",
        }
        raw_added = False
        for name, definition in raw_columns.items():
            raw_added = (
                self._add_column_if_missing(conn, "raw_outputs", name, definition)
                or raw_added
            )
        if raw_added:
            conn.execute(
                "UPDATE raw_outputs SET is_core=CASE WHEN command_name IN ('initial','menu') THEN 1 ELSE 0 END"
            )
            for row in conn.execute("SELECT id, raw_output FROM raw_outputs").fetchall():
                value = row["raw_output"] or ""
                conn.execute(
                    "UPDATE raw_outputs SET stored_output_sha256=?, stored_output_length=? WHERE id=?",
                    (hashlib.sha256(value.encode("utf-8")).hexdigest(), len(value), row["id"]),
                )

        target_columns = {
            "console_line_source": "TEXT NOT NULL DEFAULT 'UNRESOLVED'",
            "state_reason_code": "TEXT NOT NULL DEFAULT ''",
            "state_evidence": "TEXT NOT NULL DEFAULT '{}'",
            "mapping_source_command": "TEXT NOT NULL DEFAULT ''",
            "mapping_text_line": "TEXT NOT NULL DEFAULT ''",
            "mapping_command_line": "TEXT NOT NULL DEFAULT ''",
        }
        target_added = False
        for name, definition in target_columns.items():
            target_added = (
                self._add_column_if_missing(conn, "console_targets", name, definition)
                or target_added
            )
        if target_added:
            conn.execute(
                """
                UPDATE console_targets
                SET console_line_source=CASE WHEN console_line IS NULL THEN 'LEGACY_UNRESOLVED' ELSE 'LEGACY_UNKNOWN' END,
                    state_reason_code=CASE WHEN state_confident=1 THEN 'LEGACY_CONFIDENT_STATE' ELSE 'LEGACY_UNVERIFIED_STATE' END,
                    state_evidence='{}'
                """
            )

        snapshot_added = False
        for name, definition in target_columns.items():
            snapshot_added = (
                self._add_column_if_missing(conn, "console_snapshots", name, definition)
                or snapshot_added
            )
        if snapshot_added:
            conn.execute(
                """
                UPDATE console_snapshots
                SET console_line_source=CASE WHEN console_line IS NULL THEN 'LEGACY_UNRESOLVED' ELSE 'LEGACY_UNKNOWN' END,
                    state_reason_code=CASE WHEN state_confident=1 THEN 'LEGACY_CONFIDENT_STATE' ELSE 'LEGACY_UNVERIFIED_STATE' END,
                    state_evidence='{}'
                """
            )

        connection_columns = {
            "target_command": "TEXT NOT NULL DEFAULT ''",
            "console_line": "INTEGER",
            "mapping_last_scan_id": "INTEGER",
            "oob_name_at_connection": "TEXT NOT NULL DEFAULT ''",
            "oob_host_at_connection": "TEXT NOT NULL DEFAULT ''",
            "oob_ssh_port_at_connection": "INTEGER NOT NULL DEFAULT 0",
            "vendor_at_connection": "TEXT NOT NULL DEFAULT ''",
            "connection_mode_at_connection": "TEXT NOT NULL DEFAULT ''",
            "connection_revision": "INTEGER NOT NULL DEFAULT 1",
            "baseline_revision": "INTEGER NOT NULL DEFAULT 1",
            "config_snapshot_source": "TEXT NOT NULL DEFAULT 'LIVE_CAPTURE'",
            "console_path_verified": "INTEGER NOT NULL DEFAULT 0",
            "path_verification_code": "TEXT NOT NULL DEFAULT 'UNVERIFIED'",
            "path_verification_message": "TEXT NOT NULL DEFAULT ''",
            "runtime_menu_verified": "INTEGER NOT NULL DEFAULT 0",
            "process_pid": "INTEGER NOT NULL DEFAULT 0",
            "process_hostname": "TEXT NOT NULL DEFAULT ''",
        }
        connection_added = False
        for name, definition in connection_columns.items():
            connection_added = (
                self._add_column_if_missing(conn, "connection_history", name, definition)
                or connection_added
            )
        if connection_added:
            conn.execute(
                """
                UPDATE connection_history
                SET oob_name_at_connection=COALESCE((SELECT o.name FROM oob_devices o WHERE o.id=connection_history.oob_id), ''),
                    oob_host_at_connection=COALESCE((SELECT o.host FROM oob_devices o WHERE o.id=connection_history.oob_id), ''),
                    oob_ssh_port_at_connection=COALESCE((SELECT o.ssh_port FROM oob_devices o WHERE o.id=connection_history.oob_id), 0),
                    vendor_at_connection=COALESCE((SELECT o.vendor FROM oob_devices o WHERE o.id=connection_history.oob_id), ''),
                    connection_mode_at_connection=COALESCE((SELECT o.connection_mode FROM oob_devices o WHERE o.id=connection_history.oob_id), ''),
                    connection_revision=COALESCE((SELECT o.connection_revision FROM oob_devices o WHERE o.id=connection_history.oob_id), 1),
                    baseline_revision=COALESCE((SELECT o.baseline_revision FROM oob_devices o WHERE o.id=connection_history.oob_id), 1),
                    config_snapshot_source='BACKFILLED_CURRENT',
                    path_verification_code='LEGACY_UNVERIFIED'
                """
            )

        # scan_findings được tạo bởi schema mới. Với lịch sử cũ chỉ có thể nói rằng
        # chi tiết finding không còn đầy đủ; không được bịa lại warning đã mất.
        conn.execute(
            """
            INSERT INTO scan_findings(scan_id, finding_type, severity, code, source, message, created_at)
            SELECT s.id, 'MIGRATION', 'INFO', 'LEGACY_FINDINGS_UNAVAILABLE', 'migration_v4',
                   'Scan được tạo trước schema v4; warning/reason chi tiết không còn đủ để khôi phục.',
                   COALESCE(s.finished_at, s.started_at)
            FROM scan_runs s
            WHERE s.status IN ('PARTIAL','REJECTED','FAILED')
              AND NOT EXISTS (
                  SELECT 1 FROM scan_findings f
                  WHERE f.scan_id=s.id AND f.code='LEGACY_FINDINGS_UNAVAILABLE'
              )
            """
        )


    def _migrate_v5(self, conn: sqlite3.Connection) -> None:
        """Audit actor/profile lineage without pretending legacy data is exact."""
        oob_columns = {
            "current_profile_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "baseline_profile_fingerprint": "TEXT NOT NULL DEFAULT ''",
        }
        oob_added = False
        for name, definition in oob_columns.items():
            oob_added = self._add_column_if_missing(conn, "oob_devices", name, definition) or oob_added
        if oob_added:
            # Best-effort: profile used by last accepted baseline is exact only for scans
            # captured since v4. If unavailable but current targets exist, mark legacy
            # baseline as unknown so next real operation fails closed until rescan.
            conn.execute(
                """
                UPDATE oob_devices
                SET baseline_profile_fingerprint=COALESCE((
                        SELECT NULLIF(s.profile_fingerprint,'') FROM scan_runs s
                        WHERE s.oob_id=oob_devices.id AND s.baseline_updated=1
                        ORDER BY s.id DESC LIMIT 1
                    ), CASE WHEN EXISTS(SELECT 1 FROM console_targets t WHERE t.oob_id=oob_devices.id)
                            THEN 'LEGACY_UNKNOWN' ELSE '' END),
                    current_profile_fingerprint=COALESCE((
                        SELECT NULLIF(s.profile_fingerprint,'') FROM scan_runs s
                        WHERE s.oob_id=oob_devices.id AND s.baseline_updated=1
                        ORDER BY s.id DESC LIMIT 1
                    ), '')
                """
            )

        scan_columns = {
            "ssh_username_at_scan": "TEXT NOT NULL DEFAULT ''",
            "trigger_source": "TEXT NOT NULL DEFAULT 'SERVICE'",
            "process_pid": "INTEGER NOT NULL DEFAULT 0",
            "process_hostname": "TEXT NOT NULL DEFAULT ''",
            "process_user": "TEXT NOT NULL DEFAULT ''",
        }
        for name, definition in scan_columns.items():
            self._add_column_if_missing(conn, "scan_runs", name, definition)

        # Provenance dòng menu giúp operator dò đúng dòng raw config đã sinh target.
        for table_name in ("console_targets", "console_snapshots"):
            self._add_column_if_missing(conn, table_name, "mapping_text_line_no", "INTEGER")
            self._add_column_if_missing(conn, table_name, "mapping_command_line_no", "INTEGER")

        self._add_column_if_missing(
            conn, "connection_history", "process_user", "TEXT NOT NULL DEFAULT ''"
        )
        self._add_column_if_missing(
            conn, "connection_history", "downstream_identity_verified",
            "INTEGER NOT NULL DEFAULT 0"
        )
        self._add_column_if_missing(
            conn, "connection_history", "downstream_identity_method",
            "TEXT NOT NULL DEFAULT 'NOT_VERIFIED'"
        )
        self._add_column_if_missing(
            conn, "connection_history", "downstream_identity_value",
            "TEXT NOT NULL DEFAULT ''"
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS oob_change_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                oob_id INTEGER,
                oob_name TEXT NOT NULL DEFAULT '',
                changed_at TEXT NOT NULL,
                change_type TEXT NOT NULL,
                changed_fields TEXT NOT NULL DEFAULT '',
                old_data TEXT NOT NULL DEFAULT '{}',
                new_data TEXT NOT NULL DEFAULT '{}',
                source TEXT NOT NULL DEFAULT 'repository',
                process_pid INTEGER NOT NULL DEFAULT 0,
                process_hostname TEXT NOT NULL DEFAULT '',
                process_user TEXT NOT NULL DEFAULT ''
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_oob_change_history_oob_time "
            "ON oob_change_history(oob_id, changed_at DESC)"
        )

    def _migrate_v6(self, conn: sqlite3.Connection) -> None:
        """SSH transport identity audit: persistent TOFU fingerprint metadata."""
        for table in ("scan_runs", "connection_history"):
            self._add_column_if_missing(
                conn, table, "ssh_host_key_algorithm", "TEXT NOT NULL DEFAULT ''"
            )
            self._add_column_if_missing(
                conn, table, "ssh_host_key_fingerprint", "TEXT NOT NULL DEFAULT ''"
            )
            self._add_column_if_missing(
                conn, table, "ssh_host_key_policy", "TEXT NOT NULL DEFAULT ''"
            )

        self._add_column_if_missing(
            conn, "scan_runs", "profile_snapshot_json", "TEXT NOT NULL DEFAULT '{}'"
        )
        self._add_column_if_missing(
            conn, "scan_runs", "scan_policy_snapshot_json", "TEXT NOT NULL DEFAULT '{}'"
        )

    def _migrate_v7(self, conn: sqlite3.Connection) -> None:
        """Guard future writes against invalid application-level enum/counter states.

        SQLite cannot add CHECK constraints to existing tables without rebuilding
        them.  BEFORE triggers give old databases the same protection as fresh
        databases while preserving every historical row.
        """
        conn.executescript(
            """
            DROP TRIGGER IF EXISTS trg_scan_runs_validate_insert;
            CREATE TRIGGER trg_scan_runs_validate_insert
            BEFORE INSERT ON scan_runs
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','PARTIAL','FAILED','REJECTED')
              OR NEW.mapping_quality NOT IN ('ACCEPTED','PARTIAL','REJECTED')
              OR NEW.mapping_count < 0 OR NEW.complete_count < 0
              OR NEW.complete_count > NEW.mapping_count
              OR NEW.complete_ratio < 0 OR NEW.complete_ratio > 1
              OR NEW.warning_count < 0 OR NEW.change_count < 0
              OR (NEW.baseline_updated=1 AND NEW.mapping_quality<>'ACCEPTED')
            BEGIN
                SELECT RAISE(ABORT, 'invalid scan_runs semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_scan_runs_validate_update;
            CREATE TRIGGER trg_scan_runs_validate_update
            BEFORE UPDATE ON scan_runs
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','PARTIAL','FAILED','REJECTED')
              OR NEW.mapping_quality NOT IN ('ACCEPTED','PARTIAL','REJECTED')
              OR NEW.mapping_count < 0 OR NEW.complete_count < 0
              OR NEW.complete_count > NEW.mapping_count
              OR NEW.complete_ratio < 0 OR NEW.complete_ratio > 1
              OR NEW.warning_count < 0 OR NEW.change_count < 0
              OR (NEW.baseline_updated=1 AND NEW.mapping_quality<>'ACCEPTED')
            BEGIN
                SELECT RAISE(ABORT, 'invalid scan_runs semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_targets_validate_insert;
            CREATE TRIGGER trg_console_targets_validate_insert
            BEFORE INSERT ON console_targets
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_targets semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_targets_validate_update;
            CREATE TRIGGER trg_console_targets_validate_update
            BEFORE UPDATE ON console_targets
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_targets semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_snapshots_validate_insert;
            CREATE TRIGGER trg_console_snapshots_validate_insert
            BEFORE INSERT ON console_snapshots
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_snapshots semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_snapshots_validate_update;
            CREATE TRIGGER trg_console_snapshots_validate_update
            BEFORE UPDATE ON console_snapshots
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_snapshots semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_connection_history_validate_insert;
            CREATE TRIGGER trg_connection_history_validate_insert
            BEFORE INSERT ON connection_history
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','FAILED','ABANDONED')
              OR (NEW.status='RUNNING' AND NEW.ended_at IS NOT NULL)
              OR (NEW.status IN ('SUCCESS','FAILED','ABANDONED') AND NEW.ended_at IS NULL)
            BEGIN
                SELECT RAISE(ABORT, 'invalid connection_history status');
            END;

            DROP TRIGGER IF EXISTS trg_connection_history_validate_update;
            CREATE TRIGGER trg_connection_history_validate_update
            BEFORE UPDATE ON connection_history
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','FAILED','ABANDONED')
              OR (NEW.status='RUNNING' AND NEW.ended_at IS NOT NULL)
              OR (NEW.status IN ('SUCCESS','FAILED','ABANDONED') AND NEW.ended_at IS NULL)
            BEGIN
                SELECT RAISE(ABORT, 'invalid connection_history status');
            END;
            """
        )

    def _migrate_v8(self, conn: sqlite3.Connection) -> None:
        """Persist live pre-connect mapping/state evidence for console sessions."""
        columns = {
            "runtime_mapping_verified": "INTEGER NOT NULL DEFAULT 0",
            "runtime_mapping_verification_code": "TEXT NOT NULL DEFAULT 'UNVERIFIED'",
            "runtime_mapping_verification_message": "TEXT NOT NULL DEFAULT ''",
            "live_state": "TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "live_state_confident": "INTEGER NOT NULL DEFAULT 0",
            "live_session_user": "TEXT NOT NULL DEFAULT ''",
            "live_state_reason_code": "TEXT NOT NULL DEFAULT ''",
            "live_state_evidence": "TEXT NOT NULL DEFAULT '{}'",
            "live_state_checked_at": "TEXT",
        }
        for name, definition in columns.items():
            self._add_column_if_missing(conn, "connection_history", name, definition)

        # Recreate only connection guards so upgraded databases get the same
        # semantic protection as fresh schema without rebuilding historical rows.
        conn.executescript(
            """
            DROP TRIGGER IF EXISTS trg_connection_history_validate_insert;
            CREATE TRIGGER trg_connection_history_validate_insert
            BEFORE INSERT ON connection_history
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','FAILED','ABANDONED')
              OR (NEW.status='RUNNING' AND NEW.ended_at IS NOT NULL)
              OR (NEW.status IN ('SUCCESS','FAILED','ABANDONED') AND NEW.ended_at IS NULL)
              OR NEW.runtime_mapping_verified NOT IN (0,1)
              OR NEW.live_state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.live_state_confident NOT IN (0,1)
              OR (NEW.live_state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.live_state_confident<>1)
              OR (NEW.live_state='UNKNOWN' AND NEW.live_state_confident<>0)
              OR (NEW.live_state='BUSY' AND TRIM(NEW.live_session_user)='')
              OR (NEW.live_state='AVAILABLE' AND TRIM(NEW.live_session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid connection_history semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_connection_history_validate_update;
            CREATE TRIGGER trg_connection_history_validate_update
            BEFORE UPDATE ON connection_history
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','FAILED','ABANDONED')
              OR (NEW.status='RUNNING' AND NEW.ended_at IS NOT NULL)
              OR (NEW.status IN ('SUCCESS','FAILED','ABANDONED') AND NEW.ended_at IS NULL)
              OR NEW.runtime_mapping_verified NOT IN (0,1)
              OR NEW.live_state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.live_state_confident NOT IN (0,1)
              OR (NEW.live_state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.live_state_confident<>1)
              OR (NEW.live_state='UNKNOWN' AND NEW.live_state_confident<>0)
              OR (NEW.live_state='BUSY' AND TRIM(NEW.live_session_user)='')
              OR (NEW.live_state='AVAILABLE' AND TRIM(NEW.live_session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid connection_history semantic state');
            END;
            """
        )


    def _migrate_v9(self, conn: sqlite3.Connection) -> None:
        """Downstream read-only device identity discovery/audit."""
        # v9 was designed as the first downstream-identity schema. Keep these
        # additions idempotent so a pre-release v9 database can still be opened
        # safely without asking the operator to delete any data.
        identity_run_columns = {
            "collector_version": "TEXT NOT NULL DEFAULT ''",
            "oob_name_at_run": "TEXT NOT NULL DEFAULT ''",
            "oob_host_at_run": "TEXT NOT NULL DEFAULT ''",
            "oob_ssh_port_at_run": "INTEGER NOT NULL DEFAULT 0",
            "oob_vendor_at_run": "TEXT NOT NULL DEFAULT ''",
            "oob_connection_mode_at_run": "TEXT NOT NULL DEFAULT ''",
            "oob_connection_revision_at_run": "INTEGER NOT NULL DEFAULT 0",
            "oob_baseline_revision_at_run": "INTEGER NOT NULL DEFAULT 0",
            "target_command_at_run": "TEXT NOT NULL DEFAULT ''",
            "target_protocol_at_run": "TEXT NOT NULL DEFAULT ''",
        }
        for column_name, definition in identity_run_columns.items():
            self._add_column_if_missing(
                conn, "device_identity_runs", column_name, definition
            )

        conn.executescript(
            """
            DROP TRIGGER IF EXISTS trg_identity_runs_validate_insert;
            CREATE TRIGGER trg_identity_runs_validate_insert
            BEFORE INSERT ON device_identity_runs
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','PARTIAL','FAILED','ABANDONED')
              OR NEW.identity_quality NOT IN ('ACCEPTED','PARTIAL','REJECTED')
              OR NEW.identity_confidence NOT IN ('HIGH','MEDIUM','LOW')
              OR NEW.alias_comparison NOT IN ('EXACT_MATCH','DIFFERENT','UNKNOWN')
              OR NEW.runtime_mapping_verified NOT IN (0,1)
              OR NEW.live_state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.live_state_confident NOT IN (0,1)
              OR (NEW.status='RUNNING' AND NEW.finished_at IS NOT NULL)
              OR (NEW.status<>'RUNNING' AND NEW.finished_at IS NULL)
              OR (NEW.status='SUCCESS' AND NEW.identity_quality<>'ACCEPTED')
              OR (NEW.status='PARTIAL' AND NEW.identity_quality<>'PARTIAL')
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND NEW.runtime_mapping_verified<>1)
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND (NEW.live_state<>'AVAILABLE' OR NEW.live_state_confident<>1))
            BEGIN
                SELECT RAISE(ABORT, 'invalid device_identity_runs semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_identity_runs_validate_update;
            CREATE TRIGGER trg_identity_runs_validate_update
            BEFORE UPDATE ON device_identity_runs
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','PARTIAL','FAILED','ABANDONED')
              OR NEW.identity_quality NOT IN ('ACCEPTED','PARTIAL','REJECTED')
              OR NEW.identity_confidence NOT IN ('HIGH','MEDIUM','LOW')
              OR NEW.alias_comparison NOT IN ('EXACT_MATCH','DIFFERENT','UNKNOWN')
              OR NEW.runtime_mapping_verified NOT IN (0,1)
              OR NEW.live_state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.live_state_confident NOT IN (0,1)
              OR (NEW.status='RUNNING' AND NEW.finished_at IS NOT NULL)
              OR (NEW.status<>'RUNNING' AND NEW.finished_at IS NULL)
              OR (NEW.status='SUCCESS' AND NEW.identity_quality<>'ACCEPTED')
              OR (NEW.status='PARTIAL' AND NEW.identity_quality<>'PARTIAL')
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND NEW.runtime_mapping_verified<>1)
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND (NEW.live_state<>'AVAILABLE' OR NEW.live_state_confident<>1))
            BEGIN
                SELECT RAISE(ABORT, 'invalid device_identity_runs semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_device_identities_validate_insert;
            CREATE TRIGGER trg_device_identities_validate_insert
            BEFORE INSERT ON device_identities
            WHEN NEW.identity_quality<>'ACCEPTED'
              OR NOT EXISTS(
                    SELECT 1 FROM device_identity_runs r
                    WHERE r.id=NEW.last_identity_run_id
                      AND r.target_id=NEW.target_id
                      AND r.oob_id=NEW.oob_id
                      AND r.status='SUCCESS'
                      AND r.identity_quality='ACCEPTED'
                )
            BEGIN
                SELECT RAISE(ABORT, 'invalid current device identity provenance');
            END;

            DROP TRIGGER IF EXISTS trg_device_identities_validate_update;
            CREATE TRIGGER trg_device_identities_validate_update
            BEFORE UPDATE ON device_identities
            WHEN NEW.identity_quality<>'ACCEPTED'
              OR NOT EXISTS(
                    SELECT 1 FROM device_identity_runs r
                    WHERE r.id=NEW.last_identity_run_id
                      AND r.target_id=NEW.target_id
                      AND r.oob_id=NEW.oob_id
                      AND r.status='SUCCESS'
                      AND r.identity_quality='ACCEPTED'
                )
            BEGIN
                SELECT RAISE(ABORT, 'invalid current device identity provenance');
            END;
            """
        )


    def _migrate_v10(self, conn: sqlite3.Connection) -> None:
        """Device identity verification/mismatch history (v1.1.6)."""
        run_columns = {
            "verification_status": "TEXT NOT NULL DEFAULT 'INCONCLUSIVE'",
            "verification_severity": "TEXT NOT NULL DEFAULT 'INFO'",
            "hardware_continuity": "TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "previous_identity_run_id": "INTEGER",
            "changed_fields": "TEXT NOT NULL DEFAULT ''",
            "verification_reason_codes": "TEXT NOT NULL DEFAULT '[]'",
            "verification_summary": "TEXT NOT NULL DEFAULT ''",
            "identity_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "previous_identity_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "verification_source": "TEXT NOT NULL DEFAULT 'LEGACY_BACKFILL_V1_1_6'",
        }
        current_columns = {
            "verification_status": "TEXT NOT NULL DEFAULT 'INCONCLUSIVE'",
            "verification_severity": "TEXT NOT NULL DEFAULT 'INFO'",
            "hardware_continuity": "TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "previous_identity_run_id": "INTEGER",
            "changed_fields": "TEXT NOT NULL DEFAULT ''",
            "verification_reason_codes": "TEXT NOT NULL DEFAULT '[]'",
            "verification_summary": "TEXT NOT NULL DEFAULT ''",
            "identity_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "verification_source": "TEXT NOT NULL DEFAULT 'LEGACY_BACKFILL_V1_1_6'",
        }
        snapshot_columns = {
            "verification_status": "TEXT NOT NULL DEFAULT 'INCONCLUSIVE'",
            "verification_severity": "TEXT NOT NULL DEFAULT 'INFO'",
            "hardware_continuity": "TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "previous_identity_run_id": "INTEGER",
            "changed_fields": "TEXT NOT NULL DEFAULT ''",
            "verification_reason_codes": "TEXT NOT NULL DEFAULT '[]'",
            "verification_summary": "TEXT NOT NULL DEFAULT ''",
            "identity_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "previous_identity_fingerprint": "TEXT NOT NULL DEFAULT ''",
            "verification_source": "TEXT NOT NULL DEFAULT 'LEGACY_BACKFILL_V1_1_6'",
        }
        added = False
        for name, definition in run_columns.items():
            added = self._add_column_if_missing(conn, "device_identity_runs", name, definition) or added
        for name, definition in current_columns.items():
            added = self._add_column_if_missing(conn, "device_identities", name, definition) or added
        for name, definition in snapshot_columns.items():
            added = self._add_column_if_missing(conn, "device_identity_snapshots", name, definition) or added

        if added:
            conn.execute(
                """
                UPDATE device_identity_runs
                SET verification_status=CASE
                        WHEN status='SUCCESS' AND alias_comparison='EXACT_MATCH' THEN 'VERIFIED_MATCH'
                        WHEN status='SUCCESS' AND alias_comparison='DIFFERENT' THEN 'VERIFIED_MISMATCH'
                        WHEN status='SUCCESS' THEN 'VERIFIED_IDENTITY'
                        ELSE 'INCONCLUSIVE'
                    END,
                    verification_severity=CASE
                        WHEN status='SUCCESS' AND alias_comparison='DIFFERENT' THEN 'WARNING'
                        ELSE 'INFO'
                    END,
                    hardware_continuity='UNKNOWN',
                    verification_reason_codes='[]',
                    verification_source='LEGACY_BACKFILL_V1_1_6'
                WHERE verification_source<>'LIVE_V1_1_6'
                """
            )
            conn.execute(
                """
                UPDATE device_identities
                SET verification_status=CASE
                        WHEN alias_comparison='EXACT_MATCH' THEN 'VERIFIED_MATCH'
                        WHEN alias_comparison='DIFFERENT' THEN 'VERIFIED_MISMATCH'
                        ELSE 'VERIFIED_IDENTITY'
                    END,
                    verification_severity=CASE WHEN alias_comparison='DIFFERENT' THEN 'WARNING' ELSE 'INFO' END,
                    hardware_continuity='UNKNOWN',
                    verification_reason_codes='[]',
                    verification_source='LEGACY_BACKFILL_V1_1_6'
                WHERE verification_source<>'LIVE_V1_1_6'
                """
            )
            conn.execute(
                """
                UPDATE device_identity_snapshots
                SET verification_status=CASE
                        WHEN identity_quality='ACCEPTED' AND alias_comparison='EXACT_MATCH' THEN 'VERIFIED_MATCH'
                        WHEN identity_quality='ACCEPTED' AND alias_comparison='DIFFERENT' THEN 'VERIFIED_MISMATCH'
                        WHEN identity_quality='ACCEPTED' THEN 'VERIFIED_IDENTITY'
                        ELSE 'INCONCLUSIVE'
                    END,
                    verification_severity=CASE
                        WHEN identity_quality='ACCEPTED' AND alias_comparison='DIFFERENT' THEN 'WARNING'
                        ELSE 'INFO'
                    END,
                    hardware_continuity='UNKNOWN',
                    verification_reason_codes='[]',
                    verification_source='LEGACY_BACKFILL_V1_1_6'
                WHERE verification_source<>'LIVE_V1_1_6'
                """
            )

        # Backfill canonical fingerprints. These hashes contain no secret; they only
        # identify the accepted hostname/vendor/model/serial tuple used for audit.
        from oob_manager.downstream.verification import identity_fingerprint
        from oob_manager.models.device_identity import DeviceIdentity

        def fp_from_row(row) -> str:
            identity = DeviceIdentity(
                actual_hostname=str(row["actual_hostname"] or ""),
                vendor=str(row["vendor"] or row["detected_vendor"] or "UNKNOWN") if "detected_vendor" in row.keys() else str(row["vendor"] or "UNKNOWN"),
                model=str(row["model"] or ""),
                serial_number=str(row["serial_number"] or ""),
                quality="ACCEPTED",
            )
            return identity_fingerprint(identity)

        for row in conn.execute(
            "SELECT target_id,actual_hostname,vendor,model,serial_number,identity_fingerprint FROM device_identities"
        ).fetchall():
            if not str(row["identity_fingerprint"] or ""):
                conn.execute(
                    "UPDATE device_identities SET identity_fingerprint=? WHERE target_id=?",
                    (fp_from_row(row), row["target_id"]),
                )
        for row in conn.execute(
            "SELECT id,actual_hostname,detected_vendor,model,serial_number,identity_fingerprint FROM device_identity_runs WHERE identity_quality='ACCEPTED'"
        ).fetchall():
            if not str(row["identity_fingerprint"] or ""):
                identity = DeviceIdentity(
                    actual_hostname=str(row["actual_hostname"] or ""),
                    vendor=str(row["detected_vendor"] or "UNKNOWN"),
                    model=str(row["model"] or ""),
                    serial_number=str(row["serial_number"] or ""),
                    quality="ACCEPTED",
                )
                conn.execute(
                    "UPDATE device_identity_runs SET identity_fingerprint=? WHERE id=?",
                    (identity_fingerprint(identity), row["id"]),
                )
        for row in conn.execute(
            "SELECT id,actual_hostname,vendor,model,serial_number,identity_quality,identity_fingerprint FROM device_identity_snapshots"
        ).fetchall():
            if row["identity_quality"] == "ACCEPTED" and not str(row["identity_fingerprint"] or ""):
                conn.execute(
                    "UPDATE device_identity_snapshots SET identity_fingerprint=? WHERE id=?",
                    (fp_from_row(row), row["id"]),
                )

        conn.executescript(
            """
            DROP TRIGGER IF EXISTS trg_identity_runs_validate_insert;
            CREATE TRIGGER trg_identity_runs_validate_insert
            BEFORE INSERT ON device_identity_runs
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','PARTIAL','FAILED','ABANDONED')
              OR NEW.identity_quality NOT IN ('ACCEPTED','PARTIAL','REJECTED')
              OR NEW.identity_confidence NOT IN ('HIGH','MEDIUM','LOW')
              OR NEW.alias_comparison NOT IN ('EXACT_MATCH','DIFFERENT','UNKNOWN')
              OR NEW.verification_status NOT IN ('INCONCLUSIVE','VERIFIED_IDENTITY','VERIFIED_MATCH','VERIFIED_MISMATCH','DEVICE_CHANGE_SUSPECTED')
              OR NEW.verification_severity NOT IN ('INFO','WARNING','HIGH')
              OR NEW.hardware_continuity NOT IN ('UNKNOWN','FIRST_SEEN','UNCHANGED','CHANGED')
              OR NEW.runtime_mapping_verified NOT IN (0,1)
              OR NEW.live_state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.live_state_confident NOT IN (0,1)
              OR (NEW.status='RUNNING' AND NEW.finished_at IS NOT NULL)
              OR (NEW.status<>'RUNNING' AND NEW.finished_at IS NULL)
              OR (NEW.status='SUCCESS' AND NEW.identity_quality<>'ACCEPTED')
              OR (NEW.status='SUCCESS' AND NEW.verification_status='INCONCLUSIVE')
              OR (NEW.status='PARTIAL' AND NEW.identity_quality<>'PARTIAL')
              OR (NEW.status='PARTIAL' AND NEW.verification_status<>'INCONCLUSIVE')
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND NEW.runtime_mapping_verified<>1)
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND (NEW.live_state<>'AVAILABLE' OR NEW.live_state_confident<>1))
              OR (NEW.verification_status='DEVICE_CHANGE_SUSPECTED' AND (NEW.hardware_continuity<>'CHANGED' OR NEW.verification_severity<>'HIGH'))
            BEGIN
                SELECT RAISE(ABORT, 'invalid device_identity_runs semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_identity_runs_validate_update;
            CREATE TRIGGER trg_identity_runs_validate_update
            BEFORE UPDATE ON device_identity_runs
            WHEN NEW.status NOT IN ('RUNNING','SUCCESS','PARTIAL','FAILED','ABANDONED')
              OR NEW.identity_quality NOT IN ('ACCEPTED','PARTIAL','REJECTED')
              OR NEW.identity_confidence NOT IN ('HIGH','MEDIUM','LOW')
              OR NEW.alias_comparison NOT IN ('EXACT_MATCH','DIFFERENT','UNKNOWN')
              OR NEW.verification_status NOT IN ('INCONCLUSIVE','VERIFIED_IDENTITY','VERIFIED_MATCH','VERIFIED_MISMATCH','DEVICE_CHANGE_SUSPECTED')
              OR NEW.verification_severity NOT IN ('INFO','WARNING','HIGH')
              OR NEW.hardware_continuity NOT IN ('UNKNOWN','FIRST_SEEN','UNCHANGED','CHANGED')
              OR NEW.runtime_mapping_verified NOT IN (0,1)
              OR NEW.live_state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.live_state_confident NOT IN (0,1)
              OR (NEW.status='RUNNING' AND NEW.finished_at IS NOT NULL)
              OR (NEW.status<>'RUNNING' AND NEW.finished_at IS NULL)
              OR (NEW.status='SUCCESS' AND NEW.identity_quality<>'ACCEPTED')
              OR (NEW.status='SUCCESS' AND NEW.verification_status='INCONCLUSIVE')
              OR (NEW.status='PARTIAL' AND NEW.identity_quality<>'PARTIAL')
              OR (NEW.status='PARTIAL' AND NEW.verification_status<>'INCONCLUSIVE')
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND NEW.runtime_mapping_verified<>1)
              OR (NEW.status IN ('SUCCESS','PARTIAL') AND (NEW.live_state<>'AVAILABLE' OR NEW.live_state_confident<>1))
              OR (NEW.verification_status='DEVICE_CHANGE_SUSPECTED' AND (NEW.hardware_continuity<>'CHANGED' OR NEW.verification_severity<>'HIGH'))
            BEGIN
                SELECT RAISE(ABORT, 'invalid device_identity_runs semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_device_identities_validate_insert;
            CREATE TRIGGER trg_device_identities_validate_insert
            BEFORE INSERT ON device_identities
            WHEN NEW.identity_quality<>'ACCEPTED'
              OR NEW.verification_status='INCONCLUSIVE'
              OR NEW.verification_status NOT IN ('VERIFIED_IDENTITY','VERIFIED_MATCH','VERIFIED_MISMATCH','DEVICE_CHANGE_SUSPECTED')
              OR NEW.verification_severity NOT IN ('INFO','WARNING','HIGH')
              OR NEW.hardware_continuity NOT IN ('UNKNOWN','FIRST_SEEN','UNCHANGED','CHANGED')
              OR (NEW.verification_status='DEVICE_CHANGE_SUSPECTED' AND (NEW.hardware_continuity<>'CHANGED' OR NEW.verification_severity<>'HIGH'))
              OR NOT EXISTS(
                    SELECT 1 FROM device_identity_runs r
                    WHERE r.id=NEW.last_identity_run_id
                      AND r.target_id=NEW.target_id
                      AND r.oob_id=NEW.oob_id
                      AND r.status='SUCCESS'
                      AND r.identity_quality='ACCEPTED'
                      AND r.verification_status=NEW.verification_status
                )
            BEGIN
                SELECT RAISE(ABORT, 'invalid current device identity provenance');
            END;

            DROP TRIGGER IF EXISTS trg_device_identities_validate_update;
            CREATE TRIGGER trg_device_identities_validate_update
            BEFORE UPDATE ON device_identities
            WHEN NEW.identity_quality<>'ACCEPTED'
              OR NEW.verification_status='INCONCLUSIVE'
              OR NEW.verification_status NOT IN ('VERIFIED_IDENTITY','VERIFIED_MATCH','VERIFIED_MISMATCH','DEVICE_CHANGE_SUSPECTED')
              OR NEW.verification_severity NOT IN ('INFO','WARNING','HIGH')
              OR NEW.hardware_continuity NOT IN ('UNKNOWN','FIRST_SEEN','UNCHANGED','CHANGED')
              OR (NEW.verification_status='DEVICE_CHANGE_SUSPECTED' AND (NEW.hardware_continuity<>'CHANGED' OR NEW.verification_severity<>'HIGH'))
              OR NOT EXISTS(
                    SELECT 1 FROM device_identity_runs r
                    WHERE r.id=NEW.last_identity_run_id
                      AND r.target_id=NEW.target_id
                      AND r.oob_id=NEW.oob_id
                      AND r.status='SUCCESS'
                      AND r.identity_quality='ACCEPTED'
                      AND r.verification_status=NEW.verification_status
                )
            BEGIN
                SELECT RAISE(ABORT, 'invalid current device identity provenance');
            END;

            DROP TRIGGER IF EXISTS trg_identity_snapshots_validate_insert;
            CREATE TRIGGER trg_identity_snapshots_validate_insert
            BEFORE INSERT ON device_identity_snapshots
            WHEN NEW.verification_status NOT IN ('INCONCLUSIVE','VERIFIED_IDENTITY','VERIFIED_MATCH','VERIFIED_MISMATCH','DEVICE_CHANGE_SUSPECTED')
              OR NEW.verification_severity NOT IN ('INFO','WARNING','HIGH')
              OR NEW.hardware_continuity NOT IN ('UNKNOWN','FIRST_SEEN','UNCHANGED','CHANGED')
              OR (NEW.identity_quality='ACCEPTED' AND NEW.verification_status='INCONCLUSIVE')
              OR (NEW.identity_quality<>'ACCEPTED' AND NEW.verification_status<>'INCONCLUSIVE')
            BEGIN
                SELECT RAISE(ABORT, 'invalid device_identity_snapshot semantic state');
            END;
            """
        )


    @staticmethod
    def _recreate_audit_views(conn: sqlite3.Connection) -> None:
        conn.executescript(
            """
            DROP VIEW IF EXISTS v_current_console_inventory;
            CREATE VIEW v_current_console_inventory AS
            SELECT
                t.id AS target_id,
                t.oob_id,
                o.name AS oob_name,
                o.host AS oob_host,
                o.ssh_port AS oob_ssh_port,
                o.vendor,
                CASE WHEN o.connection_revision=o.baseline_revision AND (o.baseline_profile_fingerprint='' OR o.current_profile_fingerprint=o.baseline_profile_fingerprint) THEN 'VALID' ELSE 'STALE' END AS mapping_validity,
                o.baseline_stale_reason,
                o.current_profile_fingerprint, o.baseline_profile_fingerprint,
                t.menu_name,
                t.menu_item,
                t.alias,
                t.protocol,
                t.target_host,
                t.target_port,
                t.console_line,
                t.console_line_source,
                t.state,
                t.state_confident,
                t.state_reason_code,
                t.session_user,
                t.is_complete,
                t.last_scan_id,
                t.first_seen_at,
                t.last_seen_at
            FROM console_targets t
            JOIN oob_devices o ON o.id=t.oob_id;

            DROP VIEW IF EXISTS v_scan_audit;
            CREATE VIEW v_scan_audit AS
            SELECT
                s.*,
                (SELECT COUNT(*) FROM raw_outputs r WHERE r.scan_id=s.id) AS raw_output_count,
                (SELECT COUNT(*) FROM scan_findings f WHERE f.scan_id=s.id) AS finding_count,
                (SELECT COUNT(*) FROM console_snapshots p WHERE p.scan_id=s.id) AS snapshot_count
            FROM scan_runs s;

            DROP VIEW IF EXISTS v_connection_audit;
            CREATE VIEW v_connection_audit AS
            SELECT
                h.*,
                COALESCE(NULLIF(h.target_alias,''), t.alias) AS current_or_historical_alias
            FROM connection_history h
            LEFT JOIN console_targets t ON t.id=h.target_id;

            DROP VIEW IF EXISTS v_connection_trace;
            CREATE VIEW v_connection_trace AS
            SELECT
                h.id AS connection_id, h.oob_id, h.target_id, h.mapping_last_scan_id,
                h.started_at, h.ended_at, h.status AS connection_status,
                h.username AS operator_username, h.process_hostname, h.process_user,
                h.oob_name_at_connection, h.oob_host_at_connection, h.oob_ssh_port_at_connection,
                h.vendor_at_connection, h.connection_mode_at_connection,
                h.connection_revision AS connection_revision_at_open,
                h.baseline_revision AS baseline_revision_at_open,
                h.target_alias, h.menu_name, h.menu_item, h.target_command,
                h.target_host, h.target_port, h.console_line,
                h.console_path_verified, h.path_verification_code, h.path_verification_message,
                h.runtime_menu_verified, h.runtime_mapping_verified,
                h.runtime_mapping_verification_code, h.runtime_mapping_verification_message,
                h.live_state, h.live_state_confident, h.live_session_user,
                h.live_state_reason_code, h.live_state_evidence, h.live_state_checked_at,
                h.downstream_identity_verified, h.downstream_identity_method, h.downstream_identity_value,
                h.safety_override_requested, h.safety_override_used, h.safety_override_reason, h.session_log_path,
                h.ssh_host_key_algorithm AS connection_ssh_host_key_algorithm,
                h.ssh_host_key_fingerprint AS connection_ssh_host_key_fingerprint,
                h.ssh_host_key_policy AS connection_ssh_host_key_policy,
                s.status AS mapping_scan_status, s.mapping_quality AS mapping_scan_quality,
                s.baseline_updated AS mapping_scan_baseline_updated,
                s.oob_name_at_scan AS mapping_oob_name_at_scan,
                s.oob_host_at_scan AS mapping_oob_host_at_scan,
                s.oob_ssh_port_at_scan AS mapping_oob_ssh_port_at_scan,
                s.vendor_at_scan AS mapping_vendor_at_scan,
                s.connection_revision AS mapping_scan_connection_revision,
                s.profile_fingerprint AS mapping_profile_fingerprint,
                s.ssh_host_key_algorithm AS scan_ssh_host_key_algorithm,
                s.ssh_host_key_fingerprint AS scan_ssh_host_key_fingerprint,
                s.ssh_host_key_policy AS scan_ssh_host_key_policy,
                CASE
                    WHEN h.mapping_last_scan_id IS NULL THEN 'NO_MAPPING_SCAN'
                    WHEN s.id IS NULL THEN 'MAPPING_SCAN_MISSING'
                    WHEN s.oob_id<>h.oob_id THEN 'MAPPING_SCAN_OOB_MISMATCH'
                    WHEN s.mapping_quality<>'ACCEPTED' OR s.baseline_updated<>1 THEN 'MAPPING_NOT_ACCEPTED'
                    ELSE 'TRACE_OK'
                END AS trace_status,
                CASE
                    WHEN h.status<>'SUCCESS' THEN 'SESSION_NOT_SUCCESSFUL'
                    WHEN h.runtime_mapping_verified<>1 THEN 'SUCCESS_MAPPING_NOT_RUNTIME_VERIFIED'
                    WHEN h.live_state_confident=1 AND h.live_state IN ('BUSY','BUSY_UNKNOWN_USER') THEN 'INCONSISTENT_SUCCESS_ON_BUSY_LINE'
                    WHEN h.live_state_confident=1 AND h.live_state='AVAILABLE' THEN 'SUCCESS_MAPPING_VERIFIED_LINE_AVAILABLE'
                    WHEN h.live_state='UNKNOWN' THEN 'SUCCESS_MAPPING_VERIFIED_LINE_UNKNOWN'
                    ELSE 'SUCCESS_MAPPING_VERIFIED'
                END AS runtime_safety_status
            FROM connection_history h
            LEFT JOIN scan_runs s ON s.id=h.mapping_last_scan_id;

            DROP VIEW IF EXISTS v_target_trace;
            CREATE VIEW v_target_trace AS
            SELECT
                t.id AS target_id,
                t.oob_id,
                o.name AS current_oob_name,
                o.host AS current_oob_host,
                CASE WHEN o.connection_revision=o.baseline_revision AND (o.baseline_profile_fingerprint='' OR o.current_profile_fingerprint=o.baseline_profile_fingerprint) THEN 'VALID' ELSE 'STALE' END AS mapping_validity,
                t.alias, t.menu_name, t.menu_item, t.protocol,
                t.target_host, t.target_port, t.command,
                t.console_line, t.console_line_source,
                t.state, t.state_confident, t.state_reason_code, t.state_evidence,
                t.mapping_source_command, t.mapping_text_line, t.mapping_text_line_no,
                t.mapping_command_line, t.mapping_command_line_no,
                t.last_scan_id,
                s.status AS last_scan_status,
                s.mapping_quality AS last_mapping_quality,
                s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                s.vendor_at_scan, s.connection_revision AS scan_connection_revision,
                s.profile_fingerprint, s.config_snapshot_source,
                o.current_profile_fingerprint, o.baseline_profile_fingerprint
            FROM console_targets t
            JOIN oob_devices o ON o.id=t.oob_id
            LEFT JOIN scan_runs s ON s.id=t.last_scan_id;

            DROP VIEW IF EXISTS v_scan_command_audit;
            CREATE VIEW v_scan_command_audit AS
            SELECT
                r.id AS raw_output_id, r.scan_id, s.oob_id,
                s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                s.vendor_at_scan, s.status AS scan_status, s.mapping_quality,
                s.ssh_username_at_scan, s.trigger_source, s.process_hostname, s.process_user,
                s.ssh_host_key_algorithm, s.ssh_host_key_fingerprint, s.ssh_host_key_policy,
                r.command_name, r.command_text, r.is_core, r.redaction_applied, r.success,
                r.error_message, r.stored_output_length, r.stored_output_sha256, r.created_at
            FROM raw_outputs r
            JOIN scan_runs s ON s.id=r.scan_id;

            DROP VIEW IF EXISTS v_current_target_source_trace;
            CREATE VIEW v_current_target_source_trace AS
            SELECT
                t.id AS target_id, t.oob_id, t.alias AS configured_alias,
                t.menu_name, t.menu_item, t.protocol, t.target_host, t.target_port,
                t.console_line, t.console_line_source, t.state, t.state_confident,
                t.state_reason_code, t.state_evidence, t.last_scan_id,
                t.mapping_source_command, t.mapping_text_line, t.mapping_text_line_no,
                t.mapping_command_line, t.mapping_command_line_no,
                s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                s.vendor_at_scan, s.status AS scan_status, s.mapping_quality,
                s.baseline_updated, s.connection_revision AS scan_connection_revision,
                s.profile_fingerprint, s.profile_snapshot_json, s.scan_policy_snapshot_json,
                s.config_snapshot_source, s.ssh_host_key_algorithm, s.ssh_host_key_fingerprint, s.ssh_host_key_policy,
                r.id AS source_raw_output_id, r.command_name AS source_command_name,
                r.command_text AS source_command_text, r.success AS source_command_success,
                r.stored_output_length AS source_raw_length,
                r.stored_output_sha256 AS source_raw_sha256, r.created_at AS source_raw_created_at
            FROM console_targets t
            JOIN scan_runs s ON s.id=t.last_scan_id
            LEFT JOIN raw_outputs r
              ON r.scan_id=t.last_scan_id
             AND r.command_name='menu'
             AND r.command_text=t.mapping_source_command
             AND r.is_core=1
             AND r.success=1;

            DROP VIEW IF EXISTS v_snapshot_source_trace;
            CREATE VIEW v_snapshot_source_trace AS
            SELECT
                p.id AS snapshot_id, p.target_id, p.scan_id, p.oob_id,
                p.alias AS configured_alias, p.menu_name, p.menu_item, p.protocol,
                p.target_host, p.target_port, p.console_line, p.console_line_source,
                p.state, p.state_confident, p.state_reason_code, p.state_evidence,
                p.mapping_source_command, p.mapping_text_line, p.mapping_text_line_no,
                p.mapping_command_line, p.mapping_command_line_no, p.is_complete, p.captured_at,
                s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                s.vendor_at_scan, s.status AS scan_status, s.mapping_quality, s.baseline_updated,
                s.connection_revision AS scan_connection_revision, s.profile_fingerprint,
                s.profile_snapshot_json, s.scan_policy_snapshot_json,
                s.config_snapshot_source, s.ssh_host_key_algorithm,
                s.ssh_host_key_fingerprint, s.ssh_host_key_policy,
                r.id AS source_raw_output_id, r.command_name AS source_command_name,
                r.command_text AS source_command_text, r.success AS source_command_success,
                r.stored_output_length AS source_raw_length,
                r.stored_output_sha256 AS source_raw_sha256, r.created_at AS source_raw_created_at
            FROM console_snapshots p
            JOIN scan_runs s ON s.id=p.scan_id
            LEFT JOIN raw_outputs r
              ON r.scan_id=p.scan_id
             AND r.command_name='menu'
             AND r.command_text=p.mapping_source_command
             AND r.is_core=1
             AND r.success=1;


            DROP VIEW IF EXISTS v_current_device_identity;
            CREATE VIEW v_current_device_identity AS
            SELECT
                i.target_id, i.oob_id, o.name AS oob_name, o.host AS oob_host,
                t.menu_name, t.menu_item, t.target_host, t.target_port, t.console_line,
                i.configured_alias, i.actual_hostname, i.vendor AS device_vendor,
                i.platform_family, i.model, i.serial_number, i.software_version,
                i.identity_quality, i.identity_confidence, i.alias_comparison,
                i.source_evidence_json, i.verification_status, i.verification_severity,
                i.hardware_continuity, i.previous_identity_run_id, i.changed_fields,
                i.verification_reason_codes, i.verification_summary, i.identity_fingerprint,
                i.verification_source, i.last_identity_run_id, i.verified_at,
                r.collector_version, r.mapping_scan_id, r.oob_name_at_run, r.oob_host_at_run,
                r.oob_ssh_port_at_run, r.oob_vendor_at_run, r.oob_connection_mode_at_run,
                r.oob_connection_revision_at_run, r.oob_baseline_revision_at_run,
                r.oob_ssh_host_key_algorithm, r.oob_ssh_host_key_fingerprint,
                r.oob_ssh_host_key_policy,
                (SELECT COUNT(*) FROM device_identity_events e WHERE e.target_id=i.target_id) AS identity_event_count,
                (SELECT MAX(e.detected_at) FROM device_identity_events e WHERE e.target_id=i.target_id) AS last_identity_event_at,
                CASE WHEN o.connection_revision=o.baseline_revision
                          AND (o.baseline_profile_fingerprint='' OR o.current_profile_fingerprint=o.baseline_profile_fingerprint)
                     THEN 'VALID' ELSE 'STALE' END AS mapping_validity
            FROM device_identities i
            JOIN console_targets t ON t.id=i.target_id
            JOIN oob_devices o ON o.id=i.oob_id
            JOIN device_identity_runs r ON r.id=i.last_identity_run_id;

            DROP VIEW IF EXISTS v_device_identity_trace;
            CREATE VIEW v_device_identity_trace AS
            SELECT
                r.id AS identity_run_id, r.oob_id, r.target_id, r.mapping_scan_id,
                r.collector_version, r.oob_name_at_run, r.oob_host_at_run,
                r.oob_ssh_port_at_run, r.oob_vendor_at_run, r.oob_connection_mode_at_run,
                r.oob_connection_revision_at_run, r.oob_baseline_revision_at_run,
                r.started_at, r.finished_at, r.status, r.error_code, r.error_message,
                r.target_alias_at_run, r.target_command_at_run, r.target_protocol_at_run,
                r.target_host_at_run, r.target_port_at_run,
                r.menu_name_at_run, r.menu_item_at_run, r.console_line_at_run,
                r.oob_username, r.downstream_username, r.login_method, r.downstream_prompt,
                r.detected_vendor, r.identity_quality, r.identity_confidence,
                r.actual_hostname, r.platform_family, r.model, r.serial_number,
                r.software_version, r.alias_comparison, r.source_evidence_json,
                r.verification_status, r.verification_severity, r.hardware_continuity,
                r.previous_identity_run_id, r.changed_fields, r.verification_reason_codes,
                r.verification_summary, r.identity_fingerprint, r.previous_identity_fingerprint,
                r.verification_source,
                r.runtime_mapping_verified, r.runtime_mapping_verification_code,
                r.runtime_mapping_verification_message, r.live_state, r.live_state_confident,
                r.live_state_reason_code, r.live_state_evidence, r.live_state_checked_at,
                r.oob_ssh_host_key_algorithm, r.oob_ssh_host_key_fingerprint,
                r.oob_ssh_host_key_policy, r.process_hostname, r.process_user,
                s.status AS mapping_scan_status, s.mapping_quality AS mapping_scan_quality,
                s.baseline_updated AS mapping_scan_baseline_updated,
                s.oob_host_at_scan AS mapping_oob_host_at_scan,
                s.connection_revision AS mapping_scan_connection_revision,
                s.profile_fingerprint AS mapping_profile_fingerprint,
                (SELECT COUNT(*) FROM device_identity_raw_outputs x WHERE x.identity_run_id=r.id) AS raw_output_count,
                (SELECT COUNT(*) FROM device_identity_raw_outputs x WHERE x.identity_run_id=r.id AND x.success=1) AS successful_command_count,
                (SELECT COUNT(*) FROM device_identity_snapshots p WHERE p.identity_run_id=r.id) AS snapshot_count,
                (SELECT COUNT(*) FROM device_identity_events e WHERE e.identity_run_id=r.id) AS identity_event_count
            FROM device_identity_runs r
            LEFT JOIN scan_runs s ON s.id=r.mapping_scan_id;

            DROP VIEW IF EXISTS v_device_identity_events;
            CREATE VIEW v_device_identity_events AS
            SELECT
                e.id AS identity_event_id, e.identity_run_id, e.target_id, e.oob_id,
                o.name AS oob_name, r.target_alias_at_run AS configured_alias,
                r.actual_hostname, r.detected_vendor AS device_vendor, r.model, r.serial_number,
                r.verification_status, r.hardware_continuity,
                e.event_code, e.severity, e.field_name, e.old_value, e.new_value,
                e.reason, e.evidence_json, e.detected_at, e.viewed_at,
                r.mapping_scan_id, r.collector_version
            FROM device_identity_events e
            JOIN device_identity_runs r ON r.id=e.identity_run_id
            JOIN oob_devices o ON o.id=e.oob_id;

            DROP VIEW IF EXISTS v_data_quality_issues;
            CREATE VIEW v_data_quality_issues AS
            SELECT
                'BASELINE_UPDATED_WITH_UNACCEPTED_MAPPING' AS issue_code,
                'ERROR' AS severity,
                s.oob_id,
                s.id AS scan_id,
                NULL AS target_id,
                'baseline_updated=1 nhưng mapping_quality không phải ACCEPTED' AS message
            FROM scan_runs s
            WHERE s.baseline_updated=1 AND s.mapping_quality<>'ACCEPTED'
            UNION ALL
            SELECT
                'CURRENT_TARGET_FROM_NON_BASELINE_SCAN',
                'ERROR',
                t.oob_id,
                t.last_scan_id,
                t.id,
                'Current target trỏ tới scan không xác nhận baseline'
            FROM console_targets t
            LEFT JOIN scan_runs s ON s.id=t.last_scan_id
            WHERE s.id IS NULL OR s.baseline_updated<>1 OR s.mapping_quality<>'ACCEPTED'
            UNION ALL
            SELECT
                'INCOMPLETE_CURRENT_TARGET',
                'ERROR',
                t.oob_id,
                t.last_scan_id,
                t.id,
                'Current inventory chứa target core mapping chưa đầy đủ'
            FROM console_targets t
            WHERE t.is_complete<>1
            UNION ALL
            SELECT
                'ACCEPTED_SCAN_HAS_INCOMPLETE_TARGETS',
                'ERROR',
                s.oob_id,
                s.id,
                NULL,
                'mapping_quality=ACCEPTED nhưng complete_count khác mapping_count'
            FROM scan_runs s
            WHERE s.mapping_quality='ACCEPTED' AND s.complete_count<>s.mapping_count
            UNION ALL
            SELECT
                'CURRENT_TARGET_SCAN_OOB_MISMATCH',
                'ERROR',
                t.oob_id,
                t.last_scan_id,
                t.id,
                'Current target trỏ tới scan của OOB khác'
            FROM console_targets t
            JOIN scan_runs s ON s.id=t.last_scan_id
            WHERE s.oob_id<>t.oob_id
            UNION ALL
            SELECT
                'INVALID_CURRENT_TARGET_STATE',
                'ERROR',
                t.oob_id,
                t.last_scan_id,
                t.id,
                'Current target có state ngoài tập giá trị được hỗ trợ'
            FROM console_targets t
            WHERE t.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
            UNION ALL
            SELECT
                'STALE_CURRENT_MAPPING',
                'WARNING',
                o.id,
                NULL,
                NULL,
                COALESCE(NULLIF(o.baseline_stale_reason,''),'Current mapping chưa khớp connection/profile baseline')
            FROM oob_devices o
            WHERE EXISTS(SELECT 1 FROM console_targets t WHERE t.oob_id=o.id)
              AND (
                    o.connection_revision<>o.baseline_revision
                    OR (o.baseline_profile_fingerprint<>'' AND o.current_profile_fingerprint<>o.baseline_profile_fingerprint)
              )
            UNION ALL
            SELECT
                'SUCCESS_CONNECTION_WITHOUT_RUNTIME_MAPPING_VERIFICATION',
                'WARNING',
                h.oob_id,
                h.mapping_last_scan_id,
                h.target_id,
                'Phiên SUCCESS nhưng mapping chưa được xác minh lại ngay trước connect; đây có thể là lịch sử trước v1.1.4 hoặc profile legacy.'
            FROM connection_history h
            WHERE h.status='SUCCESS' AND h.runtime_mapping_verified<>1
            UNION ALL
            SELECT
                'SUCCESS_CONNECTION_ON_REPORTED_BUSY_LINE',
                'ERROR',
                h.oob_id,
                h.mapping_last_scan_id,
                h.target_id,
                'Phiên SUCCESS nhưng live pre-check ghi nhận line BUSY; dữ liệu hoặc workflow cần được điều tra.'
            FROM connection_history h
            WHERE h.status='SUCCESS'
              AND h.live_state_confident=1
              AND h.live_state IN ('BUSY','BUSY_UNKNOWN_USER');
            """
        )

    def _migrate_v11(self, conn: sqlite3.Connection) -> None:
        """Allow the audited Vertiv ACS CLI target protocol (v1.1.7).

        v7 introduced semantic write guards.  Recreate only the target/snapshot
        guards here so existing v10 databases can persist ``VERTIV_CLI`` while
        every previous state/confidence invariant remains unchanged.
        """
        conn.executescript(
            """
            DROP TRIGGER IF EXISTS trg_console_targets_validate_insert;
            CREATE TRIGGER trg_console_targets_validate_insert
            BEFORE INSERT ON console_targets
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','VERTIV_CLI','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_targets semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_targets_validate_update;
            CREATE TRIGGER trg_console_targets_validate_update
            BEFORE UPDATE ON console_targets
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','VERTIV_CLI','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_targets semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_snapshots_validate_insert;
            CREATE TRIGGER trg_console_snapshots_validate_insert
            BEFORE INSERT ON console_snapshots
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','VERTIV_CLI','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_snapshots semantic state');
            END;

            DROP TRIGGER IF EXISTS trg_console_snapshots_validate_update;
            CREATE TRIGGER trg_console_snapshots_validate_update
            BEFORE UPDATE ON console_snapshots
            WHEN NEW.state NOT IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER','UNKNOWN','INCOMPLETE')
              OR NEW.protocol NOT IN ('TELNET','SSH','VERTIV_CLI','OTHER','UNKNOWN')
              OR (NEW.state IN ('AVAILABLE','BUSY','BUSY_UNKNOWN_USER') AND NEW.state_confident<>1)
              OR (NEW.state='UNKNOWN' AND NEW.state_confident<>0)
              OR (NEW.state='BUSY' AND TRIM(NEW.session_user)='')
              OR (NEW.state='AVAILABLE' AND TRIM(NEW.session_user)<>'')
            BEGIN
                SELECT RAISE(ABORT, 'invalid console_snapshots semantic state');
            END;
            """
        )


    def _migrate_v12(self, conn: sqlite3.Connection) -> None:
        """Generalize scan locks into leased per-OOB operation locks (v1.1.8)."""
        self._add_column_if_missing(
            conn, "scan_locks", "operation", "TEXT NOT NULL DEFAULT 'SCAN'"
        )
        self._add_column_if_missing(
            conn, "scan_locks", "heartbeat_at", "TEXT NOT NULL DEFAULT ''"
        )
        self._add_column_if_missing(
            conn, "scan_locks", "expires_at", "TEXT NOT NULL DEFAULT ''"
        )
        # Old locks had no lease and could block a copied database forever. Mark
        # them expired so startup recovery can safely remove them. A currently
        # running pre-v1.1.8 process cannot coordinate with this schema anyway.
        conn.execute(
            """
            UPDATE scan_locks
            SET operation=COALESCE(NULLIF(operation,''),'SCAN'),
                heartbeat_at=COALESCE(NULLIF(heartbeat_at,''),started_at),
                expires_at=COALESCE(NULLIF(expires_at,''),started_at)
            """
        )


    def _migrate_v13(self, conn: sqlite3.Connection) -> None:
        """Historical compatibility hook.

        v1.1.19 used v13 to redact account identifiers.  v1.1.20 changes the
        audit policy: usernames are identities and must be retained.  Existing
        redaction markers cannot be reconstructed, so this migration is now
        intentionally non-destructive.
        """
        return

    def _migrate_v14(self, conn: sqlite3.Connection) -> None:
        """Local audit/safety hardening for v1.1.20."""
        connection_columns = {
            "safety_override_requested": "INTEGER NOT NULL DEFAULT 0",
            "safety_override_used": "INTEGER NOT NULL DEFAULT 0",
            "safety_override_reason": "TEXT NOT NULL DEFAULT ''",
            "session_log_path": "TEXT NOT NULL DEFAULT ''",
        }
        for name, definition in connection_columns.items():
            self._add_column_if_missing(conn, "connection_history", name, definition)

        # Only events created after the feature is installed should be presented
        # as "chưa xem".  When upgrading a v13 database, historical rows predate
        # the notification concept and may number in the thousands; mark those
        # rows viewed at migration time to avoid a misleading alert storm.
        change_viewed_added = self._add_column_if_missing(
            conn, "change_events", "viewed_at", "TEXT"
        )
        identity_viewed_added = self._add_column_if_missing(
            conn, "device_identity_events", "viewed_at", "TEXT"
        )
        migrated_at = to_db(utc_now())
        if change_viewed_added:
            conn.execute(
                "UPDATE change_events SET viewed_at=? WHERE viewed_at IS NULL",
                (migrated_at,),
            )
        if identity_viewed_added:
            conn.execute(
                "UPDATE device_identity_events SET viewed_at=? WHERE viewed_at IS NULL",
                (migrated_at,),
            )


    def _migrate_v15(self, conn: sqlite3.Connection) -> None:
        """Controlled OOB mapping reconciliation audit for v1.1.21."""
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS oob_reconciliation_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                oob_id INTEGER NOT NULL REFERENCES oob_devices(id) ON DELETE CASCADE,
                target_id INTEGER REFERENCES console_targets(id) ON DELETE SET NULL,
                identity_run_id INTEGER REFERENCES device_identity_runs(id) ON DELETE SET NULL,
                vendor TEXT NOT NULL,
                operator_username TEXT NOT NULL DEFAULT '',
                ticket_id TEXT NOT NULL DEFAULT '',
                reason TEXT NOT NULL DEFAULT '',
                old_alias TEXT NOT NULL DEFAULT '',
                new_alias TEXT NOT NULL DEFAULT '',
                physical_path TEXT NOT NULL DEFAULT '',
                proposed_commands TEXT NOT NULL DEFAULT '',
                applied_commands TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'RUNNING',
                started_at TEXT NOT NULL,
                finished_at TEXT,
                verification_code TEXT NOT NULL DEFAULT '',
                verification_message TEXT NOT NULL DEFAULT '',
                rollback_attempted INTEGER NOT NULL DEFAULT 0 CHECK(rollback_attempted IN (0,1)),
                rollback_succeeded INTEGER NOT NULL DEFAULT 0 CHECK(rollback_succeeded IN (0,1)),
                error_code TEXT NOT NULL DEFAULT '',
                error_message TEXT NOT NULL DEFAULT '',
                baseline_refresh_status TEXT NOT NULL DEFAULT 'NOT_RUN',
                process_pid INTEGER NOT NULL DEFAULT 0,
                process_hostname TEXT NOT NULL DEFAULT '',
                process_user TEXT NOT NULL DEFAULT ''
            )
            """
        )
        # Keep v15 idempotent for pre-release databases that may already have
        # the table without the final audit columns.
        self._add_column_if_missing(
            conn, "oob_reconciliation_history", "applied_commands",
            "TEXT NOT NULL DEFAULT ''",
        )


    def _migrate_v16(self, conn: sqlite3.Connection) -> None:
        """Controlled Cisco clear-line recovery audit for v1.1.22."""
        columns = {
            "clear_line_recovery_requested": "INTEGER NOT NULL DEFAULT 0 CHECK(clear_line_recovery_requested IN (0,1))",
            "clear_line_recovery_used": "INTEGER NOT NULL DEFAULT 0 CHECK(clear_line_recovery_used IN (0,1))",
            "clear_line_number": "INTEGER",
            "clear_line_reason": "TEXT NOT NULL DEFAULT ''",
            "clear_line_result": "TEXT NOT NULL DEFAULT ''",
        }
        for name, definition in columns.items():
            self._add_column_if_missing(conn, "connection_history", name, definition)

    @staticmethod
    def _table_exists(conn: sqlite3.Connection, table_name: str) -> bool:
        return conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
        ).fetchone() is not None

    def _migrate_v17(self, conn: sqlite3.Connection) -> None:
        """Quick A/B persistence tables are created idempotently by SCHEMA_SQL."""
        return None

    def _migrate_v18(self, conn: sqlite3.Connection) -> None:
        """Persist per-port runtime mapping/state evidence for Quick A/B."""
        columns = {
            "runtime_mapping_verified": "INTEGER NOT NULL DEFAULT 0 CHECK(runtime_mapping_verified IN (0,1))",
            "runtime_mapping_verification_code": "TEXT NOT NULL DEFAULT 'UNVERIFIED'",
            "runtime_mapping_verification_message": "TEXT NOT NULL DEFAULT ''",
            "live_state": "TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "live_state_confident": "INTEGER NOT NULL DEFAULT 0 CHECK(live_state_confident IN (0,1))",
            "live_state_reason_code": "TEXT NOT NULL DEFAULT ''",
            "live_state_evidence": "TEXT NOT NULL DEFAULT '{}'",
            "live_state_checked_at": "TEXT",
        }
        for name, definition in columns.items():
            self._add_column_if_missing(conn, "cable_check_results", name, definition)


    def _migrate_v19(self, conn: sqlite3.Connection) -> None:
        """Encrypted reusable credential profiles assigned to OOB devices."""
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS credential_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                username TEXT NOT NULL,
                secret_blob TEXT NOT NULL,
                protection_provider TEXT NOT NULL,
                vendor_scope TEXT NOT NULL DEFAULT 'ANY' CHECK(vendor_scope IN ('ANY','CISCO','VERTIV')),
                notes TEXT NOT NULL DEFAULT '',
                enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_used_at TEXT,
                last_test_status TEXT NOT NULL DEFAULT '',
                last_test_message TEXT NOT NULL DEFAULT ''
            )
            """
        )
        self._add_column_if_missing(
            conn, "oob_devices", "credential_profile_id",
            "INTEGER REFERENCES credential_profiles(id) ON DELETE SET NULL",
        )

    @staticmethod
    def _add_column_if_missing(
        conn: sqlite3.Connection,
        table_name: str,
        column_name: str,
        definition: str,
    ) -> bool:
        columns = {
            row["name"]
            for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall()
        }
        if column_name not in columns:
            conn.execute(
                f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"
            )
            return True
        return False
