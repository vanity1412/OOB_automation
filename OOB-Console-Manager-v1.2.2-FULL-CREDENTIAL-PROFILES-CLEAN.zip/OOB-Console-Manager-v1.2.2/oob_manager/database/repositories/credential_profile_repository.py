from __future__ import annotations
import sqlite3
from oob_manager.database.connection import DatabaseConnection
from oob_manager.exceptions import DatabaseError, ValidationError
from oob_manager.models import SessionCredentials
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.secret_protection import protect_mapping, unprotect_mapping


class CredentialProfileRepository:
    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def list_all(self, include_disabled: bool = True) -> list[dict]:
        sql = "SELECT id,name,username,protection_provider,vendor_scope,notes,enabled,created_at,updated_at,last_used_at,last_test_status,last_test_message FROM credential_profiles"
        if not include_disabled:
            sql += " WHERE enabled=1"
        sql += " ORDER BY name COLLATE NOCASE"
        with self.db.read() as conn:
            rows = [dict(r) for r in conn.execute(sql).fetchall()]
            for row in rows:
                row["assigned_oob_count"] = conn.execute("SELECT COUNT(*) FROM oob_devices WHERE credential_profile_id=?", (row["id"],)).fetchone()[0]
            return rows

    def get_meta(self, profile_id: int) -> dict | None:
        with self.db.read() as conn:
            row=conn.execute("SELECT id,name,username,protection_provider,vendor_scope,notes,enabled,created_at,updated_at,last_used_at,last_test_status,last_test_message FROM credential_profiles WHERE id=?",(profile_id,)).fetchone()
            return dict(row) if row else None

    def resolve(self, profile_id: int) -> SessionCredentials:
        with self.db.transaction() as conn:
            row=conn.execute("SELECT * FROM credential_profiles WHERE id=? AND enabled=1",(profile_id,)).fetchone()
            if not row:
                raise ValidationError("Credential profile không tồn tại hoặc đã tắt.", error_code="CREDENTIAL_PROFILE_UNAVAILABLE")
            secret=unprotect_mapping(row["protection_provider"], row["secret_blob"])
            conn.execute("UPDATE credential_profiles SET last_used_at=? WHERE id=?",(to_db(utc_now()),profile_id))
            return SessionCredentials(username=row["username"],password=secret.get("password", ""),enable_password=secret.get("enable_password") or None)

    def create(self, *, name: str, username: str, password: str, enable_password: str="", vendor_scope: str="ANY", notes: str="", enabled: bool=True) -> dict:
        name=name.strip(); username=username.strip(); vendor_scope=vendor_scope.strip().upper()
        if not name or not username or not password:
            raise ValidationError("Tên profile, username và password là bắt buộc.")
        if vendor_scope not in {"ANY","CISCO","VERTIV"}:
            raise ValidationError("Vendor scope không hợp lệ.")
        protected=protect_mapping({"password":password,"enable_password":enable_password})
        now=to_db(utc_now())
        try:
            with self.db.transaction() as conn:
                cur=conn.execute("INSERT INTO credential_profiles(name,username,secret_blob,protection_provider,vendor_scope,notes,enabled,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(name,username,protected.blob,protected.provider,vendor_scope,notes.strip(),int(enabled),now,now))
                pid=int(cur.lastrowid)
            return self.get_meta(pid)
        except sqlite3.IntegrityError as exc:
            raise DatabaseError("Tên credential profile đã tồn tại.") from exc

    def update(self, profile_id: int, *, name: str, username: str, password: str|None=None, enable_password: str|None=None, vendor_scope: str="ANY", notes: str="", enabled: bool=True) -> dict:
        current=self.get_meta(profile_id)
        if not current: raise ValidationError("Không tìm thấy credential profile.")
        name=name.strip(); username=username.strip(); vendor_scope=vendor_scope.strip().upper()
        if not name or not username: raise ValidationError("Tên profile và username là bắt buộc.")
        if vendor_scope not in {"ANY","CISCO","VERTIV"}: raise ValidationError("Vendor scope không hợp lệ.")
        with self.db.transaction() as conn:
            if password is not None and password != "":
                protected=protect_mapping({"password":password,"enable_password":enable_password or ""})
                conn.execute("UPDATE credential_profiles SET name=?,username=?,secret_blob=?,protection_provider=?,vendor_scope=?,notes=?,enabled=?,updated_at=? WHERE id=?",(name,username,protected.blob,protected.provider,vendor_scope,notes.strip(),int(enabled),to_db(utc_now()),profile_id))
            else:
                conn.execute("UPDATE credential_profiles SET name=?,username=?,vendor_scope=?,notes=?,enabled=?,updated_at=? WHERE id=?",(name,username,vendor_scope,notes.strip(),int(enabled),to_db(utc_now()),profile_id))
        return self.get_meta(profile_id)

    def delete(self, profile_id: int) -> None:
        with self.db.transaction() as conn:
            conn.execute("UPDATE oob_devices SET credential_profile_id=NULL WHERE credential_profile_id=?",(profile_id,))
            conn.execute("DELETE FROM credential_profiles WHERE id=?",(profile_id,))

    def record_test(self, profile_id: int, status: str, message: str) -> None:
        with self.db.transaction() as conn:
            conn.execute("UPDATE credential_profiles SET last_test_status=?,last_test_message=?,updated_at=? WHERE id=?",(status[:32],message[:1000],to_db(utc_now()),profile_id))
