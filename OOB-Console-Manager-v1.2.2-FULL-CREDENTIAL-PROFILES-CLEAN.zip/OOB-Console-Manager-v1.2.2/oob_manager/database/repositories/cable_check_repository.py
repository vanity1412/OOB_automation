from __future__ import annotations

import os
import socket
from collections.abc import Mapping

from oob_manager.database.connection import DatabaseConnection
from oob_manager.models import OOBDevice
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import current_process_user, sanitize_text


class CableCheckRepository:
    """Persist Quick A/B runs without promoting banner evidence to Full Identity."""

    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def start(self, device: OOBDevice, mapping_scan_id: int | None) -> int:
        with self.db.transaction() as conn:
            cur = conn.execute(
                """
                INSERT INTO cable_check_runs(
                    oob_id,mapping_scan_id,started_at,status,oob_name_at_run,vendor_at_run,
                    process_pid,process_hostname,process_user
                ) VALUES(?,?,?,?,?,?,?,?,?)
                """,
                (
                    device.id, mapping_scan_id, to_db(utc_now()), 'RUNNING',
                    sanitize_text(device.name), sanitize_text(device.vendor), os.getpid(),
                    socket.gethostname(), current_process_user(),
                ),
            )
            return int(cur.lastrowid)

    def record(self, run_id: int, oob_id: int, row: Mapping[str, object]) -> None:
        status = str(row.get('status', '') or '').upper()
        if status not in {'MATCH','MISMATCH','NO_HOSTNAME','SKIP/ERROR'}:
            status = 'SKIP/ERROR'
        target_id = row.get('target_id')
        with self.db.transaction() as conn:
            conn.execute(
                """
                INSERT INTO cable_check_results(
                    run_id,target_id,oob_id,target_alias,port,console_path,device_a,device_b,status,
                    evidence_source,wake_count,passive_wait_used,
                    runtime_mapping_verified,runtime_mapping_verification_code,
                    runtime_mapping_verification_message,live_state,live_state_confident,
                    live_state_reason_code,live_state_evidence,live_state_checked_at,
                    error_code,message,detected_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(run_id,target_id) DO UPDATE SET
                    target_alias=excluded.target_alias,port=excluded.port,console_path=excluded.console_path,
                    device_a=excluded.device_a,device_b=excluded.device_b,status=excluded.status,
                    evidence_source=excluded.evidence_source,wake_count=excluded.wake_count,
                    passive_wait_used=excluded.passive_wait_used,
                    runtime_mapping_verified=excluded.runtime_mapping_verified,
                    runtime_mapping_verification_code=excluded.runtime_mapping_verification_code,
                    runtime_mapping_verification_message=excluded.runtime_mapping_verification_message,
                    live_state=excluded.live_state,live_state_confident=excluded.live_state_confident,
                    live_state_reason_code=excluded.live_state_reason_code,
                    live_state_evidence=excluded.live_state_evidence,
                    live_state_checked_at=excluded.live_state_checked_at,
                    error_code=excluded.error_code,message=excluded.message,detected_at=excluded.detected_at
                """,
                (
                    run_id, int(target_id) if target_id is not None else None, int(oob_id),
                    sanitize_text(str(row.get('target_alias', '') or row.get('device_a', '') or '')),
                    sanitize_text(str(row.get('port', '') or '')),
                    sanitize_text(str(row.get('console_path', '') or '')),
                    sanitize_text(str(row.get('device_a', '') or '')),
                    sanitize_text(str(row.get('device_b', '') or '')), status,
                    sanitize_text(str(row.get('evidence_source', '') or '')),
                    max(0, int(row.get('wake_count', 0) or 0)),
                    int(bool(row.get('passive_wait_used', False))),
                    int(bool(row.get('runtime_mapping_verified', False))),
                    sanitize_text(str(row.get('runtime_mapping_verification_code', '') or 'UNVERIFIED')),
                    sanitize_text(str(row.get('runtime_mapping_verification_message', '') or '')),
                    sanitize_text(str(row.get('live_state', '') or 'UNKNOWN')),
                    int(bool(row.get('live_state_confident', False))),
                    sanitize_text(str(row.get('live_state_reason_code', '') or '')),
                    sanitize_text(str(row.get('live_state_evidence', '') or '{}')),
                    sanitize_text(str(row.get('live_state_checked_at', '') or '')) or None,
                    sanitize_text(str(row.get('error_code', '') or '')),
                    sanitize_text(str(row.get('message', '') or '')),
                    to_db(utc_now()),
                ),
            )

    def finish(self, run_id: int, *, status: str | None = None, error_code: str = '', error_message: str = '') -> None:
        with self.db.transaction() as conn:
            counts = {row['status']: int(row['c']) for row in conn.execute(
                'SELECT status, COUNT(*) AS c FROM cable_check_results WHERE run_id=? GROUP BY status',
                (run_id,),
            ).fetchall()}
            total = sum(counts.values())
            final = status
            if final is None:
                final = (
                    'PARTIAL'
                    if counts.get('SKIP/ERROR', 0) or counts.get('NO_HOSTNAME', 0)
                    else 'SUCCESS'
                )
                if total == 0:
                    final = 'FAILED'
            conn.execute(
                """
                UPDATE cable_check_runs SET finished_at=?,status=?,total_count=?,match_count=?,
                    mismatch_count=?,no_hostname_count=?,skip_error_count=?,error_code=?,error_message=?
                WHERE id=?
                """,
                (
                    to_db(utc_now()), final, total, counts.get('MATCH',0), counts.get('MISMATCH',0),
                    counts.get('NO_HOSTNAME',0), counts.get('SKIP/ERROR',0),
                    sanitize_text(error_code), sanitize_text(error_message), run_id,
                ),
            )

    def recover_abandoned_same_host(self) -> int:
        hostname = socket.gethostname()
        with self.db.read() as conn:
            rows = conn.execute(
                "SELECT id,process_pid FROM cable_check_runs WHERE status='RUNNING' AND process_hostname=?",
                (hostname,),
            ).fetchall()
        stale: list[int] = []
        for row in rows:
            pid = int(row['process_pid'] or 0)
            if pid <= 0 or pid == os.getpid():
                stale.append(int(row['id']))
                continue
            try:
                os.kill(pid, 0)
            except OSError:
                stale.append(int(row['id']))
        if not stale:
            return 0
        with self.db.transaction() as conn:
            for run_id in stale:
                conn.execute(
                    """UPDATE cable_check_runs SET status='ABANDONED',finished_at=?,
                       error_code='PROCESS_INTERRUPTED',error_message='Quick A/B process ended before run completion.'
                       WHERE id=? AND status='RUNNING'""",
                    (to_db(utc_now()), run_id),
                )
        return len(stale)


    def list_run_summaries(self, limit: int = 100, oob_id: int | None = None):
        """Return Quick A/B run summaries with the source live-scan audit fields."""
        where = 'WHERE r.oob_id=?' if oob_id is not None else ''
        safe_limit = max(1, min(int(limit), 1000))
        args = (int(oob_id), safe_limit) if oob_id is not None else (safe_limit,)
        with self.db.read() as conn:
            return conn.execute(
                f"""
                SELECT r.*,
                       s.status AS scan_status, s.mapping_quality, s.mapping_count,
                       s.complete_count, s.warning_count, s.baseline_updated,
                       s.trigger_source, s.started_at AS scan_started_at,
                       s.finished_at AS scan_finished_at
                FROM cable_check_runs r
                LEFT JOIN scan_runs s ON s.id=r.mapping_scan_id
                {where}
                ORDER BY r.started_at DESC, r.id DESC LIMIT ?
                """,
                args,
            ).fetchall()

    def list_results_for_run(self, run_id: int):
        """Return every target result for one Quick A/B run in physical-port order."""
        with self.db.read() as conn:
            return conn.execute(
                """
                SELECT x.*, r.status AS run_status, r.mapping_scan_id,
                       r.started_at, r.finished_at, r.oob_name_at_run, r.vendor_at_run
                FROM cable_check_results x
                JOIN cable_check_runs r ON r.id=x.run_id
                WHERE x.run_id=?
                ORDER BY
                    CASE WHEN CAST(x.port AS INTEGER) GLOB '[0-9]*' THEN CAST(x.port AS INTEGER) ELSE 2147483647 END,
                    x.port COLLATE NOCASE, x.id
                """,
                (int(run_id),),
            ).fetchall()

    def list_recent(self, limit: int = 200, oob_id: int | None = None):
        where = 'WHERE r.oob_id=?' if oob_id is not None else ''
        args = (int(oob_id), max(1, min(int(limit), 1000))) if oob_id is not None else (max(1, min(int(limit), 1000)),)
        with self.db.read() as conn:
            return conn.execute(
                f"""
                SELECT x.*, r.status AS run_status, r.started_at, r.finished_at, r.oob_name_at_run, r.vendor_at_run
                FROM cable_check_results x
                JOIN cable_check_runs r ON r.id=x.run_id
                {where}
                ORDER BY x.detected_at DESC, x.id DESC LIMIT ?
                """,
                args,
            ).fetchall()
