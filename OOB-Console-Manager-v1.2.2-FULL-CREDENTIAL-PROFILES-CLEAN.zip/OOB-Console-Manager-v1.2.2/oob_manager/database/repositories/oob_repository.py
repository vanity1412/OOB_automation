"""Repository inventory OOB."""
from __future__ import annotations

from contextlib import nullcontext
import json
import os
import socket
import sqlite3

from oob_manager.database.connection import DatabaseConnection
from oob_manager.exceptions import DatabaseError
from oob_manager.models.oob_device import OOBDevice
from oob_manager.utils.datetime_utils import from_db, to_db, utc_now
from oob_manager.utils.security import current_process_user
from oob_manager.utils.validation import is_valid_host, normalize_host


class OOBRepository:
    """Persistence cho OOB và revision của mapping/baseline."""

    IDENTITY_FIELDS = ("host", "ssh_port", "vendor", "connection_mode")

    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    @staticmethod
    def _map(row: sqlite3.Row) -> OOBDevice:
        return OOBDevice(
            id=row["id"],
            name=row["name"],
            host=row["host"],
            ssh_port=row["ssh_port"],
            vendor=row["vendor"],
            device_type=row["device_type"],
            default_username=row["default_username"] or "",
            credential_profile_id=row["credential_profile_id"] if "credential_profile_id" in row.keys() else None,
            connection_mode=row["connection_mode"],
            enabled=bool(row["enabled"]),
            notes=row["notes"],
            created_at=from_db(row["created_at"]),
            updated_at=from_db(row["updated_at"]),
            last_scan_at=from_db(row["last_scan_at"]),
            connection_revision=row["connection_revision"],
            baseline_revision=row["baseline_revision"],
            baseline_stale_reason=row["baseline_stale_reason"],
            baseline_stale_at=from_db(row["baseline_stale_at"]),
            current_profile_fingerprint=row["current_profile_fingerprint"],
            baseline_profile_fingerprint=row["baseline_profile_fingerprint"],
        )

    def create(self, device: OOBDevice) -> OOBDevice:
        try:
            with self.db.transaction() as conn:
                cursor = conn.execute(
                    """
                    INSERT INTO oob_devices(
                        name, host, ssh_port, vendor, device_type,
                        default_username, credential_profile_id, connection_mode, enabled, notes,
                        created_at, updated_at, last_scan_at,
                        connection_revision, baseline_revision,
                        baseline_stale_reason, baseline_stale_at,
                        current_profile_fingerprint, baseline_profile_fingerprint
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        device.name,
                        device.host,
                        device.ssh_port,
                        device.vendor,
                        device.device_type,
                        device.default_username,
                        device.credential_profile_id,
                        device.connection_mode,
                        int(device.enabled),
                        device.notes,
                        to_db(device.created_at),
                        to_db(device.updated_at),
                        to_db(device.last_scan_at),
                        device.connection_revision,
                        device.baseline_revision,
                        device.baseline_stale_reason,
                        to_db(device.baseline_stale_at),
                        device.current_profile_fingerprint,
                        device.baseline_profile_fingerprint,
                    ),
                )
                device.id = int(cursor.lastrowid)
                self._record_raw_change(
                    conn,
                    oob_id=device.id,
                    oob_name=device.name,
                    change_type="OOB_CREATED",
                    changed_fields=["created"],
                    old_payload={},
                    new_payload=self._audit_payload(device),
                )
            return device
        except sqlite3.IntegrityError as exc:
            raise DatabaseError("Tên OOB hoặc host/cổng đã tồn tại.") from exc

    def get(self, oob_id: int) -> OOBDevice | None:
        with self.db.read() as conn:
            row = conn.execute(
                "SELECT * FROM oob_devices WHERE id=?",
                (oob_id,),
            ).fetchone()
            return self._map(row) if row else None

    def list_all(self, *, include_disabled: bool = True) -> list[OOBDevice]:
        sql = "SELECT * FROM oob_devices"
        if not include_disabled:
            sql += " WHERE enabled=1"
        sql += " ORDER BY name COLLATE NOCASE"
        with self.db.read() as conn:
            return [self._map(row) for row in conn.execute(sql).fetchall()]

    def update(self, device: OOBDevice) -> OOBDevice:
        """Cập nhật OOB và invalidate baseline nếu identity/connectivity đổi.

        Việc tăng revision nằm ở repository để mọi caller đều được bảo vệ, không chỉ CLI.
        """
        if device.id is None:
            raise DatabaseError("OOB chưa có ID.")
        now = utc_now()
        device.updated_at = now
        try:
            with self.db.transaction() as conn:
                existing_row = conn.execute(
                    "SELECT * FROM oob_devices WHERE id=?", (device.id,)
                ).fetchone()
                if not existing_row:
                    raise DatabaseError("Không tìm thấy OOB cần cập nhật.")
                existing = self._map(existing_row)
                changed_fields: list[str] = []
                tracked_fields = (
                    "name", "host", "ssh_port", "vendor", "device_type",
                    "default_username", "credential_profile_id", "connection_mode", "enabled", "notes",
                )
                for field in tracked_fields:
                    old_value = getattr(existing, field)
                    new_value = getattr(device, field)
                    if field == "host" and isinstance(old_value, str) and isinstance(new_value, str):
                        if is_valid_host(old_value) and is_valid_host(new_value):
                            changed = normalize_host(old_value) != normalize_host(new_value)
                        else:
                            changed = old_value.casefold() != new_value.casefold()
                    else:
                        changed = old_value != new_value
                    if changed:
                        changed_fields.append(field)
                changed_identity_fields = [field for field in changed_fields if field in self.IDENTITY_FIELDS]

                connection_revision = existing.connection_revision
                baseline_revision = existing.baseline_revision
                stale_reason = existing.baseline_stale_reason
                stale_at = existing.baseline_stale_at
                if changed_identity_fields:
                    connection_revision += 1
                    stale_reason = "OOB connection settings changed: " + ", ".join(
                        changed_identity_fields
                    )
                    stale_at = now

                cursor = conn.execute(
                    """
                    UPDATE oob_devices
                    SET name=?, host=?, ssh_port=?, vendor=?, device_type=?,
                        default_username=?, credential_profile_id=?, connection_mode=?, enabled=?, notes=?,
                        updated_at=?, connection_revision=?, baseline_revision=?,
                        baseline_stale_reason=?, baseline_stale_at=?,
                        current_profile_fingerprint=?, baseline_profile_fingerprint=?
                    WHERE id=?
                    """,
                    (
                        device.name,
                        device.host,
                        device.ssh_port,
                        device.vendor,
                        device.device_type,
                        device.default_username,
                        device.credential_profile_id,
                        device.connection_mode,
                        int(device.enabled),
                        device.notes,
                        to_db(device.updated_at),
                        connection_revision,
                        baseline_revision,
                        stale_reason,
                        to_db(stale_at),
                        existing.current_profile_fingerprint,
                        existing.baseline_profile_fingerprint,
                        device.id,
                    ),
                )
                if cursor.rowcount != 1:
                    raise DatabaseError("Không tìm thấy OOB cần cập nhật.")

                device.connection_revision = connection_revision
                device.baseline_revision = baseline_revision
                device.baseline_stale_reason = stale_reason
                device.baseline_stale_at = stale_at
                device.current_profile_fingerprint = existing.current_profile_fingerprint
                device.baseline_profile_fingerprint = existing.baseline_profile_fingerprint
                if changed_fields:
                    self._record_change(
                        conn, existing, device, "OOB_SETTINGS_CHANGED", changed_fields
                    )
            return device
        except sqlite3.IntegrityError as exc:
            raise DatabaseError("Tên OOB hoặc host/cổng đã tồn tại.") from exc

    def get_connection_revision(
        self,
        oob_id: int,
        *,
        conn: sqlite3.Connection | None = None,
    ) -> int:
        manager = nullcontext(conn) if conn is not None else self.db.read()
        with manager as active_conn:
            assert active_conn is not None
            row = active_conn.execute(
                "SELECT connection_revision FROM oob_devices WHERE id=?", (oob_id,)
            ).fetchone()
            if not row:
                raise DatabaseError("Không tìm thấy OOB.")
            return int(row["connection_revision"])

    def get_mapping_context(
        self,
        oob_id: int,
        *,
        conn: sqlite3.Connection | None = None,
    ) -> tuple[int, str]:
        """Lấy revision + profile fingerprint trong cùng transaction persistence."""
        manager = nullcontext(conn) if conn is not None else self.db.read()
        with manager as active_conn:
            assert active_conn is not None
            row = active_conn.execute(
                "SELECT connection_revision, current_profile_fingerprint FROM oob_devices WHERE id=?",
                (oob_id,),
            ).fetchone()
            if not row:
                raise DatabaseError("Không tìm thấy OOB.")
            return int(row["connection_revision"]), str(row["current_profile_fingerprint"] or "")

    def mark_baseline_current(
        self,
        oob_id: int,
        expected_revision: int,
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        """Xác nhận baseline chỉ khi scan thuộc đúng revision cấu hình hiện tại."""
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            cursor = active_conn.execute(
                """
                UPDATE oob_devices
                SET baseline_revision=connection_revision,
                    baseline_profile_fingerprint=current_profile_fingerprint,
                    baseline_stale_reason='', baseline_stale_at=NULL,
                    updated_at=?
                WHERE id=? AND connection_revision=?
                """,
                (to_db(utc_now()), oob_id, expected_revision),
            )
            if cursor.rowcount != 1:
                raise DatabaseError(
                    "Cấu hình OOB đã thay đổi trong lúc scan; không thể xác nhận baseline."
                )

    def sync_profile_fingerprint(self, oob_id: int, fingerprint: str) -> OOBDevice:
        """Đồng bộ fingerprint profile; profile đổi sẽ làm baseline STALE mà không xóa history."""
        with self.db.transaction() as conn:
            row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
            if not row:
                raise DatabaseError("Không tìm thấy OOB.")
            existing = self._map(row)
            current = existing.current_profile_fingerprint
            if current != fingerprint:
                now = utc_now()
                # Lần sync đầu của OOB mới chỉ ghi fingerprint hiện tại. Nếu đã có
                # baseline legacy/accepted thì fingerprint khác phải fail-closed.
                has_baseline_profile = bool(existing.baseline_profile_fingerprint)
                restored_to_baseline = bool(
                    has_baseline_profile
                    and fingerprint == existing.baseline_profile_fingerprint
                    and existing.connection_revision == existing.baseline_revision
                )
                if restored_to_baseline:
                    reason = ""
                    stale_at = None
                elif current or has_baseline_profile:
                    reason = "Vendor profile changed; rescan required"
                    stale_at = now
                else:
                    reason = existing.baseline_stale_reason
                    stale_at = existing.baseline_stale_at
                conn.execute(
                    """UPDATE oob_devices
                       SET current_profile_fingerprint=?, baseline_stale_reason=?,
                           baseline_stale_at=?, updated_at=? WHERE id=?""",
                    (fingerprint, reason, to_db(stale_at), to_db(now), oob_id),
                )
                updated_row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
                updated = self._map(updated_row)
                self._record_change(
                    conn, existing, updated,
                    "PROFILE_FINGERPRINT_CHANGED" if current or has_baseline_profile else "PROFILE_FINGERPRINT_INITIALIZED",
                    ["current_profile_fingerprint"],
                )
                return updated
            return existing

    def mark_mapping_reconciliation_pending(
        self, oob_id: int, *, old_alias: str, new_alias: str, physical_path: str
    ) -> OOBDevice:
        """Invalidate the current baseline after a verified write to the OOB.

        A successful reconciliation changes device configuration outside the last
        accepted scan. Incrementing ``connection_revision`` makes every console
        operation fail closed until a fresh scan reads the new mapping and marks
        the baseline current again.
        """
        with self.db.transaction() as conn:
            row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
            if not row:
                raise DatabaseError("Không tìm thấy OOB.")
            old = self._map(row)
            now = utc_now()
            new_revision = int(old.connection_revision) + 1
            reason = (
                f"CONTROLLED_RECONCILIATION: requested alias on {physical_path}: "
                f"{old_alias} -> {new_alias}; baseline invalidated before device write; rescan required"
            )
            conn.execute(
                """
                UPDATE oob_devices
                SET connection_revision=?, baseline_stale_reason=?, baseline_stale_at=?, updated_at=?
                WHERE id=?
                """,
                (new_revision, reason, to_db(now), to_db(now), oob_id),
            )
            updated_row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
            updated = self._map(updated_row)
            self._record_change(
                conn, old, updated, "OOB_MAPPING_RECONCILED",
                ["connection_revision", "baseline_stale_reason"],
            )
            return updated

    @staticmethod
    def _audit_payload(device: OOBDevice) -> dict[str, object]:
        return {
            "name": device.name, "host": device.host, "ssh_port": device.ssh_port,
            "vendor": device.vendor, "device_type": device.device_type,
            "connection_mode": device.connection_mode, "enabled": device.enabled,
            "default_username": device.default_username, "notes": device.notes,
            "connection_revision": device.connection_revision,
            "baseline_revision": device.baseline_revision,
            "current_profile_fingerprint": device.current_profile_fingerprint,
            "baseline_profile_fingerprint": device.baseline_profile_fingerprint,
        }

    @classmethod
    def _record_change(
        cls, conn: sqlite3.Connection, old: OOBDevice, new: OOBDevice,
        change_type: str, changed_fields: list[str],
    ) -> None:
        cls._record_raw_change(
            conn,
            oob_id=new.id or old.id,
            oob_name=new.name or old.name,
            change_type=change_type,
            changed_fields=changed_fields,
            old_payload=cls._audit_payload(old),
            new_payload=cls._audit_payload(new),
        )

    @staticmethod
    def _record_raw_change(
        conn: sqlite3.Connection,
        *,
        oob_id: int | None,
        oob_name: str,
        change_type: str,
        changed_fields: list[str],
        old_payload: dict[str, object],
        new_payload: dict[str, object],
    ) -> None:
        conn.execute(
            """INSERT INTO oob_change_history(
                oob_id,oob_name,changed_at,change_type,changed_fields,old_data,new_data,
                source,process_pid,process_hostname,process_user
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (
                oob_id, oob_name, to_db(utc_now()), change_type,
                ",".join(changed_fields),
                json.dumps(old_payload, ensure_ascii=False, sort_keys=True),
                json.dumps(new_payload, ensure_ascii=False, sort_keys=True),
                "repository", os.getpid(), socket.gethostname(), current_process_user(),
            ),
        )

    def update_last_scan(
        self,
        oob_id: int,
        when,
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            active_conn.execute(
                """
                UPDATE oob_devices
                SET last_scan_at=?, updated_at=?
                WHERE id=?
                """,
                (to_db(when), to_db(utc_now()), oob_id),
            )

    def disable(self, oob_id: int) -> None:
        with self.db.transaction() as conn:
            row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
            if not row:
                raise DatabaseError("Không tìm thấy OOB.")
            old = self._map(row)
            conn.execute(
                "UPDATE oob_devices SET enabled=0, updated_at=? WHERE id=?",
                (to_db(utc_now()), oob_id),
            )
            updated = self._map(
                conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
            )
            if old.enabled != updated.enabled:
                self._record_change(conn, old, updated, "OOB_DISABLED", ["enabled"])

    def related_counts(self, oob_id: int) -> dict[str, int]:
        queries = {
            "scan_runs": "SELECT COUNT(*) FROM scan_runs WHERE oob_id=?",
            "raw_outputs": """
                SELECT COUNT(*) FROM raw_outputs
                WHERE scan_id IN (SELECT id FROM scan_runs WHERE oob_id=?)
            """,
            "console_targets": "SELECT COUNT(*) FROM console_targets WHERE oob_id=?",
            "console_snapshots": "SELECT COUNT(*) FROM console_snapshots WHERE oob_id=?",
            "change_events": "SELECT COUNT(*) FROM change_events WHERE oob_id=?",
            "connection_history": "SELECT COUNT(*) FROM connection_history WHERE oob_id=?",
            "oob_change_history": "SELECT COUNT(*) FROM oob_change_history WHERE oob_id=?",
        }
        with self.db.read() as conn:
            return {
                name: int(conn.execute(sql, (oob_id,)).fetchone()[0])
                for name, sql in queries.items()
            }

    def hard_delete(self, oob_id: int) -> None:
        with self.db.transaction() as conn:
            row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
            if not row:
                raise DatabaseError("Không tìm thấy OOB.")
            device = self._map(row)
            self._record_raw_change(
                conn,
                oob_id=oob_id,
                oob_name=device.name,
                change_type="OOB_HARD_DELETED",
                changed_fields=["deleted"],
                old_payload=self._audit_payload(device),
                new_payload={},
            )
            conn.execute("DELETE FROM oob_devices WHERE id=?", (oob_id,))
