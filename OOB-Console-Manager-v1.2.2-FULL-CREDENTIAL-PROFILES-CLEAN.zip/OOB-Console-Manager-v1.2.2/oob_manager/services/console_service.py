"""Workflow mở phiên console và lưu metadata kết nối có thể audit."""
from __future__ import annotations

import inspect
import re

from oob_manager.config import profile_fingerprint
from oob_manager.exceptions import ValidationError
from oob_manager.models import PortAuthenticationCredentials
from oob_manager.utils.security import sanitize_text
from oob_manager.utils.paths import SESSION_LOG_DIR
from oob_manager.utils.datetime_utils import utc_now
from oob_manager.utils.validation import is_valid_host
from oob_manager.vendors.factory import create_vendor_adapter


class ConsoleService:
    def __init__(
        self,
        oob_repo,
        target_repo,
        connection_repo,
        settings,
        lock_repo=None,
        adapter_factory=create_vendor_adapter,
    ) -> None:
        self.oob_repo = oob_repo
        self.target_repo = target_repo
        self.connection_repo = connection_repo
        self.settings = settings
        self.lock_repo = lock_repo
        self.adapter_factory = adapter_factory

    def open(
        self,
        target_id,
        credentials,
        *,
        port_credentials: PortAuthenticationCredentials | None = None,
        allow_unverified_state: bool = False,
        override_reason: str = "",
        clear_line_recovery_callback=None,
        serial_port_password_callback=None,
        terminal_bridge_factory=None,
    ) -> None:
        override_reason = str(override_reason or "").strip()
        if allow_unverified_state and not override_reason:
            raise ValidationError(
                "Override trạng thái UNKNOWN bắt buộc phải có lý do để lưu audit.",
                error_code="UNKNOWN_OVERRIDE_REASON_REQUIRED",
            )
        if len(override_reason) > 1000:
            raise ValidationError(
                "Lý do override tối đa 1000 ký tự.",
                error_code="UNKNOWN_OVERRIDE_REASON_TOO_LONG",
            )

        target = self.target_repo.get(target_id)
        if not target:
            raise ValidationError("Không tìm thấy target.")
        if not target.is_complete:
            raise ValidationError(
                "Không thể mở console tự động vì dữ liệu target chưa đầy đủ."
            )

        device = self.oob_repo.get(target.oob_id)
        if not device or not device.enabled:
            raise ValidationError("OOB không tồn tại hoặc đang bị vô hiệu hóa.")

        if device.vendor == "CISCO":
            if target.protocol != "TELNET":
                raise ValidationError(
                    "Cisco target không phải reverse-Telnet được hỗ trợ."
                )
            if not is_valid_host(target.target_host):
                raise ValidationError("Target host không hợp lệ; từ chối mở console.")
            if not isinstance(target.target_port, int) or not 1 <= target.target_port <= 65535:
                raise ValidationError("Target port không hợp lệ; từ chối mở console.")
            if target.menu_item is not None and (
                not isinstance(target.menu_item, int) or target.menu_item <= 0
            ):
                raise ValidationError("Menu item không hợp lệ; từ chối mở console.")
        elif device.vendor == "VERTIV":
            if target.protocol != "VERTIV_CLI":
                raise ValidationError(
                    "Vertiv target không phải ACS CLI access port được hỗ trợ."
                )
            if not isinstance(target.console_line, int) or target.console_line <= 0:
                raise ValidationError("Vertiv serial port không hợp lệ; từ chối mở console.")
        else:
            raise ValidationError(
                f"Vendor {device.vendor} chưa hỗ trợ mở console tự động."
            )

        adapter = self.adapter_factory(device, self.settings)
        if terminal_bridge_factory is not None:
            setattr(adapter, "terminal_bridge_factory", terminal_bridge_factory)
        setattr(adapter, "allow_unverified_state", bool(allow_unverified_state))
        setattr(adapter, "clear_line_recovery_callback", clear_line_recovery_callback)
        runtime_secret_values: list[str] = [
            credentials.password,
            credentials.enable_password or "",
        ]

        if callable(serial_port_password_callback):
            def _serial_password_callback(context=None):
                value = serial_port_password_callback(context or {})
                password = str(value or "")
                if password:
                    runtime_secret_values.append(password)
                return password

            setattr(adapter, "serial_port_password_callback", _serial_password_callback)
        runtime_profile = getattr(adapter, "profile", None)
        if isinstance(runtime_profile, dict):
            device = self.oob_repo.sync_profile_fingerprint(
                device.id,
                profile_fingerprint(runtime_profile),
            )
        if device.mapping_stale:
            raise ValidationError(
                "Mapping console đã cũ do cấu hình kết nối OOB/profile thay đổi. "
                "Cần scan lại OOB với mapping đủ tin cậy trước khi mở console.",
                error_code="STALE_MAPPING",
            )

        provenance_ok, provenance_code, provenance_message = (
            self.target_repo.verify_open_provenance(target_id)
        )
        if not provenance_ok:
            raise ValidationError(
                provenance_message
                + " Tool từ chối mở console để tránh dùng mapping không truy vết được; cần scan lại OOB.",
                error_code=provenance_code or "MAPPING_PROVENANCE_INVALID",
            )

        port_credentials = port_credentials or PortAuthenticationCredentials()
        runtime_secret_values.extend(
            [
                port_credentials.resolved_password(credentials.password),
                port_credentials.resolved_direct_password(credentials.password),
            ]
        )
        secret_values = tuple(runtime_secret_values)
        lease = (
            self.lock_repo.start_lease(device.id, "CONSOLE")
            if self.lock_repo is not None
            else None
        )
        try:
            connection_id = self.connection_repo.start(
                device.id,
                target,
                credentials.username,
                device=device,
                safety_override_requested=bool(allow_unverified_state),
                safety_override_reason=sanitize_text(override_reason, secret_values),
            )
        except Exception:
            if lease is not None:
                lease.close(raise_on_heartbeat_error=False)
            raise

        local_day = utc_now().astimezone().strftime("%Y-%m-%d")
        alias_slug = re.sub(r"[^A-Za-z0-9._-]+", "_", str(target.alias or "target")).strip("._-") or "target"
        alias_slug = alias_slug[:80]
        session_log_path = (
            SESSION_LOG_DIR / local_day / f"conn_{connection_id}_{alias_slug}.log"
        )
        session_log_path.parent.mkdir(parents=True, exist_ok=True)
        setattr(adapter, "session_log_path", session_log_path)
        set_log_path = getattr(self.connection_repo, "set_session_log_path", None)
        if callable(set_log_path):
            set_log_path(
                connection_id,
                f"session_logs/{local_day}/conn_{connection_id}_{alias_slug}.log",
            )

        setattr(
            adapter,
            "transport_audit_callback",
            lambda algorithm, fingerprint, policy: self.connection_repo.update_ssh_host_key(
                connection_id, algorithm, fingerprint, policy
            ),
        )
        try:
            open_method = adapter.open_console
            if "port_credentials" in inspect.signature(open_method).parameters:
                result = open_method(
                    device,
                    target,
                    credentials,
                    port_credentials=port_credentials,
                )
            else:
                result = open_method(device, target, credentials)
            if lease is not None:
                lease.ensure_owned()
            audit_secrets = tuple(runtime_secret_values)
            self.connection_repo.finish(
                connection_id,
                "SUCCESS",
                console_path_verified=bool(getattr(result, "console_path_verified", False)),
                path_verification_code=sanitize_text(
                    getattr(result, "path_verification_code", "UNVERIFIED"), audit_secrets
                ),
                path_verification_message=sanitize_text(
                    getattr(result, "path_verification_message", ""), audit_secrets
                ),
                runtime_menu_verified=bool(getattr(result, "runtime_menu_verified", False)),
                runtime_mapping_verified=bool(
                    getattr(result, "runtime_mapping_verified", False)
                ),
                runtime_mapping_verification_code=sanitize_text(
                    getattr(result, "runtime_mapping_verification_code", "UNVERIFIED") or "UNVERIFIED",
                    audit_secrets,
                ),
                runtime_mapping_verification_message=sanitize_text(
                    getattr(result, "runtime_mapping_verification_message", "") or "",
                    audit_secrets,
                ),
                live_state=sanitize_text(getattr(result, "live_state", "UNKNOWN") or "UNKNOWN", audit_secrets),
                live_state_confident=bool(getattr(result, "live_state_confident", False)),
                live_session_user=sanitize_text(getattr(result, "live_session_user", "") or "", audit_secrets),
                live_state_reason_code=sanitize_text(getattr(result, "live_state_reason_code", "") or "", audit_secrets),
                live_state_evidence=sanitize_text(getattr(result, "live_state_evidence", "{}") or "{}", audit_secrets),
                live_state_checked_at=sanitize_text(getattr(result, "live_state_checked_at", "") or "", audit_secrets),
                safety_override_used=bool(allow_unverified_state) and not bool(getattr(result, "live_state_confident", False)),
                clear_line_recovery_requested=bool(getattr(result, "clear_line_recovery_requested", False)),
                clear_line_recovery_used=bool(getattr(result, "clear_line_recovery_used", False)),
                clear_line_number=getattr(result, "clear_line_number", None),
                clear_line_reason=sanitize_text(getattr(result, "clear_line_reason", "") or "", audit_secrets),
                clear_line_result=sanitize_text(getattr(result, "clear_line_result", "") or "", audit_secrets),
                ssh_host_key_algorithm=str(getattr(getattr(adapter, "ssh", None), "last_host_key_algorithm", "") or ""),
                ssh_host_key_fingerprint=str(getattr(getattr(adapter, "ssh", None), "last_host_key_fingerprint", "") or ""),
                ssh_host_key_policy=str(getattr(getattr(adapter, "ssh", None), "host_key_policy", "") or ""),
            )
        except Exception as exc:
            audit_secrets = tuple(runtime_secret_values)
            safe_error = sanitize_text(str(exc), audit_secrets)
            self.connection_repo.finish(
                connection_id,
                "FAILED",
                getattr(exc, "error_code", "INTERACTIVE_SESSION_ERROR"),
                safe_error,
                path_verification_code=sanitize_text(getattr(exc, "error_code", "UNVERIFIED"), audit_secrets),
                path_verification_message="Phiên không mở hoàn tất; xem error_code/error_message.",
                runtime_mapping_verified=bool(getattr(exc, "runtime_mapping_verified", False)),
                runtime_mapping_verification_code=sanitize_text(
                    getattr(exc, "runtime_mapping_verification_code", getattr(exc, "error_code", "UNVERIFIED")) or "UNVERIFIED",
                    audit_secrets,
                ),
                runtime_mapping_verification_message=sanitize_text(
                    getattr(exc, "runtime_mapping_verification_message", safe_error) or safe_error,
                    audit_secrets,
                ),
                live_state=sanitize_text(getattr(exc, "live_state", "UNKNOWN") or "UNKNOWN", audit_secrets),
                live_state_confident=bool(getattr(exc, "live_state_confident", False)),
                live_session_user=sanitize_text(getattr(exc, "live_session_user", "") or "", audit_secrets),
                live_state_reason_code=sanitize_text(getattr(exc, "live_state_reason_code", "") or "", audit_secrets),
                live_state_evidence=sanitize_text(getattr(exc, "live_state_evidence", "{}") or "{}", audit_secrets),
                live_state_checked_at=sanitize_text(getattr(exc, "live_state_checked_at", "") or "", audit_secrets),
                safety_override_used=bool(allow_unverified_state) and not bool(getattr(exc, "live_state_confident", False)),
                clear_line_recovery_requested=bool(getattr(exc, "clear_line_recovery_requested", False)),
                clear_line_recovery_used=bool(getattr(exc, "clear_line_recovery_used", False)),
                clear_line_number=getattr(exc, "clear_line_number", None),
                clear_line_reason=sanitize_text(getattr(exc, "clear_line_reason", "") or "", audit_secrets),
                clear_line_result=sanitize_text(getattr(exc, "clear_line_result", "") or "", audit_secrets),
                ssh_host_key_algorithm=str(getattr(getattr(adapter, "ssh", None), "last_host_key_algorithm", "") or ""),
                ssh_host_key_fingerprint=str(getattr(getattr(adapter, "ssh", None), "last_host_key_fingerprint", "") or ""),
                ssh_host_key_policy=str(getattr(getattr(adapter, "ssh", None), "host_key_policy", "") or ""),
            )
            raise
        finally:
            if lease is not None:
                lease.close(raise_on_heartbeat_error=False)
