"""Lightweight Device-A/Device-B cable verification service.

This workflow is intentionally separate from full downstream identity discovery.
It never asks for downstream credentials, never executes downstream show commands,
and never writes identity-history rows.  Its only job is to prove a fresh OOB
mapping is safe to open, read the downstream hostname from banner/prompt, and
return that evidence to the CLI for MATCH/MISMATCH reporting.
"""
from __future__ import annotations

from oob_manager.config import profile_fingerprint
from oob_manager.exceptions import InteractiveSessionError, ValidationError
from oob_manager.models import (
    DownstreamDiscoveryResult,
    PortAuthenticationCredentials,
    SessionCredentials,
)
from oob_manager.utils.security import sanitize_text, sanitize_value
from oob_manager.utils.validation import is_valid_host
from oob_manager.vendors.factory import create_vendor_adapter


class CableVerificationService:
    """Coordinate the minimal A/B quick-probe path without full identity machinery."""

    def __init__(
        self,
        oob_repo,
        target_repo,
        settings,
        lock_repo=None,
        adapter_factory=create_vendor_adapter,
    ) -> None:
        self.oob_repo = oob_repo
        self.target_repo = target_repo
        self.settings = settings
        self.lock_repo = lock_repo
        self.adapter_factory = adapter_factory

    @staticmethod
    def _mapping_signature(target) -> tuple[object, ...]:
        return (
            target.oob_id,
            target.menu_name.casefold(),
            target.menu_item,
            target.alias.casefold(),
            target.protocol,
            target.target_host.casefold(),
            target.target_port,
            target.console_line,
            target.command.strip(),
            target.last_scan_id,
        )

    @staticmethod
    def _sanitize_result(
        result: DownstreamDiscoveryResult,
        secrets: tuple[str, ...],
    ) -> DownstreamDiscoveryResult:
        result.downstream_prompt = sanitize_text(result.downstream_prompt, secrets)
        result.runtime_mapping_verification_message = sanitize_text(
            result.runtime_mapping_verification_message, secrets
        )
        result.live_state_evidence = sanitize_text(result.live_state_evidence, secrets)
        result.identity.source_evidence = sanitize_value(result.identity.source_evidence, secrets)
        result.metadata = sanitize_value(result.metadata, secrets)
        for item in result.raw_outputs:
            item.command_name = sanitize_text(item.command_name, secrets)
            item.command_text = sanitize_text(item.command_text, secrets)
            item.raw_output = sanitize_text(item.raw_output, secrets)
            item.error_message = sanitize_text(item.error_message, secrets)
        return result

    def probe(
        self,
        target_id: int,
        oob_credentials: SessionCredentials,
        port_credentials: PortAuthenticationCredentials | None = None,
    ) -> DownstreamDiscoveryResult:
        """Read Device B hostname only from a freshly validated console path."""

        target = self.target_repo.get(target_id)
        if not target:
            raise ValidationError("Không tìm thấy target.")
        if not target.is_complete:
            raise ValidationError(
                "Target chưa đủ dữ liệu để quick A/B.",
                error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
            )
        if not target.state_confident or target.state != "AVAILABLE":
            raise ValidationError(
                "Target không ở trạng thái AVAILABLE/confident từ scan gần nhất.",
                error_code=(
                    "CONSOLE_LINE_BUSY"
                    if target.state in {"BUSY", "BUSY_UNKNOWN_USER"}
                    else "DOWNSTREAM_LINE_NOT_CONFIRMED_AVAILABLE"
                ),
            )

        device = self.oob_repo.get(target.oob_id)
        if not device or not device.enabled:
            raise ValidationError("OOB không tồn tại hoặc đang bị vô hiệu hóa.")

        if device.vendor == "CISCO":
            if target.protocol != "TELNET":
                raise ValidationError(
                    "Cisco quick A/B chỉ hỗ trợ reverse-Telnet target.",
                    error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
                )
            if not is_valid_host(target.target_host) or not 1 <= int(target.target_port) <= 65535:
                raise ValidationError(
                    "Endpoint reverse-Telnet không hợp lệ.",
                    error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
                )
        elif device.vendor == "VERTIV":
            if target.protocol != "VERTIV_CLI" or not isinstance(target.console_line, int) or target.console_line <= 0:
                raise ValidationError(
                    "Vertiv quick A/B cần ACS serial port hợp lệ.",
                    error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
                )
        else:
            raise ValidationError(
                f"Quick A/B chưa hỗ trợ vendor {device.vendor}.",
                error_code="DOWNSTREAM_OOB_VENDOR_UNSUPPORTED",
            )

        adapter = self.adapter_factory(device, self.settings)
        runtime_profile = getattr(adapter, "profile", None)
        if isinstance(runtime_profile, dict):
            device = self.oob_repo.sync_profile_fingerprint(
                device.id,
                profile_fingerprint(runtime_profile),
            )
        if device.mapping_stale:
            raise ValidationError(
                "Mapping OOB đang STALE; cần scan lại trước quick A/B.",
                error_code="STALE_MAPPING",
            )

        provenance_ok, provenance_code, provenance_message = self.target_repo.verify_open_provenance(target_id)
        if not provenance_ok:
            raise ValidationError(
                provenance_message + " Cần scan lại trước quick A/B.",
                error_code=provenance_code or "MAPPING_PROVENANCE_INVALID",
            )

        initial_device_revision = int(device.connection_revision)
        initial_baseline_revision = int(device.baseline_revision)
        initial_signature = self._mapping_signature(target)
        lease = self.lock_repo.start_lease(device.id, "CABLE_VERIFY") if self.lock_repo is not None else None
        secrets = (
            oob_credentials.password,
            oob_credentials.enable_password or "",
            (port_credentials.password if port_credentials is not None else ""),
        )
        try:
            method = getattr(adapter, "quick_probe_hostname", None)
            if not callable(method):
                raise InteractiveSessionError(
                    "Adapter hiện tại chưa hỗ trợ quick A/B hostname probe.",
                    error_code="QUICK_CABLE_PROBE_UNSUPPORTED",
                )
            if port_credentials is None:
                result = method(device, target, oob_credentials)
            else:
                result = method(device, target, oob_credentials, port_credentials)
            result = self._sanitize_result(result, secrets)

            current_device = self.oob_repo.get(device.id)
            current_target = self.target_repo.get(target_id)
            if (
                not current_device
                or not current_target
                or int(current_device.connection_revision) != initial_device_revision
                or int(current_device.baseline_revision) != initial_baseline_revision
                or current_device.mapping_stale
                or self._mapping_signature(current_target) != initial_signature
            ):
                raise InteractiveSessionError(
                    "OOB/target mapping thay đổi trong lúc quick A/B; kết quả bị loại bỏ.",
                    error_code="CABLE_MAPPING_CHANGED_DURING_PROBE",
                )
            provenance_ok, provenance_code, provenance_message = self.target_repo.verify_open_provenance(target_id)
            if not provenance_ok:
                raise InteractiveSessionError(
                    provenance_message,
                    error_code=provenance_code or "MAPPING_PROVENANCE_INVALID",
                )
            if lease is not None:
                lease.ensure_owned()
            return result
        finally:
            if lease is not None:
                lease.close(raise_on_heartbeat_error=False)
