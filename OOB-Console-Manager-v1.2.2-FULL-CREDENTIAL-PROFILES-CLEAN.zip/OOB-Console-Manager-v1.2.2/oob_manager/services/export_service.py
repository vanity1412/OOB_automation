"""Xuất báo cáo CSV audit-friendly cho Excel/Power BI.

Mục tiêu chính: dữ liệu lịch sử phải phản ánh đúng cấu hình OOB tại thời điểm
scan/kết nối, không JOIN ngược sang IP/vendor hiện tại rồi làm sai lịch sử.
"""
from __future__ import annotations

import csv
from datetime import date, datetime, time, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from typing import Iterable, Mapping

from oob_manager.database.schema import SCHEMA_VERSION
from oob_manager.services.database_audit_service import DatabaseAuditService
from oob_manager.utils.datetime_utils import utc_now


STATUS_LABELS_VI = {
    "RUNNING": "Đang chạy",
    "SUCCESS": "Thành công",
    "PARTIAL": "Một phần",
    "FAILED": "Thất bại",
    "REJECTED": "Bị từ chối - dữ liệu không đủ tin cậy",
    "ABANDONED": "Bị gián đoạn/tiến trình cũ đã kết thúc",
    "CANCELLED": "Đã hủy",
}

# Status của connection_history mô tả vòng đời phiên console, KHÔNG khẳng định
# hostname/model vật lý ở đầu dây console đã được xác minh.
CONNECTION_STATUS_LABELS_VI = {
    "RUNNING": "Phiên đang mở",
    "SUCCESS": "Phiên kết thúc không ghi nhận lỗi",
    "FAILED": "Phiên mở/kết nối thất bại",
    "ABANDONED": "Phiên bị gián đoạn/tiến trình cũ đã kết thúc",
}

STATE_LABELS_VI = {
    "AVAILABLE": "Sẵn sàng",
    "BUSY": "Đang được sử dụng",
    "BUSY_UNKNOWN_USER": "Đang dùng - chưa rõ người dùng",
    "UNKNOWN": "Chưa xác định",
    "INCOMPLETE": "Thiếu dữ liệu",
}

EVENT_LABELS_VI = {
    "NEW_CONSOLE_TARGET": "Phát hiện target mới",
    "CONSOLE_TARGET_MISSING": "Target không còn xuất hiện",
    "CONSOLE_ALIAS_CHANGED": "Alias thay đổi",
    "CONSOLE_TARGET_HOST_CHANGED": "Host đích thay đổi",
    "CONSOLE_TARGET_PORT_CHANGED": "Port đích thay đổi",
    "CONSOLE_MENU_ITEM_CHANGED": "Menu item thay đổi",
    "CONSOLE_MENU_CHANGED": "Menu thay đổi",
    "CONSOLE_TARGET_MOVED": "Target được di chuyển",
    "CONSOLE_COMMAND_CHANGED": "Command console thay đổi",
    "CONSOLE_LINE_CHANGED": "Console line thay đổi",
    "CONSOLE_STATE_CHANGED": "Trạng thái target thay đổi",
}

MAX_RAW_OUTPUT_CSV_CHARS = 30_000


class ExportService:
    """Xuất metadata/audit; không xuất password hoặc nội dung console interactive."""

    def __init__(self, db, settings) -> None:
        self.db = db
        self.settings = settings

    def export_all(self) -> Path:
        """Xuất bộ audit đầy đủ vào thư mục timestamp riêng, không ghi đè lần trước."""
        now_local = utc_now().astimezone()
        day_root = Path(self.settings.export_dir) / now_local.strftime("%Y-%m-%d")
        export_dir = self._available_dir(
            day_root / "advanced" / f"full_{now_local.strftime('%H%M%S')}"
        )
        export_dir.mkdir(parents=True, exist_ok=True)

        with self.db.read() as conn:
            # Một read transaction duy nhất => tất cả CSV cùng DB snapshot.
            conn.execute("BEGIN")
            try:
                db_version = int(conn.execute("PRAGMA user_version").fetchone()[0])
                datasets = {
                    "oob_analysis_summary.csv": self._oob_analysis_summary(conn),
                    "inventory_summary.csv": self._inventory_summary(conn),
                    "oob_devices.csv": self._oob_devices(conn),
                    "console_targets.csv": self._console_targets(conn),
                    "console_snapshots.csv": self._console_snapshots(conn),
                    "scan_history.csv": self._scan_history(conn),
                    "scan_findings.csv": self._scan_findings(conn),
                    "raw_outputs.csv": self._raw_outputs(conn),
                    "change_events.csv": self._change_events(conn),
                    "connection_history.csv": self._connection_history(conn),
                    "oob_reconciliation_history.csv": self._reconciliation_history(conn),
                    "oob_change_history.csv": self._oob_change_history(conn),
                    "data_quality_issues.csv": self._data_quality_issues(conn),
                    "current_target_trace.csv": self._audit_view_rows(conn, "v_current_target_source_trace", "target_id"),
                    "snapshot_trace.csv": self._audit_view_rows(conn, "v_snapshot_source_trace", "scan_id DESC, snapshot_id"),
                    "scan_command_audit.csv": self._audit_view_rows(conn, "v_scan_command_audit", "scan_id DESC, raw_output_id"),
                    "connection_trace.csv": self._audit_view_rows(conn, "v_connection_trace", "connection_id DESC"),
                    "current_device_identities.csv": self._audit_view_rows(conn, "v_current_device_identity", "oob_name COLLATE NOCASE, configured_alias COLLATE NOCASE"),
                    "device_identity_runs.csv": self._audit_view_rows(conn, "v_device_identity_trace", "identity_run_id DESC"),
                    "device_identity_raw_outputs.csv": self._device_identity_raw_outputs(conn),
                    "device_identity_snapshots.csv": self._device_identity_snapshots(conn),
                    "device_identity_events.csv": self._audit_view_rows(conn, "v_device_identity_events", "identity_event_id DESC"),
                    "cable_check_runs.csv": self._cable_check_runs(conn),
                    "cable_check_results.csv": self._cable_check_results(conn),
                }
            finally:
                conn.rollback()

        manifest_path = export_dir / "export_manifest.csv"
        progress_path = export_dir / ".export_in_progress"
        root_progress_path = day_root / ".export_in_progress"
        progress_token = str(export_dir.resolve())
        manifest_path.unlink(missing_ok=True)
        progress_message = (
            "Export chưa hoàn tất. Không sử dụng bộ CSV này cho tới khi file này biến mất.\n"
            f"run={progress_token}\n"
        )
        progress_path.write_text(progress_message, encoding="utf-8")
        # Marker cấp ngày giữ tương thích với tooling cũ và cho operator biết có
        # một full export chưa hoàn tất. Nội dung chứa đúng run path để không xóa
        # nhầm marker của một export khác.
        root_progress_path.write_text(progress_message, encoding="utf-8")
        completed = False
        try:
            for filename, rows in datasets.items():
                self._write_dict_rows(export_dir / filename, rows)
            readme_path = export_dir / "README_EXPORT.txt"
            self._write_data_dictionary(readme_path)

            # Manifest tạo SAU khi ghi file để hash/size phản ánh đúng artifact thực tế.
            manifest = self._manifest_from_files(
                export_dir,
                datasets,
                database_version=db_version,
                extra_files=[readme_path.name],
            )
            self._write_dict_rows(manifest_path, manifest)
            completed = True
            return export_dir
        finally:
            if completed:
                progress_path.unlink(missing_ok=True)
                try:
                    if root_progress_path.exists() and progress_token in root_progress_path.read_text(encoding="utf-8"):
                        root_progress_path.unlink(missing_ok=True)
                except OSError:
                    pass

    def list_daily_scans(self, day: date) -> list[dict[str, object]]:
        """Liệt kê scan của một ngày theo timezone local của máy chạy tool."""
        start_utc, end_utc = self._local_day_bounds_utc(day)
        with self.db.read() as conn:
            rows = conn.execute(
                """
                SELECT s.*, o.name AS current_oob_name
                FROM scan_runs s
                LEFT JOIN oob_devices o ON o.id=s.oob_id
                WHERE s.started_at >= ? AND s.started_at < ?
                ORDER BY s.started_at, s.id
                """,
                (start_utc, end_utc),
            ).fetchall()
        return [
            {
                "scan_id": row["id"],
                "oob_name": row["oob_name_at_scan"] or row["current_oob_name"] or f"OOB {row['oob_id']}",
                "started_at": row["started_at"],
                "finished_at": row["finished_at"],
                "status": row["status"],
                "mapping_quality": row["mapping_quality"],
                "baseline_updated": int(row["baseline_updated"] or 0),
                "mapping_count": int(row["mapping_count"] or 0),
                "complete_count": int(row["complete_count"] or 0),
                "change_count": int(row["change_count"] or 0),
                "warning_count": int(row["warning_count"] or 0),
            }
            for row in rows
        ]

    def daily_inventory_rows(self, day: date) -> list[dict[str, object]]:
        """Snapshot dễ đọc của ngày.

        Với mỗi OOB, chọn scan mapping ACCEPTED mới nhất trong ngày. Identity được
        lấy từ identity snapshot mới nhất của cùng target trước cuối ngày, nhờ đó
        không JOIN nhầm identity hiện tại vào lịch sử cũ.
        """
        start_utc, end_utc = self._local_day_bounds_utc(day)
        with self.db.read() as conn:
            scan_rows = conn.execute(
                """
                SELECT s.*
                FROM scan_runs s
                JOIN (
                    SELECT oob_id, MAX(id) AS scan_id
                    FROM scan_runs
                    WHERE started_at >= ? AND started_at < ?
                      AND mapping_quality='ACCEPTED'
                    GROUP BY oob_id
                ) latest ON latest.scan_id=s.id
                ORDER BY s.oob_name_at_scan COLLATE NOCASE, s.id
                """,
                (start_utc, end_utc),
            ).fetchall()
            result: list[dict[str, object]] = []
            for scan in scan_rows:
                snapshots = conn.execute(
                    """
                    SELECT * FROM console_snapshots
                    WHERE scan_id=?
                    ORDER BY alias COLLATE NOCASE, menu_name COLLATE NOCASE, menu_item
                    """,
                    (scan["id"],),
                ).fetchall()
                for snap in snapshots:
                    identity = None
                    if snap["target_id"] is not None:
                        identity = conn.execute(
                            """
                            SELECT * FROM device_identity_snapshots
                            WHERE target_id=? AND captured_at < ?
                            ORDER BY captured_at DESC, id DESC LIMIT 1
                            """,
                            (snap["target_id"], end_utc),
                        ).fetchone()
                    cable = None
                    if snap["target_id"] is not None:
                        cable = conn.execute(
                            """
                            SELECT x.*, r.status AS run_status
                            FROM cable_check_results x
                            JOIN cable_check_runs r ON r.id=x.run_id
                            WHERE x.target_id=? AND r.mapping_scan_id=? AND x.detected_at < ?
                            ORDER BY x.detected_at DESC, x.id DESC LIMIT 1
                            """,
                            (snap["target_id"], scan["id"], end_utc),
                        ).fetchone()
                    result.append(self._daily_inventory_row(day, scan, snap, identity, cable))
            return result

    def export_daily_inventory(self, day: date) -> Path:
        """Xuất file tổng hợp của ngày; file này đại diện daily/latest-of-day và được cập nhật."""
        rows = self.daily_inventory_rows(day)
        export_dir = Path(self.settings.export_dir) / day.isoformat() / "daily"
        export_dir.mkdir(parents=True, exist_ok=True)
        path = export_dir / f"daily_inventory_{day.isoformat()}.csv"
        self._write_dict_rows(path, rows)
        return path

    def current_inventory_rows(self) -> list[dict[str, object]]:
        """Inventory hiện tại dạng ngắn gọn cho CLI/operator."""
        with self.db.read() as conn:
            return self._inventory_summary(conn)

    def export_current_inventory(self) -> Path:
        """Xuất trạng thái mới nhất vào latest/current_inventory.csv."""
        rows = self.current_inventory_rows()
        export_dir = (
            Path(self.settings.export_dir)
            / utc_now().astimezone().strftime("%Y-%m-%d")
            / "latest"
        )
        export_dir.mkdir(parents=True, exist_ok=True)
        path = export_dir / "current_inventory.csv"
        self._write_dict_rows(path, rows)
        return path

    def export_cable_verification(
        self,
        oob_name: str,
        rows: Iterable[Mapping[str, object]],
    ) -> dict[str, Path]:
        """Xuất kết quả batch A/B và một CSV riêng chỉ chứa mismatch.

        ``cable_mismatch.csv`` luôn được tạo (header-only khi không có mismatch)
        để automation/operator có artifact ổn định. Bốn cột đầu đúng contract
        vận hành: port, device_a, device_b, detected_at.
        """
        row_list = list(rows)
        now_local = utc_now().astimezone()
        day_root = Path(self.settings.export_dir) / now_local.strftime("%Y-%m-%d")
        run_dir = self._available_dir(
            day_root
            / "cable_checks"
            / f"{now_local.strftime('%H%M%S')}_{self._safe_component(oob_name)}"
        )
        run_dir.mkdir(parents=True, exist_ok=True)

        all_path = run_dir / "cable_verification.csv"
        mismatch_path = run_dir / "cable_mismatch.csv"
        self._write_dict_rows(all_path, row_list)

        mismatch_rows: list[dict[str, object]] = []
        for row in row_list:
            if str(row.get("status", "")).upper() != "MISMATCH":
                continue
            mismatch_rows.append({
                "port": row.get("port", ""),
                "device_a": row.get("device_a", ""),
                "device_b": row.get("device_b", ""),
                "detected_at": row.get("detected_at", ""),
                "oob": row.get("oob", oob_name),
                "vendor": row.get("vendor", ""),
                "console_path": row.get("console_path", ""),
                "evidence_source": row.get("evidence_source", ""),
            })
        self._write_dict_rows(mismatch_path, mismatch_rows)
        return {"run_dir": run_dir, "all": all_path, "mismatch": mismatch_path}

    def export_after_scan(self, scan_id: int) -> dict[str, Path]:
        """Tạo artifact dễ đọc ngay sau một scan mà không làm mất artifact cũ.

        ``runs`` là immutable per-run; ``latest`` và ``daily`` là hai view tiện dụng
        được cập nhật để operator không phải lục nhiều file.
        """
        summary = self.get_scan_summary(scan_id)
        if not summary:
            raise ValueError(f"Không tìm thấy scan ID {scan_id}.")
        scan_local = datetime.fromisoformat(str(summary["started_at_utc"])).astimezone()
        run_dir = self.export_scan_run(scan_id)
        latest_path = self.export_current_inventory()
        daily_path = self.export_daily_inventory(scan_local.date())
        return {"run_dir": run_dir, "latest": latest_path, "daily": daily_path}

    def export_scan_run(self, scan_id: int) -> Path:
        """Xuất snapshot của đúng một scan vào ``runs/HHMMSS_scan-ID_OOB``."""
        with self.db.read() as conn:
            scan = conn.execute(
                """
                SELECT s.*, COALESCE(NULLIF(s.oob_name_at_scan,''), o.name) AS display_oob_name
                FROM scan_runs s LEFT JOIN oob_devices o ON o.id=s.oob_id
                WHERE s.id=?
                """,
                (scan_id,),
            ).fetchone()
            if scan is None:
                raise ValueError(f"Không tìm thấy scan ID {scan_id}.")
            snapshots = conn.execute(
                """SELECT * FROM console_snapshots WHERE scan_id=?
                   ORDER BY alias COLLATE NOCASE, menu_name COLLATE NOCASE, menu_item""",
                (scan_id,),
            ).fetchall()
            changes = conn.execute(
                """SELECT * FROM change_events WHERE scan_id=? ORDER BY id""",
                (scan_id,),
            ).fetchall()

            finished_at = scan["finished_at"] or scan["started_at"]
            finished_local = datetime.fromisoformat(finished_at).astimezone()
            inventory_rows: list[dict[str, object]] = []
            for snap in snapshots:
                identity = None
                if snap["target_id"] is not None:
                    identity = conn.execute(
                        """
                        SELECT * FROM device_identity_snapshots
                        WHERE target_id=? AND captured_at <= ?
                        ORDER BY captured_at DESC, id DESC LIMIT 1
                        """,
                        (snap["target_id"], finished_at),
                    ).fetchone()
                inventory_rows.append(
                    self._daily_inventory_row(finished_local.date(), scan, snap, identity)
                )

        oob_name = str(scan["display_oob_name"] or f"OOB-{scan['oob_id']}")
        day_root = Path(self.settings.export_dir) / finished_local.strftime("%Y-%m-%d")
        folder_name = (
            f"{finished_local.strftime('%H%M%S')}_scan-{scan_id}_"
            f"{self._safe_component(oob_name)}"
        )
        run_dir = self._available_dir(day_root / "runs" / folder_name)
        run_dir.mkdir(parents=True, exist_ok=True)

        summary = self.get_scan_summary(scan_id)
        self._write_dict_rows(run_dir / "scan_summary.csv", [summary] if summary else [])
        self._write_dict_rows(run_dir / "inventory.csv", inventory_rows)
        change_rows = [
            {
                "event_id": row["id"],
                "event_code": row["event_code"],
                "target_identity": row["target_identity"],
                "old_data": row["old_data"] or "",
                "new_data": row["new_data"] or "",
                "detected_at": self._local_datetime(row["detected_at"]),
            }
            for row in changes
        ]
        self._write_dict_rows(run_dir / "changes.csv", change_rows)
        (run_dir / "README_RUN.txt").write_text(
            "OOB Console Manager - per-scan artifact\n"
            f"Scan ID: {scan_id}\n"
            f"OOB: {oob_name}\n"
            "inventory.csv = mapping/state đúng tại lần scan này.\n"
            "scan_summary.csv = trạng thái scan.\n"
            "changes.csv = thay đổi phát hiện bởi scan này.\n"
            "Raw evidence đầy đủ vẫn nằm trong SQLite/full audit export.\n",
            encoding="utf-8",
        )
        return run_dir

    def get_scan_summary(self, scan_id: int) -> dict[str, object] | None:
        with self.db.read() as conn:
            row = conn.execute(
                """
                SELECT s.*, COALESCE(NULLIF(s.oob_name_at_scan,''), o.name) AS display_oob_name
                FROM scan_runs s LEFT JOIN oob_devices o ON o.id=s.oob_id
                WHERE s.id=?
                """,
                (scan_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "scan_id": row["id"],
            "oob_id": row["oob_id"],
            "oob_name": row["display_oob_name"] or f"OOB {row['oob_id']}",
            "vendor": row["vendor_at_scan"] or "",
            "started_at_utc": row["started_at"],
            "started_at_local": self._local_datetime(row["started_at"]),
            "finished_at_utc": row["finished_at"] or "",
            "finished_at_local": self._local_datetime(row["finished_at"]),
            "status": row["status"],
            "mapping_quality": row["mapping_quality"],
            "baseline_updated": int(row["baseline_updated"] or 0),
            "mapping_count": int(row["mapping_count"] or 0),
            "complete_count": int(row["complete_count"] or 0),
            "warning_count": int(row["warning_count"] or 0),
            "change_count": int(row["change_count"] or 0),
            "error_code": row["error_code"] or "",
            "error_message": row["error_message"] or "",
        }

    def scan_snapshot_rows(self, scan_id: int) -> list[dict[str, object]]:
        """Trả inventory của đúng scan ID, không dùng current target."""
        with self.db.read() as conn:
            scan = conn.execute("SELECT * FROM scan_runs WHERE id=?", (scan_id,)).fetchone()
            if scan is None:
                return []
            snapshots = conn.execute(
                """SELECT * FROM console_snapshots WHERE scan_id=?
                   ORDER BY alias COLLATE NOCASE, menu_name COLLATE NOCASE, menu_item""",
                (scan_id,),
            ).fetchall()
            finished_at = scan["finished_at"] or scan["started_at"]
            day = datetime.fromisoformat(finished_at).astimezone().date()
            rows: list[dict[str, object]] = []
            for snap in snapshots:
                identity = None
                if snap["target_id"] is not None:
                    identity = conn.execute(
                        """
                        SELECT * FROM device_identity_snapshots
                        WHERE target_id=? AND captured_at <= ?
                        ORDER BY captured_at DESC, id DESC LIMIT 1
                        """,
                        (snap["target_id"], finished_at),
                    ).fetchone()
                rows.append(self._daily_inventory_row(day, scan, snap, identity))
            return rows

    def search_history_targets(self, query: str, limit: int = 50) -> list[dict[str, object]]:
        """Tìm target trong snapshot lịch sử, kể cả target không còn ở current inventory."""
        import re
        tokens = re.findall(r"[^\W_]+", str(query or "").strip(), flags=re.UNICODE)[:8]
        if not tokens:
            return []
        fields = [
            "cs.alias LIKE ? COLLATE NOCASE",
            "s.oob_name_at_scan LIKE ? COLLATE NOCASE",
            "cs.target_host LIKE ? COLLATE NOCASE",
            "CAST(cs.target_port AS TEXT) LIKE ?",
            "CAST(cs.console_line AS TEXT) LIKE ?",
        ]
        clause = "(" + " OR ".join(fields) + ")"
        where = " AND ".join(clause for _ in tokens)
        params: list[object] = []
        for token in tokens:
            params.extend([f"%{token}%"] * len(fields))
        params.append(min(max(int(limit) * 10, 100), 5000))
        with self.db.read() as conn:
            rows = conn.execute(
                f"""
                SELECT cs.*, s.oob_name_at_scan, s.vendor_at_scan
                FROM console_snapshots cs
                JOIN scan_runs s ON s.id=cs.scan_id
                WHERE cs.target_id IS NOT NULL AND {where}
                ORDER BY cs.captured_at DESC, cs.id DESC
                LIMIT ?
                """,
                tuple(params),
            ).fetchall()
        seen: set[int] = set()
        result: list[dict[str, object]] = []
        for row in rows:
            target_id = int(row["target_id"])
            if target_id in seen:
                continue
            seen.add(target_id)
            result.append({
                "target_id": target_id,
                "alias": row["alias"],
                "oob": row["oob_name_at_scan"] or f"OOB {row['oob_id']}",
                "console_path": self._simple_console_path(row),
                "last_seen": self._local_datetime(row["captured_at"]),
            })
            if len(result) >= limit:
                break
        return result

    def target_history_rows(self, target_id: int, limit: int = 500) -> list[dict[str, object]]:
        """Lịch sử mapping/state của một target theo snapshot, mới nhất trước."""
        safe_limit = min(max(int(limit), 1), 5000)
        with self.db.read() as conn:
            snapshots = conn.execute(
                """
                SELECT cs.*, s.started_at, s.finished_at, s.status AS scan_status,
                       s.mapping_quality, s.oob_name_at_scan, s.vendor_at_scan
                FROM console_snapshots cs
                JOIN scan_runs s ON s.id=cs.scan_id
                WHERE cs.target_id=?
                ORDER BY cs.captured_at DESC, cs.id DESC
                LIMIT ?
                """,
                (target_id, safe_limit),
            ).fetchall()
            result: list[dict[str, object]] = []
            for snap in snapshots:
                identity = conn.execute(
                    """
                    SELECT * FROM device_identity_snapshots
                    WHERE target_id=? AND captured_at <= ?
                    ORDER BY captured_at DESC, id DESC LIMIT 1
                    """,
                    (target_id, snap["captured_at"]),
                ).fetchone()
                actual_hostname = identity["actual_hostname"] if identity is not None else ""
                serial = identity["serial_number"] if identity is not None else ""
                identity_status = identity["verification_status"] if identity is not None else ""
                result.append({
                    "scan_id": snap["scan_id"],
                    "time": self._local_datetime(snap["captured_at"]),
                    "oob": snap["oob_name_at_scan"] or f"OOB {snap['oob_id']}",
                    "target_alias": snap["alias"],
                    "console_path": self._simple_console_path(snap),
                    "state": snap["state"] if snap["state_confident"] else "UNKNOWN",
                    "scan_status": snap["scan_status"],
                    "mapping_quality": snap["mapping_quality"],
                    "actual_hostname": actual_hostname,
                    "serial": serial,
                    "identity_status": identity_status or "CHƯA_XÁC_MINH",
                })
            return result

    @staticmethod
    def _safe_component(value: str) -> str:
        import re
        text = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
        text = text.strip("._-")
        return (text or "item")[:80]

    @staticmethod
    def _available_dir(path: Path) -> Path:
        if not path.exists():
            return path
        counter = 2
        while True:
            candidate = path.with_name(f"{path.name}_{counter:02d}")
            if not candidate.exists():
                return candidate
            counter += 1

    def _inventory_summary(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        """Một file current inventory ngắn gọn cho operator/Excel."""
        rows = conn.execute(
            """
            SELECT
                t.id AS target_id, t.oob_id, o.name AS oob_name, o.vendor AS oob_vendor,
                t.alias, t.protocol, t.target_host, t.target_port, t.console_line,
                t.state, t.state_confident, t.is_complete, t.last_scan_id,
                s.finished_at AS last_scan_at, s.mapping_quality, s.status AS scan_status,
                d.actual_hostname, d.vendor AS device_vendor, d.model, d.serial_number,
                d.software_version, d.identity_quality, d.identity_confidence,
                d.alias_comparison, d.verification_status, d.verified_at,
                ir.id AS observed_identity_run_id,
                ir.status AS observed_run_status,
                ir.error_code AS observed_error_code,
                ir.error_message AS observed_error_message,
                ir.actual_hostname AS observed_hostname,
                ir.detected_vendor AS observed_vendor,
                ir.platform_family AS observed_platform_family,
                ir.model AS observed_model,
                ir.serial_number AS observed_serial_number,
                ir.software_version AS observed_software_version,
                ir.identity_quality AS observed_identity_quality,
                ir.identity_confidence AS observed_identity_confidence,
                ir.alias_comparison AS observed_alias_comparison,
                ir.verification_status AS observed_verification_status,
                ir.finished_at AS observed_finished_at,
                c.device_a AS cable_device_a, c.device_b AS cable_device_b,
                c.port AS cable_port, c.console_path AS cable_console_path,
                c.status AS cable_status, c.evidence_source AS cable_evidence_source,
                c.wake_count AS cable_wake_count,
                c.passive_wait_used AS cable_passive_wait_used,
                c.runtime_mapping_verified AS cable_runtime_mapping_verified,
                c.runtime_mapping_verification_code AS cable_runtime_mapping_verification_code,
                c.runtime_mapping_verification_message AS cable_runtime_mapping_verification_message,
                c.live_state AS cable_live_state,
                c.live_state_confident AS cable_live_state_confident,
                c.live_state_reason_code AS cable_live_state_reason_code,
                c.live_state_evidence AS cable_live_state_evidence,
                c.live_state_checked_at AS cable_live_state_checked_at,
                c.error_code AS cable_error_code, c.message AS cable_message,
                c.detected_at AS cable_checked_at, c.run_id AS cable_run_id,
                cr.mapping_scan_id AS cable_mapping_scan_id,
                cr.status AS cable_run_status, cr.started_at AS cable_run_started_at,
                cr.finished_at AS cable_run_finished_at,
                cr.total_count AS cable_total_count, cr.match_count AS cable_match_count,
                cr.mismatch_count AS cable_mismatch_count,
                cr.no_hostname_count AS cable_no_hostname_count,
                cr.skip_error_count AS cable_skip_error_count,
                cr.error_code AS cable_run_error_code,
                cr.error_message AS cable_run_error_message
            FROM console_targets t
            JOIN oob_devices o ON o.id=t.oob_id
            LEFT JOIN scan_runs s ON s.id=t.last_scan_id
            LEFT JOIN device_identities d ON d.target_id=t.id
            LEFT JOIN device_identity_runs ir ON ir.id=(
                SELECT irx.id
                FROM device_identity_runs irx
                WHERE irx.target_id=t.id AND irx.status<>'RUNNING'
                ORDER BY COALESCE(irx.finished_at, irx.started_at) DESC, irx.id DESC LIMIT 1
            )
            LEFT JOIN cable_check_results c ON c.id=(
                SELECT cx.id
                FROM cable_check_results cx
                JOIN cable_check_runs crx ON crx.id=cx.run_id
                WHERE cx.target_id=t.id
                ORDER BY cx.detected_at DESC, cx.id DESC LIMIT 1
            )
            LEFT JOIN cable_check_runs cr ON cr.id=c.run_id
            ORDER BY o.name COLLATE NOCASE, t.alias COLLATE NOCASE
            """
        ).fetchall()
        return [self._simple_inventory_row(row) for row in rows]

    @staticmethod
    def _simple_console_path(row: Mapping[str, object]) -> str:
        protocol = str(row["protocol"] or "")
        line = row["console_line"]
        if protocol == "VERTIV_CLI":
            return f"serial/{line}" if line is not None else "serial/-"
        host = str(row["target_host"] or "")
        port = row["target_port"]
        endpoint = f"{host}:{port}" if host else "-"
        return f"{endpoint} / line {line if line is not None else '-'}"

    def _simple_inventory_row(self, row: Mapping[str, object]) -> dict[str, object]:
        accepted_identity_status = str(row["verification_status"] or "")
        accepted_identity_hostname = str(row["actual_hostname"] or "")
        observed_identity_status = str(row["observed_verification_status"] or "")
        observed_identity_hostname = str(row["observed_hostname"] or "")
        accepted_identity_available = bool(
            accepted_identity_hostname
            or str(row["model"] or "")
            or str(row["serial_number"] or "")
            or str(row["software_version"] or "")
        )
        observed_identity_available = bool(row["observed_identity_run_id"])
        identity_status = (
            accepted_identity_status
            if accepted_identity_available
            else observed_identity_status
        )
        identity_hostname = (
            accepted_identity_hostname
            if accepted_identity_available
            else observed_identity_hostname
        )
        cable_hostname = str(row["cable_device_b"] or "")
        raw_cable_status = str(row["cable_status"] or "")
        alias = str(row["alias"] or "")
        current_console_path = self._simple_console_path(row)

        # Never make completed work disappear merely because a later mapping-only
        # scan refreshed last_scan_id. The result remains current when either it was
        # produced from the exact scan or the Device-A + physical console path are
        # still identical. If mapping changed, surface the old result as STALE so an
        # operator can see what was done without treating it as current evidence.
        cable_mapping_scan_id = int(row["cable_mapping_scan_id"] or 0)
        current_scan_id = int(row["last_scan_id"] or 0)
        cable_device_a = str(row["cable_device_a"] or "")
        cable_console_path = str(row["cable_console_path"] or "")
        exact_scan = bool(raw_cable_status) and cable_mapping_scan_id == current_scan_id
        same_mapping = bool(raw_cable_status) and (
            cable_device_a.casefold() == alias.casefold()
            and cable_console_path == current_console_path
        )
        cable_is_current = bool(raw_cable_status) and (exact_scan or same_mapping)
        if not raw_cable_status:
            cable_freshness = "CHƯA_CHECK"
        elif exact_scan:
            cable_freshness = "CURRENT_SCAN"
        elif same_mapping:
            cable_freshness = "SAME_MAPPING_RESCAN"
        else:
            cable_freshness = "STALE_MAPPING"

        cable_status = raw_cable_status if cable_is_current else ""
        cable_status_display = (
            raw_cable_status
            if cable_is_current
            else (f"STALE/{raw_cable_status}" if raw_cable_status else "CHƯA_CHECK")
        )
        actual_hostname = (
            cable_hostname if cable_is_current and cable_hostname else identity_hostname
        )
        # Still expose the latest historical Device B for audit in a dedicated field.
        latest_device_b = cable_hostname

        overall = "CHƯA_XÁC_MINH"
        if not bool(row["is_complete"]):
            overall = "MAPPING_INCOMPLETE"
        elif raw_cable_status and not cable_is_current:
            overall = "CẦN_CHECK_LẠI"
        elif cable_status == "MISMATCH" or identity_status in {"VERIFIED_MISMATCH", "DEVICE_CHANGE_SUSPECTED"}:
            overall = "MISMATCH"
        elif cable_status == "MATCH":
            overall = "NORMAL"
        elif cable_status in {"NO_HOSTNAME", "SKIP/ERROR"}:
            overall = cable_status
        elif actual_hostname:
            overall = "NORMAL" if str(row["alias_comparison"] or "") == "EXACT_MATCH" else "CẦN_KIỂM_TRA"

        state = str(row["state"] or "UNKNOWN") if bool(row["state_confident"]) else "UNKNOWN"
        wake_count = int(row["cable_wake_count"] or 0)
        passive_used = bool(row["cable_passive_wait_used"])
        evidence = str(row["cable_evidence_source"] or "")
        error_code = str(row["cable_error_code"] or "")
        message = str(row["cable_message"] or "")
        runtime_mapping_verified = bool(row["cable_runtime_mapping_verified"])
        runtime_mapping_code = str(row["cable_runtime_mapping_verification_code"] or "UNVERIFIED")
        runtime_mapping_message = str(row["cable_runtime_mapping_verification_message"] or "")
        cable_live_state = str(row["cable_live_state"] or "UNKNOWN")
        cable_live_state_confident = bool(row["cable_live_state_confident"])
        cable_live_state_reason = str(row["cable_live_state_reason_code"] or "")
        cable_live_state_evidence = str(row["cable_live_state_evidence"] or "{}")
        if not raw_cable_status:
            action_summary = "Chưa chạy Quick A/B cho target này."
        elif raw_cable_status in {"MATCH", "MISMATCH"}:
            action_summary = (
                f"Đã mở console; đọc Device B từ {evidence or 'banner/prompt'}; "
                f"passive={'YES' if passive_used else 'NO'}; wake={wake_count}; "
                "không login/chạy lệnh downstream."
            )
        elif raw_cable_status == "NO_HOSTNAME":
            action_summary = (
                f"Đã mở console; passive={'YES' if passive_used else 'NO'}; wake={wake_count}; "
                "không thấy hostname nên dừng trước downstream login."
            )
        else:
            action_summary = message or error_code or "Port bị bỏ qua/lỗi trước khi lấy Device B."
        if raw_cable_status:
            action_summary += (
                f" Runtime mapping={'VERIFIED' if runtime_mapping_verified else 'UNVERIFIED'}"
                f"({runtime_mapping_code}); live_state={cable_live_state}"
                f"/confident={'YES' if cable_live_state_confident else 'NO'}"
                f"/{cable_live_state_reason or '-'}."
            )
        if raw_cable_status and not cable_is_current:
            action_summary += " Kết quả thuộc mapping cũ; cần chạy lại A/B cho mapping hiện tại."

        if accepted_identity_available:
            identity_source = "ACCEPTED_CURRENT"
            display_vendor = str(row["device_vendor"] or "")
            display_model = str(row["model"] or "")
            display_serial = str(row["serial_number"] or "")
            display_version = str(row["software_version"] or "")
            display_quality = str(row["identity_quality"] or "ACCEPTED")
            display_confidence = str(row["identity_confidence"] or "")
            display_alias_check = str(row["alias_comparison"] or "UNKNOWN")
            display_identity_checked_at = row["verified_at"]
            display_identity_error_code = ""
            display_identity_error_message = ""
        elif observed_identity_available:
            identity_source = "LATEST_OBSERVED"
            display_vendor = str(row["observed_vendor"] or "")
            display_model = str(row["observed_model"] or "")
            display_serial = str(row["observed_serial_number"] or "")
            display_version = str(row["observed_software_version"] or "")
            display_quality = str(row["observed_identity_quality"] or "REJECTED")
            display_confidence = str(row["observed_identity_confidence"] or "LOW")
            display_alias_check = str(row["observed_alias_comparison"] or "UNKNOWN")
            display_identity_checked_at = row["observed_finished_at"]
            display_identity_error_code = str(row["observed_error_code"] or "")
            display_identity_error_message = str(row["observed_error_message"] or "")
        else:
            identity_source = "NOT_COLLECTED"
            display_vendor = display_model = display_serial = display_version = ""
            display_quality = "CHƯA_XÁC_MINH"
            display_confidence = ""
            display_alias_check = "CHƯA_XÁC_MINH"
            display_identity_checked_at = None
            display_identity_error_code = ""
            display_identity_error_message = ""

        return {
            "oob": row["oob_name"],
            "oob_vendor": row["oob_vendor"],
            "target_alias": alias,
            "console_path": current_console_path,
            "state": state,
            "actual_hostname": actual_hostname,
            "device_b": latest_device_b,
            "cable_status": cable_status or "CHƯA_CHECK",
            "cable_status_display": cable_status_display,
            "cable_freshness": cable_freshness,
            "cable_is_current": cable_is_current,
            "cable_evidence_source": evidence,
            "cable_checked_at": self._local_datetime(row["cable_checked_at"]),
            "cable_run_id": row["cable_run_id"] or "",
            "cable_mapping_scan_id": row["cable_mapping_scan_id"] or "",
            "cable_run_status": row["cable_run_status"] or "",
            "cable_run_started_at": self._local_datetime(row["cable_run_started_at"]),
            "cable_run_finished_at": self._local_datetime(row["cable_run_finished_at"]),
            "cable_total_count": int(row["cable_total_count"] or 0),
            "cable_match_count": int(row["cable_match_count"] or 0),
            "cable_mismatch_count": int(row["cable_mismatch_count"] or 0),
            "cable_no_hostname_count": int(row["cable_no_hostname_count"] or 0),
            "cable_skip_error_count": int(row["cable_skip_error_count"] or 0),
            "cable_error_code": error_code,
            "cable_message": message,
            "cable_wake_count": wake_count,
            "cable_passive_wait_used": passive_used,
            "cable_runtime_mapping_verified": runtime_mapping_verified,
            "cable_runtime_mapping_verification_code": runtime_mapping_code,
            "cable_runtime_mapping_verification_message": runtime_mapping_message,
            "cable_live_state": cable_live_state,
            "cable_live_state_confident": cable_live_state_confident,
            "cable_live_state_reason_code": cable_live_state_reason,
            "cable_live_state_evidence": cable_live_state_evidence,
            "cable_live_state_checked_at": self._local_datetime(row["cable_live_state_checked_at"]),
            "action_summary": action_summary,
            "full_identity_hostname": identity_hostname,
            "device_vendor": display_vendor,
            "model": display_model,
            "serial": display_serial,
            "version": display_version,
            "identity": display_quality,
            "identity_confidence": display_confidence,
            "identity_source": identity_source,
            "identity_run_id": row["observed_identity_run_id"] or "",
            "identity_run_status": row["observed_run_status"] or "",
            "identity_error_code": display_identity_error_code,
            "identity_error_message": display_identity_error_message,
            "alias_check": display_alias_check,
            "overall": overall,
            "last_scan_at": self._local_datetime(row["last_scan_at"]),
            "scan_status": row["scan_status"] or "",
            "mapping_quality": row["mapping_quality"] or "",
            "identity_checked_at": self._local_datetime(display_identity_checked_at),
            "scan_id": row["last_scan_id"],
            "target_id": row["target_id"],
        }

    def _daily_inventory_row(
        self,
        day: date,
        scan: sqlite3.Row,
        snap: sqlite3.Row,
        identity: sqlite3.Row | None,
        cable: sqlite3.Row | None = None,
    ) -> dict[str, object]:
        row: dict[str, object] = {
            "date": day.isoformat(),
            "scan_time": self._local_datetime(scan["finished_at"] or scan["started_at"]),
            "scan_id": scan["id"],
            "oob": scan["oob_name_at_scan"] or f"OOB {scan['oob_id']}",
            "oob_vendor": scan["vendor_at_scan"],
            "target_alias": snap["alias"],
            "console_path": self._simple_console_path(snap),
            "state": snap["state"] if snap["state_confident"] else "UNKNOWN",
            "mapping_complete": "YES" if snap["is_complete"] else "NO",
            "actual_hostname": "",
            "device_b": "",
            "cable_status": "CHƯA_CHECK",
            "cable_evidence_source": "",
            "cable_checked_at": "",
            "cable_run_id": "",
            "full_identity_hostname": "",
            "device_vendor": "",
            "model": "",
            "serial": "",
            "version": "",
            "identity": "CHƯA_XÁC_MINH",
            "alias_check": "CHƯA_XÁC_MINH",
            "overall": "CHƯA_XÁC_MINH" if snap["is_complete"] else "MAPPING_INCOMPLETE",
            "identity_checked_at": "",
        }
        if identity is not None:
            row.update({
                "actual_hostname": identity["actual_hostname"],
                "full_identity_hostname": identity["actual_hostname"],
                "device_vendor": identity["vendor"],
                "model": identity["model"],
                "serial": identity["serial_number"],
                "version": identity["software_version"],
                "identity": identity["identity_quality"],
                "alias_check": identity["alias_comparison"],
                "identity_checked_at": self._local_datetime(identity["captured_at"]),
            })
            if identity["verification_status"] in {"VERIFIED_MISMATCH", "DEVICE_CHANGE_SUSPECTED"}:
                row["overall"] = "MISMATCH"
            elif identity["alias_comparison"] == "EXACT_MATCH" and snap["is_complete"]:
                row["overall"] = "NORMAL"
            else:
                row["overall"] = "CẦN_KIỂM_TRA"
        if cable is not None:
            cable_status = str(cable["status"] or "")
            cable_hostname = str(cable["device_b"] or "")
            row.update({
                "device_b": cable_hostname,
                "cable_status": cable_status or "CHƯA_CHECK",
                "cable_evidence_source": cable["evidence_source"] or "",
                "cable_checked_at": self._local_datetime(cable["detected_at"]),
                "cable_run_id": cable["run_id"],
            })
            if cable_hostname:
                row["actual_hostname"] = cable_hostname
            if cable_status == "MISMATCH":
                row["overall"] = "MISMATCH"
            elif cable_status == "MATCH" and snap["is_complete"]:
                row["overall"] = "NORMAL"
            elif cable_status in {"NO_HOSTNAME", "SKIP/ERROR"}:
                row["overall"] = cable_status
        return row

    @staticmethod
    def _local_day_bounds_utc(day: date) -> tuple[str, str]:
        local_tz = datetime.now().astimezone().tzinfo
        start_local = datetime.combine(day, time.min, tzinfo=local_tz)
        end_local = start_local + timedelta(days=1)
        return (
            start_local.astimezone(timezone.utc).isoformat(),
            end_local.astimezone(timezone.utc).isoformat(),
        )

    def _oob_analysis_summary(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT
                o.id, o.name, o.host, o.ssh_port, o.vendor, o.enabled,
                o.connection_revision, o.baseline_revision,
                o.baseline_stale_reason, o.baseline_stale_at,
                o.current_profile_fingerprint, o.baseline_profile_fingerprint,
                COUNT(DISTINCT s.id) AS total_scan_count,
                COUNT(DISTINCT CASE WHEN s.status='SUCCESS' THEN s.id END) AS success_scan_count,
                COUNT(DISTINCT CASE WHEN s.status='PARTIAL' THEN s.id END) AS partial_scan_count,
                COUNT(DISTINCT CASE WHEN s.status='FAILED' THEN s.id END) AS failed_scan_count,
                COUNT(DISTINCT CASE WHEN s.status='REJECTED' THEN s.id END) AS rejected_scan_count,
                COUNT(DISTINCT CASE WHEN s.mapping_quality='ACCEPTED' THEN s.id END) AS accepted_mapping_scan_count,
                (SELECT COUNT(*) FROM console_targets t WHERE t.oob_id=o.id) AS current_target_count,
                (SELECT COUNT(*) FROM console_targets t WHERE t.oob_id=o.id AND t.is_complete=0) AS current_incomplete_count,
                (SELECT COUNT(*) FROM change_events e WHERE e.oob_id=o.id) AS total_change_count,
                (SELECT MAX(e.detected_at) FROM change_events e WHERE e.oob_id=o.id) AS last_change_at,
                (SELECT MAX(x.finished_at) FROM scan_runs x WHERE x.oob_id=o.id AND x.mapping_quality='ACCEPTED') AS last_accepted_mapping_at,
                (SELECT MAX(x.finished_at) FROM scan_runs x WHERE x.oob_id=o.id AND x.status IN ('FAILED','REJECTED')) AS last_problem_at,
                (SELECT x.status FROM scan_runs x WHERE x.oob_id=o.id ORDER BY x.id DESC LIMIT 1) AS latest_scan_status,
                (SELECT x.mapping_quality FROM scan_runs x WHERE x.oob_id=o.id ORDER BY x.id DESC LIMIT 1) AS latest_mapping_quality
            FROM oob_devices o
            LEFT JOIN scan_runs s ON s.oob_id=o.id
            GROUP BY o.id
            ORDER BY o.name COLLATE NOCASE
            """
        ).fetchall()
        result: list[dict[str, object]] = []
        for row in rows:
            total_scans = int(row["total_scan_count"] or 0)
            success_scans = int(row["success_scan_count"] or 0)
            stale = self._row_mapping_stale(row)
            result.append({
                "oob_id": row["id"],
                "oob_name": row["name"],
                "oob_host": row["host"],
                "oob_ssh_port": row["ssh_port"],
                "oob_address": f"{row['host']}:{row['ssh_port']}",
                "vendor_code": row["vendor"],
                "enabled": row["enabled"],
                "enabled_label_vi": "Đang bật" if row["enabled"] else "Đã tắt",
                "connection_revision": row["connection_revision"],
                "baseline_revision": row["baseline_revision"],
                "current_profile_fingerprint": row["current_profile_fingerprint"],
                "baseline_profile_fingerprint": row["baseline_profile_fingerprint"],
                "mapping_stale": int(stale),
                "mapping_stale_label_vi": "Cần scan lại" if stale else "Hợp lệ",
                "baseline_stale_reason": row["baseline_stale_reason"],
                "baseline_stale_at_utc": row["baseline_stale_at"],
                "baseline_stale_at_local": self._local_datetime(row["baseline_stale_at"]),
                "total_scan_count": total_scans,
                "success_scan_count": success_scans,
                "partial_scan_count": row["partial_scan_count"],
                "failed_scan_count": row["failed_scan_count"],
                "rejected_scan_count": row["rejected_scan_count"],
                "accepted_mapping_scan_count": row["accepted_mapping_scan_count"],
                "success_rate": round(success_scans / total_scans, 4) if total_scans else 0,
                "success_rate_percent": round(success_scans * 100 / total_scans, 2) if total_scans else 0,
                "current_target_count": row["current_target_count"],
                "current_incomplete_count": row["current_incomplete_count"],
                "total_change_count": row["total_change_count"],
                "latest_scan_status_code": row["latest_scan_status"] or "",
                "latest_scan_status_vi": STATUS_LABELS_VI.get(row["latest_scan_status"], row["latest_scan_status"] or "Chưa quét"),
                "latest_mapping_quality": row["latest_mapping_quality"] or "",
                "last_accepted_mapping_at_utc": row["last_accepted_mapping_at"],
                "last_accepted_mapping_at_local": self._local_datetime(row["last_accepted_mapping_at"]),
                "last_problem_at_utc": row["last_problem_at"],
                "last_problem_at_local": self._local_datetime(row["last_problem_at"]),
                "last_change_at_utc": row["last_change_at"],
                "last_change_at_local": self._local_datetime(row["last_change_at"]),
            })
        return result

    def _oob_devices(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT o.*,
                   ls.id AS latest_scan_id, ls.status AS latest_scan_status,
                   ls.mapping_quality AS latest_mapping_quality,
                   ls.baseline_updated AS latest_baseline_updated,
                   ls.finished_at AS latest_scan_finished_at,
                   ls.mapping_count AS latest_mapping_count,
                   ls.complete_ratio AS latest_complete_ratio,
                   (SELECT COUNT(*) FROM console_targets t WHERE t.oob_id=o.id) AS current_target_count
            FROM oob_devices o
            LEFT JOIN scan_runs ls ON ls.id=(
                SELECT s.id FROM scan_runs s WHERE s.oob_id=o.id ORDER BY s.id DESC LIMIT 1
            )
            ORDER BY o.name COLLATE NOCASE
            """
        ).fetchall()
        result = []
        for row in rows:
            stale = self._row_mapping_stale(row)
            result.append({
                "oob_id": row["id"], "oob_name": row["name"], "oob_host": row["host"],
                "ssh_port": row["ssh_port"], "oob_address": f"{row['host']}:{row['ssh_port']}",
                "vendor_code": row["vendor"], "device_type": row["device_type"],
                "connection_mode_code": row["connection_mode"], "enabled": row["enabled"],
                "enabled_label_vi": "Đang bật" if row["enabled"] else "Đã tắt",
                "default_username": row["default_username"], "notes": row["notes"],
                "connection_revision": row["connection_revision"], "baseline_revision": row["baseline_revision"],
                "current_profile_fingerprint": row["current_profile_fingerprint"],
                "baseline_profile_fingerprint": row["baseline_profile_fingerprint"],
                "mapping_stale": int(stale), "mapping_stale_label_vi": "Cần scan lại" if stale else "Hợp lệ",
                "baseline_stale_reason": row["baseline_stale_reason"],
                "baseline_stale_at_utc": row["baseline_stale_at"],
                "baseline_stale_at_local": self._local_datetime(row["baseline_stale_at"]),
                "created_at_utc": row["created_at"], "created_at_local": self._local_datetime(row["created_at"]),
                "updated_at_utc": row["updated_at"], "updated_at_local": self._local_datetime(row["updated_at"]),
                "last_scan_at_utc": row["last_scan_at"], "last_scan_at_local": self._local_datetime(row["last_scan_at"]),
                "latest_scan_id": row["latest_scan_id"],
                "latest_scan_status_code": row["latest_scan_status"] or "",
                "latest_scan_status_vi": STATUS_LABELS_VI.get(row["latest_scan_status"], row["latest_scan_status"] or "Chưa quét"),
                "latest_mapping_quality": row["latest_mapping_quality"] or "",
                "latest_baseline_updated": row["latest_baseline_updated"] or 0,
                "latest_scan_finished_at_utc": row["latest_scan_finished_at"],
                "latest_scan_finished_at_local": self._local_datetime(row["latest_scan_finished_at"]),
                "latest_mapping_count": row["latest_mapping_count"] or 0,
                "latest_complete_ratio": row["latest_complete_ratio"] or 0,
                "current_target_count": row["current_target_count"],
            })
        return result

    def _console_targets(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT t.*, o.name AS oob_name, o.host AS oob_host, o.ssh_port AS oob_ssh_port,
                   o.vendor, o.connection_revision, o.baseline_revision,
                   o.baseline_stale_reason, o.current_profile_fingerprint,
                   o.baseline_profile_fingerprint, s.status AS last_scan_status,
                   s.mapping_quality AS last_mapping_quality
            FROM console_targets t
            JOIN oob_devices o ON o.id=t.oob_id
            LEFT JOIN scan_runs s ON s.id=t.last_scan_id
            ORDER BY o.name COLLATE NOCASE, t.menu_name COLLATE NOCASE, t.menu_item, t.alias COLLATE NOCASE
            """
        ).fetchall()
        result = []
        for row in rows:
            stale = self._row_mapping_stale(row)
            result.append({
                "target_id": row["id"], "oob_id": row["oob_id"], "oob_name": row["oob_name"],
                "oob_host": row["oob_host"], "oob_ssh_port": row["oob_ssh_port"],
                "oob_address": f"{row['oob_host']}:{row['oob_ssh_port']}", "vendor_code": row["vendor"],
                "menu_name": row["menu_name"], "menu_item": row["menu_item"],
                "alias": row["alias"], "configured_alias": row["alias"],
                "protocol_code": row["protocol"],
                "target_host": row["target_host"], "target_port": row["target_port"],
                "target_endpoint": self._endpoint(row["target_host"], row["target_port"]),
                "console_endpoint_host": row["target_host"], "console_endpoint_port": row["target_port"],
                "console_endpoint": self._endpoint(row["target_host"], row["target_port"]),
                "console_line": row["console_line"], "console_line_source": row["console_line_source"],
                "state_code": row["state"], "state_label_vi": STATE_LABELS_VI.get(row["state"], row["state"]),
                "state_confident": row["state_confident"],
                "state_confident_label_vi": "Có" if row["state_confident"] else "Không",
                "state_reason_code": row["state_reason_code"], "state_evidence_json": row["state_evidence"],
                "session_user": row["session_user"],
                "mapping_stale": int(stale), "mapping_stale_label_vi": "Cần scan lại" if stale else "Hợp lệ",
                "current_profile_fingerprint": row["current_profile_fingerprint"],
                "baseline_profile_fingerprint": row["baseline_profile_fingerprint"],
                "baseline_stale_reason": row["baseline_stale_reason"], "source": row["source"],
                "mapping_source_command": row["mapping_source_command"],
                "mapping_text_line": row["mapping_text_line"], "mapping_text_line_no": row["mapping_text_line_no"],
                "mapping_command_line": row["mapping_command_line"], "mapping_command_line_no": row["mapping_command_line_no"],
                "is_complete": row["is_complete"], "is_complete_label_vi": "Đầy đủ" if row["is_complete"] else "Thiếu dữ liệu",
                "command": row["command"], "first_seen_at_utc": row["first_seen_at"],
                "first_seen_at_local": self._local_datetime(row["first_seen_at"]),
                "last_seen_at_utc": row["last_seen_at"], "last_seen_at_local": self._local_datetime(row["last_seen_at"]),
                "last_scan_id": row["last_scan_id"], "last_scan_status_code": row["last_scan_status"] or "",
                "last_scan_status_vi": STATUS_LABELS_VI.get(row["last_scan_status"], row["last_scan_status"] or ""),
                "last_mapping_quality": row["last_mapping_quality"] or "",
            })
        return result

    def _console_snapshots(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT p.*, s.status AS scan_status, s.mapping_quality,
                   s.finished_at AS scan_finished_at,
                   s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                   s.vendor_at_scan, s.connection_mode_at_scan, s.connection_revision,
                   s.profile_fingerprint, s.config_snapshot_source
            FROM console_snapshots p
            JOIN scan_runs s ON s.id=p.scan_id
            ORDER BY p.scan_id DESC, p.menu_name COLLATE NOCASE, p.menu_item, p.alias COLLATE NOCASE
            """
        ).fetchall()
        return [{
            "snapshot_id": row["id"], "scan_id": row["scan_id"],
            "scan_status_code": row["scan_status"], "scan_status_vi": STATUS_LABELS_VI.get(row["scan_status"], row["scan_status"]),
            "mapping_quality": row["mapping_quality"],
            "scan_finished_at_utc": row["scan_finished_at"], "scan_finished_at_local": self._local_datetime(row["scan_finished_at"]),
            "target_id": row["target_id"], "oob_id": row["oob_id"], "oob_name_at_scan": row["oob_name_at_scan"],
            "oob_host_at_scan": row["oob_host_at_scan"], "oob_ssh_port_at_scan": row["oob_ssh_port_at_scan"],
            "oob_address_at_scan": self._endpoint(row["oob_host_at_scan"], row["oob_ssh_port_at_scan"]),
            "vendor_at_scan": row["vendor_at_scan"], "connection_mode_at_scan": row["connection_mode_at_scan"],
            "connection_revision": row["connection_revision"], "profile_fingerprint": row["profile_fingerprint"],
            "config_snapshot_source": row["config_snapshot_source"],
            "menu_name": row["menu_name"], "menu_item": row["menu_item"],
            "alias": row["alias"], "configured_alias": row["alias"],
            "command": row["command"], "protocol_code": row["protocol"], "target_host": row["target_host"],
            "target_port": row["target_port"], "target_endpoint": self._endpoint(row["target_host"], row["target_port"]),
            "console_endpoint_host": row["target_host"], "console_endpoint_port": row["target_port"],
            "console_endpoint": self._endpoint(row["target_host"], row["target_port"]),
            "console_line": row["console_line"], "console_line_source": row["console_line_source"],
            "state_code": row["state"], "state_label_vi": STATE_LABELS_VI.get(row["state"], row["state"]),
            "state_confident": row["state_confident"], "state_confident_label_vi": "Có" if row["state_confident"] else "Không",
            "state_reason_code": row["state_reason_code"], "state_evidence_json": row["state_evidence"],
            "session_user": row["session_user"], "source": row["source"],
            "mapping_source_command": row["mapping_source_command"],
            "mapping_text_line": row["mapping_text_line"], "mapping_text_line_no": row["mapping_text_line_no"],
            "mapping_command_line": row["mapping_command_line"], "mapping_command_line_no": row["mapping_command_line_no"],
            "is_complete": row["is_complete"], "is_complete_label_vi": "Đầy đủ" if row["is_complete"] else "Thiếu dữ liệu",
            "captured_at_utc": row["captured_at"], "captured_at_local": self._local_datetime(row["captured_at"]),
        } for row in rows]

    def _scan_history(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT s.*,
                   (SELECT COUNT(*) FROM raw_outputs r WHERE r.scan_id=s.id) AS raw_command_count,
                   (SELECT COUNT(*) FROM raw_outputs r WHERE r.scan_id=s.id AND r.success=1) AS successful_command_count,
                   (SELECT COUNT(*) FROM raw_outputs r WHERE r.scan_id=s.id AND r.success=0) AS failed_command_count,
                   (SELECT COUNT(*) FROM raw_outputs r WHERE r.scan_id=s.id AND r.is_core=1) AS core_command_count,
                   (SELECT COUNT(*) FROM raw_outputs r WHERE r.scan_id=s.id AND r.is_core=0) AS supporting_command_count,
                   (SELECT COUNT(*) FROM console_snapshots p WHERE p.scan_id=s.id) AS snapshot_target_count,
                   (SELECT COUNT(*) FROM scan_findings f WHERE f.scan_id=s.id) AS finding_count
            FROM scan_runs s
            ORDER BY s.id DESC
            """
        ).fetchall()
        result = []
        for row in rows:
            result.append({
                "scan_id": row["id"], "oob_id": row["oob_id"],
                "oob_name_at_scan": row["oob_name_at_scan"], "oob_host_at_scan": row["oob_host_at_scan"],
                "oob_ssh_port_at_scan": row["oob_ssh_port_at_scan"],
                "oob_address_at_scan": self._endpoint(row["oob_host_at_scan"], row["oob_ssh_port_at_scan"]),
                "vendor_at_scan": row["vendor_at_scan"], "connection_mode_at_scan": row["connection_mode_at_scan"],
                "device_type_at_scan": row["device_type_at_scan"], "connection_revision": row["connection_revision"],
                "profile_fingerprint": row["profile_fingerprint"],
                "profile_snapshot_json": row["profile_snapshot_json"],
                "scan_policy_snapshot_json": row["scan_policy_snapshot_json"],
                "config_snapshot_source": row["config_snapshot_source"],
                "ssh_username_at_scan": row["ssh_username_at_scan"],
                "trigger_source": row["trigger_source"],
                "process_pid": row["process_pid"],
                "process_hostname": row["process_hostname"],
                "process_user": row["process_user"],
                "ssh_host_key_algorithm": row["ssh_host_key_algorithm"],
                "ssh_host_key_fingerprint": row["ssh_host_key_fingerprint"],
                "ssh_host_key_policy": row["ssh_host_key_policy"],
                "started_at_utc": row["started_at"], "started_at_local": self._local_datetime(row["started_at"]),
                "finished_at_utc": row["finished_at"], "finished_at_local": self._local_datetime(row["finished_at"]),
                "duration_seconds": self._duration_seconds(row["started_at"], row["finished_at"]),
                "status_code": row["status"], "status_label_vi": STATUS_LABELS_VI.get(row["status"], row["status"]),
                "mapping_quality": row["mapping_quality"], "baseline_updated": row["baseline_updated"],
                "baseline_updated_label_vi": "Có" if row["baseline_updated"] else "Không",
                "mapping_count": row["mapping_count"], "complete_count": row["complete_count"],
                "complete_ratio": row["complete_ratio"], "change_count": row["change_count"], "warning_count": row["warning_count"],
                "finding_count": row["finding_count"], "snapshot_target_count": row["snapshot_target_count"],
                "raw_command_count": row["raw_command_count"], "core_command_count": row["core_command_count"],
                "supporting_command_count": row["supporting_command_count"],
                "successful_command_count": row["successful_command_count"], "failed_command_count": row["failed_command_count"],
                "error_code": row["error_code"], "error_message": row["error_message"], "scanner_version": row["scanner_version"],
            })
        return result

    def _scan_findings(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT f.*, s.oob_id, s.status AS scan_status, s.mapping_quality,
                   s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                   s.vendor_at_scan, s.config_snapshot_source
            FROM scan_findings f JOIN scan_runs s ON s.id=f.scan_id
            ORDER BY f.scan_id DESC, f.id
            """
        ).fetchall()
        return [{
            "finding_id": row["id"], "scan_id": row["scan_id"], "oob_id": row["oob_id"],
            "oob_name_at_scan": row["oob_name_at_scan"], "oob_host_at_scan": row["oob_host_at_scan"],
            "oob_ssh_port_at_scan": row["oob_ssh_port_at_scan"],
            "oob_address_at_scan": self._endpoint(row["oob_host_at_scan"], row["oob_ssh_port_at_scan"]),
            "vendor_at_scan": row["vendor_at_scan"], "config_snapshot_source": row["config_snapshot_source"],
            "scan_status_code": row["scan_status"], "mapping_quality": row["mapping_quality"],
            "finding_type": row["finding_type"], "severity": row["severity"], "code": row["code"],
            "source": row["source"], "message": row["message"],
            "created_at_utc": row["created_at"], "created_at_local": self._local_datetime(row["created_at"]),
        } for row in rows]

    def _raw_outputs(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT r.*, s.oob_id, s.status AS scan_status, s.mapping_quality,
                   s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                   s.vendor_at_scan, s.config_snapshot_source
            FROM raw_outputs r JOIN scan_runs s ON s.id=r.scan_id
            ORDER BY r.scan_id DESC, r.id
            """
        ).fetchall()
        result = []
        for row in rows:
            raw_output = row["raw_output"] or ""
            calculated_hash = hashlib.sha256(raw_output.encode("utf-8")).hexdigest()
            calculated_length = len(raw_output)
            result.append({
                "raw_output_id": row["id"], "scan_id": row["scan_id"], "oob_id": row["oob_id"],
                "oob_name_at_scan": row["oob_name_at_scan"], "oob_host_at_scan": row["oob_host_at_scan"],
                "oob_ssh_port_at_scan": row["oob_ssh_port_at_scan"],
                "oob_address_at_scan": self._endpoint(row["oob_host_at_scan"], row["oob_ssh_port_at_scan"]),
                "vendor_at_scan": row["vendor_at_scan"], "config_snapshot_source": row["config_snapshot_source"],
                "scan_status_code": row["scan_status"], "mapping_quality": row["mapping_quality"],
                "command_name": row["command_name"], "command_text": row["command_text"],
                "is_core": row["is_core"], "data_role": "CORE_MAPPING" if row["is_core"] else "SUPPORTING_TELEMETRY",
                "redaction_applied": row["redaction_applied"],
                "redaction_applied_label_vi": "Có" if row["redaction_applied"] else "Không",
                "success": row["success"], "success_label_vi": "Thành công" if row["success"] else "Thất bại",
                "error_message": row["error_message"],
                "raw_output_length": calculated_length, "raw_output_sha256": calculated_hash,
                "stored_output_length": row["stored_output_length"], "calculated_output_length": calculated_length,
                "stored_output_sha256": row["stored_output_sha256"], "calculated_output_sha256": calculated_hash,
                "output_integrity_ok": int(row["stored_output_length"] == calculated_length and row["stored_output_sha256"] == calculated_hash),
                "raw_output_truncated": int(calculated_length > MAX_RAW_OUTPUT_CSV_CHARS),
                "raw_output_truncated_label_vi": "Có" if calculated_length > MAX_RAW_OUTPUT_CSV_CHARS else "Không",
                "raw_output_preview": raw_output[:MAX_RAW_OUTPUT_CSV_CHARS],
                "created_at_utc": row["created_at"], "created_at_local": self._local_datetime(row["created_at"]),
            })
        return result

    def _change_events(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT e.*, s.oob_name_at_scan, s.oob_host_at_scan, s.oob_ssh_port_at_scan,
                   s.vendor_at_scan, s.connection_revision, s.config_snapshot_source
            FROM change_events e JOIN scan_runs s ON s.id=e.scan_id
            ORDER BY e.id DESC
            """
        ).fetchall()
        result = []
        for row in rows:
            old_data = self._parse_json_object(row["old_data"])
            new_data = self._parse_json_object(row["new_data"])
            result.append({
                "event_id": row["id"], "scan_id": row["scan_id"], "oob_id": row["oob_id"],
                "oob_name_at_scan": row["oob_name_at_scan"], "oob_host_at_scan": row["oob_host_at_scan"],
                "oob_ssh_port_at_scan": row["oob_ssh_port_at_scan"], "vendor_at_scan": row["vendor_at_scan"],
                "connection_revision": row["connection_revision"], "config_snapshot_source": row["config_snapshot_source"],
                "detected_at_utc": row["detected_at"], "detected_at_local": self._local_datetime(row["detected_at"]),
                "event_code": row["event_code"], "event_label_vi": EVENT_LABELS_VI.get(row["event_code"], row["event_code"]),
                "target_identity": row["target_identity"], "changed_fields": ",".join(self._changed_fields(old_data, new_data)),
                "old_target_id": old_data.get("target_id"), "new_target_id": new_data.get("target_id"),
                "old_alias": old_data.get("alias", ""), "new_alias": new_data.get("alias", ""),
                "old_menu_name": old_data.get("menu_name", ""), "new_menu_name": new_data.get("menu_name", ""),
                "old_menu_item": old_data.get("menu_item"), "new_menu_item": new_data.get("menu_item"),
                "old_target_host": old_data.get("target_host", ""), "new_target_host": new_data.get("target_host", ""),
                "old_target_port": old_data.get("target_port"), "new_target_port": new_data.get("target_port"),
                "old_endpoint": self._endpoint(old_data.get("target_host", ""), old_data.get("target_port", 0)),
                "new_endpoint": self._endpoint(new_data.get("target_host", ""), new_data.get("target_port", 0)),
                "old_console_line": old_data.get("console_line"), "new_console_line": new_data.get("console_line"),
                "old_console_line_source": old_data.get("console_line_source", ""),
                "new_console_line_source": new_data.get("console_line_source", ""),
                "old_state": old_data.get("state", ""), "new_state": new_data.get("state", ""),
                "old_state_reason_code": old_data.get("state_reason_code", ""),
                "new_state_reason_code": new_data.get("state_reason_code", ""),
                "old_protocol": old_data.get("protocol", ""), "new_protocol": new_data.get("protocol", ""),
                "old_command": old_data.get("command", ""), "new_command": new_data.get("command", ""),
                "old_data_json": row["old_data"] or "", "new_data_json": row["new_data"] or "",
            })
        return result

    def _connection_history(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT h.*, t.alias AS current_target_alias
            FROM connection_history h
            LEFT JOIN console_targets t ON t.id=h.target_id
            ORDER BY h.id DESC
            """
        ).fetchall()
        return [{
            "connection_id": row["id"], "oob_id": row["oob_id"],
            "oob_name_at_connection": row["oob_name_at_connection"], "oob_host_at_connection": row["oob_host_at_connection"],
            "oob_ssh_port_at_connection": row["oob_ssh_port_at_connection"],
            "oob_address_at_connection": self._endpoint(row["oob_host_at_connection"], row["oob_ssh_port_at_connection"]),
            "vendor_at_connection": row["vendor_at_connection"], "connection_mode_at_connection": row["connection_mode_at_connection"],
            "connection_revision": row["connection_revision"], "baseline_revision": row["baseline_revision"],
            "config_snapshot_source": row["config_snapshot_source"], "target_id": row["target_id"],
            "target_alias_at_connection": row["target_alias"], "current_target_alias": row["current_target_alias"] or "",
            "target_host_at_connection": row["target_host"], "target_port_at_connection": row["target_port"],
            "target_endpoint_at_connection": self._endpoint(row["target_host"], row["target_port"]),
            "target_command_at_connection": row["target_command"], "console_line_at_connection": row["console_line"],
            "menu_name_at_connection": row["menu_name"], "menu_item_at_connection": row["menu_item"],
            "mapping_last_scan_id": row["mapping_last_scan_id"], "username": row["username"],
            "started_at_utc": row["started_at"], "started_at_local": self._local_datetime(row["started_at"]),
            "ended_at_utc": row["ended_at"], "ended_at_local": self._local_datetime(row["ended_at"]),
            "duration_seconds": self._duration_seconds(row["started_at"], row["ended_at"]),
            "status_code": row["status"], "status_label_vi": CONNECTION_STATUS_LABELS_VI.get(row["status"], row["status"]),
            "error_code": row["error_code"], "error_message": row["error_message"],
            "console_path_verified": row["console_path_verified"], "console_path_verified_label_vi": "Có" if row["console_path_verified"] else "Chưa xác minh",
            "path_verification_code": row["path_verification_code"], "path_verification_message": row["path_verification_message"],
            "runtime_menu_verified": row["runtime_menu_verified"],
            "runtime_menu_verified_label_vi": "Có" if row["runtime_menu_verified"] else "Không/không áp dụng",
            "runtime_mapping_verified": row["runtime_mapping_verified"],
            "runtime_mapping_verified_label_vi": "Đã xác minh" if row["runtime_mapping_verified"] else "Chưa xác minh",
            "runtime_mapping_verification_code": row["runtime_mapping_verification_code"],
            "runtime_mapping_verification_message": row["runtime_mapping_verification_message"],
            "live_state_code": row["live_state"],
            "live_state_label_vi": STATE_LABELS_VI.get(row["live_state"], row["live_state"]),
            "live_state_confident": row["live_state_confident"],
            "live_state_confident_label_vi": "Có" if row["live_state_confident"] else "Không",
            "live_session_user": row["live_session_user"],
            "live_state_reason_code": row["live_state_reason_code"],
            "live_state_evidence_json": row["live_state_evidence"],
            "live_state_checked_at_utc": row["live_state_checked_at"],
            "live_state_checked_at_local": self._local_datetime(row["live_state_checked_at"]),
            "downstream_identity_verified": row["downstream_identity_verified"],
            "downstream_identity_verified_label_vi": "Đã xác minh" if row["downstream_identity_verified"] else "Chưa xác minh",
            "downstream_identity_method": row["downstream_identity_method"],
            "downstream_identity_value": row["downstream_identity_value"],
            "process_pid": row["process_pid"], "process_hostname": row["process_hostname"],
            "process_user": row["process_user"],
            "safety_override_requested": row["safety_override_requested"],
            "safety_override_used": row["safety_override_used"],
            "safety_override_reason": row["safety_override_reason"],
            "clear_line_recovery_requested": row["clear_line_recovery_requested"],
            "clear_line_recovery_used": row["clear_line_recovery_used"],
            "clear_line_number": row["clear_line_number"],
            "clear_line_reason": row["clear_line_reason"],
            "clear_line_result": row["clear_line_result"],
            "session_log_path": row["session_log_path"],
            "ssh_host_key_algorithm": row["ssh_host_key_algorithm"],
            "ssh_host_key_fingerprint": row["ssh_host_key_fingerprint"],
            "ssh_host_key_policy": row["ssh_host_key_policy"],
        } for row in rows]


    def _reconciliation_history(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT r.*, o.name AS oob_name, o.host AS oob_host,
                   o.ssh_port AS oob_ssh_port
            FROM oob_reconciliation_history r
            JOIN oob_devices o ON o.id=r.oob_id
            ORDER BY r.id DESC
            """
        ).fetchall()
        return [{
            "reconciliation_id": row["id"],
            "oob_id": row["oob_id"],
            "oob_name": row["oob_name"],
            "oob_host": row["oob_host"],
            "oob_ssh_port": row["oob_ssh_port"],
            "target_id": row["target_id"],
            "identity_run_id": row["identity_run_id"],
            "vendor": row["vendor"],
            "operator_username": row["operator_username"],
            "ticket_id": row["ticket_id"],
            "reason": row["reason"],
            "old_alias": row["old_alias"],
            "new_alias": row["new_alias"],
            "physical_path": row["physical_path"],
            "proposed_commands": row["proposed_commands"],
            "applied_commands": row["applied_commands"],
            "status": row["status"],
            "started_at_utc": row["started_at"],
            "started_at_local": self._local_datetime(row["started_at"]),
            "finished_at_utc": row["finished_at"],
            "finished_at_local": self._local_datetime(row["finished_at"]),
            "verification_code": row["verification_code"],
            "verification_message": row["verification_message"],
            "rollback_attempted": row["rollback_attempted"],
            "rollback_succeeded": row["rollback_succeeded"],
            "error_code": row["error_code"],
            "error_message": row["error_message"],
            "baseline_refresh_status": row["baseline_refresh_status"],
            "process_pid": row["process_pid"],
            "process_hostname": row["process_hostname"],
            "process_user": row["process_user"],
        } for row in rows]

    def _oob_change_history(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT * FROM oob_change_history
            ORDER BY id DESC
            """
        ).fetchall()
        return [{
            "change_id": row["id"],
            "oob_id": row["oob_id"],
            "oob_name": row["oob_name"],
            "changed_at_utc": row["changed_at"],
            "changed_at_local": self._local_datetime(row["changed_at"]),
            "change_type": row["change_type"],
            "changed_fields": row["changed_fields"],
            "old_data_json": row["old_data"],
            "new_data_json": row["new_data"],
            "source": row["source"],
            "process_pid": row["process_pid"],
            "process_hostname": row["process_hostname"],
            "process_user": row["process_user"],
        } for row in rows]

    @staticmethod
    def _device_identity_raw_outputs(conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            """
            SELECT x.*, r.oob_id, r.target_id, r.target_alias_at_run, r.actual_hostname,
                   r.detected_vendor, r.identity_quality, r.identity_confidence
            FROM device_identity_raw_outputs x
            JOIN device_identity_runs r ON r.id=x.identity_run_id
            ORDER BY x.identity_run_id DESC, x.id
            """
        ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _cable_check_runs(conn: sqlite3.Connection) -> list[dict[str, object]]:
        return [dict(row) for row in conn.execute("SELECT * FROM cable_check_runs ORDER BY id DESC").fetchall()]

    @staticmethod
    def _cable_check_results(conn: sqlite3.Connection) -> list[dict[str, object]]:
        return [dict(row) for row in conn.execute("SELECT * FROM cable_check_results ORDER BY run_id DESC, id").fetchall()]

    @staticmethod
    def _device_identity_snapshots(conn: sqlite3.Connection) -> list[dict[str, object]]:
        rows = conn.execute(
            "SELECT * FROM device_identity_snapshots ORDER BY identity_run_id DESC, id"
        ).fetchall()
        return [dict(row) for row in rows]

    def _data_quality_issues(self, conn: sqlite3.Connection) -> list[dict[str, object]]:
        return DatabaseAuditService.collect_issues(conn)

    @staticmethod
    def _audit_view_rows(conn: sqlite3.Connection, view_name: str, order_by: str) -> list[dict[str, object]]:
        allowed = {
            "v_current_target_source_trace",
            "v_snapshot_source_trace",
            "v_scan_command_audit",
            "v_connection_trace",
            "v_current_device_identity",
            "v_device_identity_trace",
            "v_device_identity_events",
        }
        if view_name not in allowed:
            raise ValueError("Audit view không được phép export.")
        rows = conn.execute(f"SELECT * FROM {view_name} ORDER BY {order_by}").fetchall()
        return [dict(row) for row in rows]

    def _manifest_from_files(
        self,
        export_dir: Path,
        datasets: Mapping[str, list[dict[str, object]]],
        *,
        database_version: int,
        extra_files: list[str],
    ) -> list[dict[str, object]]:
        exported_at = utc_now()
        rows: list[dict[str, object]] = []
        for filename in [*datasets.keys(), *extra_files]:
            path = export_dir / filename
            data = path.read_bytes()
            rows.append({
                "exported_at_utc": exported_at.isoformat(),
                "exported_at_local": exported_at.astimezone().isoformat(),
                "schema_version_expected": SCHEMA_VERSION,
                "schema_version_database": database_version,
                "file_name": filename,
                "row_count": len(datasets.get(filename, [])) if filename in datasets else "",
                "file_size_bytes": len(data),
                "file_sha256": hashlib.sha256(data).hexdigest(),
                "encoding": self.settings.export_encoding if filename.endswith(".csv") else "utf-8-sig",
                "delimiter": "," if filename.endswith(".csv") else "",
            })
        return rows

    def _write_dict_rows(self, path: Path, rows: Iterable[Mapping[str, object]]) -> None:
        row_list = list(rows)
        headers = list(row_list[0].keys()) if row_list else self._empty_headers(path.name)
        temporary_path = path.with_suffix(path.suffix + ".tmp")
        with temporary_path.open("w", newline="", encoding=self.settings.export_encoding) as file_handle:
            writer = csv.DictWriter(file_handle, fieldnames=headers, extrasaction="ignore", lineterminator="\n")
            writer.writeheader()
            for row in row_list:
                writer.writerow({key: self._csv_safe(value) for key, value in row.items()})
            file_handle.flush()
            os.fsync(file_handle.fileno())
        os.replace(temporary_path, path)

    @staticmethod
    def _csv_safe(value: object) -> object:
        if value is None:
            return ""
        if not isinstance(value, str):
            return value
        cleaned = " ".join(value.replace("\x00", "").splitlines()).strip()
        if cleaned.startswith(("=", "+", "-", "@", "\t")):
            return "'" + cleaned
        return cleaned

    @staticmethod
    def _parse_json_object(value: str | None) -> dict[str, object]:
        if not value:
            return {}
        try:
            parsed = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return {}
        return parsed if isinstance(parsed, dict) else {}

    @staticmethod
    def _changed_fields(old_data: Mapping[str, object], new_data: Mapping[str, object]) -> list[str]:
        keys = sorted(set(old_data) | set(new_data))
        return [key for key in keys if old_data.get(key) != new_data.get(key)]

    @staticmethod
    def _endpoint(host: object, port: object) -> str:
        if not host:
            return ""
        return f"{host}:{port}" if port else str(host)

    @staticmethod
    def _row_mapping_stale(row: sqlite3.Row) -> bool:
        keys = set(row.keys())
        connection_stale = row["connection_revision"] != row["baseline_revision"]
        profile_stale = bool(
            "baseline_profile_fingerprint" in keys
            and row["baseline_profile_fingerprint"]
            and row["current_profile_fingerprint"]
            != row["baseline_profile_fingerprint"]
        )
        return connection_stale or profile_stale

    @staticmethod
    def _local_datetime(value: str | None) -> str:
        if not value:
            return ""
        try:
            return datetime.fromisoformat(value).astimezone().isoformat(timespec="seconds")
        except ValueError:
            return value

    @staticmethod
    def _duration_seconds(start_value: str | None, end_value: str | None) -> int | str:
        if not start_value or not end_value:
            return ""
        try:
            duration = datetime.fromisoformat(end_value) - datetime.fromisoformat(start_value)
            return max(0, int(duration.total_seconds()))
        except ValueError:
            return ""

    @staticmethod
    def _empty_headers(filename: str) -> list[str]:
        # Giữ header ngay cả khi DB chưa có dữ liệu để Excel/Power BI import ổn định.
        if filename == "cable_verification.csv":
            return [
                "detected_at","oob","vendor","port","device_a","device_b","status",
                "evidence_source","target_id","target_alias","console_path",
                "runtime_mapping_verified","runtime_mapping_verification_code",
                "runtime_mapping_verification_message","live_state","live_state_confident",
                "live_state_reason_code","live_state_evidence","live_state_checked_at",
                "error_code","message",
            ]
        if filename == "cable_mismatch.csv":
            return [
                "port","device_a","device_b","detected_at","oob","vendor",
                "console_path","evidence_source",
            ]
        if filename.startswith("daily_inventory_") and filename.endswith(".csv"):
            return [
                "date","scan_time","scan_id","oob","oob_vendor","target_alias","console_path","state",
                "mapping_complete","actual_hostname","device_vendor","model","serial","version","identity",
                "alias_check","overall","identity_checked_at",
            ]
        headers = {
            "inventory.csv": [
                "date","scan_time","scan_id","oob","oob_vendor","target_alias","console_path","state",
                "mapping_complete","actual_hostname","device_vendor","model","serial","version","identity",
                "alias_check","overall","identity_checked_at",
            ],
            "scan_summary.csv": [
                "scan_id","oob_id","oob_name","vendor","started_at_utc","started_at_local",
                "finished_at_utc","finished_at_local","status","mapping_quality","baseline_updated",
                "mapping_count","complete_count","warning_count","change_count","error_code","error_message",
            ],
            "changes.csv": [
                "event_id","event_code","target_identity","old_data","new_data","detected_at",
            ],
            "inventory_summary.csv": [
                "oob","oob_vendor","target_alias","console_path","state","actual_hostname","device_b",
                "cable_status","cable_status_display","cable_freshness","cable_is_current",
                "cable_evidence_source","cable_checked_at","cable_run_id","cable_mapping_scan_id",
                "cable_run_status","cable_run_started_at","cable_run_finished_at","cable_total_count",
                "cable_match_count","cable_mismatch_count","cable_no_hostname_count","cable_skip_error_count",
                "cable_error_code","cable_message","cable_wake_count","cable_passive_wait_used",
                "cable_runtime_mapping_verified","cable_runtime_mapping_verification_code",
                "cable_runtime_mapping_verification_message","cable_live_state","cable_live_state_confident",
                "cable_live_state_reason_code","cable_live_state_evidence","cable_live_state_checked_at",
                "action_summary","full_identity_hostname","device_vendor","model","serial","version",
                "identity","identity_confidence","identity_source","identity_run_id","identity_run_status",
                "identity_error_code","identity_error_message","alias_check","overall","last_scan_at",
                "scan_status","mapping_quality","identity_checked_at","scan_id","target_id",
            ],
            "oob_analysis_summary.csv": [
                "oob_id","oob_name","oob_host","oob_ssh_port","oob_address","vendor_code","enabled","enabled_label_vi",
                "connection_revision","baseline_revision","current_profile_fingerprint","baseline_profile_fingerprint",
                "mapping_stale","mapping_stale_label_vi","baseline_stale_reason",
                "baseline_stale_at_utc","baseline_stale_at_local","total_scan_count","success_scan_count","partial_scan_count",
                "failed_scan_count","rejected_scan_count","accepted_mapping_scan_count","success_rate","success_rate_percent",
                "current_target_count","current_incomplete_count","total_change_count","latest_scan_status_code","latest_scan_status_vi",
                "latest_mapping_quality","last_accepted_mapping_at_utc","last_accepted_mapping_at_local","last_problem_at_utc",
                "last_problem_at_local","last_change_at_utc","last_change_at_local",
            ],
            "oob_devices.csv": [
                "oob_id","oob_name","oob_host","ssh_port","oob_address","vendor_code","device_type","connection_mode_code","enabled",
                "enabled_label_vi","default_username","notes","connection_revision","baseline_revision","current_profile_fingerprint",
                "baseline_profile_fingerprint","mapping_stale","mapping_stale_label_vi",
                "baseline_stale_reason","baseline_stale_at_utc","baseline_stale_at_local","created_at_utc","created_at_local","updated_at_utc",
                "updated_at_local","last_scan_at_utc","last_scan_at_local","latest_scan_id","latest_scan_status_code","latest_scan_status_vi",
                "latest_mapping_quality","latest_baseline_updated","latest_scan_finished_at_utc","latest_scan_finished_at_local",
                "latest_mapping_count","latest_complete_ratio","current_target_count",
            ],
            "console_targets.csv": [
                "target_id","oob_id","oob_name","oob_host","oob_ssh_port","oob_address","vendor_code","menu_name","menu_item","alias","configured_alias",
                "protocol_code","target_host","target_port","target_endpoint","console_endpoint_host","console_endpoint_port","console_endpoint","console_line","console_line_source","state_code","state_label_vi",
                "state_confident","state_confident_label_vi","state_reason_code","state_evidence_json","session_user","mapping_stale",
                "mapping_stale_label_vi","current_profile_fingerprint","baseline_profile_fingerprint","baseline_stale_reason","source","mapping_source_command","mapping_text_line","mapping_text_line_no","mapping_command_line","mapping_command_line_no",
                "is_complete","is_complete_label_vi","command","first_seen_at_utc","first_seen_at_local","last_seen_at_utc","last_seen_at_local",
                "last_scan_id","last_scan_status_code","last_scan_status_vi","last_mapping_quality",
            ],
            "console_snapshots.csv": [
                "snapshot_id","scan_id","scan_status_code","scan_status_vi","mapping_quality","scan_finished_at_utc","scan_finished_at_local",
                "target_id","oob_id","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","oob_address_at_scan","vendor_at_scan",
                "connection_mode_at_scan","connection_revision","profile_fingerprint","config_snapshot_source","menu_name","menu_item","alias","configured_alias","command",
                "protocol_code","target_host","target_port","target_endpoint","console_endpoint_host","console_endpoint_port","console_endpoint","console_line","console_line_source","state_code","state_label_vi",
                "state_confident","state_confident_label_vi","state_reason_code","state_evidence_json","session_user","source","mapping_source_command",
                "mapping_text_line","mapping_text_line_no","mapping_command_line","mapping_command_line_no","is_complete","is_complete_label_vi","captured_at_utc","captured_at_local",
            ],
            "scan_history.csv": [
                "scan_id","oob_id","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","oob_address_at_scan","vendor_at_scan",
                "connection_mode_at_scan","device_type_at_scan","connection_revision","profile_fingerprint","config_snapshot_source",
                "ssh_username_at_scan","trigger_source","process_pid","process_hostname","process_user",
                "ssh_host_key_algorithm","ssh_host_key_fingerprint","ssh_host_key_policy","started_at_utc",
                "started_at_local","finished_at_utc","finished_at_local","duration_seconds","status_code","status_label_vi","mapping_quality",
                "baseline_updated","baseline_updated_label_vi","mapping_count","complete_count","complete_ratio","change_count","warning_count",
                "finding_count","snapshot_target_count","raw_command_count","core_command_count","supporting_command_count","successful_command_count",
                "failed_command_count","error_code","error_message","scanner_version",
            ],
            "scan_findings.csv": [
                "finding_id","scan_id","oob_id","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","oob_address_at_scan",
                "vendor_at_scan","config_snapshot_source","scan_status_code","mapping_quality","finding_type","severity","code","source","message",
                "created_at_utc","created_at_local",
            ],
            "raw_outputs.csv": [
                "raw_output_id","scan_id","oob_id","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","oob_address_at_scan",
                "vendor_at_scan","config_snapshot_source","scan_status_code","mapping_quality","command_name","command_text","is_core","data_role",
                "redaction_applied","redaction_applied_label_vi","success","success_label_vi","error_message","raw_output_length","raw_output_sha256","stored_output_length","calculated_output_length","stored_output_sha256",
                "calculated_output_sha256","output_integrity_ok","raw_output_truncated","raw_output_truncated_label_vi","raw_output_preview",
                "created_at_utc","created_at_local",
            ],
            "change_events.csv": [
                "event_id","scan_id","oob_id","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","vendor_at_scan","connection_revision",
                "config_snapshot_source","detected_at_utc","detected_at_local","event_code","event_label_vi","target_identity","changed_fields",
                "old_target_id","new_target_id","old_alias","new_alias","old_menu_name","new_menu_name","old_menu_item","new_menu_item",
                "old_target_host","new_target_host","old_target_port","new_target_port","old_endpoint","new_endpoint","old_console_line",
                "new_console_line","old_console_line_source","new_console_line_source","old_state","new_state","old_state_reason_code",
                "new_state_reason_code","old_protocol","new_protocol","old_command","new_command","old_data_json","new_data_json",
            ],
            "connection_history.csv": [
                "connection_id","oob_id","oob_name_at_connection","oob_host_at_connection","oob_ssh_port_at_connection","oob_address_at_connection",
                "vendor_at_connection","connection_mode_at_connection","connection_revision","baseline_revision","config_snapshot_source","target_id",
                "target_alias_at_connection","current_target_alias","target_host_at_connection","target_port_at_connection","target_endpoint_at_connection",
                "target_command_at_connection","console_line_at_connection","menu_name_at_connection","menu_item_at_connection","mapping_last_scan_id",
                "username","started_at_utc","started_at_local","ended_at_utc","ended_at_local","duration_seconds","status_code","status_label_vi",
                "error_code","error_message","console_path_verified","console_path_verified_label_vi","path_verification_code","path_verification_message",
                "runtime_menu_verified","runtime_menu_verified_label_vi","downstream_identity_verified","downstream_identity_verified_label_vi",
                "downstream_identity_method","downstream_identity_value","process_pid","process_hostname","process_user",
                "safety_override_requested","safety_override_used","safety_override_reason",
                "clear_line_recovery_requested","clear_line_recovery_used","clear_line_number","clear_line_reason","clear_line_result",
                "session_log_path","ssh_host_key_algorithm","ssh_host_key_fingerprint","ssh_host_key_policy",
            ],
            "oob_reconciliation_history.csv": [
                "reconciliation_id","oob_id","oob_name","oob_host","oob_ssh_port","target_id","identity_run_id",
                "vendor","operator_username","ticket_id","reason","old_alias","new_alias","physical_path",
                "proposed_commands","applied_commands","status","started_at_utc","started_at_local","finished_at_utc",
                "finished_at_local","verification_code","verification_message","rollback_attempted","rollback_succeeded",
                "error_code","error_message","baseline_refresh_status","process_pid","process_hostname","process_user",
            ],
            "oob_change_history.csv": [
                "change_id","oob_id","oob_name","changed_at_utc","changed_at_local","change_type","changed_fields",
                "old_data_json","new_data_json","source","process_pid","process_hostname","process_user",
            ],
            "data_quality_issues.csv": [
                "issue_code","severity","oob_id","scan_id","target_id","message",
            ],
            "current_target_trace.csv": [
                "target_id","oob_id","configured_alias","menu_name","menu_item","protocol","target_host","target_port",
                "console_line","console_line_source","state","state_confident","state_reason_code","state_evidence","last_scan_id",
                "mapping_source_command","mapping_text_line","mapping_text_line_no","mapping_command_line","mapping_command_line_no",
                "oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","vendor_at_scan","scan_status","mapping_quality",
                "baseline_updated","scan_connection_revision","profile_fingerprint","profile_snapshot_json","scan_policy_snapshot_json","config_snapshot_source","ssh_host_key_algorithm",
                "ssh_host_key_fingerprint","ssh_host_key_policy","source_raw_output_id","source_command_name","source_command_text",
                "source_command_success","source_raw_length","source_raw_sha256","source_raw_created_at",
            ],
            "snapshot_trace.csv": [
                "snapshot_id","target_id","scan_id","oob_id","configured_alias","menu_name","menu_item","protocol","target_host",
                "target_port","console_line","console_line_source","state","state_confident","state_reason_code","state_evidence",
                "mapping_source_command","mapping_text_line","mapping_text_line_no","mapping_command_line","mapping_command_line_no",
                "is_complete","captured_at","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","vendor_at_scan",
                "scan_status","mapping_quality","baseline_updated","scan_connection_revision","profile_fingerprint","profile_snapshot_json","scan_policy_snapshot_json","config_snapshot_source",
                "ssh_host_key_algorithm","ssh_host_key_fingerprint","ssh_host_key_policy","source_raw_output_id","source_command_name",
                "source_command_text","source_command_success","source_raw_length","source_raw_sha256","source_raw_created_at",
            ],
            "scan_command_audit.csv": [
                "raw_output_id","scan_id","oob_id","oob_name_at_scan","oob_host_at_scan","oob_ssh_port_at_scan","vendor_at_scan",
                "scan_status","mapping_quality","ssh_username_at_scan","trigger_source","process_hostname","process_user",
                "ssh_host_key_algorithm","ssh_host_key_fingerprint","ssh_host_key_policy","command_name","command_text","is_core",
                "redaction_applied","success","error_message","stored_output_length","stored_output_sha256","created_at",
            ],
            "connection_trace.csv": [
                "connection_id","oob_id","target_id","mapping_last_scan_id","started_at","ended_at","connection_status",
                "operator_username","process_hostname","process_user","oob_name_at_connection","oob_host_at_connection",
                "oob_ssh_port_at_connection","vendor_at_connection","connection_mode_at_connection","connection_revision_at_open",
                "baseline_revision_at_open","target_alias","menu_name","menu_item","target_command","target_host","target_port",
                "console_line","console_path_verified","path_verification_code","path_verification_message","runtime_menu_verified",
                "downstream_identity_verified","downstream_identity_method","downstream_identity_value",
                "safety_override_requested","safety_override_used","safety_override_reason","session_log_path",
                "connection_ssh_host_key_algorithm","connection_ssh_host_key_fingerprint","connection_ssh_host_key_policy",
                "mapping_scan_status","mapping_scan_quality","mapping_scan_baseline_updated","mapping_oob_name_at_scan",
                "mapping_oob_host_at_scan","mapping_oob_ssh_port_at_scan","mapping_vendor_at_scan",
                "mapping_scan_connection_revision","mapping_profile_fingerprint","scan_ssh_host_key_algorithm",
                "scan_ssh_host_key_fingerprint","scan_ssh_host_key_policy","trace_status",
            ],
            "current_device_identities.csv": [
                "target_id","oob_id","oob_name","oob_host","menu_name","menu_item","target_host","target_port","console_line",
                "configured_alias","actual_hostname","device_vendor","platform_family","model","serial_number","software_version",
                "identity_quality","identity_confidence","alias_comparison","source_evidence_json","verification_status","verification_severity",
                "hardware_continuity","previous_identity_run_id","changed_fields","verification_reason_codes","verification_summary",
                "identity_fingerprint","verification_source","last_identity_run_id","verified_at",
                "collector_version","mapping_scan_id","oob_name_at_run","oob_host_at_run","oob_ssh_port_at_run","oob_vendor_at_run",
                "oob_connection_mode_at_run","oob_connection_revision_at_run","oob_baseline_revision_at_run",
                "oob_ssh_host_key_algorithm","oob_ssh_host_key_fingerprint","oob_ssh_host_key_policy","mapping_validity",
            ],
            "device_identity_runs.csv": [
                "identity_run_id","oob_id","target_id","mapping_scan_id","collector_version","oob_name_at_run","oob_host_at_run",
                "oob_ssh_port_at_run","oob_vendor_at_run","oob_connection_mode_at_run","oob_connection_revision_at_run",
                "oob_baseline_revision_at_run","started_at","finished_at","status","error_code","error_message",
                "target_alias_at_run","target_command_at_run","target_protocol_at_run","target_host_at_run","target_port_at_run",
                "menu_name_at_run","menu_item_at_run","console_line_at_run","oob_username","downstream_username","login_method",
                "downstream_prompt","detected_vendor","identity_quality","identity_confidence","actual_hostname","platform_family","model",
                "serial_number","software_version","alias_comparison","source_evidence_json","verification_status","verification_severity",
                "hardware_continuity","previous_identity_run_id","changed_fields","verification_reason_codes","verification_summary",
                "identity_fingerprint","previous_identity_fingerprint","verification_source","runtime_mapping_verified",
                "runtime_mapping_verification_code","runtime_mapping_verification_message","live_state","live_state_confident",
                "live_state_reason_code","live_state_evidence","live_state_checked_at","oob_ssh_host_key_algorithm","oob_ssh_host_key_fingerprint",
                "oob_ssh_host_key_policy","process_hostname","process_user","mapping_scan_status","mapping_scan_quality",
                "mapping_scan_baseline_updated","mapping_oob_host_at_scan","mapping_scan_connection_revision","mapping_profile_fingerprint",
                "raw_output_count","successful_command_count","snapshot_count","identity_event_count",
            ],
            "device_identity_raw_outputs.csv": [
                "id","identity_run_id","command_name","command_text","raw_output","success","error_message","stored_output_sha256",
                "stored_output_length","created_at","oob_id","target_id","target_alias_at_run","actual_hostname","detected_vendor",
                "identity_quality","identity_confidence",
            ],
            "device_identity_snapshots.csv": [
                "id","identity_run_id","target_id","oob_id","configured_alias","actual_hostname","vendor","platform_family","model",
                "serial_number","software_version","identity_quality","identity_confidence","alias_comparison","source_evidence_json",
                "verification_status","verification_severity","hardware_continuity","previous_identity_run_id","changed_fields",
                "verification_reason_codes","verification_summary","identity_fingerprint","previous_identity_fingerprint","verification_source","captured_at",
            ],
            "device_identity_events.csv": [
                "identity_event_id","identity_run_id","target_id","oob_id","oob_name","configured_alias","actual_hostname",
                "device_vendor","model","serial_number","verification_status","hardware_continuity","event_code","severity",
                "field_name","old_value","new_value","reason","evidence_json","detected_at","mapping_scan_id","collector_version",
            ],
            "cable_check_runs.csv": [
                "id","oob_id","mapping_scan_id","started_at","finished_at","status","oob_name_at_run","vendor_at_run",
                "total_count","match_count","mismatch_count","no_hostname_count","skip_error_count","process_pid",
                "process_hostname","process_user","error_code","error_message",
            ],
            "cable_check_results.csv": [
                "id","run_id","target_id","oob_id","target_alias","port","console_path","device_a","device_b","status",
                "evidence_source","wake_count","passive_wait_used","runtime_mapping_verified",
                "runtime_mapping_verification_code","runtime_mapping_verification_message","live_state",
                "live_state_confident","live_state_reason_code","live_state_evidence","live_state_checked_at",
                "error_code","message","detected_at",
            ],
            "export_manifest.csv": [
                "exported_at_utc","exported_at_local","schema_version_expected","schema_version_database","file_name","row_count","file_size_bytes",
                "file_sha256","encoding","delimiter",
            ],
        }
        return headers[filename]

    @staticmethod
    def _write_data_dictionary(path: Path) -> None:
        content = """OOB CONSOLE MANAGER - HƯỚNG DẪN ĐỐI CHIẾU DỮ LIỆU

MỤC TIÊU
- Mỗi target có thể dò ngược: current target -> scan_id -> snapshot -> raw command -> finding -> cấu hình OOB tại thời điểm scan.
- Dữ liệu lịch sử dùng các cột *_at_scan / *_at_connection; KHÔNG dùng IP/vendor hiện tại để thay thế lịch sử.
- config_snapshot_source=LIVE_CAPTURE: snapshot được ghi đúng tại thời điểm chạy.
- config_snapshot_source=BACKFILLED_CURRENT: dữ liệu cũ trước schema v4 chỉ được backfill từ cấu hình hiện tại; KHÔNG được coi là lịch sử chính xác tuyệt đối.

FILE CHÍNH
1. inventory_summary.csv: file ngắn gọn nhất để operator mở Excel xem OOB/target/state/identity hiện tại.
2. oob_analysis_summary.csv: tổng quan health/mapping theo OOB.
3. oob_devices.csv: inventory OOB hiện tại và revision VALID/STALE.
4. console_targets.csv: current console inventory; alias là alias cấu hình trên OOB, endpoint là endpoint reverse-console, có provenance line/state/mapping để biết dữ liệu đến từ đâu.
5. console_snapshots.csv: target ở từng scan, kể cả PARTIAL/REJECTED khi có dữ liệu để audit.
6. scan_history.csv: scan status, mapping quality, baseline_updated, profile fingerprint và OOB snapshot.
7. scan_findings.csv: warning/error/reason chi tiết; dùng để trả lời 'vì sao scan bị PARTIAL/REJECTED?'.
8. raw_outputs.csv: command, CORE/SUPPORTING, success, SHA-256 và preview; raw đầy đủ vẫn nằm trong SQLite.
9. change_events.csv: event old/new đã flatten, gắn đúng OOB snapshot tại scan.
10. connection_history.csv: target/OOB snapshot lúc mở console, operator username, UNKNOWN override reason, clear-line recovery audit, session_log_path, console_path_verified runtime và cờ downstream_identity_verified riêng biệt.
11. oob_reconciliation_history.csv: audit mọi lần operator được phê duyệt đổi alias/Port Name trên OOB, gồm ticket, reason, exact physical path, command đề xuất/đã chạy, read-back, rollback và trạng thái rescan baseline.
12. oob_change_history.csv: lịch sử tạo/sửa/vô hiệu hóa/xóa OOB và profile fingerprint, có actor/process để truy vết.
13. data_quality_issues.csv: các bất nhất nền móng do audit view phát hiện; ERROR cần xử lý trước khi tin dữ liệu.
14. current_target_trace.csv: một dòng current target nối thẳng tới scan và raw menu command đã sinh mapping, gồm số dòng + SHA256.
15. snapshot_trace.csv: truy vết mọi target lịch sử theo scan tới raw menu source tương ứng.
16. scan_command_audit.csv: bảng command-level gọn để xem command nào chạy, CORE/SUPPORTING, success và hash raw output.
17. connection_trace.csv: nối từng phiên console với mapping scan đã dùng, OOB snapshot và SSH fingerprint để audit đường đi.
18. current_device_identities.csv: identity downstream hiện tại chỉ gồm run quality=ACCEPTED.
19. device_identity_runs.csv: lịch sử mọi lần downstream discovery, kể cả FAILED/PARTIAL.
20. device_identity_raw_outputs.csv: raw whitelist identity command + SHA-256/length để đối chiếu parser.
21. device_identity_snapshots.csv: snapshot identity + verification theo từng run.
22. device_identity_events.csv: sự kiện FIRST_VERIFIED / ALIAS_MISMATCH / SERIAL_CHANGED / DEVICE_REPLACED_SUSPECTED... kèm old/new/evidence.
23. cable_check_runs.csv: lịch sử từng batch Quick A/B, tổng MATCH/MISMATCH/NO_HOSTNAME/SKIP-ERROR.
24. cable_check_results.csv: Device A, Device B, evidence source và trạng thái từng port; không lưu password/raw login transcript.
25. export_manifest.csv: SHA-256 + kích thước từng file để kiểm tra export bị sửa/hỏng.

GIẢI THÍCH QUAN TRỌNG
- Scan Status (SUCCESS/PARTIAL/FAILED/REJECTED) KHÁC Mapping Quality (ACCEPTED/...)
- Console State (AVAILABLE/BUSY/UNKNOWN/...) KHÁC Mapping Validity (VALID/STALE)
- Mapping validity xét cả connection revision và vendor-profile fingerprint; sửa profile parse/port rule sẽ yêu cầu xác nhận baseline lại.
- Username/operator/process_user được giữ trong audit nội bộ và export nội bộ để truy vết. Password/token/secret/API key/authorization mới là dữ liệu bắt buộc redact.
- profile_snapshot_json + scan_policy_snapshot_json lưu đúng parser/profile và ngưỡng quality đã dùng tại thời điểm scan, giúp tái dựng quyết định về sau.
- alias/configured_alias là alias cấu hình trên OOB, KHÔNG phải hostname thật đã xác minh của router/switch phía sau.
- target_host/target_port (và console_endpoint_*) là endpoint reverse-console, KHÔNG mặc định là management IP của thiết bị phía sau.
- mapping_text_line_no/mapping_command_line_no cho biết đúng số dòng trong raw menu output đã sinh mapping.
- state_reason_code + state_evidence_json cho biết vì sao resolver kết luận trạng thái.
- console_line_source cho biết line được xác nhận bằng show line hay chỉ suy ra từ reverse-Telnet port.
- output_integrity_ok=1 nghĩa SHA/length lưu trong DB khớp raw_output hiện tại.
- redaction_applied=1 nghĩa tool đã che credential/secret trước khi lưu; hash là của bản đã che, không phải byte nguyên gốc từ thiết bị.
- console_path_verified=1 chỉ xác nhận có runtime evidence đường console đã mở; KHÔNG xác minh hostname/model/serial của thiết bị vật lý ở đầu dây.
- Downstream identity discovery chỉ dùng command read-only và chỉ cập nhật current identity khi identity_quality=ACCEPTED.
- identity_quality=ACCEPTED yêu cầu vendor + actual hostname + hardware serial; hostname/version thiếu serial chỉ được giữ PARTIAL để tránh nhận nhầm thiết bị vật lý.
- identity_quality tách biệt verification_status: ACCEPTED chỉ nói dữ liệu identity đủ tin cậy; verification_status mới nói MATCH/MISMATCH/DEVICE_CHANGE_SUSPECTED.
- DEVICE_CHANGE_SUSPECTED được kích hoạt khi hardware serial khác identity ACCEPTED trước đó; đây là cảnh báo cần operator đối chiếu RMA/change ticket/mapping, KHÔNG phải kết luận tự động cắm nhầm line.
- ALIAS_MISMATCH chỉ khẳng định configured alias khác actual hostname theo normalization bảo thủ (case/whitespace/trailing DNS dot), không tự sửa alias.
- identity_fingerprint là SHA-256 của vendor + hostname + model + serial đã chuẩn hóa, dùng để dò continuity; không chứa password/secret.
- ssh_host_key_policy=TOFU_PERSISTENT: lần đầu tool ghi host key vào data/ssh_known_hosts; các lần sau key đổi sẽ bị chặn. Fingerprint SHA256 được lưu trong scan/connection history để đối chiếu.
- TOFU không tự chứng minh key ở lần đầu là đúng; lần onboard đầu tiên nên đối chiếu fingerprint với nguồn quản trị độc lập nếu yêu cầu bảo mật cao.

AN TOÀN EXCEL
- Chuỗi bắt đầu bằng =, +, -, @ được thêm dấu nháy đơn để tránh CSV formula injection.
- Encoding: UTF-8 BOM (utf-8-sig). Delimiter: dấu phẩy (,).
"""
        temporary_path = path.with_suffix(path.suffix + ".tmp")
        temporary_path.write_text(content, encoding="utf-8-sig")
        os.replace(temporary_path, path)
