from __future__ import annotations
import base64, ctypes, hashlib, json, os
from ctypes import wintypes
from dataclasses import dataclass

from oob_manager.exceptions import ValidationError


@dataclass(slots=True)
class ProtectedSecret:
    provider: str
    blob: str


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(data: bytes):
    buf = ctypes.create_string_buffer(data)
    return _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf


def _dpapi_protect(data: bytes) -> bytes:
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    src, keep = _blob(data)
    out = _DATA_BLOB()
    # CRYPTPROTECT_UI_FORBIDDEN: local Windows user/machine policy, no prompt.
    if not crypt32.CryptProtectData(ctypes.byref(src), "OOB Credential", None, None, None, 1, ctypes.byref(out)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def _dpapi_unprotect(data: bytes) -> bytes:
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    src, keep = _blob(data)
    out = _DATA_BLOB()
    if not crypt32.CryptUnprotectData(ctypes.byref(src), None, None, None, None, 1, ctypes.byref(out)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def protect_mapping(values: dict[str, str]) -> ProtectedSecret:
    raw = json.dumps(values, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if os.name == "nt":
        return ProtectedSecret("WINDOWS_DPAPI_CURRENT_USER", base64.b64encode(_dpapi_protect(raw)).decode("ascii"))
    master = os.environ.get("OOB_CREDENTIAL_MASTER_KEY", "")
    if not master:
        raise ValidationError("Linux/macOS cần đặt OOB_CREDENTIAL_MASTER_KEY trước khi lưu credential profile.", error_code="CREDENTIAL_MASTER_KEY_REQUIRED")
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except Exception as exc:
        raise ValidationError("Thiếu thư viện cryptography để mã hóa credential.") from exc
    key = hashlib.sha256(master.encode("utf-8")).digest()
    nonce = os.urandom(12)
    encrypted = AESGCM(key).encrypt(nonce, raw, b"OOB-CREDENTIAL-V1")
    return ProtectedSecret("AES256_GCM_ENV", base64.b64encode(nonce + encrypted).decode("ascii"))


def unprotect_mapping(provider: str, blob: str) -> dict[str, str]:
    packed = base64.b64decode(blob.encode("ascii"), validate=True)
    if provider == "WINDOWS_DPAPI_CURRENT_USER":
        if os.name != "nt":
            raise ValidationError("Credential này được bảo vệ bằng Windows DPAPI và chỉ mở được bởi tài khoản Windows đã tạo nó.", error_code="DPAPI_CONTEXT_MISMATCH")
        raw = _dpapi_unprotect(packed)
    elif provider == "AES256_GCM_ENV":
        master = os.environ.get("OOB_CREDENTIAL_MASTER_KEY", "")
        if not master:
            raise ValidationError("Thiếu OOB_CREDENTIAL_MASTER_KEY.", error_code="CREDENTIAL_MASTER_KEY_REQUIRED")
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        key = hashlib.sha256(master.encode("utf-8")).digest()
        raw = AESGCM(key).decrypt(packed[:12], packed[12:], b"OOB-CREDENTIAL-V1")
    else:
        raise ValidationError("Kiểu bảo vệ credential không được hỗ trợ.")
    values = json.loads(raw.decode("utf-8"))
    return {str(k): str(v or "") for k, v in values.items()}
