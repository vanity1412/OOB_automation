from __future__ import annotations

import re
import time

from oob_manager.exceptions import CommandExecutionError, InteractiveSessionError
from oob_manager.models import (
    DeviceIdentity,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    RawCommandOutput,
)
from oob_manager.downstream.parsers import detect_vendor, parse_identity
from oob_manager.utils.validation import normalize_alias

USERNAME_PROMPT_RE = re.compile(r"(?im)(?:^|\n)\s*(?:username|login)\s*:\s*$")
PASSWORD_PROMPT_RE = re.compile(r"(?im)(?:^|\n)\s*password\s*:\s*$")
AUTH_FAILURE_RE = re.compile(
    r"(?i)(authentication\s+failed|login\s+(?:invalid|incorrect)|access\s+denied|"
    r"incorrect\s+password|bad\s+password|permission\s+denied)"
)
DEVICE_PROMPT_PATTERNS = (
    re.compile(r"^\S{1,120}[#>]\s*$"),
    re.compile(r"^<[^<>\r\n]{1,120}>\s*$"),
)
PAGER_RE = re.compile(
    r"(?i)(--\s*more\s*--|<---\s*more\s*--->|----\s*more\s*----|"
    r"press\s+(?:any\s+key|return)\s+to\s+continue)"
)
CLI_ERROR_RE = re.compile(
    r"(?i)(%\s*invalid input|%\s*incomplete command|%\s*ambiguous command|"
    r"unknown\s+command|unrecognized\s+command|error:\s*unrecognized|"
    r"error:\s*wrong parameter|authorization failed|command authorization failed|"
    r"error:\s*too many parameters|\^\s*$)"
)

# Một số thiết bị appliance/management in hostname ra serial console trước login,
# ví dụ: ``HCM-AggSW-MNGT-FNX02L03H1-01 (ttyd0)``. Đây là evidence rất
# hữu ích cho bài toán A/B vì không cần biết password downstream. Pattern cố ý
# chặt: chỉ nhận một token hostname + suffix TTY/console trong ngoặc, không lấy
# đại một dòng banner prose làm hostname.
CONSOLE_BANNER_HOST_RE = re.compile(
    r"(?im)^\s*(?P<hostname>[A-Za-z0-9][A-Za-z0-9_.:-]{1,119})\s*"
    r"\((?:ttyd?\d+|ttyu\d+|ttyS?\d+|console(?:\d+)?|con\d+)\)\s*$"
)
# FreeBSD serial login banner observed behind Cisco reverse Telnet:
# ``FreeBSD/amd64 (HNI-BRAS-CTR-01-10) (ttyu0)``.  Here the hostname is
# wrapped in the first parentheses and the TTY is the second pair.
FREEBSD_CONSOLE_BANNER_HOST_RE = re.compile(
    r"(?im)^\s*FreeBSD(?:/[A-Za-z0-9_.-]+)?\s+"
    r"\((?P<hostname>[A-Za-z0-9][A-Za-z0-9_.:-]{1,119})\)\s*"
    r"\((?:ttyd?\d+|ttyu\d+|ttyS?\d+|console(?:\d+)?|con\d+)\)\s*$"
)
UNIX_CONSOLE_BANNER_HOST_RE = re.compile(
    r"(?im)^\s*(?:Linux|NetBSD|OpenBSD)(?:/[A-Za-z0-9_.-]+)?\s+"
    r"\((?P<hostname>[A-Za-z0-9][A-Za-z0-9_.:-]{1,119})\)\s*"
    r"\((?:ttyd?\d+|ttyu\d+|ttyS?\d+|console(?:\d+)?|con\d+)\)\s*$"
)
# Some serial consoles expose the hostname directly in the login line, e.g.
# ``EDGE-01 login:``.  This is strong pre-auth Device-B evidence and does not
# require sending a username or password.
CONSOLE_LOGIN_HOST_RE = re.compile(
    r"(?im)^\s*(?P<hostname>[A-Za-z0-9][A-Za-z0-9_.:-]{1,119})\s+"
    r"(?:login|username|user\s*name)\s*:\s*$"
)

# Quick A/B runs against raw serial streams, not a terminal emulator. Real
# devices can therefore leave ANSI color/control bytes around an otherwise
# valid prompt. Normalize only presentation bytes; never synthesize text.
ANSI_CSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
ANSI_OSC_RE = re.compile(r"\x1b\][^\x07]*(?:\x07|\x1b\\)")

_RESERVED_CONSOLE_HOSTNAMES = {
    "login", "username", "user", "password", "root", "admin",
    "cli", "access", "open", "telnet", "ssh", "unknown",
}


def _valid_console_hostname(value: str) -> bool:
    hostname = str(value or "").strip().rstrip(":").casefold()
    return bool(hostname) and hostname not in _RESERVED_CONSOLE_HOSTNAMES


def _clean_console_text(value: str) -> str:
    text = str(value or "")
    text = ANSI_OSC_RE.sub("", text)
    text = ANSI_CSI_RE.sub("", text)
    # Drop harmless C0 presentation bytes (BEL/NUL/etc.) while retaining
    # TAB/LF/CR/backspace until line/backspace normalization is complete.
    text = re.sub(r"[\x00-\x06\x07\x0b\x0c\x0e-\x1f\x7f]", "", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    while "\b" in text:
        text = re.sub(r"[^\n]\x08", "", text)
        text = text.replace("\b", "")
    return text


def _console_lines(value: str) -> list[str]:
    return [line.strip() for line in _clean_console_text(value).split("\n") if line.strip()]


class DownstreamIdentityCollector:
    """Thu thập identity read-only từ CLI phía sau console.

    Collector chỉ dùng một whitelist command cố định. Nó không nhận command tự do
    từ user/database, không vào configuration mode và không ghi password xuống raw
    output. Paging được xử lý bằng Space để giữ nguyên ngữ nghĩa read-only.
    """

    MAX_OUTPUT_CHARS = 2_000_000
    MAX_PAGER_CONTINUES = 200

    def __init__(self, ssh_wrapper, command_timeout: int = 20) -> None:
        self.ssh = ssh_wrapper
        self.command_timeout = command_timeout

    @staticmethod
    def extract_device_prompt(value: str) -> str | None:
        lines = _console_lines(value)
        if not lines:
            return None
        candidate = lines[-1]
        if any(pattern.fullmatch(candidate) for pattern in DEVICE_PROMPT_PATTERNS):
            return candidate
        return None

    @staticmethod
    def extract_console_banner_hostname(value: str) -> str:
        """Lấy hostname từ banner serial pre-login có marker TTY/console rõ ràng."""
        cleaned = _clean_console_text(value)
        observations: list[tuple[int, str]] = []
        for pattern in (CONSOLE_BANNER_HOST_RE, FREEBSD_CONSOLE_BANNER_HOST_RE, UNIX_CONSOLE_BANNER_HOST_RE):
            observations.extend(
                (match.start(), match.group("hostname").strip())
                for match in pattern.finditer(cleaned)
                if _valid_console_hostname(match.group("hostname"))
            )
        if not observations:
            return ""
        # Nếu thiết bị in banner nhiều lần, dùng observation cuối cùng gần login nhất.
        observations.sort(key=lambda item: item[0])
        return observations[-1][1]

    @staticmethod
    def extract_login_banner_hostname(value: str) -> str:
        """Lấy hostname từ dòng ``HOST login:`` mà không đăng nhập downstream."""
        matches = list(CONSOLE_LOGIN_HOST_RE.finditer(_clean_console_text(value)))
        if not matches:
            return ""
        for match in reversed(matches):
            hostname = match.group("hostname").strip()
            if not _valid_console_hostname(hostname):
                continue
            return hostname
        return ""

    def _probe_banner_before_login(
        self,
        channel,
        initial_output: str,
    ) -> tuple[str, str]:
        """Thử lấy banner hostname trước khi gửi username/password.

        Nếu preflight chỉ mới có ``Trying ... Open`` thì gửi đúng một Enter để
        đánh thức serial console, sau đó chờ tới login/password/prompt. Transcript
        trả về được tái sử dụng cho _authenticate nên không mất evidence.
        """
        transcript = initial_output or ""
        hostname = self.extract_console_banner_hostname(transcript)
        if hostname:
            return hostname, transcript

        # Đã có terminal state thì không gõ thêm gì; caller sẽ login bình thường.
        if self._authentication_state(transcript) is not None:
            return "", transcript

        channel.send("\n")
        more, _state = self._read_auth_transition(channel)
        transcript += more
        return self.extract_console_banner_hostname(transcript), transcript

    @staticmethod
    def _banner_only_result(
        hostname: str,
        transcript: str,
        configured_alias: str,
    ) -> DownstreamDiscoveryResult:
        comparison = "UNKNOWN"
        if hostname and configured_alias.strip():
            comparison = (
                "EXACT_MATCH"
                if normalize_alias(hostname) == normalize_alias(configured_alias)
                else "DIFFERENT"
            )
        identity = DeviceIdentity(
            actual_hostname=hostname,
            vendor="UNKNOWN",
            quality="PARTIAL",
            confidence="MEDIUM",
            alias_comparison=comparison,
            source_evidence={"actual_hostname": "console_banner_tty"},
        )
        raw = [
            RawCommandOutput(
                command_name="console_banner",
                command_text="(pre-login serial banner)",
                raw_output=transcript,
                success=True,
                error_message="",
                is_core=True,
                redaction_applied=False,
            )
        ]
        return DownstreamDiscoveryResult(
            identity=identity,
            raw_outputs=raw,
            login_method="BANNER_ONLY",
            downstream_prompt="",
            metadata={
                "cable_identity_source": "CONSOLE_BANNER_TTY",
                "banner_hostname": hostname,
            },
        )


    @staticmethod
    def extract_prompt_hostname(value: str) -> tuple[str, str]:
        """Extract Device B only from a strong terminal-prompt shape.

        Production console prompts are not limited to ``HOST#``.  The quick
        verifier must also understand shells observed behind OOBs such as
        ``root@HOST:~#`` and ``[vrf:none] root@HOST:~#`` without treating free
        banner prose as a hostname.
        """
        lines = _console_lines(value)
        if not lines:
            return "", ""
        candidate = lines[-1]
        if USERNAME_PROMPT_RE.fullmatch(candidate) or PASSWORD_PROMPT_RE.fullmatch(candidate):
            return "", ""

        # Huawei/H3C-style system-view prompt.
        match = re.fullmatch(r"<([A-Za-z0-9][A-Za-z0-9_.:-]{1,119})>", candidate)
        if match and _valid_console_hostname(match.group(1)):
            return match.group(1), "DEVICE_PROMPT"

        # Linux/Junos/appliance shells. Optional context prefixes are common on
        # routing appliances, e.g. ``[vrf:none] root@HOST:~#``.  Hostname stops
        # before the optional ``:cwd`` suffix, so ``~`` can never leak into it.
        match = re.fullmatch(
            r"(?:\[[^]\r\n]{1,80}\]\s*)?"
            r"[^@\s]+@(?P<host>[A-Za-z0-9][A-Za-z0-9_.-]{0,118})"
            r"(?::[^\r\n#$>]{0,160})?[#$>]",
            candidate,
        )
        if match and _valid_console_hostname(match.group("host")):
            return match.group("host"), "DEVICE_PROMPT"

        # IOS-XR commonly prefixes the node location before the actual hostname:
        # ``RP/0/RP0/CPU0:HOST#``.
        match = re.fullmatch(
            r"(?:RP/[^\s:]{1,40}(?:/[^\s:]{1,40}){1,4}:)?"
            r"(?P<host>[A-Za-z0-9][A-Za-z0-9_.:-]{1,119})"
            r"(?:\([^\r\n)]{1,80}\))?[#>]",
            candidate,
            flags=re.IGNORECASE,
        )
        if match and _valid_console_hostname(match.group("host")):
            return match.group("host"), "DEVICE_PROMPT"
        return "", ""

    @staticmethod
    def _quick_hostname_result(
        hostname: str,
        transcript: str,
        configured_alias: str,
        evidence_source: str,
        *,
        wake_count: int = 0,
        passive_wait_used: bool = False,
    ) -> DownstreamDiscoveryResult:
        comparison = "UNKNOWN"
        if hostname and configured_alias.strip():
            comparison = (
                "EXACT_MATCH"
                if normalize_alias(hostname) == normalize_alias(configured_alias)
                else "DIFFERENT"
            )
        identity = DeviceIdentity(
            actual_hostname=hostname,
            vendor="UNKNOWN",
            quality="PARTIAL" if hostname else "REJECTED",
            confidence="MEDIUM" if hostname else "LOW",
            alias_comparison=comparison,
            source_evidence={"actual_hostname": evidence_source or "none"},
        )
        raw = [RawCommandOutput(
            command_name="quick_hostname_probe",
            command_text="(console banner/prompt only; no downstream login)",
            raw_output=transcript,
            success=bool(hostname),
            error_message="" if hostname else "NO_HOSTNAME",
            is_core=True,
            redaction_applied=False,
        )]
        return DownstreamDiscoveryResult(
            identity=identity,
            raw_outputs=raw,
            login_method="NO_DOWNSTREAM_LOGIN",
            downstream_prompt="",
            metadata={
                "cable_identity_source": evidence_source or "NO_HOSTNAME",
                "quick_hostname_only": True,
                "quick_probe_wake_sent": bool(wake_count),
                "quick_probe_wake_count": int(wake_count),
                "quick_probe_passive_wait_used": bool(passive_wait_used),
            },
        )

    def collect_quick_hostname(
        self,
        channel,
        initial_output: str,
        configured_alias: str,
        *,
        wake_timeout: float = 5.0,
        passive_timeout: float = 1.5,
        max_wake_attempts: int = 1,
        wake_delay: float = 0.45,
    ) -> DownstreamDiscoveryResult:
        """Probe Device B from banner/prompt only; never authenticate downstream.

        The probe is deliberately conservative: first consume a short passive
        window when the console already emitted something, then send a small,
        explicitly bounded number of bare Enters only while no login/prompt
        evidence exists. It never sends a username, password, or downstream
        command. Cisco reverse-Telnet may require two wake Enters after ``Open``;
        other callers keep the default of one.
        """
        transcript = initial_output or ""
        wake_count = 0
        passive_wait_used = False
        wake_limit = max(0, min(int(max_wake_attempts), 2))

        def conclude() -> DownstreamDiscoveryResult | None:
            hostname = self.extract_console_banner_hostname(transcript)
            if hostname:
                return self._quick_hostname_result(
                    hostname, transcript, configured_alias, "CONSOLE_BANNER_TTY",
                    wake_count=wake_count, passive_wait_used=passive_wait_used,
                )
            hostname = self.extract_login_banner_hostname(transcript)
            if hostname:
                return self._quick_hostname_result(
                    hostname, transcript, configured_alias, "CONSOLE_LOGIN_BANNER",
                    wake_count=wake_count, passive_wait_used=passive_wait_used,
                )
            hostname, source = self.extract_prompt_hostname(transcript)
            if hostname:
                return self._quick_hostname_result(
                    hostname, transcript, configured_alias, source,
                    wake_count=wake_count, passive_wait_used=passive_wait_used,
                )
            state = self._authentication_state(transcript)
            if state in {"PASSWORD", "AUTH_FAILURE"}:
                return self._quick_hostname_result(
                    "", transcript, configured_alias, "NO_HOSTNAME",
                    wake_count=wake_count, passive_wait_used=passive_wait_used,
                )
            if state == "USERNAME":
                # Cisco reverse-Telnet targets can first redraw only a bare
                # ``login:`` line, then reveal the hostname banner after one
                # more bare Enter.  While a caller explicitly allows another
                # bounded wake attempt, do not terminate the probe at that
                # first anonymous login prompt.  No username/password is ever
                # sent; after the wake budget is exhausted, return NO_HOSTNAME.
                if wake_limit > 1 and wake_count < wake_limit:
                    return None
                return self._quick_hostname_result(
                    "", transcript, configured_alias, "NO_HOSTNAME",
                    wake_count=wake_count, passive_wait_used=passive_wait_used,
                )
            return None

        result = conclude()
        if result is not None:
            return result

        # If the target already produced a banner/open message, give it a short
        # passive chance to finish drawing login/prompt before typing anything.
        if transcript.strip() and passive_timeout > 0:
            passive_wait_used = True
            more, _ = self._read_auth_transition(
                channel, timeout=min(float(self.command_timeout), float(passive_timeout))
            )
            transcript += more
            result = conclude()
            if result is not None:
                return result

        # Still no semantic state. Send only a bounded number of bare Enters.
        # Cisco reverse-Telnet often reports ``Open`` before the downstream TTY
        # has drawn anything; some real consoles need a second Enter to emit the
        # FreeBSD/TTY banner. Stop immediately once authentication/prompt evidence
        # appears so Quick A/B never types into an authentication flow.
        for attempt in range(wake_limit):
            if attempt > 0 and wake_delay > 0:
                time.sleep(min(float(wake_delay), 2.0))
            channel.send("\n")
            wake_count += 1
            more, _ = self._read_auth_transition(
                channel, timeout=min(float(self.command_timeout), float(wake_timeout))
            )
            transcript += more
            result = conclude()
            if result is not None:
                return result
        return self._quick_hostname_result(
            "", transcript, configured_alias, "NO_HOSTNAME",
            wake_count=wake_count, passive_wait_used=passive_wait_used,
        )

    @classmethod
    def _authentication_state(cls, value: str) -> str | None:
        if AUTH_FAILURE_RE.search(value):
            return "AUTH_FAILURE"
        if cls.extract_device_prompt(value):
            return "PROMPT"
        # Check username before password. Some login banners can contain the word
        # password in prose, while these patterns require a terminal prompt line.
        if USERNAME_PROMPT_RE.search(value):
            return "USERNAME"
        if PASSWORD_PROMPT_RE.search(value):
            return "PASSWORD"
        return None

    def _read_auth_transition(
        self,
        channel,
        *,
        timeout: float | None = None,
        initial: str = "",
    ) -> tuple[str, str | None]:
        """Wait for a semantic downstream login/CLI state.

        Real routers and switches may pause after console banners or AAA messages.
        A short quiet period therefore cannot be used as proof that a login step
        completed.  v1.1.19 waits until username/password/device-prompt/failure
        evidence is observed or the configured command deadline expires.
        """

        reader = getattr(self.ssh, "read_until_state", None)
        if callable(reader):
            return reader(
                channel,
                self._authentication_state,
                timeout=timeout or self.command_timeout,
                settle=0.2,
                initial=initial,
            )
        output = initial + self.ssh.read_until_quiet(
            channel, timeout=timeout or self.command_timeout, quiet=0.35
        )
        return output, self._authentication_state(output)

    def _read_after_send(self, channel, timeout: float | None = None, quiet: float = 0.35) -> str:
        # Retained for compatibility in non-authentication paths/test doubles.
        return self.ssh.read_until_quiet(channel, timeout=timeout or self.command_timeout, quiet=quiet)

    def _authenticate(
        self,
        channel,
        initial_output: str,
        credentials: DownstreamCredentials,
    ) -> tuple[str, str]:
        transcript = initial_output or ""
        username_sent = False
        password_sent = False
        newline_sent = False

        # Evaluate any evidence already received before typing.  If the serial
        # target is silent, send a single Enter and then wait for a semantic state.
        for _ in range(10):
            state = self._authentication_state(transcript)
            if state == "AUTH_FAILURE":
                raise InteractiveSessionError(
                    "Thiết bị downstream từ chối đăng nhập.",
                    error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
                )
            if state == "PROMPT":
                prompt = self.extract_device_prompt(transcript)
                if not prompt:
                    break
                if username_sent and password_sent:
                    method = "USERNAME_PASSWORD"
                elif username_sent:
                    method = "USERNAME_ONLY"
                elif password_sent:
                    method = "PASSWORD_ONLY"
                else:
                    method = "EXISTING_CLI"
                return prompt, method

            if state == "USERNAME":
                if username_sent:
                    raise InteractiveSessionError(
                        "Thiết bị downstream hỏi username lặp lại; đăng nhập không thành công.",
                        error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
                    )
                if not credentials.username:
                    raise InteractiveSessionError(
                        "Thiết bị downstream yêu cầu username nhưng chưa được cung cấp.",
                        error_code="DOWNSTREAM_USERNAME_REQUIRED",
                    )
                channel.send(credentials.username + "\n")
                username_sent = True
                transcript, _ = self._read_auth_transition(channel)
                continue

            if state == "PASSWORD":
                if password_sent:
                    raise InteractiveSessionError(
                        "Thiết bị downstream hỏi password lặp lại; đăng nhập không thành công.",
                        error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
                    )
                if not credentials.password:
                    raise InteractiveSessionError(
                        "Thiết bị downstream yêu cầu password nhưng chưa được cung cấp.",
                        error_code="DOWNSTREAM_PASSWORD_REQUIRED",
                    )
                channel.send(credentials.password + "\n")
                password_sent = True
                transcript, _ = self._read_auth_transition(channel)
                continue

            if not newline_sent:
                # Only one Enter is sent to wake a quiet serial console.  The
                # semantic reader then waits through slow banner/AAA gaps.
                channel.send("\n")
                newline_sent = True
                transcript, _ = self._read_auth_transition(channel)
                continue

            # No semantic state arrived by the configured deadline. Do not send
            # additional text into an unknown terminal state.
            break

        raise InteractiveSessionError(
            "Không xác định được login prompt/CLI prompt của thiết bị downstream.",
            error_code="DOWNSTREAM_PROMPT_UNVERIFIED",
        )

    def _run_readonly_command(self, channel, command: str, expected_prompt: str) -> str:
        self.ssh.drain_channel(channel)
        channel.send(command + "\n")
        deadline = time.monotonic() + self.command_timeout
        chunks: list[str] = []
        pager_count = 0
        prompt_seen_at: float | None = None
        last_pager_position = -1

        while time.monotonic() < deadline:
            if channel.recv_ready():
                data = channel.recv(65535)
                if not data:
                    break
                chunks.append(data.decode("utf-8", errors="replace"))
                joined = "".join(chunks)
                if len(joined) > self.MAX_OUTPUT_CHARS:
                    exc = CommandExecutionError(
                        f"Output downstream vượt giới hạn an toàn: {command}",
                        error_code="DOWNSTREAM_OUTPUT_TOO_LARGE",
                    )
                    exc.raw_output = joined[: self.MAX_OUTPUT_CHARS]
                    raise exc

                pager_matches = list(PAGER_RE.finditer(joined))
                if pager_matches:
                    latest = pager_matches[-1]
                    if latest.start() != last_pager_position:
                        pager_count += 1
                        last_pager_position = latest.start()
                        if pager_count > self.MAX_PAGER_CONTINUES:
                            exc = CommandExecutionError(
                                f"Downstream paging vượt giới hạn: {command}",
                                error_code="DOWNSTREAM_PAGING_LIMIT",
                            )
                            exc.raw_output = joined
                            raise exc
                        channel.send("\n")

                lines = [line.strip() for line in joined.replace("\r", "").split("\n") if line.strip()]
                prompt_seen_at = (
                    time.monotonic()
                    if lines and lines[-1] == expected_prompt.strip()
                    else None
                )
            elif prompt_seen_at is not None and time.monotonic() - prompt_seen_at >= 0.2:
                break
            else:
                time.sleep(0.04)

        output = "".join(chunks)
        lines = [line.strip() for line in output.replace("\r", "").split("\n") if line.strip()]
        if not lines or lines[-1] != expected_prompt.strip():
            exc = CommandExecutionError(
                f"Downstream command không trở về đúng prompt: {command}",
                error_code="DOWNSTREAM_COMMAND_TIMEOUT",
            )
            exc.raw_output = output
            raise exc
        return output

    @staticmethod
    def _append_raw(
        raw: list[RawCommandOutput],
        name: str,
        command: str,
        output: str,
        success: bool,
        error: str = "",
    ) -> None:
        raw.append(
            RawCommandOutput(
                command_name=name,
                command_text=command,
                raw_output=output,
                success=success,
                error_message=error,
                is_core=True,
                redaction_applied=False,
            )
        )

    def _try_command(
        self,
        channel,
        raw: list[RawCommandOutput],
        name: str,
        command: str,
        prompt: str,
    ) -> str:
        try:
            output = self._run_readonly_command(channel, command, prompt)
            ok = not bool(CLI_ERROR_RE.search(output))
            self._append_raw(raw, name, command, output, ok, "CLI error" if not ok else "")
            return output if ok else ""
        except CommandExecutionError as exc:
            # A timeout/output-limit/paging failure means we no longer know that
            # the channel is synchronized at the expected CLI prompt. Continuing
            # with another command could send text into an unfinished pager or
            # command context, so fail closed. Preserve the partial evidence.
            partial = str(getattr(exc, "raw_output", "") or "")
            self._append_raw(raw, name, command, partial, False, str(exc))
            exc.raw_outputs = list(raw)
            raise
        except Exception as exc:
            partial = str(getattr(exc, "raw_output", "") or "")
            self._append_raw(raw, name, command, partial, False, str(exc))
            error = InteractiveSessionError(
                f"Downstream command channel mất đồng bộ khi chạy {command}.",
                error_code="DOWNSTREAM_COMMAND_CHANNEL_ERROR",
            )
            error.raw_outputs = list(raw)
            raise error from exc

    def collect(
        self,
        channel,
        initial_output: str,
        credentials: DownstreamCredentials,
        configured_alias: str,
        *,
        prefer_banner_hostname: bool = False,
    ) -> DownstreamDiscoveryResult:
        auth_input = initial_output or ""
        if prefer_banner_hostname:
            banner_hostname, auth_input = self._probe_banner_before_login(
                channel, auth_input
            )
            if banner_hostname:
                return self._banner_only_result(
                    banner_hostname, auth_input, configured_alias
                )

        prompt, login_method = self._authenticate(channel, auth_input, credentials)
        raw: list[RawCommandOutput] = []
        outputs: dict[str, str] = {}

        # Detection uses only read-only commands. show version is valid on Cisco/
        # Juniper; display version is tried only when show version cannot identify.
        show_version = self._try_command(channel, raw, "show_version", "show version", prompt)
        outputs["show_version"] = show_version
        vendor = detect_vendor(show_version=show_version)

        if vendor == "UNKNOWN":
            display_version = self._try_command(channel, raw, "display_version", "display version", prompt)
            outputs["display_version"] = display_version
            vendor = detect_vendor(show_version=show_version, display_version=display_version)

        if vendor == "CISCO":
            outputs["show_inventory"] = self._try_command(
                channel, raw, "show_inventory", "show inventory", prompt
            )
        elif vendor == "JUNIPER":
            outputs["show_chassis_hardware"] = self._try_command(
                channel,
                raw,
                "show_chassis_hardware",
                "show chassis hardware | no-more",
                prompt,
            )
        elif vendor == "HUAWEI":
            outputs["display_esn"] = self._try_command(
                channel, raw, "display_esn", "display esn", prompt
            )

        identity = parse_identity(vendor, outputs, prompt, configured_alias)
        if identity.quality == "REJECTED":
            error = InteractiveSessionError(
                "Đã vào CLI downstream nhưng không thu thập được identity đủ tin cậy.",
                error_code="DOWNSTREAM_IDENTITY_REJECTED",
            )
            error.raw_outputs = raw
            error.identity = identity
            error.downstream_prompt = prompt
            error.login_method = login_method
            raise error

        return DownstreamDiscoveryResult(
            identity=identity,
            raw_outputs=raw,
            login_method=login_method,
            downstream_prompt=prompt,
        )
