"""OOB Console Manager CLI."""

__version__ = "1.2.2"
