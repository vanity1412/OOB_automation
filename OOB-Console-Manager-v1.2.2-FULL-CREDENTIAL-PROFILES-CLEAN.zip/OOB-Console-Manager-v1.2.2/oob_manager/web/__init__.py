"""Web application for OOB Console Manager."""
