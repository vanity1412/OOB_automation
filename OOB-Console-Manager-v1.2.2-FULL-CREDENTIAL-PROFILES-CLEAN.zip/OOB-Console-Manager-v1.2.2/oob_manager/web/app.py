from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
from queue import Queue
import threading
from typing import Any

from fastapi import Cookie, Depends, FastAPI, Form, Header, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel, Field

from oob_manager import __version__
from oob_manager.exceptions import ValidationError, friendly_error
from oob_manager.models import SessionCredentials
from oob_manager.utils.paths import BACKUP_DIR, EXPORT_DIR
from oob_manager.web.auth import LoginThrottle, WebAuth, WebUser
from oob_manager.web.bridge import QueueTerminalBridge
from oob_manager.web.core import WebCore, jsonable
from oob_manager.web.tasks import TaskManager
from oob_manager.web.templates import APP_HTML, LOGIN_HTML


class JsonBody(BaseModel):
    model_config = {"extra": "allow"}


class CredentialBody(BaseModel):
    scope: str = Field("default", max_length=16)
    scope_id: str = Field("default", max_length=128)
    username: str = Field("", max_length=128)
    password: str = Field("", max_length=1024)
    enable_password: str = Field("", max_length=1024)


class OOBBody(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    host: str = Field(..., min_length=1, max_length=255)
    ssh_port: int = Field(22, ge=1, le=65535)
    vendor: str = Field("CISCO", pattern="^(?i:CISCO|VERTIV)$")
    default_username: str = Field("", max_length=128)
    enabled: bool = True
    notes: str = Field("", max_length=4000)
    credential_profile_id: int | None = None


class CredentialProfileBody(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    username: str = Field(..., min_length=1, max_length=128)
    password: str = Field("", max_length=1024)
    enable_password: str = Field("", max_length=1024)
    vendor_scope: str = Field("ANY", pattern="^(?i:ANY|CISCO|VERTIV)$")
    notes: str = Field("", max_length=2000)
    enabled: bool = True


def create_app(*, db_path=None) -> FastAPI:
    auth = WebAuth()
    core = WebCore(db_path) if db_path is not None else WebCore()
    tasks = TaskManager(max_workers=int(os.environ.get("OOB_WEB_WORKERS", "4")))
    throttle = LoginThrottle(
        max_failures=int(os.environ.get("OOB_WEB_LOGIN_MAX_FAILURES", "8")),
        window_seconds=int(os.environ.get("OOB_WEB_LOGIN_WINDOW", "300")),
        block_seconds=int(os.environ.get("OOB_WEB_LOGIN_BLOCK", "300")),
    )

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        try:
            yield
        finally:
            tasks.shutdown()

    app = FastAPI(
        title="OOB Monitor", version="1.2.2", docs_url=None, redoc_url=None,
        lifespan=lifespan,
    )
    app.state.auth = auth
    app.state.core = core
    app.state.tasks = tasks

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        try:
            content_length = int(request.headers.get("content-length", "0") or 0)
        except ValueError:
            content_length = 0
        if content_length > int(os.environ.get("OOB_WEB_MAX_REQUEST_BYTES", "1048576")):
            return JSONResponse(status_code=413, content={"detail": "REQUEST_TOO_LARGE"})
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Cache-Control"] = "no-store"
        if request.url.scheme == "https" or os.environ.get("OOB_WEB_COOKIE_SECURE", "0") == "1":
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; "
            "img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'"
        )
        return response

    def current_user(token: str | None = Cookie(default=None, alias=auth.cookie_name)) -> WebUser:
        if auth.local_mode:
            return auth.local_user()
        user = auth.parse(token)
        if not user:
            raise HTTPException(status_code=401, detail="UNAUTHORIZED")
        return user

    def require_role(minimum: str):
        def dependency(user: WebUser = Depends(current_user)) -> WebUser:
            if not auth.allowed(user, minimum):
                raise HTTPException(status_code=403, detail="FORBIDDEN")
            return user
        return dependency

    def csrf_guard(
        user: WebUser = Depends(current_user),
        csrf: str | None = Header(default=None, alias="X-CSRF-Token"),
    ) -> WebUser:
        if not auth.valid_csrf(user, csrf):
            raise HTTPException(status_code=403, detail="CSRF_INVALID")
        return user

    def operator_csrf(user: WebUser = Depends(csrf_guard)) -> WebUser:
        if not auth.allowed(user, "operator"):
            raise HTTPException(status_code=403, detail="OPERATOR_REQUIRED")
        return user

    def admin_csrf(user: WebUser = Depends(csrf_guard)) -> WebUser:
        if not auth.allowed(user, "admin"):
            raise HTTPException(status_code=403, detail="ADMIN_REQUIRED")
        return user

    @app.exception_handler(ValidationError)
    async def validation_error_handler(_request: Request, exc: ValidationError):
        return JSONResponse(
            status_code=400,
            content={"detail": friendly_error(exc), "error_code": getattr(exc, "error_code", "VALIDATION_ERROR")},
        )

    @app.exception_handler(Exception)
    async def generic_error_handler(_request: Request, exc: Exception):
        # Never expose arbitrary transport buffers or credentials to the browser.
        return JSONResponse(
            status_code=500,
            content={"detail": f"Lỗi kỹ thuật {type(exc).__name__}", "error_code": getattr(exc, "error_code", "WEB_INTERNAL_ERROR")},
        )

    @app.get("/login", response_class=HTMLResponse)
    async def login_page():
        if auth.local_mode:
            return RedirectResponse("/", status_code=303)
        return LOGIN_HTML.replace("__ERROR__", "")

    @app.post("/login")
    async def login(request: Request, username: str = Form(...), password: str = Form(...)):
        if auth.local_mode:
            return RedirectResponse("/", status_code=303)
        client_ip = request.client.host if request.client else "unknown"
        account_key = f"account:{client_ip}|{str(username).strip().lower()[:128]}"
        ip_key = f"ip:{client_ip}"
        decisions = [throttle.allowed(ip_key), throttle.allowed(account_key)]
        allowed = all(item[0] for item in decisions)
        retry_after = max(item[1] for item in decisions)
        if not allowed:
            response = HTMLResponse(
                LOGIN_HTML.replace("__ERROR__", '<div class="err">Quá nhiều lần đăng nhập thất bại. Thử lại sau.</div>'),
                status_code=429,
            )
            response.headers["Retry-After"] = str(retry_after)
            return response
        result = auth.authenticate(username, password)
        if not result:
            throttle.failure(ip_key)
            throttle.failure(account_key)
            return HTMLResponse(
                LOGIN_HTML.replace("__ERROR__", '<div class="err">Sai tài khoản hoặc mật khẩu.</div>'),
                status_code=401,
            )
        throttle.success(ip_key)
        throttle.success(account_key)
        username, role = result
        token, _user = auth.issue(username, role)
        response = RedirectResponse("/", status_code=303)
        secure = os.environ.get("OOB_WEB_COOKIE_SECURE", "0") == "1"
        response.set_cookie(
            auth.cookie_name, token, httponly=True, samesite="strict",
            secure=secure, max_age=auth.ttl, path="/",
        )
        return response

    @app.post("/logout")
    async def logout(user: WebUser = Depends(csrf_guard)):
        core.vault.clear(user.session_id)
        response = JSONResponse({"status": "ok", "local_mode": auth.local_mode})
        response.delete_cookie(auth.cookie_name, path="/")
        return response

    @app.get("/", response_class=HTMLResponse)
    async def index(token: str | None = Cookie(default=None, alias=auth.cookie_name)):
        if not auth.local_mode and not auth.parse(token):
            return RedirectResponse("/login", status_code=303)
        return APP_HTML

    @app.get("/api/bootstrap")
    async def bootstrap(user: WebUser = Depends(current_user)):
        return {
            "user": {"username": user.username, "role": user.role},
            "csrf": auth.csrf(user),
            "version": "1.2.2",
            "core_version": __version__,
        }

    @app.get("/api/dashboard")
    async def dashboard(_user: WebUser = Depends(current_user)):
        return core.dashboard()

    @app.get("/api/oobs")
    async def list_oobs(_user: WebUser = Depends(current_user)):
        return core.oobs(include_disabled=True)

    @app.post("/api/oobs")
    async def create_oob(body: OOBBody, _user: WebUser = Depends(admin_csrf)):
        return core.create_oob(body.model_dump())

    @app.put("/api/oobs/{oob_id}")
    async def update_oob(oob_id: int, body: OOBBody, _user: WebUser = Depends(admin_csrf)):
        return core.update_oob(oob_id, body.model_dump())

    @app.delete("/api/oobs/{oob_id}")
    async def disable_oob(oob_id: int, _user: WebUser = Depends(admin_csrf)):
        core.disable_oob(oob_id)
        return {"status": "disabled"}


    @app.get("/api/credential-profiles")
    async def list_credential_profiles(_user: WebUser = Depends(current_user)):
        return core.credential_profiles()

    @app.post("/api/credential-profiles")
    async def create_credential_profile(body: CredentialProfileBody, _user: WebUser = Depends(admin_csrf)):
        return core.create_credential_profile(body.model_dump())

    @app.put("/api/credential-profiles/{profile_id}")
    async def update_credential_profile(profile_id: int, body: CredentialProfileBody, _user: WebUser = Depends(admin_csrf)):
        return core.update_credential_profile(profile_id, body.model_dump())

    @app.delete("/api/credential-profiles/{profile_id}")
    async def delete_credential_profile(profile_id: int, _user: WebUser = Depends(admin_csrf)):
        core.delete_credential_profile(profile_id)
        return {"status": "deleted"}

    @app.put("/api/oobs/{oob_id}/credential-profile")
    async def assign_credential_profile(oob_id: int, body: dict[str, Any], _user: WebUser = Depends(admin_csrf)):
        raw = body.get("credential_profile_id")
        return core.assign_credential_profile(oob_id, int(raw) if raw not in (None, "", 0, "0") else None)

    @app.get("/api/inventory")
    async def inventory(_user: WebUser = Depends(current_user)):
        return core.inventory()

    @app.get("/api/targets")
    async def targets(oob_id: int | None = None, _user: WebUser = Depends(current_user)):
        return core.targets(oob_id)

    @app.get("/api/targets/{target_id}")
    async def target_detail(target_id: int, _user: WebUser = Depends(current_user)):
        return core.inventory_detail(target_id)

    @app.get("/api/search")
    async def search(q: str = "", _user: WebUser = Depends(current_user)):
        return core.search(q)

    @app.get("/api/history/{kind}")
    async def history(kind: str, limit: int = 300, _user: WebUser = Depends(current_user)):
        return core.history(kind, limit)

    @app.get("/api/inventory/daily")
    async def daily_inventory(day: str, _user: WebUser = Depends(current_user)):
        return core.daily_inventory(day)

    @app.get("/api/scans/{scan_id}/snapshot")
    async def scan_snapshot(scan_id: int, _user: WebUser = Depends(current_user)):
        return core.scan_snapshot(scan_id)

    @app.post("/api/history/mark-viewed")
    async def mark_history_viewed(body: dict[str, Any], _user: WebUser = Depends(operator_csrf)):
        return core.mark_viewed(str(body.get("kind", "")), list(body.get("ids") or []))

    @app.get("/api/health")
    async def health(_user: WebUser = Depends(current_user)):
        return core.health()

    @app.get("/api/settings")
    async def get_settings(_user: WebUser = Depends(current_user)):
        return core.settings_data()

    @app.put("/api/settings")
    async def set_settings(body: dict[str, Any], _user: WebUser = Depends(admin_csrf)):
        return core.update_settings(body)

    @app.get("/api/credentials")
    async def credential_status(user: WebUser = Depends(current_user)):
        return core.vault.status(user.session_id)

    @app.put("/api/credentials")
    async def set_credentials(body: CredentialBody, user: WebUser = Depends(operator_csrf)):
        if not body.username.strip():
            raise HTTPException(status_code=400, detail="USERNAME_REQUIRED")
        credentials = SessionCredentials(
            username=body.username.strip(), password=body.password,
            enable_password=body.enable_password or None,
        )
        core.vault.set(
            user.session_id, scope=body.scope,
            scope_id=body.scope_id, credentials=credentials,
        )
        return core.vault.status(user.session_id)

    @app.delete("/api/credentials")
    async def clear_credentials(user: WebUser = Depends(operator_csrf)):
        core.vault.clear(user.session_id)
        return {"status": "cleared"}

    def submit(kind: str, user: WebUser, fn):
        task = tasks.submit(kind, user.username, fn)
        return {"id": task.id, "status": task.status, "kind": task.kind}

    @app.get("/api/tasks")
    async def list_tasks(user: WebUser = Depends(current_user)):
        owner = None if user.role == "admin" else user.username
        return [task.public() for task in tasks.list(owner=owner, limit=150)]

    @app.get("/api/tasks/{task_id}")
    async def get_task(task_id: str, user: WebUser = Depends(current_user)):
        task = tasks.get(task_id)
        if not task or (user.role != "admin" and task.owner != user.username):
            raise HTTPException(status_code=404, detail="TASK_NOT_FOUND")
        return task.public()

    @app.post("/api/tasks/{task_id}/cancel")
    async def cancel_task(task_id: str, user: WebUser = Depends(operator_csrf)):
        task = tasks.get(task_id)
        if not task or (user.role != "admin" and task.owner != user.username):
            raise HTTPException(status_code=404, detail="TASK_NOT_FOUND")
        return {"cancel_requested": tasks.cancel(task_id)}

    @app.post("/api/tasks/test_connection")
    async def task_test_connection(body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        oob_id = int(body.get("oob_id") or 0)
        return submit("TEST_CONNECTION", user, lambda ctx: core.test_connection(ctx, user.session_id, oob_id))

    @app.post("/api/tasks/scan")
    async def task_scan(body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        oob_id = int(body.get("oob_id") or 0)
        return submit("SCAN_ONE", user, lambda ctx: core.scan_one(ctx, user.session_id, oob_id, "WEB_MANUAL"))

    @app.post("/api/tasks/scan_all")
    async def task_scan_all(_body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        return submit("SCAN_ALL", user, lambda ctx: core.scan_all(ctx, user.session_id))

    @app.post("/api/tasks/quick_ab")
    async def task_quick_ab(body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        oob_id = int(body.get("oob_id") or 0)
        port_credentials = body.get("port_credentials") or {}
        return submit("QUICK_AB", user, lambda ctx: core.quick_ab(ctx, user.session_id, oob_id, port_credentials))

    @app.post("/api/tasks/smart_verify")
    async def task_smart_verify(body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        oob_id = int(body.get("oob_id") or 0)
        downstream = body.get("downstream") or {}
        port_credentials = body.get("port_credentials") or {}
        return submit("SMART_VERIFY", user, lambda ctx: core.smart_verify(ctx, user.session_id, oob_id, downstream, port_credentials))

    @app.post("/api/tasks/full_inventory")
    async def task_full_inventory(body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        oob_id = int(body.get("oob_id") or 0)
        downstream = body.get("downstream") or {}
        port_credentials = body.get("port_credentials") or {}
        return submit("FULL_INVENTORY", user, lambda ctx: core.full_inventory(ctx, user.session_id, oob_id, downstream, port_credentials))

    @app.post("/api/tasks/identity")
    async def task_identity(body: dict[str, Any], user: WebUser = Depends(operator_csrf)):
        target_id = int(body.get("target_id") or 0)
        downstream = body.get("downstream") or {}
        port_credentials = body.get("port_credentials") or {}
        return submit("IDENTITY_ONE", user, lambda ctx: core.identity_one(ctx, user.session_id, target_id, downstream, port_credentials))

    @app.post("/api/tasks/reconcile")
    async def task_reconcile(body: dict[str, Any], user: WebUser = Depends(admin_csrf)):
        target_id = int(body.get("target_id") or 0)
        return submit(
            "RECONCILE_ALIAS", user,
            lambda ctx: core.reconcile_apply(
                ctx, user.session_id, target_id,
                str(body.get("new_alias", "")), str(body.get("ticket_id", "")),
                str(body.get("reason", "")),
            ),
        )

    @app.post("/api/tasks/backup")
    async def task_backup(_body: dict[str, Any], user: WebUser = Depends(admin_csrf)):
        return submit("DATABASE_BACKUP", user, lambda ctx: core.backup())

    @app.get("/api/reconcile/preview/{target_id}")
    async def reconcile_preview(target_id: int, new_alias: str | None = None, _user: WebUser = Depends(require_role("admin"))):
        return core.reconcile_preview(target_id, new_alias)

    @app.post("/api/exports/daily")
    async def export_daily(body: dict[str, Any], _user: WebUser = Depends(csrf_guard)):
        return core.export_daily(str(body.get("day", "")))

    @app.post("/api/exports/current")
    async def export_current(_user: WebUser = Depends(csrf_guard)):
        return core.export_current()

    @app.post("/api/exports/all")
    async def export_all(_user: WebUser = Depends(csrf_guard)):
        return core.export_all()

    @app.get("/api/download")
    async def download(path: str, _user: WebUser = Depends(current_user)):
        candidate = Path(path).resolve()
        allowed_roots = [EXPORT_DIR.resolve(), BACKUP_DIR.resolve()]
        if not any(candidate == root or root in candidate.parents for root in allowed_roots):
            raise HTTPException(status_code=403, detail="DOWNLOAD_PATH_FORBIDDEN")
        if not candidate.is_file():
            raise HTTPException(status_code=404, detail="FILE_NOT_FOUND")
        return FileResponse(candidate, filename=candidate.name)

    @app.websocket("/ws/console/{target_id}")
    async def console_ws(websocket: WebSocket, target_id: int):
        token = websocket.cookies.get(auth.cookie_name)
        user = auth.parse(token)
        if not user or not auth.allowed(user, "operator"):
            await websocket.close(code=4401)
            return
        await websocket.accept()
        try:
            first = json.loads(await asyncio.wait_for(websocket.receive_text(), timeout=15))
        except Exception:
            await websocket.send_text(json.dumps({"type": "error", "data": "Console init timeout/invalid."}))
            await websocket.close(code=4400)
            return
        if first.get("type") != "start" or not auth.valid_csrf(user, first.get("csrf")):
            await websocket.close(code=4403)
            return
        target = core.target_repo.get(int(target_id))
        if not target:
            await websocket.send_text(json.dumps({"type": "error", "data": "Target not found."}))
            await websocket.close(code=4404)
            return
        try:
            _device, credentials = core.require_credentials(user.session_id, int(target.oob_id))
        except Exception as exc:
            await websocket.send_text(json.dumps({"type": "error", "data": friendly_error(exc)}))
            await websocket.close(code=4400)
            return
        output_q: Queue = Queue()
        input_q: Queue = Queue()
        stop_event = threading.Event()
        port_credentials = core.port_credentials(first.get("port_credentials") or {})
        override_reason = str(first.get("override_reason", "") or "")
        allow_unverified = bool(first.get("allow_unverified_state", False))

        def bridge_factory(path):
            return QueueTerminalBridge(path, output_q, input_q, stop_event)

        def worker():
            try:
                core.console_service.open(
                    int(target_id), credentials,
                    port_credentials=port_credentials,
                    allow_unverified_state=allow_unverified,
                    override_reason=override_reason,
                    clear_line_recovery_callback=None,
                    terminal_bridge_factory=bridge_factory,
                )
            except Exception as exc:
                output_q.put({"type": "error", "data": f"{getattr(exc, 'error_code', 'CONSOLE_FAILED')}: {friendly_error(exc)}"})
            finally:
                stop_event.set()
                output_q.put({"type": "closed", "data": "Console worker stopped."})

        thread = threading.Thread(target=worker, daemon=True, name=f"web-console-{target_id}")
        thread.start()

        async def sender():
            while not stop_event.is_set() or not output_q.empty():
                try:
                    item = await asyncio.to_thread(output_q.get, True, 0.25)
                except Exception:
                    continue
                await websocket.send_text(json.dumps(item, ensure_ascii=False))

        async def receiver():
            try:
                while not stop_event.is_set():
                    text = await websocket.receive_text()
                    message = json.loads(text)
                    if message.get("type") == "input":
                        input_q.put(str(message.get("data", "")).encode("utf-8"))
                    elif message.get("type") == "resize":
                        input_q.put(message)
                    elif message.get("type") == "close":
                        stop_event.set()
            except WebSocketDisconnect:
                stop_event.set()

        try:
            await asyncio.gather(sender(), receiver())
        finally:
            stop_event.set()
            try:
                await websocket.close()
            except Exception:
                pass

    return app
