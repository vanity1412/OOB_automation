from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
import threading
import traceback
import uuid
from typing import Any, Callable

from oob_manager.utils.security import sanitize_text


@dataclass(slots=True)
class WebTask:
    id: str
    kind: str
    owner: str
    status: str = "QUEUED"
    progress: int = 0
    current: int = 0
    total: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().astimezone().isoformat(timespec="seconds"))
    started_at: str = ""
    finished_at: str = ""
    logs: list[dict[str, str]] = field(default_factory=list)
    result: Any = None
    error_code: str = ""
    error_message: str = ""
    cancel_requested: bool = False

    def public(self, *, include_logs: bool = True) -> dict[str, Any]:
        data = {
            "id": self.id, "kind": self.kind, "owner": self.owner, "status": self.status,
            "progress": self.progress, "current": self.current, "total": self.total,
            "created_at": self.created_at, "started_at": self.started_at,
            "finished_at": self.finished_at, "result": self.result,
            "error_code": self.error_code, "error_message": self.error_message,
            "cancel_requested": self.cancel_requested,
        }
        if include_logs:
            data["logs"] = list(self.logs[-500:])
        return data


class TaskContext:
    def __init__(self, manager: "TaskManager", task: WebTask) -> None:
        self.manager = manager
        self.task = task

    def log(self, message: str, level: str = "INFO") -> None:
        self.manager.log(self.task.id, message, level)

    def step(self, current: int, total: int, message: str = "") -> None:
        self.manager.progress(self.task.id, current, total)
        if message:
            self.log(message)

    def cancelled(self) -> bool:
        return self.manager.is_cancelled(self.task.id)

    def ensure_not_cancelled(self) -> None:
        if self.cancelled():
            raise TaskCancelled("Operator requested cancellation")


class TaskCancelled(RuntimeError):
    pass


class TaskManager:
    def __init__(self, max_workers: int = 4, max_tasks: int = 300) -> None:
        self._executor = ThreadPoolExecutor(max_workers=max(1, min(max_workers, 8)), thread_name_prefix="oob-web")
        self._tasks: dict[str, WebTask] = {}
        self._lock = threading.RLock()
        self.max_tasks = max_tasks

    def submit(self, kind: str, owner: str, fn: Callable[[TaskContext], Any]) -> WebTask:
        task = WebTask(id=uuid.uuid4().hex, kind=kind, owner=owner)
        with self._lock:
            self._tasks[task.id] = task
            self._prune()
        self._executor.submit(self._run, task.id, fn)
        return task

    def _run(self, task_id: str, fn: Callable[[TaskContext], Any]) -> None:
        with self._lock:
            task = self._tasks[task_id]
            task.status = "RUNNING"
            task.started_at = datetime.now().astimezone().isoformat(timespec="seconds")
        ctx = TaskContext(self, task)
        try:
            result = fn(ctx)
            with self._lock:
                task.result = result
                task.progress = 100 if task.status != "CANCELLED" else task.progress
                if task.status not in {"CANCELLED", "FAILED"}:
                    task.status = "SUCCESS"
        except TaskCancelled:
            with self._lock:
                task.status = "CANCELLED"
                task.error_code = "USER_CANCELLED"
                task.error_message = "Operator requested cancellation."
            self.log(task_id, "Tác vụ đã dừng tại checkpoint an toàn.", "WARNING")
        except Exception as exc:
            code = str(getattr(exc, "error_code", "WEB_TASK_FAILED") or "WEB_TASK_FAILED")
            with self._lock:
                task.status = "FAILED"
                task.error_code = code
                task.error_message = sanitize_text(str(exc))[:2000]
            self.log(task_id, f"FAILED: {code} / {type(exc).__name__}", "ERROR")
            # Technical trace stays process-local; never goes to the browser.
            traceback.print_exc()
        finally:
            with self._lock:
                task.finished_at = datetime.now().astimezone().isoformat(timespec="seconds")

    def log(self, task_id: str, message: str, level: str = "INFO") -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return
            task.logs.append({
                "ts": datetime.now().astimezone().isoformat(timespec="seconds"),
                "level": str(level).upper(),
                "message": sanitize_text(str(message))[:4000],
            })
            if len(task.logs) > 1000:
                del task.logs[:-700]

    def progress(self, task_id: str, current: int, total: int) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return
            task.current = max(0, int(current))
            task.total = max(0, int(total))
            task.progress = min(100, int((task.current / task.total) * 100)) if task.total else 0

    def cancel(self, task_id: str) -> bool:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.status not in {"QUEUED", "RUNNING"}:
                return False
            task.cancel_requested = True
            return True

    def is_cancelled(self, task_id: str) -> bool:
        with self._lock:
            task = self._tasks.get(task_id)
            return bool(task and task.cancel_requested)

    def get(self, task_id: str) -> WebTask | None:
        with self._lock:
            return self._tasks.get(task_id)

    def list(self, owner: str | None = None, limit: int = 100) -> list[WebTask]:
        with self._lock:
            tasks = sorted(self._tasks.values(), key=lambda t: t.created_at, reverse=True)
            if owner:
                tasks = [task for task in tasks if task.owner == owner]
            return tasks[: max(1, min(limit, 500))]

    def shutdown(self) -> None:
        """Stop accepting work and release worker threads during web shutdown/tests."""
        self._executor.shutdown(wait=True, cancel_futures=True)

    def _prune(self) -> None:
        if len(self._tasks) <= self.max_tasks:
            return
        completed = sorted(
            (t for t in self._tasks.values() if t.status not in {"QUEUED", "RUNNING"}),
            key=lambda t: t.created_at,
        )
        for task in completed[: max(0, len(self._tasks) - self.max_tasks)]:
            self._tasks.pop(task.id, None)
