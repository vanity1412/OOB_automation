from __future__ import annotations

from dataclasses import dataclass
import hashlib
import hmac
import os
import secrets
import time
import threading
from typing import Mapping


ROLE_RANK = {"viewer": 10, "operator": 20, "admin": 30}


@dataclass(frozen=True, slots=True)
class WebUser:
    username: str
    role: str
    session_id: str
    expires_at: int


class WebAuth:
    """Small signed-cookie auth layer with role separation and CSRF tokens.

    Passwords are read from environment variables only. There is deliberately no
    default admin password and no password table in the OOB SQLite database.
    """

    cookie_name = "oob_web_session"

    def __init__(self) -> None:
        self.local_mode = os.environ.get("OOB_WEB_LOCAL_MODE", "0") == "1"
        admin_password = os.environ.get("OOB_WEB_ADMIN_PASSWORD", "")
        legacy_password = os.environ.get("OOB_WEB_PASSWORD", "")
        if not admin_password and legacy_password:
            admin_password = legacy_password
        if not self.local_mode and not admin_password:
            raise RuntimeError(
                "Chế độ remote cần đặt OOB_WEB_ADMIN_PASSWORD."
            )
        self.users: dict[str, tuple[str, str]] = {}
        if admin_password:
            self.users["admin"] = (admin_password, "admin")
        operator = os.environ.get("OOB_WEB_OPERATOR_PASSWORD", "")
        viewer = os.environ.get("OOB_WEB_VIEWER_PASSWORD", "")
        if operator:
            self.users["operator"] = (operator, "operator")
        if viewer:
            self.users["viewer"] = (viewer, "viewer")
        secret = os.environ.get("OOB_WEB_SECRET", "")
        self.secret = (secret or secrets.token_hex(48)).encode("utf-8")
        self.ttl = max(900, min(int(os.environ.get("OOB_WEB_SESSION_TTL", "28800")), 86400))

    def local_user(self) -> WebUser:
        now = int(time.time())
        return WebUser(
            username="local-admin",
            role="admin",
            session_id="local-loopback-session",
            expires_at=now + self.ttl,
        )

    def authenticate(self, username: str, password: str) -> tuple[str, str] | None:
        record = self.users.get(str(username or "").strip())
        if not record:
            # Constant-ish work for unknown users.
            hmac.compare_digest(hashlib.sha256(str(password).encode()).digest(), b"\x00" * 32)
            return None
        expected, role = record
        if not hmac.compare_digest(str(password or ""), expected):
            return None
        return str(username).strip(), role

    def issue(self, username: str, role: str) -> tuple[str, WebUser]:
        now = int(time.time())
        expires = now + self.ttl
        session_id = secrets.token_urlsafe(24)
        payload = f"{session_id}|{username}|{role}|{expires}"
        signature = hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()
        token = f"{payload}|{signature}"
        return token, WebUser(username=username, role=role, session_id=session_id, expires_at=expires)

    def parse(self, token: str | None) -> WebUser | None:
        if not token:
            return None
        try:
            session_id, username, role, expires_text, signature = token.split("|", 4)
            expires = int(expires_text)
        except (ValueError, TypeError):
            return None
        if role not in ROLE_RANK or expires < int(time.time()) or expires > int(time.time()) + self.ttl + 60:
            return None
        payload = f"{session_id}|{username}|{role}|{expires}"
        expected = hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            return None
        return WebUser(username=username, role=role, session_id=session_id, expires_at=expires)

    def csrf(self, user: WebUser) -> str:
        return hmac.new(self.secret, f"csrf|{user.session_id}".encode(), hashlib.sha256).hexdigest()

    def valid_csrf(self, user: WebUser, token: str | None) -> bool:
        return bool(token and hmac.compare_digest(token, self.csrf(user)))

    @staticmethod
    def allowed(user: WebUser, minimum_role: str) -> bool:
        return ROLE_RANK.get(user.role, 0) >= ROLE_RANK.get(minimum_role, 99)


class LoginThrottle:
    """Small process-local failure throttle; no username/password is persisted."""

    def __init__(self, *, max_failures: int = 8, window_seconds: int = 300, block_seconds: int = 300) -> None:
        self.max_failures = max(3, min(int(max_failures), 50))
        self.window_seconds = max(60, min(int(window_seconds), 3600))
        self.block_seconds = max(60, min(int(block_seconds), 3600))
        self._lock = threading.RLock()
        self._failures: dict[str, list[float]] = {}
        self._blocked_until: dict[str, float] = {}

    def allowed(self, key: str) -> tuple[bool, int]:
        now = time.time()
        with self._lock:
            until = self._blocked_until.get(key, 0.0)
            if until > now:
                return False, max(1, int(until - now))
            self._blocked_until.pop(key, None)
            recent = [ts for ts in self._failures.get(key, []) if now - ts <= self.window_seconds]
            if recent:
                self._failures[key] = recent
            else:
                self._failures.pop(key, None)
            return True, 0

    def failure(self, key: str) -> None:
        now = time.time()
        with self._lock:
            recent = [ts for ts in self._failures.get(key, []) if now - ts <= self.window_seconds]
            recent.append(now)
            self._failures[key] = recent
            if len(recent) >= self.max_failures:
                self._blocked_until[key] = now + self.block_seconds
                self._failures.pop(key, None)

    def success(self, key: str) -> None:
        with self._lock:
            self._failures.pop(key, None)
            self._blocked_until.pop(key, None)
