from __future__ import annotations

from dataclasses import asdict, is_dataclass
from datetime import date, datetime
import json
from pathlib import Path
import threading
import time
from typing import Any, Mapping

from oob_manager.config import ApplicationSettings, validate_all_profiles
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.cable_check_repository import CableCheckRepository
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.credential_profile_repository import CredentialProfileRepository
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.reconciliation_repository import ReconciliationRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.settings_repository import SettingsRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import ValidationError, friendly_error
from oob_manager.models import (
    DownstreamCredentials,
    OOBDevice,
    PortAuthenticationCredentials,
    SessionCredentials,
)
from oob_manager.services.backup_service import BackupService
from oob_manager.services.cable_verification_service import CableVerificationService
from oob_manager.services.console_service import ConsoleService
from oob_manager.services.database_audit_service import DatabaseAuditService
from oob_manager.services.device_identity_service import DeviceIdentityService
from oob_manager.services.export_service import ExportService
from oob_manager.services.oob_service import OOBService
from oob_manager.services.reconciliation_service import ReconciliationService
from oob_manager.services.scan_service import ScanService
from oob_manager.services.search_service import SearchService
from oob_manager.utils.datetime_utils import utc_now
from oob_manager.utils.paths import DB_PATH, ensure_directories
from oob_manager.utils.security import sanitize_text
from oob_manager.utils.validation import normalize_alias
from oob_manager.vendors.factory import create_vendor_adapter


ROLE_KEYS = {"viewer": 10, "operator": 20, "admin": 30}


def jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {key: jsonable(val) for key, val in asdict(value).items()}
    if isinstance(value, datetime):
        return value.astimezone().isoformat(timespec="seconds")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): jsonable(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [jsonable(item) for item in value]
    return value


class CredentialVault:
    """RAM-only web credential store keyed by signed web session ID."""

    def __init__(self, ttl: int = 8 * 60 * 60) -> None:
        self.ttl = ttl
        self._lock = threading.RLock()
        self._data: dict[str, dict[str, Any]] = {}

    def _entry(self, session_id: str) -> dict[str, Any]:
        with self._lock:
            self._cleanup()
            entry = self._data.setdefault(session_id, {"expires": time.time() + self.ttl, "oob": {}, "vendor": {}, "default": None})
            entry["expires"] = time.time() + self.ttl
            return entry

    def set(self, session_id: str, *, scope: str, scope_id: str, credentials: SessionCredentials) -> None:
        entry = self._entry(session_id)
        with self._lock:
            if scope == "default":
                entry["default"] = credentials
            elif scope == "vendor":
                entry["vendor"][scope_id.upper()] = credentials
            elif scope == "oob":
                entry["oob"][str(scope_id)] = credentials
            else:
                raise ValidationError("Credential scope không hợp lệ.")

    def resolve(self, session_id: str, device: OOBDevice) -> SessionCredentials | None:
        entry = self._entry(session_id)
        with self._lock:
            return (
                entry["oob"].get(str(device.id))
                or entry["vendor"].get(device.vendor.upper())
                or entry.get("default")
            )

    def status(self, session_id: str) -> dict[str, Any]:
        entry = self._entry(session_id)
        with self._lock:
            default = entry.get("default")
            return {
                "default": {"loaded": bool(default), "username": default.username if default else ""},
                "vendors": {key: {"loaded": True, "username": value.username} for key, value in entry["vendor"].items()},
                "oobs": {key: {"loaded": True, "username": value.username} for key, value in entry["oob"].items()},
                "expires_in": max(0, int(entry["expires"] - time.time())),
            }

    def clear(self, session_id: str) -> None:
        with self._lock:
            self._data.pop(session_id, None)

    def _cleanup(self) -> None:
        now = time.time()
        for key in [key for key, value in self._data.items() if value.get("expires", 0) < now]:
            self._data.pop(key, None)


class WebCore:
    """Business facade used by the web API.

    All device/network operations call the same services as the CLI. The web layer
    does not reimplement Cisco/Vertiv safety logic.
    """

    SAFE_SETTING_KEYS = {
        "connect_timeout", "banner_timeout", "auth_timeout", "shell_timeout",
        "command_timeout", "connection_attempts", "retry_delay",
        "operation_lock_lease_seconds", "operation_lock_heartbeat_seconds",
        "maximum_drop_ratio", "export_encoding", "export_dir",
    }

    def __init__(self, db_path: Path | str = DB_PATH) -> None:
        ensure_directories()
        validate_all_profiles()
        self.db = DatabaseConnection(db_path)
        MigrationManager(self.db).migrate()
        self.oob_repo = OOBRepository(self.db)
        self.target_repo = TargetRepository(self.db)
        self.scan_repo = ScanRepository(self.db)
        self.change_repo = ChangeRepository(self.db)
        self.credential_profile_repo = CredentialProfileRepository(self.db)
        self.cable_repo = CableCheckRepository(self.db)
        self.connection_repo = ConnectionRepository(self.db)
        self.identity_repo = DeviceIdentityRepository(self.db)
        self.reconciliation_repo = ReconciliationRepository(self.db)
        self.settings_repo = SettingsRepository(self.db)
        self.vault = CredentialVault()
        self._build_services()
        self.recover_abandoned()

    def _build_services(self) -> None:
        self.settings = ApplicationSettings.from_mapping(self.settings_repo.get_all())
        self.lock_repo = ScanLockRepository(
            self.db,
            lease_seconds=self.settings.operation_lock_lease_seconds,
            heartbeat_seconds=self.settings.operation_lock_heartbeat_seconds,
        )
        self.oob_service = OOBService(self.oob_repo)
        self.search_service = SearchService(self.target_repo)
        self.scan_service = ScanService(
            self.oob_repo, self.target_repo, self.scan_repo, self.change_repo,
            self.lock_repo, self.settings,
        )
        self.cable_service = CableVerificationService(
            self.oob_repo, self.target_repo, self.settings, self.lock_repo,
        )
        self.console_service = ConsoleService(
            self.oob_repo, self.target_repo, self.connection_repo,
            self.settings, self.lock_repo,
        )
        self.identity_service = DeviceIdentityService(
            self.oob_repo, self.target_repo, self.identity_repo,
            self.settings, self.lock_repo,
        )
        self.reconciliation_service = ReconciliationService(
            self.oob_repo, self.target_repo, self.identity_repo,
            self.reconciliation_repo, self.settings, self.lock_repo,
        )
        self.backup_service = BackupService(self.db)
        self.export_service = ExportService(self.db, self.settings)

    def recover_abandoned(self) -> dict[str, int]:
        return {
            "scan": self.scan_repo.recover_abandoned_same_host(),
            "cable": self.cable_repo.recover_abandoned_same_host(),
            "connection": self.connection_repo.recover_abandoned_same_host(),
            "identity": self.identity_repo.recover_abandoned_same_host(),
            "lock": self.lock_repo.recover_stale_same_host(),
        }

    def require_credentials(self, session_id: str, oob_id: int) -> tuple[OOBDevice, SessionCredentials]:
        device = self.oob_repo.get(int(oob_id))
        if not device or not device.enabled:
            raise ValidationError("OOB không tồn tại hoặc đang bị vô hiệu hóa.")
        credentials = self.vault.resolve(session_id, device)
        if not credentials and device.credential_profile_id:
            meta = self.credential_profile_repo.get_meta(device.credential_profile_id)
            if meta and meta.get("vendor_scope") not in ("ANY", device.vendor):
                raise ValidationError("Credential profile không phù hợp vendor OOB.", error_code="CREDENTIAL_VENDOR_SCOPE_MISMATCH")
            credentials = self.credential_profile_repo.resolve(device.credential_profile_id)
        if not credentials:
            raise ValidationError(
                "OOB chưa được gán Credential Profile và phiên web chưa nạp credential RAM.",
                error_code="WEB_OOB_CREDENTIAL_REQUIRED",
            )
        return device, credentials

    @staticmethod
    def port_credentials(payload: Mapping[str, Any] | None) -> PortAuthenticationCredentials:
        payload = payload or {}
        return PortAuthenticationCredentials(
            password=str(payload.get("password", "") or ""),
            use_oob_password=bool(payload.get("use_oob_password", False)),
            direct_username=str(payload.get("direct_username", "") or ""),
            direct_password=str(payload.get("direct_password", "") or ""),
            use_oob_credentials_for_direct=bool(payload.get("use_oob_credentials_for_direct", True)),
            access_method=str(payload.get("access_method", "CLI_CONNECT") or "CLI_CONNECT"),
        )

    @staticmethod
    def downstream_credentials(payload: Mapping[str, Any] | None) -> DownstreamCredentials:
        payload = payload or {}
        return DownstreamCredentials(
            username=str(payload.get("username", "") or ""),
            password=str(payload.get("password", "") or ""),
        )

    # ---------- Read models ----------
    def dashboard(self) -> dict[str, Any]:
        inventory = self.export_service.current_inventory_rows()
        oobs = self.oob_repo.list_all(include_disabled=True)
        with self.db.read() as conn:
            recent_tasks = {
                "scans_running": conn.execute("SELECT COUNT(*) FROM scan_runs WHERE status='RUNNING'").fetchone()[0],
                "cable_running": conn.execute("SELECT COUNT(*) FROM cable_check_runs WHERE status='RUNNING'").fetchone()[0],
                "identity_running": conn.execute("SELECT COUNT(*) FROM device_identity_runs WHERE status='RUNNING'").fetchone()[0],
                "critical_identity": conn.execute(
                    "SELECT COUNT(*) FROM device_identity_events WHERE viewed_at IS NULL AND severity='HIGH'"
                ).fetchone()[0],
                "unviewed_changes": conn.execute("SELECT COUNT(*) FROM change_events WHERE viewed_at IS NULL").fetchone()[0],
            }
        stats = {
            "oobs_total": len(oobs),
            "oobs_enabled": sum(bool(item.enabled) for item in oobs),
            "targets": len(inventory),
            "available": sum(row.get("state") == "AVAILABLE" for row in inventory),
            "busy": sum(str(row.get("state", "")).startswith("BUSY") for row in inventory),
            "unknown": sum(row.get("state") == "UNKNOWN" for row in inventory),
            "match": sum(row.get("cable_status") == "MATCH" for row in inventory),
            "mismatch": sum(row.get("cable_status") == "MISMATCH" for row in inventory),
            "no_hostname": sum(row.get("cable_status") == "NO_HOSTNAME" for row in inventory),
            "identity_accepted": sum(row.get("identity_source") == "ACCEPTED_CURRENT" for row in inventory),
            "identity_observed": sum(row.get("identity_source") == "LATEST_OBSERVED" for row in inventory),
            **recent_tasks,
        }
        return {"stats": stats, "oobs": [jsonable(item) for item in oobs], "recent_inventory": inventory[:30]}

    def inventory(self) -> list[dict[str, Any]]:
        return self.export_service.current_inventory_rows()

    def inventory_detail(self, target_id: int) -> dict[str, Any]:
        target = self.target_repo.get(int(target_id))
        if not target:
            raise ValidationError("Không tìm thấy target.")
        rows = [row for row in self.export_service.current_inventory_rows() if int(row.get("target_id") or 0) == int(target_id)]
        history = self.export_service.target_history_rows(int(target_id), limit=300)
        with self.db.read() as conn:
            raw_identity = [dict(row) for row in conn.execute(
                "SELECT * FROM device_identity_raw_outputs WHERE identity_run_id IN (SELECT id FROM device_identity_runs WHERE target_id=?) ORDER BY id DESC LIMIT 100",
                (int(target_id),),
            ).fetchall()]
            connections = [dict(row) for row in conn.execute(
                "SELECT * FROM connection_history WHERE target_id=? ORDER BY id DESC LIMIT 50", (int(target_id),)
            ).fetchall()]
        return {
            "target": jsonable(target),
            "inventory": rows[0] if rows else {},
            "history": history,
            "raw_identity": raw_identity,
            "connections": connections,
        }

    def oobs(self, include_disabled: bool = True) -> list[dict[str, Any]]:
        result = []
        with self.db.read() as conn:
            for item in self.oob_repo.list_all(include_disabled=include_disabled):
                counts = conn.execute(
                    "SELECT COUNT(*) total, SUM(CASE WHEN state='AVAILABLE' THEN 1 ELSE 0 END) available, SUM(CASE WHEN state LIKE 'BUSY%' THEN 1 ELSE 0 END) busy, SUM(CASE WHEN state='UNKNOWN' THEN 1 ELSE 0 END) unknown FROM console_targets WHERE oob_id=?",
                    (item.id,),
                ).fetchone()
                row = jsonable(item)
                row["target_counts"] = dict(counts) if counts else {}
                if item.credential_profile_id:
                    meta = self.credential_profile_repo.get_meta(item.credential_profile_id)
                    row["credential_profile_name"] = meta.get("name", "") if meta else ""
                    row["credential_profile_username"] = meta.get("username", "") if meta else ""
                else:
                    row["credential_profile_name"] = ""
                    row["credential_profile_username"] = ""
                result.append(row)
        return result

    def targets(self, oob_id: int | None = None) -> list[dict[str, Any]]:
        if oob_id is None:
            with self.db.read() as conn:
                return [dict(row) for row in conn.execute(
                    "SELECT t.*,o.name AS oob_name,o.vendor AS oob_vendor FROM console_targets t JOIN oob_devices o ON o.id=t.oob_id ORDER BY o.name,t.menu_item,t.console_line,t.alias"
                ).fetchall()]
        return [jsonable(item) for item in self.target_repo.list_current(int(oob_id))]

    def search(self, query: str) -> list[dict[str, Any]]:
        results = self.search_service.search_targets(str(query or ""), limit=100)
        return [
            {
                "score": item.score,
                "mapping_stale": item.mapping_stale,
                "oob_name": item.oob_name,
                "target": jsonable(item.target),
            }
            for item in results
        ]

    def history(self, kind: str, limit: int = 200) -> list[dict[str, Any]]:
        safe = max(1, min(int(limit), 1000))
        queries = {
            "scans": "SELECT * FROM scan_runs ORDER BY id DESC LIMIT ?",
            "changes": "SELECT c.*,o.name AS oob_name FROM change_events c JOIN oob_devices o ON o.id=c.oob_id ORDER BY c.id DESC LIMIT ?",
            "connections": "SELECT h.*,o.name AS oob_name FROM connection_history h JOIN oob_devices o ON o.id=h.oob_id ORDER BY h.id DESC LIMIT ?",
            "cable_runs": "SELECT r.*,o.name AS oob_name FROM cable_check_runs r JOIN oob_devices o ON o.id=r.oob_id ORDER BY r.id DESC LIMIT ?",
            "cable_results": "SELECT x.*,r.started_at,r.status run_status,o.name AS oob_name FROM cable_check_results x JOIN cable_check_runs r ON r.id=x.run_id JOIN oob_devices o ON o.id=x.oob_id ORDER BY x.id DESC LIMIT ?",
            "identity_runs": "SELECT r.*,o.name AS oob_name FROM device_identity_runs r JOIN oob_devices o ON o.id=r.oob_id ORDER BY r.id DESC LIMIT ?",
            "identity_events": "SELECT e.*,o.name AS oob_name FROM device_identity_events e JOIN oob_devices o ON o.id=e.oob_id ORDER BY e.id DESC LIMIT ?",
            "reconciliations": "SELECT r.*,o.name AS oob_name FROM oob_reconciliation_history r JOIN oob_devices o ON o.id=r.oob_id ORDER BY r.id DESC LIMIT ?",
            "raw_outputs": "SELECT * FROM raw_outputs ORDER BY id DESC LIMIT ?",
        }
        if kind not in queries:
            raise ValidationError("Loại lịch sử không hợp lệ.")
        with self.db.read() as conn:
            return [dict(row) for row in conn.execute(queries[kind], (safe,)).fetchall()]


    def daily_inventory(self, day_text: str) -> list[dict[str, Any]]:
        try:
            day = date.fromisoformat(str(day_text))
        except ValueError as exc:
            raise ValidationError("Ngày phải có định dạng YYYY-MM-DD.") from exc
        return self.export_service.daily_inventory_rows(day)

    def scan_snapshot(self, scan_id: int) -> list[dict[str, Any]]:
        return self.export_service.scan_snapshot_rows(int(scan_id))

    def export_daily(self, day_text: str) -> dict[str, Any]:
        try:
            day = date.fromisoformat(str(day_text))
        except ValueError as exc:
            raise ValidationError("Ngày phải có định dạng YYYY-MM-DD.") from exc
        path = self.export_service.export_daily_inventory(day)
        return {"path": str(path), "name": path.name}

    def mark_viewed(self, kind: str, event_ids: list[int]) -> dict[str, Any]:
        ids = sorted({int(value) for value in event_ids if int(value) > 0})
        if kind == "changes":
            self.change_repo.mark_viewed(ids)
        elif kind == "identity_events":
            self.identity_repo.mark_events_viewed(ids)
        else:
            raise ValidationError("Chỉ mapping changes và identity events hỗ trợ đánh dấu đã xem.")
        return {"kind": kind, "marked": len(ids)}

    def health(self) -> dict[str, Any]:
        with self.db.read() as conn:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            foreign = [dict(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]
            schema = conn.execute("PRAGMA user_version").fetchone()[0]
            issues = DatabaseAuditService.collect_issues(conn)
        return {"integrity": integrity, "foreign_key_violations": foreign, "schema": schema, "issues": issues}

    def settings_data(self) -> dict[str, Any]:
        values = self.settings_repo.get_all()
        return {key: values.get(key, str(getattr(self.settings, key))) for key in sorted(self.SAFE_SETTING_KEYS)}

    # ---------- CRUD ----------
    def create_oob(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        vendor = str(payload.get("vendor", "CISCO") or "CISCO").upper()
        device = OOBDevice(
            name=str(payload.get("name", "") or "").strip(),
            host=str(payload.get("host", "") or "").strip(),
            ssh_port=int(payload.get("ssh_port", 22) or 22),
            vendor=vendor,
            device_type="cisco_ios" if vendor == "CISCO" else "vertiv",
            default_username=str(payload.get("default_username", "") or "").strip(),
            credential_profile_id=(int(payload.get("credential_profile_id")) if payload.get("credential_profile_id") not in (None, "", 0, "0") else None),
            connection_mode="SSH",
            enabled=bool(payload.get("enabled", True)),
            notes=str(payload.get("notes", "") or "").strip(),
        )
        return jsonable(self.oob_service.create(device))

    def update_oob(self, oob_id: int, payload: Mapping[str, Any]) -> dict[str, Any]:
        device = self.oob_repo.get(int(oob_id))
        if not device:
            raise ValidationError("Không tìm thấy OOB.")
        for key in ("name", "host", "default_username", "notes"):
            if key in payload:
                setattr(device, key, str(payload[key] or "").strip())
        if "credential_profile_id" in payload:
            device.credential_profile_id = int(payload["credential_profile_id"]) if payload["credential_profile_id"] not in (None, "", 0, "0") else None
        if "ssh_port" in payload:
            device.ssh_port = int(payload["ssh_port"])
        if "vendor" in payload:
            device.vendor = str(payload["vendor"] or "").upper()
            device.device_type = "cisco_ios" if device.vendor == "CISCO" else "vertiv"
        if "enabled" in payload:
            device.enabled = bool(payload["enabled"])
        return jsonable(self.oob_service.update(device))

    def disable_oob(self, oob_id: int) -> None:
        self.oob_service.disable(int(oob_id))

    def update_settings(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        updates = {key: str(payload[key]) for key in self.SAFE_SETTING_KEYS if key in payload}
        current = self.settings_repo.get_all()
        proposed = {**current, **updates}
        ApplicationSettings.from_mapping(proposed)
        self.settings_repo.set_many(updates)
        self._build_services()
        return self.settings_data()

    # ---------- Persistent credential profiles ----------
    def credential_profiles(self) -> list[dict[str, Any]]:
        return self.credential_profile_repo.list_all(include_disabled=True)

    def create_credential_profile(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        return self.credential_profile_repo.create(
            name=str(payload.get("name", "")), username=str(payload.get("username", "")),
            password=str(payload.get("password", "")), enable_password=str(payload.get("enable_password", "")),
            vendor_scope=str(payload.get("vendor_scope", "ANY")), notes=str(payload.get("notes", "")),
            enabled=bool(payload.get("enabled", True)),
        )

    def update_credential_profile(self, profile_id: int, payload: Mapping[str, Any]) -> dict[str, Any]:
        return self.credential_profile_repo.update(
            int(profile_id), name=str(payload.get("name", "")), username=str(payload.get("username", "")),
            password=(str(payload.get("password")) if payload.get("password") not in (None, "") else None),
            enable_password=(str(payload.get("enable_password", "")) if payload.get("password") not in (None, "") else None),
            vendor_scope=str(payload.get("vendor_scope", "ANY")), notes=str(payload.get("notes", "")),
            enabled=bool(payload.get("enabled", True)),
        )

    def delete_credential_profile(self, profile_id: int) -> None:
        self.credential_profile_repo.delete(int(profile_id))

    def assign_credential_profile(self, oob_id: int, profile_id: int | None) -> dict[str, Any]:
        device = self.oob_repo.get(int(oob_id))
        if not device: raise ValidationError("Không tìm thấy OOB.")
        if profile_id is not None:
            meta=self.credential_profile_repo.get_meta(int(profile_id))
            if not meta or not meta.get("enabled"): raise ValidationError("Credential profile không tồn tại hoặc đã tắt.")
            if meta.get("vendor_scope") not in ("ANY", device.vendor): raise ValidationError("Credential profile không phù hợp vendor OOB.")
        device.credential_profile_id = int(profile_id) if profile_id is not None else None
        return jsonable(self.oob_service.update(device))

    # ---------- Operations ----------

    def test_connection(self, ctx, session_id: str, oob_id: int) -> dict[str, Any]:
        device, credentials = self.require_credentials(session_id, oob_id)
        ctx.log(f"Test SSH OOB {device.name} ({device.vendor} {device.host}:{device.ssh_port})")
        result = create_vendor_adapter(device, self.settings).test_connection(device, credentials)
        level = "SUCCESS" if result.success else "ERROR"
        ctx.log(result.message or ("Kết nối thành công." if result.success else "Kết nối thất bại."), level)
        if not result.success:
            raise ValidationError(result.message or "Test connection thất bại.", error_code="OOB_CONNECTION_TEST_FAILED")
        return jsonable(result)

    def scan_one(self, ctx, session_id: str, oob_id: int, trigger: str = "WEB_SCAN") -> dict[str, Any]:
        device, credentials = self.require_credentials(session_id, oob_id)
        ctx.log(f"SSH/scan OOB {device.name} ({device.vendor} {device.host}:{device.ssh_port})")
        result = self.scan_service.scan_one(int(oob_id), credentials, trigger_source=trigger)
        ctx.log(
            f"Scan={result.status}; mapping={result.mapping_quality}; target={result.mapping_count}; complete={result.complete_count}; baseline_updated={result.baseline_updated}",
            "SUCCESS" if result.mapping_quality == "ACCEPTED" else "WARNING",
        )
        return jsonable(result)

    def scan_all(self, ctx, session_id: str) -> dict[str, Any]:
        devices = self.oob_repo.list_all(include_disabled=False)
        output = []
        for index, device in enumerate(devices, 1):
            ctx.ensure_not_cancelled()
            ctx.step(index - 1, len(devices), f"[{index}/{len(devices)}] Scan {device.name}")
            credentials = self.vault.resolve(session_id, device)
            if not credentials:
                output.append({"oob_id": device.id, "oob": device.name, "status": "SKIPPED", "error_code": "WEB_OOB_CREDENTIAL_REQUIRED"})
                ctx.log(f"Bỏ qua {device.name}: chưa có credential RAM.", "WARNING")
                continue
            try:
                result = self.scan_service.scan_one(int(device.id), credentials, trigger_source="WEB_SCAN_ALL")
                output.append(jsonable(result))
            except Exception as exc:
                output.append({"oob_id": device.id, "oob": device.name, "status": "FAILED", "error_code": getattr(exc, "error_code", "SCAN_FAILED"), "message": friendly_error(exc)})
                ctx.log(f"{device.name}: {getattr(exc, 'error_code', 'SCAN_FAILED')}", "ERROR")
        ctx.step(len(devices), len(devices), "Scan tất cả hoàn tất.")
        return {"items": output}

    @staticmethod
    def _port_value(target) -> str:
        if target.protocol == "VERTIV_CLI":
            value = target.console_line if target.console_line is not None else target.menu_item
            return str(value) if value is not None else "-"
        return str(target.target_port or target.console_line or target.menu_item or "-")

    @staticmethod
    def _console_path(target) -> str:
        if target.protocol == "VERTIV_CLI":
            return f"serial/{target.console_line or target.menu_item or '-'}"
        return f"{target.target_host or '-'}:{target.target_port or '-'} / line {target.console_line or '-'}"

    def _audit_fields(self, source: Any, target: Any, *, probed: bool) -> dict[str, Any]:
        return {
            "target_alias": str(target.alias or "").strip(),
            "runtime_mapping_verified": bool(getattr(source, "runtime_mapping_verified", False)) if source else False,
            "runtime_mapping_verification_code": str(getattr(source, "runtime_mapping_verification_code", "") or ("UNVERIFIED" if probed else "FRESH_SCAN_ONLY_NOT_RUNTIME_RECHECKED")),
            "runtime_mapping_verification_message": str(getattr(source, "runtime_mapping_verification_message", "") or ("Port was not opened; runtime mapping was not re-read." if not probed else "")),
            "live_state": str(getattr(source, "live_state", "") or target.state or "UNKNOWN"),
            "live_state_confident": bool(getattr(source, "live_state_confident", False)) if source else bool(target.state_confident),
            "live_state_reason_code": str(getattr(source, "live_state_reason_code", "") or target.state_reason_code or ""),
            "live_state_evidence": str(getattr(source, "live_state_evidence", "") or target.state_evidence or "{}"),
            "live_state_checked_at": str(getattr(source, "live_state_checked_at", "") or ""),
        }

    def quick_ab(self, ctx, session_id: str, oob_id: int, port_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        device, credentials = self.require_credentials(session_id, oob_id)
        scan = self.scan_service.scan_one(int(oob_id), credentials, trigger_source="WEB_SCAN_CABLE_VERIFY")
        ctx.log(f"Fresh scan: {scan.status}/{scan.mapping_quality}; baseline_updated={scan.baseline_updated}")
        run_id = self.cable_repo.start(device, scan.scan_id)
        if scan.mapping_quality != "ACCEPTED" or not scan.baseline_updated:
            self.cable_repo.finish(run_id, status="FAILED", error_code="A_B_BLOCKED_BY_SCAN_QUALITY", error_message=scan.error_message or "Mapping not accepted")
            raise ValidationError("Fresh scan không tạo baseline ACCEPTED; Quick A/B bị chặn.", error_code="A_B_BLOCKED_BY_SCAN_QUALITY")
        device = self.oob_repo.get(int(oob_id)) or device
        targets = self.target_repo.list_current(int(oob_id))
        supported = lambda t: t.protocol == ("TELNET" if device.vendor == "CISCO" else "VERTIV_CLI")
        candidates = [t for t in targets if t.is_complete and t.state_confident and t.state == "AVAILABLE" and supported(t)]
        candidate_ids = {t.id for t in candidates}
        port_credentials = self.port_credentials(port_payload)
        counts = {"MATCH": 0, "MISMATCH": 0, "NO_HOSTNAME": 0, "SKIP/ERROR": 0}
        rows: list[dict[str, Any]] = []
        for target in targets:
            if target.id in candidate_ids:
                continue
            row = {
                "target_id": target.id, "port": self._port_value(target), "console_path": self._console_path(target),
                "device_a": target.alias, "device_b": "", "status": "SKIP/ERROR",
                "evidence_source": "", "wake_count": 0, "passive_wait_used": False,
                **self._audit_fields(None, target, probed=False),
                "error_code": "UNSAFE_OR_UNSUPPORTED_PORT",
                "message": f"Not opened: state={target.state}; confident={target.state_confident}; complete={target.is_complete}; protocol={target.protocol}",
            }
            self.cable_repo.record(run_id, int(oob_id), row)
            rows.append(row); counts["SKIP/ERROR"] += 1
        for index, target in enumerate(candidates, 1):
            ctx.ensure_not_cancelled()
            ctx.step(index - 1, len(candidates), f"[{index}/{len(candidates)}] Quick A/B {target.alias} / port {self._port_value(target)}")
            try:
                result = self.cable_service.probe(int(target.id), credentials, port_credentials=port_credentials)
                device_b = str(result.identity.actual_hostname or "").strip()
                if not device_b:
                    status = "NO_HOSTNAME"
                elif target.alias and normalize_alias(target.alias) == normalize_alias(device_b):
                    status = "MATCH"
                else:
                    status = "MISMATCH"
                row = {
                    "target_id": target.id, "port": self._port_value(target), "console_path": self._console_path(target),
                    "device_a": target.alias, "device_b": device_b, "status": status,
                    "evidence_source": str(result.metadata.get("cable_identity_source", "") or ("NO_HOSTNAME" if not device_b else "CONSOLE_BANNER")),
                    "wake_count": int(result.metadata.get("quick_probe_wake_count", 0) or 0),
                    "passive_wait_used": bool(result.metadata.get("quick_probe_passive_wait_used", False)),
                    **self._audit_fields(result, target, probed=True),
                    "error_code": "", "message": "Hostname read from banner/prompt; no downstream login or commands." if device_b else "Console opened; hostname not visible; stopped without login.",
                }
            except Exception as exc:
                row = {
                    "target_id": target.id, "port": self._port_value(target), "console_path": self._console_path(target),
                    "device_a": target.alias, "device_b": "", "status": "SKIP/ERROR",
                    "evidence_source": "", "wake_count": 0, "passive_wait_used": False,
                    **self._audit_fields(exc, target, probed=True),
                    "error_code": str(getattr(exc, "error_code", "QUICK_HOSTNAME_PROBE_FAILED")),
                    "message": friendly_error(exc),
                }
            self.cable_repo.record(run_id, int(oob_id), row)
            rows.append(row); counts[row["status"]] += 1
            ctx.log(f"{target.alias}: {row['status']} B={row['device_b'] or '-'} {row['error_code']}", "SUCCESS" if row["status"] == "MATCH" else "WARNING")
        self.cable_repo.finish(run_id)
        ctx.step(len(candidates), len(candidates), "Quick A/B hoàn tất và đã commit từng port.")
        paths = self.export_service.export_cable_verification(device.name, rows)
        return {"run_id": run_id, "scan_id": scan.scan_id, "counts": counts, "rows": rows, "exports": jsonable(paths)}

    def smart_verify(self, ctx, session_id: str, oob_id: int, downstream_payload: Mapping[str, Any], port_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Operator-friendly complete workflow using the existing safe services.

        Phase 1 establishes Device A/B from banner-only probing. Phase 2 performs
        another fresh mapping/state scan before read-only downstream inventory.
        The deliberate second scan prevents model/serial collection from relying
        on a mapping that may have changed during the A/B batch.
        """
        ctx.log("PHA 1/2 — Fresh scan + Quick A/B banner-only")
        cable = self.quick_ab(ctx, session_id, oob_id, port_payload)
        ctx.ensure_not_cancelled()
        ctx.log("PHA 2/2 — Fresh scan + Full Inventory read-only")
        identity = self.full_inventory(ctx, session_id, oob_id, downstream_payload, port_payload)
        return {
            "workflow": "SMART_VERIFY",
            "oob_id": int(oob_id),
            "cable": cable,
            "identity": identity,
        }

    def full_inventory(self, ctx, session_id: str, oob_id: int, downstream_payload: Mapping[str, Any], port_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        device, credentials = self.require_credentials(session_id, oob_id)
        downstream = self.downstream_credentials(downstream_payload)
        port_credentials = self.port_credentials(port_payload)
        scan = self.scan_service.scan_one(int(oob_id), credentials, trigger_source="WEB_BATCH_FULL_INVENTORY")
        ctx.log(f"Fresh scan: {scan.status}/{scan.mapping_quality}; baseline_updated={scan.baseline_updated}")
        if scan.mapping_quality != "ACCEPTED" or not scan.baseline_updated:
            raise ValidationError("Mapping live chưa đạt ACCEPTED; Full Inventory bị chặn.", error_code="FULL_INVENTORY_SCAN_REJECTED")
        device = self.oob_repo.get(int(oob_id)) or device
        targets = self.target_repo.list_current(int(oob_id))
        expected_protocol = "TELNET" if device.vendor == "CISCO" else "VERTIV_CLI"
        candidates = [t for t in targets if t.is_complete and t.state_confident and t.state == "AVAILABLE" and t.protocol == expected_protocol]
        output = []
        for index, target in enumerate(candidates, 1):
            ctx.ensure_not_cancelled()
            ctx.step(index - 1, len(candidates), f"[{index}/{len(candidates)}] Full Identity {target.alias}")
            try:
                result = self.identity_service.discover(
                    int(target.id), credentials, downstream, port_credentials,
                    clear_line_recovery_callback=None,
                )
                identity = result.identity
                row = {
                    "target_id": target.id, "device_a": target.alias,
                    "device_b": identity.actual_hostname, "vendor": identity.vendor,
                    "platform": identity.platform_family, "model": identity.model,
                    "serial": identity.serial_number, "version": identity.software_version,
                    "quality": identity.quality, "confidence": identity.confidence,
                    "verification": result.verification.status,
                    "error_code": "",
                }
                ctx.log(f"{target.alias}: {identity.quality} model={identity.model or '-'} serial={identity.serial_number or '-'}", "SUCCESS" if identity.quality == "ACCEPTED" else "WARNING")
            except Exception as exc:
                row = {"target_id": target.id, "device_a": target.alias, "quality": "FAILED", "error_code": str(getattr(exc, "error_code", "DOWNSTREAM_DISCOVERY_FAILED")), "message": friendly_error(exc)}
                ctx.log(f"{target.alias}: {row['error_code']}", "ERROR")
            output.append(row)
        ctx.step(len(candidates), len(candidates), "Batch Full Inventory hoàn tất.")
        return {"scan_id": scan.scan_id, "candidate_count": len(candidates), "skipped_before_open": len(targets) - len(candidates), "items": output}

    def identity_one(self, ctx, session_id: str, target_id: int, downstream_payload: Mapping[str, Any], port_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        target = self.target_repo.get(int(target_id))
        if not target:
            raise ValidationError("Không tìm thấy target.")
        device, credentials = self.require_credentials(session_id, int(target.oob_id))
        downstream = self.downstream_credentials(downstream_payload)
        port_credentials = self.port_credentials(port_payload)
        ctx.log(f"Full Identity {target.alias} qua {device.name}")
        result = self.identity_service.discover(int(target_id), credentials, downstream, port_credentials, clear_line_recovery_callback=None)
        return jsonable(result)

    def reconcile_preview(self, target_id: int, new_alias: str | None = None) -> dict[str, Any]:
        return jsonable(self.reconciliation_service.build_plan(int(target_id), new_alias))

    def reconcile_apply(self, ctx, session_id: str, target_id: int, new_alias: str, ticket_id: str, reason: str) -> dict[str, Any]:
        plan = self.reconciliation_service.build_plan(int(target_id), new_alias)
        _device, credentials = self.require_credentials(session_id, int(plan.oob_id))
        ctx.log(f"Apply controlled alias reconciliation {plan.old_alias} -> {plan.new_alias}")
        reconciliation_id, result = self.reconciliation_service.apply(plan, credentials, ticket_id=ticket_id, reason=reason)
        return {"reconciliation_id": reconciliation_id, "result": jsonable(result)}

    def backup(self) -> dict[str, Any]:
        path = self.backup_service.create_backup()
        return {"path": str(path), "name": path.name, "checksum": str(path.with_suffix(path.suffix + '.sha256'))}

    def export_current(self) -> dict[str, Any]:
        path = self.export_service.export_current_inventory()
        return {"path": str(path), "name": path.name}

    def export_all(self) -> dict[str, Any]:
        path = self.export_service.export_all()
        return {"path": str(path), "name": path.name}
