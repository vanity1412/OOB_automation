from __future__ import annotations

from queue import Empty, Queue
import threading
import time

from oob_manager.networking.terminal_bridge import _SessionRecorder


class QueueTerminalBridge:
    """Thread bridge used by the browser WebSocket console.

    It preserves the existing session recorder/redaction behavior and never logs
    browser cookies or OOB credentials.
    """

    def __init__(self, session_log_path, output_queue: Queue, input_queue: Queue, stop_event: threading.Event) -> None:
        self.output_queue = output_queue
        self.input_queue = input_queue
        self.stop_event = stop_event
        self.recorder = _SessionRecorder(session_log_path) if session_log_path else None
        self.channel = None

    def _out(self, text: str) -> None:
        if not text:
            return
        if self.recorder:
            self.recorder.output(text)
        self.output_queue.put({"type": "output", "data": text})

    def bridge(self, channel, initial_output: str = "") -> None:
        self.channel = channel
        try:
            if initial_output:
                self._out(initial_output)
            try:
                channel.settimeout(0.15)
            except Exception:
                pass
            while not self.stop_event.is_set():
                if getattr(channel, "closed", False) or getattr(channel, "eof_received", False):
                    break
                try:
                    if callable(getattr(channel, "recv_ready", None)) and channel.recv_ready():
                        payload = channel.recv(65535)
                        if not payload:
                            break
                        self._out(payload.decode("utf-8", errors="replace"))
                except Exception:
                    pass
                for _ in range(50):
                    try:
                        item = self.input_queue.get_nowait()
                    except Empty:
                        break
                    if isinstance(item, dict) and item.get("type") == "resize":
                        try:
                            channel.resize_pty(width=int(item.get("cols", 120)), height=int(item.get("rows", 36)))
                        except Exception:
                            pass
                        continue
                    payload = item if isinstance(item, bytes) else str(item).encode()
                    if self.recorder:
                        self.recorder.input(payload)
                    offset = 0
                    while offset < len(payload):
                        sent = channel.send(payload[offset:])
                        if sent is None:
                            break
                        if not isinstance(sent, int) or sent <= 0:
                            self.stop_event.set()
                            break
                        offset += sent
                time.sleep(0.02)
        finally:
            self.stop_event.set()
            try:
                channel.close()
            except Exception:
                pass
            if self.recorder:
                self.recorder.close()
            self.output_queue.put({"type": "closed", "data": "Console session closed."})
