#!/usr/bin/env python3
"""Read-only local web dashboard for OOB Console Manager.

No third-party web framework is required. The server refuses to start without
OOB_WEB_PASSWORD, binds to 127.0.0.1 by default, and exposes no write/scan/push/
clear-line/credential endpoint.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.cable_check_repository import CableCheckRepository
from oob_manager.services.export_service import ExportService
from oob_manager.utils.paths import DB_PATH, ensure_directories

USERNAME = os.environ.get("OOB_WEB_USERNAME", "operator")
PASSWORD = os.environ.get("OOB_WEB_PASSWORD", "")
if not PASSWORD:
    raise SystemExit(
        "Từ chối khởi động vì chưa đặt OOB_WEB_PASSWORD. "
        "PowerShell: $env:OOB_WEB_PASSWORD='mat-khau-manh'"
    )
SECRET = (os.environ.get("OOB_WEB_SECRET") or secrets.token_hex(32)).encode()
COOKIE_NAME = "oob_auth"
COOKIE_TTL = 8 * 60 * 60

ensure_directories()
db = DatabaseConnection(DB_PATH)
MigrationManager(db).migrate()
export_service = ExportService(db, ApplicationSettings())
cable_repo = CableCheckRepository(db)

LOGIN_HTML = """<!doctype html><meta charset=utf-8><title>OOB Login</title>
<style>body{font-family:system-ui;background:#08101f;color:#e8eefc;display:grid;place-items:center;height:100vh;margin:0}form{background:#121a31;border:1px solid #2b3b63;border-radius:14px;padding:28px;width:min(360px,86vw)}input,button{width:100%;box-sizing:border-box;padding:12px;margin-top:12px;border-radius:8px;border:1px solid #33466f}input{background:#0d152a;color:#fff}button{background:#345eea;color:#fff;font-weight:700}.err{color:#ff8e8e}</style>
<form method=post action=/login><h2>OOB Inventory</h2><p>Dashboard read-only</p><input name=username placeholder=Username required autofocus><input name=password type=password placeholder=Password required><button>Đăng nhập</button>__ERROR__</form>"""

DASHBOARD_HTML = """<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>OOB Inventory</title>
<style>:root{color-scheme:dark}body{font-family:system-ui;margin:0;background:#08101f;color:#e8eefc}.bar{position:sticky;top:0;background:#101a31;padding:14px 18px;border-bottom:1px solid #26385e;display:flex;gap:12px;align-items:center}.bar b{font-size:18px}.bar a{margin-left:auto;color:#9bb7ff}.wrap{padding:18px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px}.card{background:#111c34;border:1px solid #26385e;border-radius:12px;padding:14px}.card strong{font-size:24px;display:block}.scroll{overflow:auto;border:1px solid #26385e;border-radius:12px}table{border-collapse:collapse;width:100%;min-width:1700px;background:#0e172c}th,td{padding:9px 10px;border-bottom:1px solid #223254;text-align:left;white-space:nowrap;font-size:13px}th{position:sticky;top:55px;background:#172441}.MATCH,.NORMAL,.ACCEPTED{color:#68e39b}.MISMATCH,.FAILED,.STALE_MAPPING{color:#ff7b7b}.PARTIAL,.NO_HOSTNAME{color:#ffd166}.muted{color:#9aa8c6}.controls{display:flex;gap:10px;margin:12px 0}.controls input{flex:1;padding:10px;background:#0c1529;color:#fff;border:1px solid #31446f;border-radius:8px}</style>
<div class=bar><b>OOB Console Manager — Read-only Inventory</b><span id=stamp class=muted></span><a href=/logout>Đăng xuất</a></div><div class=wrap><div class=cards id=cards></div><div class=controls><input id=q placeholder='Lọc OOB, Device A/B, model, serial, version...'><button onclick=loadData()>Làm mới</button></div><div class=scroll><table><thead><tr><th>OOB</th><th>Console</th><th>State</th><th>Device A</th><th>Device B</th><th>A/B</th><th>A/B freshness</th><th>Runtime mapping</th><th>Live state</th><th>Vendor</th><th>Model</th><th>Serial</th><th>Version</th><th>Identity</th><th>ID source</th><th>Overall</th><th>Scan</th><th>A/B checked</th><th>ID checked</th><th>Tool action</th><th>Error</th></tr></thead><tbody id=body></tbody></table></div></div>
<script>let rows=[];const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));function td(v,cl=''){return `<td class="${esc(cl)}">${esc(v||'-')}</td>`}function render(){const q=document.getElementById('q').value.toLowerCase();const f=rows.filter(r=>JSON.stringify(r).toLowerCase().includes(q));document.getElementById('body').innerHTML=f.map(r=>`<tr>${td(r.oob)}${td(r.console_path)}${td(r.state,r.state)}${td(r.target_alias)}${td(r.device_b||r.full_identity_hostname)}${td(r.cable_status_display,r.cable_status_display)}${td(r.cable_freshness,r.cable_freshness)}${td((r.cable_runtime_mapping_verified?'YES':'NO')+'/'+(r.cable_runtime_mapping_verification_code||'UNVERIFIED'))}${td((r.cable_live_state||'UNKNOWN')+'/'+(r.cable_live_state_confident?'CONFIDENT':'UNCONFIRMED'))}${td(r.device_vendor)}${td(r.model)}${td(r.serial)}${td(r.version)}${td(r.identity,r.identity)}${td(r.identity_source)}${td(r.overall,r.overall)}${td(r.scan_id)}${td(r.cable_checked_at)}${td(r.identity_checked_at)}${td(r.action_summary)}${td((r.cable_error_code||r.identity_error_code||'')+' '+(r.cable_message||r.identity_error_message||''))}</tr>`).join('')}async function loadData(){const[ir,sr]=await Promise.all([fetch('/api/inventory'),fetch('/api/stats')]);if(ir.status===401){location='/login';return}rows=await ir.json();const s=await sr.json();document.getElementById('cards').innerHTML=Object.entries(s).map(([k,v])=>`<div class=card><span class=muted>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join('');document.getElementById('stamp').textContent='Cập nhật '+new Date().toLocaleString();render()}document.getElementById('q').addEventListener('input',render);loadData();setInterval(loadData,30000)</script>"""


def _token(timestamp: int) -> str:
    payload = f"{USERNAME}:{timestamp}".encode()
    signature = hmac.new(SECRET, payload, hashlib.sha256).hexdigest()
    return f"{timestamp}.{signature}"


def _valid_token(value: str) -> bool:
    try:
        ts_text, signature = value.split(".", 1)
        timestamp = int(ts_text)
    except (ValueError, TypeError):
        return False
    if timestamp > int(time.time()) + 60 or int(time.time()) - timestamp > COOKIE_TTL:
        return False
    expected = _token(timestamp).split(".", 1)[1]
    return hmac.compare_digest(signature, expected)


class Handler(BaseHTTPRequestHandler):
    server_version = "OOBReadOnly/1.2.0"

    def log_message(self, fmt: str, *args) -> None:
        # Do not log cookies, request bodies, or credentials.
        print(f"[WEB] {self.client_address[0]} {fmt % args}")

    def _authenticated(self) -> bool:
        jar = cookies.SimpleCookie(self.headers.get("Cookie", ""))
        item = jar.get(COOKIE_NAME)
        return bool(item and _valid_token(item.value))

    def _send(self, status: int, body: bytes, content_type: str, headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _html(self, html: str, status: int = 200, headers: dict[str, str] | None = None) -> None:
        self._send(status, html.encode("utf-8"), "text/html; charset=utf-8", headers)

    def _json(self, data, status: int = 200) -> None:
        self._send(status, json.dumps(data, ensure_ascii=False, default=str).encode("utf-8"), "application/json; charset=utf-8")

    def _redirect(self, location: str, headers: dict[str, str] | None = None) -> None:
        merged = {"Location": location, **(headers or {})}
        self._send(303, b"", "text/plain; charset=utf-8", merged)

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/login":
            self._json({"error": "read_only"}, 405)
            return
        length = min(int(self.headers.get("Content-Length", "0") or 0), 8192)
        fields = parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
        user_ok = hmac.compare_digest(fields.get("username", [""])[0], USERNAME)
        pass_ok = hmac.compare_digest(fields.get("password", [""])[0], PASSWORD)
        if not (user_ok and pass_ok):
            self._html(LOGIN_HTML.replace("__ERROR__", "<p class=err>Sai username hoặc password.</p>"), 401)
            return
        token = _token(int(time.time()))
        self._redirect("/", {"Set-Cookie": f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={COOKIE_TTL}"})

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/login":
            self._html(LOGIN_HTML.replace("__ERROR__", ""))
            return
        if path == "/logout":
            self._redirect("/login", {"Set-Cookie": f"{COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
            return
        if not self._authenticated():
            if path.startswith("/api/"):
                self._json({"error": "unauthorized"}, 401)
            else:
                self._redirect("/login")
            return
        if path == "/":
            self._html(DASHBOARD_HTML)
            return
        if path == "/api/inventory":
            self._json(export_service.current_inventory_rows())
            return
        if path == "/api/stats":
            rows = export_service.current_inventory_rows()
            self._json({
                "Targets": len(rows),
                "MATCH": sum(r.get("cable_status") == "MATCH" for r in rows),
                "MISMATCH": sum(r.get("cable_status") == "MISMATCH" for r in rows),
                "NO_HOSTNAME": sum(r.get("cable_status") == "NO_HOSTNAME" for r in rows),
                "Identity ACCEPTED": sum(r.get("identity_source") == "ACCEPTED_CURRENT" for r in rows),
                "Identity PARTIAL": sum(r.get("identity_source") == "LATEST_OBSERVED" for r in rows),
            })
            return
        if path == "/api/cable-runs":
            self._json([dict(row) for row in cable_repo.list_run_summaries(limit=100)])
            return
        if path == "/api/health":
            with db.read() as conn:
                self._json({
                    "integrity": conn.execute("PRAGMA integrity_check").fetchone()[0],
                    "foreign_key_violations": len(conn.execute("PRAGMA foreign_key_check").fetchall()),
                    "schema": conn.execute("PRAGMA user_version").fetchone()[0],
                })
            return
        self._json({"error": "not_found"}, 404)


def main() -> None:
    host = os.environ.get("OOB_WEB_HOST", "127.0.0.1")
    port = int(os.environ.get("OOB_WEB_PORT", "5000"))
    if host not in {"127.0.0.1", "localhost", "::1"}:
        print("CẢNH BÁO: Dashboard không cung cấp TLS; chỉ bind mạng ngoài khi có reverse proxy HTTPS và firewall.")
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"OOB read-only dashboard: http://{host}:{port} (user={USERNAME})")
    server.serve_forever()


if __name__ == "__main__":
    main()
