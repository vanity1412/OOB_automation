"""Điểm khởi chạy OOB Console Manager CLI."""
from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

APP_VERSION = "1.2.0"
REQUIRED_PYTHON = (3, 10)


def _bootstrap_paths() -> None:
    root = Path(__file__).resolve().parent
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Trình quản lý OOB Console bằng CLI")
    parser.add_argument("--debug", action="store_true", help="Hiển thị lỗi kỹ thuật chi tiết")
    parser.add_argument("--version", action="store_true", help="Hiển thị phiên bản")
    parser.add_argument("--check", action="store_true", help="Kiểm tra môi trường chạy")
    return parser.parse_args()


def _check_python() -> bool:
    return sys.version_info >= REQUIRED_PYTHON


def main() -> int:
    args = _parse_args()
    if args.version:
        print(f"OOB Console Manager CLI {APP_VERSION}")
        return 0
    if not _check_python():
        print("Không tìm thấy Python 3.10 trở lên.")
        return 2

    _bootstrap_paths()
    from oob_manager.utils.dependency_check import ensure_dependencies, run_environment_check

    if args.check:
        return 0 if run_environment_check(APP_VERSION) else 1

    if not ensure_dependencies(interactive=sys.stdin.isatty()):
        print("Không thể tiếp tục vì thiếu thư viện bắt buộc.")
        return 3

    from oob_manager.cli.application import CLIApplication
    from oob_manager.logging_config import configure_logging

    configure_logging(debug=args.debug)
    logger = logging.getLogger(__name__)
    try:
        CLIApplication(debug=args.debug).run()
        return 0
    except KeyboardInterrupt:
        print("\nĐã dừng chương trình.")
        return 130
    except Exception as exc:
        logger.error(
            "Ứng dụng dừng do lỗi exception_type=%s code=%s",
            type(exc).__name__,
            getattr(exc, "error_code", "UNHANDLED_ERROR"),
            extra={"operation": "main"},
        )
        print(
            "[LỖI] Chương trình gặp lỗi kỹ thuật "
            f"({type(exc).__name__}/{getattr(exc, 'error_code', 'UNHANDLED_ERROR')})."
        )
        print("Chi tiết an toàn đã được ghi vào logs/oob_manager.log")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
