from pathlib import Path

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.cable_check_repository import CableCheckRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.downstream.collector import DownstreamIdentityCollector
from oob_manager.models import ConsoleTarget, OOBDevice
from oob_manager.services.export_service import ExportService


def _seed_mapping(tmp_path: Path):
    db = DatabaseConnection(tmp_path / "oob.db")
    MigrationManager(db).migrate()
    device = OOBRepository(db).create(
        OOBDevice(name="HNI-OOB-01", host="192.0.2.10", vendor="CISCO")
    )
    scan_id = ScanRepository(db).start(device, "1.1.36")
    with db.transaction() as conn:
        conn.execute(
            """UPDATE scan_runs SET status='SUCCESS',mapping_quality='ACCEPTED',
               baseline_updated=1,finished_at=started_at WHERE id=?""",
            (scan_id,),
        )
    target = ConsoleTarget(
        oob_id=int(device.id),
        menu_name="OOB",
        menu_item=9,
        alias="HNI-BRAS-CTR-01-09",
        command="telnet 172.29.10.19 2009",
        protocol="TELNET",
        target_host="172.29.10.19",
        target_port=2009,
        console_line=9,
        console_line_source="SHOW_LINE",
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="AVAILABLE",
        source="CISCO_MENU",
        is_complete=True,
        last_scan_id=scan_id,
    )
    TargetRepository(db).replace_current(int(device.id), scan_id, [target])
    current = TargetRepository(db).list_current(int(device.id))[0]
    return db, device, scan_id, current


def test_schema_v17_has_quick_ab_history_tables(tmp_path: Path):
    db = DatabaseConnection(tmp_path / "schema.db")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 19
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
    assert {"cable_check_runs", "cable_check_results"} <= tables


def test_quick_parser_supports_linux_unix_tty_banner():
    raw = "Trying 192.0.2.5, 2009 ... Open\r\nLinux/amd64 (EDGE-01) (ttyS0)\r\nlogin: "
    assert DownstreamIdentityCollector.extract_console_banner_hostname(raw) == "EDGE-01"


def test_quick_ab_is_persisted_per_port_and_inventory_uses_device_b(tmp_path: Path):
    db, device, scan_id, target = _seed_mapping(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(
        run_id,
        int(device.id),
        {
            "target_id": target.id,
            "port": 2009,
            "console_path": "172.29.10.19:2009 / line 9",
            "device_a": "HNI-BRAS-CTR-01-09",
            "device_b": "HNI-BRAS-CTR-01-09",
            "status": "MATCH",
            "evidence_source": "CONSOLE_BANNER_TTY",
            "wake_count": 2,
            "passive_wait_used": True,
            "message": "No downstream login.",
        },
    )

    # Result exists before finish(): a crash later in the batch does not erase it.
    with db.read() as conn:
        row = conn.execute(
            "SELECT * FROM cable_check_results WHERE run_id=?", (run_id,)
        ).fetchone()
        assert row["device_b"] == "HNI-BRAS-CTR-01-09"
        assert row["status"] == "MATCH"
        assert row["wake_count"] == 2

    repo.finish(run_id)
    inventory = ExportService(db, ApplicationSettings()).current_inventory_rows()
    assert inventory[0]["actual_hostname"] == "HNI-BRAS-CTR-01-09"
    assert inventory[0]["cable_status"] == "MATCH"
    assert inventory[0]["overall"] == "NORMAL"


def test_quick_ab_no_hostname_does_not_create_fake_full_identity(tmp_path: Path):
    db, device, scan_id, target = _seed_mapping(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(
        run_id,
        int(device.id),
        {
            "target_id": target.id,
            "port": 2009,
            "device_a": target.alias,
            "device_b": "",
            "status": "NO_HOSTNAME",
            "evidence_source": "NO_HOSTNAME",
            "message": "Stopped before downstream login.",
        },
    )
    repo.finish(run_id)
    with db.read() as conn:
        assert conn.execute("SELECT COUNT(*) FROM device_identities").fetchone()[0] == 0
    row = ExportService(db, ApplicationSettings()).current_inventory_rows()[0]
    assert row["cable_status"] == "NO_HOSTNAME"
    assert row["overall"] == "NO_HOSTNAME"
    assert row["identity"] == "CHƯA_XÁC_MINH"


def test_quick_result_remains_visible_after_same_mapping_rescan(tmp_path: Path):
    db, device, scan_id, target = _seed_mapping(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(
        run_id,
        int(device.id),
        {
            "target_id": target.id,
            "port": 2009,
            "console_path": "172.29.10.19:2009 / line 9",
            "device_a": target.alias,
            "device_b": target.alias,
            "status": "MATCH",
            "evidence_source": "CONSOLE_BANNER_TTY",
        },
    )
    repo.finish(run_id)

    second_scan = ScanRepository(db).start(device, "1.1.36")
    with db.transaction() as conn:
        conn.execute(
            """UPDATE scan_runs SET status='SUCCESS',mapping_quality='ACCEPTED',
               baseline_updated=1,finished_at=started_at WHERE id=?""",
            (second_scan,),
        )
    refreshed = ConsoleTarget(
        oob_id=int(device.id), menu_name="OOB", menu_item=9,
        alias=target.alias, command="telnet 172.29.10.19 2009",
        protocol="TELNET", target_host="172.29.10.19", target_port=2009,
        console_line=9, console_line_source="SHOW_LINE", state="AVAILABLE",
        state_confident=True, state_reason_code="AVAILABLE", source="CISCO_MENU",
        is_complete=True, last_scan_id=second_scan,
    )
    TargetRepository(db).replace_current(int(device.id), second_scan, [refreshed])

    row = ExportService(db, ApplicationSettings()).current_inventory_rows()[0]
    assert row["cable_status"] == "MATCH"
    assert row["cable_status_display"] == "MATCH"
    assert row["cable_freshness"] == "SAME_MAPPING_RESCAN"
    assert row["actual_hostname"] == target.alias
    assert "Đã mở console" in row["action_summary"]


def test_full_export_contains_quick_ab_history_files(tmp_path: Path):
    db, device, scan_id, target = _seed_mapping(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(
        run_id,
        int(device.id),
        {
            "target_id": target.id,
            "port": 2009,
            "console_path": "172.29.10.19:2009 / line 9",
            "device_a": target.alias,
            "device_b": target.alias,
            "status": "MATCH",
            "evidence_source": "CONSOLE_BANNER_TTY",
        },
    )
    repo.finish(run_id)
    export_dir = ExportService(
        db, ApplicationSettings(export_dir=str(tmp_path / "exports"))
    ).export_all()
    assert (export_dir / "cable_check_runs.csv").exists()
    assert (export_dir / "cable_check_results.csv").exists()


def test_quick_parser_rejects_auth_words_as_fake_hostnames():
    collector = DownstreamIdentityCollector
    assert collector.extract_console_banner_hostname("login (ttyu0)\nlogin:") == ""
    assert collector.extract_login_banner_hostname("login:\nlogin:") == ""
    assert collector.extract_prompt_hostname("root#") == ("", "")
