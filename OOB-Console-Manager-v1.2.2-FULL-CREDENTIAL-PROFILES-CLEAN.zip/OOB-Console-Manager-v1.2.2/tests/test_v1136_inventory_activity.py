from pathlib import Path

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.cable_check_repository import CableCheckRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.models import ConsoleTarget, OOBDevice
from oob_manager.services.export_service import ExportService


def _seed(tmp_path: Path):
    db = DatabaseConnection(tmp_path / "oob.db")
    MigrationManager(db).migrate()
    device = OOBRepository(db).create(OOBDevice(name="HNI-OOB-01", host="192.0.2.10", vendor="CISCO"))
    scan_id = ScanRepository(db).start(device, "1.1.36", trigger_source="CLI_SCAN_CABLE_VERIFY")
    with db.transaction() as conn:
        conn.execute(
            """UPDATE scan_runs SET status='SUCCESS',mapping_quality='ACCEPTED',
               mapping_count=1,complete_count=1,baseline_updated=1,finished_at=started_at WHERE id=?""",
            (scan_id,),
        )
    target = ConsoleTarget(
        oob_id=int(device.id), menu_name="OOB", menu_item=9,
        alias="HNI-BRAS-CTR-01-09", command="telnet 172.29.10.19 2009",
        protocol="TELNET", target_host="172.29.10.19", target_port=2009,
        console_line=9, console_line_source="SHOW_LINE", state="AVAILABLE",
        state_confident=True, state_reason_code="AVAILABLE", source="CISCO_MENU",
        is_complete=True, last_scan_id=scan_id,
    )
    TargetRepository(db).replace_current(int(device.id), scan_id, [target])
    target = TargetRepository(db).list_current(int(device.id))[0]
    return db, device, scan_id, target


def test_inventory_exposes_full_quick_ab_action_details(tmp_path: Path):
    db, device, scan_id, target = _seed(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(run_id, int(device.id), {
        "target_id": target.id,
        "port": "2009",
        "console_path": "172.29.10.19:2009 / line 9",
        "device_a": target.alias,
        "device_b": target.alias,
        "status": "MATCH",
        "evidence_source": "CONSOLE_BANNER_TTY",
        "wake_count": 2,
        "passive_wait_used": True,
        "message": "Hostname read from console banner/prompt; no downstream login/commands.",
    })
    repo.finish(run_id)

    row = ExportService(db, ApplicationSettings()).current_inventory_rows()[0]
    assert row["cable_run_id"] == run_id
    assert row["cable_mapping_scan_id"] == scan_id
    assert row["cable_status_display"] == "MATCH"
    assert row["cable_freshness"] == "CURRENT_SCAN"
    assert row["cable_evidence_source"] == "CONSOLE_BANNER_TTY"
    assert row["cable_wake_count"] == 2
    assert row["cable_passive_wait_used"] is True
    assert "không login/chạy lệnh downstream" in row["action_summary"]

    summary = repo.list_run_summaries(limit=1)[0]
    assert summary["id"] == run_id
    assert summary["mapping_scan_id"] == scan_id
    assert summary["scan_status"] == "SUCCESS"
    assert summary["mapping_quality"] == "ACCEPTED"
    assert summary["match_count"] == 1


def test_changed_mapping_keeps_old_result_visible_but_marks_stale(tmp_path: Path):
    db, device, scan_id, target = _seed(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(run_id, int(device.id), {
        "target_id": target.id,
        "port": "2009",
        "console_path": "172.29.10.19:2009 / line 9",
        "device_a": target.alias,
        "device_b": target.alias,
        "status": "MATCH",
        "evidence_source": "CONSOLE_BANNER_TTY",
    })
    repo.finish(run_id)

    scan2 = ScanRepository(db).start(device, "1.1.36", trigger_source="CLI_MANUAL")
    with db.transaction() as conn:
        conn.execute(
            """UPDATE scan_runs SET status='SUCCESS',mapping_quality='ACCEPTED',
               mapping_count=1,complete_count=1,baseline_updated=1,finished_at=started_at WHERE id=?""",
            (scan2,),
        )
    changed = ConsoleTarget(
        oob_id=int(device.id), menu_name="OOB", menu_item=9,
        alias=target.alias, command="telnet 172.29.10.19 2010",
        protocol="TELNET", target_host="172.29.10.19", target_port=2010,
        console_line=10, console_line_source="SHOW_LINE", state="AVAILABLE",
        state_confident=True, state_reason_code="AVAILABLE", source="CISCO_MENU",
        is_complete=True, last_scan_id=scan2,
    )
    # Preserve target ID deliberately to simulate a mapping update on the same logical target.
    with db.transaction() as conn:
        conn.execute(
            """UPDATE console_targets SET command=?,target_port=?,console_line=?,last_scan_id=? WHERE id=?""",
            (changed.command, changed.target_port, changed.console_line, scan2, target.id),
        )

    row = ExportService(db, ApplicationSettings()).current_inventory_rows()[0]
    assert row["device_b"] == target.alias
    assert row["cable_status"] == "CHƯA_CHECK"
    assert row["cable_status_display"] == "STALE/MATCH"
    assert row["cable_freshness"] == "STALE_MAPPING"
    assert row["overall"] == "CẦN_CHECK_LẠI"
    assert "mapping cũ" in row["action_summary"]


def test_cancelled_run_is_visible_in_summary(tmp_path: Path):
    db, device, scan_id, target = _seed(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(run_id, int(device.id), {
        "target_id": target.id,
        "port": "2009",
        "console_path": "172.29.10.19:2009 / line 9",
        "device_a": target.alias,
        "device_b": "",
        "status": "SKIP/ERROR",
        "error_code": "USER_CANCELLED_BEFORE_PROBE",
        "message": "Live mapping was collected; operator cancelled before opening this console port.",
    })
    repo.finish(
        run_id,
        status="CANCELLED",
        error_code="USER_CANCELLED_BEFORE_PROBE",
        error_message="Operator cancelled after live scan.",
    )
    summary = repo.list_run_summaries(limit=1)[0]
    assert summary["status"] == "CANCELLED"
    assert summary["skip_error_count"] == 1
    assert summary["error_code"] == "USER_CANCELLED_BEFORE_PROBE"


def test_rejected_live_scan_creates_visible_blocked_ab_run(tmp_path: Path):
    from oob_manager.cli.application import CLIApplication
    from oob_manager.models import ScanResult, SessionCredentials

    app = CLIApplication(db_path=tmp_path / "blocked.db", pause_enabled=False)
    device = app.oob_repo.create(
        OOBDevice(name="HNI-OOB-BLOCKED", host="192.0.2.20", vendor="CISCO")
    )
    scan_id = app.scan_repo.start(
        device,
        "1.1.36",
        trigger_source="CLI_SCAN_CABLE_VERIFY",
    )
    with app.db.transaction() as conn:
        conn.execute(
            """UPDATE scan_runs SET status='REJECTED',mapping_quality='REJECTED',
               baseline_updated=0,error_code='SCAN_REJECTED',
               error_message='Live mapping incomplete',finished_at=started_at WHERE id=?""",
            (scan_id,),
        )

    app._select_oob = lambda _include_disabled=False: device
    app._credentials = lambda _device: SessionCredentials("oob", "secret")
    app._export_scan_artifacts_safe = lambda _scan_id: None
    app.scan_service.scan_one = lambda *_args, **_kwargs: ScanResult(
        scan_id=scan_id,
        oob_id=int(device.id),
        status="REJECTED",
        mapping_quality="REJECTED",
        baseline_updated=False,
        error_message="Live mapping incomplete",
    )
    probes: list[int] = []
    app._run_batch_cable_verification = lambda *_args, **_kwargs: probes.append(1)

    app.scan_and_verify_cabling()
    assert probes == []
    summary = app.cable_check_repo.list_run_summaries(limit=1)[0]
    assert summary["mapping_scan_id"] == scan_id
    assert summary["status"] == "FAILED"
    assert summary["error_code"] == "A_B_BLOCKED_BY_SCAN_QUALITY"
    assert "ACCEPTED baseline" in summary["error_message"]
