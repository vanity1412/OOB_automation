from pathlib import Path
from fastapi.testclient import TestClient
from oob_manager.web.app import create_app

def test_local_mode_opens_without_login(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("OOB_WEB_LOCAL_MODE", "1")
    monkeypatch.delenv("OOB_WEB_ADMIN_PASSWORD", raising=False)
    monkeypatch.delenv("OOB_WEB_PASSWORD", raising=False)
    app = create_app(db_path=tmp_path / "local.db")
    with TestClient(app, follow_redirects=False) as client:
        assert client.get("/").status_code == 200
        boot = client.get("/api/bootstrap")
        assert boot.status_code == 200
        data = boot.json()
        assert data["user"]["username"] == "local-admin"
        assert data["user"]["role"] == "admin"
        assert data["version"] == "1.2.2"

def test_remote_mode_still_requires_password(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("OOB_WEB_LOCAL_MODE", "0")
    monkeypatch.delenv("OOB_WEB_ADMIN_PASSWORD", raising=False)
    monkeypatch.delenv("OOB_WEB_PASSWORD", raising=False)
    import pytest
    with pytest.raises(RuntimeError):
        create_app(db_path=tmp_path / "remote.db")
