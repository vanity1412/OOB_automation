from __future__ import annotations

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.downstream.collector import DownstreamIdentityCollector
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    OOBDevice,
    PortAuthenticationCredentials,
    SessionCredentials,
)
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


class ProbeChannel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value: str):
        self.sent.append(value)
        return len(value)


class SequencedProbeSSH:
    def __init__(self, outputs: list[str]):
        self.outputs = list(outputs)
        self.timeouts: list[float | None] = []

    def read_until_state(self, _channel, detector, timeout=None, settle=0.2, initial=""):
        self.timeouts.append(timeout)
        more = self.outputs.pop(0) if self.outputs else ""
        text = initial + more
        return text, detector(text)

    def read_until_quiet(self, _channel, timeout=None, quiet=None):
        self.timeouts.append(timeout)
        return self.outputs.pop(0) if self.outputs else ""


def test_prompt_parser_accepts_real_linux_root_prompt_with_cwd():
    host, source = DownstreamIdentityCollector.extract_prompt_hostname(
        "root@HCM-CDN-GW-02-01:~#"
    )
    assert host == "HCM-CDN-GW-02-01"
    assert source == "DEVICE_PROMPT"


def test_prompt_parser_accepts_vrf_prefixed_linux_prompt():
    host, source = DownstreamIdentityCollector.extract_prompt_hostname(
        "[vrf:none] root@HCM-CDN-GW-02-01:~#"
    )
    assert host == "HCM-CDN-GW-02-01"
    assert source == "DEVICE_PROMPT"


def test_prompt_parser_strips_ansi_and_bel_before_matching():
    host, source = DownstreamIdentityCollector.extract_prompt_hostname(
        "\x1b[32mroot@EDGE-01:/var/tmp#\x1b[0m\x07"
    )
    assert host == "EDGE-01"
    assert source == "DEVICE_PROMPT"


def test_prompt_parser_accepts_ios_xr_location_prefix():
    host, source = DownstreamIdentityCollector.extract_prompt_hostname(
        "RP/0/RP0/CPU0:HCM-PE-01#"
    )
    assert host == "HCM-PE-01"
    assert source == "DEVICE_PROMPT"


def test_prompt_parser_does_not_invent_hostname_from_login_prompt():
    assert DownstreamIdentityCollector.extract_prompt_hostname("login:") == ("", "")
    assert DownstreamIdentityCollector.extract_prompt_hostname("Password:") == ("", "")
    assert DownstreamIdentityCollector.extract_prompt_hostname(
        "Welcome to device EDGE-01 - authorized users only"
    ) == ("", "")


def test_quick_probe_uses_passive_banner_without_sending_enter():
    channel = ProbeChannel()
    ssh = SequencedProbeSSH(["\r\nEDGE-01 (ttyd0)\r\nlogin: "])
    collector = DownstreamIdentityCollector(ssh, command_timeout=5)

    result = collector.collect_quick_hostname(
        channel,
        "Trying 172.28.200.11, 2008 ... Open\r\n",
        "EDGE-01",
        passive_timeout=1,
        wake_timeout=2,
    )

    assert result.identity.actual_hostname == "EDGE-01"
    assert result.metadata["quick_probe_passive_wait_used"] is True
    assert result.metadata["quick_probe_wake_sent"] is False
    assert channel.sent == []


def test_quick_probe_silent_console_sends_exactly_one_enter_then_reads_prompt():
    channel = ProbeChannel()
    # First read is the passive window after Telnet/Open; second is after wake Enter.
    ssh = SequencedProbeSSH(["", "[vrf:none] root@EDGE-02:~#"])
    collector = DownstreamIdentityCollector(ssh, command_timeout=5)

    result = collector.collect_quick_hostname(
        channel,
        "Trying 172.28.200.11, 2009 ... Open\r\n",
        "EDGE-02",
        passive_timeout=1,
        wake_timeout=2,
    )

    assert result.identity.actual_hostname == "EDGE-02"
    assert result.metadata["quick_probe_wake_sent"] is True
    assert channel.sent == ["\n"]


def test_quick_probe_stops_at_username_without_wake_or_credentials():
    channel = ProbeChannel()
    ssh = SequencedProbeSSH([])
    collector = DownstreamIdentityCollector(ssh, command_timeout=5)

    result = collector.collect_quick_hostname(
        channel,
        "\r\nUsername:\r\n",
        "EDGE-03",
    )

    assert result.identity.actual_hostname == ""
    assert result.metadata["cable_identity_source"] == "NO_HOSTNAME"
    assert result.metadata["quick_probe_wake_sent"] is False
    assert channel.sent == []


class DummyClient:
    def close(self):
        pass


class VertivFakeSSH:
    def __init__(self):
        self.channel = ProbeChannel()
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:test"
        self.host_key_policy = "TOFU_PERSISTENT"

    def connect(self, *_args, **_kwargs):
        return DummyClient()

    def open_shell(self, _client, *args, **kwargs):
        return self.channel

    def drain_channel(self, _channel):
        return ""


def _vertiv_device() -> OOBDevice:
    return OOBDevice(
        id=1,
        name="ACS-01",
        host="192.0.2.10",
        ssh_port=22,
        vendor="VERTIV",
        connection_mode="SSH",
        enabled=True,
    )


def _vertiv_target() -> ConsoleTarget:
    return ConsoleTarget(
        id=1,
        oob_id=1,
        menu_name="ACCESS",
        menu_item=1,
        alias="EDGE-01",
        command="connect EDGE-01",
        protocol="VERTIV_CLI",
        target_host="192.0.2.10",
        console_line=1,
        state="AVAILABLE",
        state_confident=True,
        is_complete=True,
        last_scan_id=1,
    )


def test_vertiv_quick_mode_allows_silent_serial_to_reach_hostname_probe(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    adapter.ssh = VertivFakeSSH()
    adapter.quick_hostname_only = True

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda _ch, target: (target, "access show"))
    # A second cd access after runtime_verify is a v1.1.32 inefficiency and must stay gone.
    monkeypatch.setattr(adapter, "_goto_access", lambda _ch: (_ for _ in ()).throw(AssertionError("redundant cd access")))

    observed: dict[str, object] = {}

    def fake_transition(_channel, *, direct_ssh=False, timeout=None):
        observed["timeout"] = timeout
        return "", None

    monkeypatch.setattr(adapter, "_read_connect_transition", fake_transition)

    def fake_quick(self, channel, initial, alias, **kwargs):
        observed["collector_called"] = True
        return DownstreamDiscoveryResult(
            identity=DeviceIdentity(actual_hostname="EDGE-01", quality="PARTIAL", confidence="MEDIUM"),
            metadata={"cable_identity_source": "DEVICE_PROMPT", "quick_hostname_only": True},
        )

    monkeypatch.setattr(DownstreamIdentityCollector, "collect_quick_hostname", fake_quick)

    result = adapter.discover_downstream_identity(
        _vertiv_device(),
        _vertiv_target(),
        SessionCredentials("admin", "secret"),
        DownstreamCredentials(),
        port_credentials=PortAuthenticationCredentials(access_method="CLI_CONNECT"),
    )

    assert result.identity.actual_hostname == "EDGE-01"
    assert observed["collector_called"] is True
    assert observed["timeout"] == 8.0
    assert adapter.ssh.channel.sent == ["connect EDGE-01\n"]


def test_vertiv_full_identity_still_fails_closed_on_silent_unverified_path(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    adapter.ssh = VertivFakeSSH()
    adapter.quick_hostname_only = False

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda _ch, target: (target, "access show"))
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *a, **k: ("", None))

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.discover_downstream_identity(
            _vertiv_device(),
            _vertiv_target(),
            SessionCredentials("admin", "secret"),
            DownstreamCredentials("down", "secret"),
            port_credentials=PortAuthenticationCredentials(access_method="CLI_CONNECT"),
        )

    assert caught.value.error_code == "DOWNSTREAM_CONSOLE_PATH_NOT_ENTERED"


def test_freebsd_amd64_ttyu_banner_extracts_hostname():
    assert DownstreamIdentityCollector.extract_console_banner_hostname(
        "FreeBSD/amd64 (HNI-BRAS-CTR-01-10) (ttyu0)\r\n\r\nlogin: "
    ) == "HNI-BRAS-CTR-01-10"


def test_cisco_reverse_telnet_can_wake_twice_before_freebsd_banner():
    channel = ProbeChannel()
    # Passive window -> silence; first Enter -> silence; second Enter -> real banner.
    ssh = SequencedProbeSSH([
        "",
        "",
        "\r\nFreeBSD/amd64 (HNI-BRAS-CTR-01-10) (ttyu0)\r\n\r\nlogin: ",
    ])
    collector = DownstreamIdentityCollector(ssh, command_timeout=5)

    result = collector.collect_quick_hostname(
        channel,
        "Trying 172.29.10.19, 2003 ... Open\r\n",
        "HNI-BRAS-CTR-01-10",
        passive_timeout=1,
        wake_timeout=2,
        max_wake_attempts=2,
    )

    assert result.identity.actual_hostname == "HNI-BRAS-CTR-01-10"
    assert result.identity.alias_comparison == "EXACT_MATCH"
    assert result.metadata["cable_identity_source"] == "CONSOLE_BANNER_TTY"
    assert result.metadata["quick_probe_wake_count"] == 2
    assert channel.sent == ["\n", "\n"]
