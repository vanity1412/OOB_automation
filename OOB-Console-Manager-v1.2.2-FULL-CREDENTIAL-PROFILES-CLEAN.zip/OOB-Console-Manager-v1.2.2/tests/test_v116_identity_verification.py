from __future__ import annotations

import csv
import json
import sqlite3

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.downstream.verification import identity_fingerprint, verify_identity
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamDiscoveryResult,
    OOBDevice,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.database_audit_service import DatabaseAuditService
from oob_manager.services.export_service import ExportService
from oob_manager.services.scan_service import ScanService


MENU = (
    "menu OOB text [4] ----> R4\n"
    "menu OOB command 4 telnet 10.0.0.1 2004"
)


def _identity(hostname="R4", serial="SERIAL-A", model="ISR4451-X/K9", version="17.9.4", alias_compare="EXACT_MATCH"):
    return DeviceIdentity(
        actual_hostname=hostname,
        vendor="CISCO",
        platform_family="IOS_FAMILY",
        model=model,
        serial_number=serial,
        software_version=version,
        quality="ACCEPTED",
        confidence="HIGH",
        alias_comparison=alias_compare,
        source_evidence={"serial_number": "show inventory", "actual_hostname": "show version"},
    )


def _previous(**overrides):
    row = {
        "configured_alias": "R4",
        "actual_hostname": "R4",
        "vendor": "CISCO",
        "model": "ISR4451-X/K9",
        "serial_number": "SERIAL-A",
        "software_version": "17.9.4",
        "alias_comparison": "EXACT_MATCH",
        "last_identity_run_id": 10,
        "identity_fingerprint": "",
    }
    row.update(overrides)
    return row


def _target() -> ConsoleTarget:
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=4,
        alias="R4",
        command="telnet 10.0.0.1 2004",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=2004,
        console_line=4,
        console_line_source="REVERSE_TELNET_PORT_CONFIRMED",
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="NO_ACTIVE_TTY_SESSION_ON_CONFIRMED_LINE",
        state_evidence='{"console_line":4}',
        source="CISCO_MENU",
        mapping_source_command="show run | i ^menu",
        mapping_text_line="menu OOB text [4] ----> R4",
        mapping_text_line_no=1,
        mapping_command_line="menu OOB command 4 telnet 10.0.0.1 2004",
        mapping_command_line_no=2,
        is_complete=True,
    )


def _accepted_result(identity: DeviceIdentity) -> DownstreamDiscoveryResult:
    return DownstreamDiscoveryResult(
        identity=identity,
        raw_outputs=[
            RawCommandOutput(
                "show_version",
                "show version",
                f"Cisco IOS XE Software, Version {identity.software_version}\n{identity.actual_hostname} uptime is 1 day\n{identity.actual_hostname}#",
                True,
                is_core=True,
            ),
            RawCommandOutput(
                "show_inventory",
                "show inventory",
                f'NAME: "Chassis"\nPID: {identity.model}, VID: V01, SN: {identity.serial_number}\n{identity.actual_hostname}#',
                True,
                is_core=True,
            ),
        ],
        login_method="USERNAME_PASSWORD",
        downstream_prompt=f"{identity.actual_hostname}#",
        runtime_mapping_verified=True,
        runtime_mapping_verification_code="LIVE_MAPPING_VERIFIED",
        runtime_mapping_verification_message="verified",
        live_state="AVAILABLE",
        live_state_confident=True,
        live_state_reason_code="NO_ACTIVE_TTY_SESSION_ON_CONFIRMED_LINE",
        live_state_evidence='{"console_line":4}',
        live_state_checked_at="2026-07-26T10:00:00+00:00",
    )


def _stack(tmp_path):
    db = DatabaseConnection(tmp_path / "v116.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    identity_repo = DeviceIdentityRepository(db)
    device = oob_repo.create(OOBDevice(name="OOB-A", host="192.0.2.10", vendor="CISCO", device_type="cisco_ios"))

    class Adapter:
        def collect(self, device, credentials):
            return VendorScanData(
                connection_success=True,
                login_mode="NORMAL_CLI",
                targets=[_target()],
                raw_outputs=[RawCommandOutput("menu", "show run | i ^menu", MENU, True, is_core=True)],
            )

    scan = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda _d, _s: Adapter(),
    ).scan_one(device.id, SessionCredentials("u", "p"))
    assert scan.baseline_updated
    target = target_repo.list_current(device.id)[0]
    return db, identity_repo, device, target


def test_first_verified_identity_match_is_first_seen():
    result = verify_identity("R4", _identity(), None)
    assert result.status == "VERIFIED_MATCH"
    assert result.severity == "INFO"
    assert result.hardware_continuity == "FIRST_SEEN"
    assert result.identity_fingerprint
    assert {event["event_code"] for event in result.events} == {"IDENTITY_FIRST_VERIFIED"}


def test_first_verified_alias_mismatch_records_warning():
    result = verify_identity("R4", _identity(hostname="R9", alias_compare="DIFFERENT"), None)
    assert result.status == "VERIFIED_MISMATCH"
    assert result.severity == "WARNING"
    assert {event["event_code"] for event in result.events} == {"IDENTITY_FIRST_VERIFIED", "ALIAS_MISMATCH"}


def test_serial_change_is_high_device_change_suspected():
    result = verify_identity("R4", _identity(serial="SERIAL-B"), _previous())
    assert result.status == "DEVICE_CHANGE_SUSPECTED"
    assert result.severity == "HIGH"
    assert result.hardware_continuity == "CHANGED"
    assert result.previous_identity_run_id == 10
    assert "serial_number" in result.changed_fields
    codes = {event["event_code"] for event in result.events}
    assert {"SERIAL_CHANGED", "DEVICE_REPLACED_SUSPECTED"} <= codes


def test_same_serial_version_change_keeps_hardware_continuity():
    result = verify_identity("R4", _identity(version="17.12.1"), _previous())
    assert result.status == "VERIFIED_MATCH"
    assert result.hardware_continuity == "UNCHANGED"
    assert result.severity == "INFO"
    assert result.changed_fields == ["software_version"]
    assert [event["event_code"] for event in result.events] == ["SOFTWARE_VERSION_CHANGED"]


def test_alias_comparison_is_conservative_about_domain_suffix():
    result = verify_identity("R4.example.com", _identity(hostname="R4", alias_compare="DIFFERENT"), None)
    assert result.status == "VERIFIED_MISMATCH"
    assert "ALIAS_MISMATCH" in result.reason_codes


def test_empty_alias_yields_verified_identity_not_fake_match():
    result = verify_identity("", _identity(alias_compare="UNKNOWN"), None)
    assert result.status == "VERIFIED_IDENTITY"
    assert "ALIAS_COMPARISON_UNAVAILABLE" in result.reason_codes


def test_repeated_same_alias_mismatch_does_not_duplicate_alias_event():
    previous = _previous(
        actual_hostname="R9",
        alias_comparison="DIFFERENT",
        serial_number="SERIAL-A",
    )
    result = verify_identity("R4", _identity(hostname="R9", alias_compare="DIFFERENT"), previous)
    assert result.status == "VERIFIED_MISMATCH"
    assert "ALIAS_MISMATCH" not in {event["event_code"] for event in result.events}


def test_repository_stores_verification_history_and_events(tmp_path):
    db, repo, device, target = _stack(tmp_path)

    first_id = repo.start(device, target, "oob", "down")
    first = _accepted_result(_identity())
    repo.finish(first_id, target, first)
    assert first.verification.status == "VERIFIED_MATCH"

    second_id = repo.start(device, target, "oob", "down")
    second = _accepted_result(_identity(serial="SERIAL-B"))
    repo.finish(second_id, target, second)
    assert second.verification.status == "DEVICE_CHANGE_SUSPECTED"

    current = repo.get_current_for_target(target.id)[0:] if False else repo.get_current_for_target(target.id)
    assert current is not None
    assert current["verification_status"] == "DEVICE_CHANGE_SUSPECTED"
    assert current["hardware_continuity"] == "CHANGED"
    assert current["previous_identity_run_id"] == first_id
    assert current["identity_fingerprint"] == identity_fingerprint(second.identity)

    events = repo.list_recent_events()
    codes = [row["event_code"] for row in events]
    assert "IDENTITY_FIRST_VERIFIED" in codes
    assert "SERIAL_CHANGED" in codes
    assert "DEVICE_REPLACED_SUSPECTED" in codes

    with db.read() as conn:
        run = conn.execute("SELECT * FROM device_identity_runs WHERE id=?", (second_id,)).fetchone()
        snapshot = conn.execute("SELECT * FROM device_identity_snapshots WHERE identity_run_id=?", (second_id,)).fetchone()
        assert run["previous_identity_run_id"] == first_id
        assert run["verification_status"] == "DEVICE_CHANGE_SUSPECTED"
        assert snapshot["verification_status"] == "DEVICE_CHANGE_SUSPECTED"
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("PRAGMA foreign_key_check").fetchall() == []
        assert DatabaseAuditService.collect_issues(conn) == []


def test_alias_mismatch_restored_event(tmp_path):
    _db, repo, device, target = _stack(tmp_path)
    first_id = repo.start(device, target, "oob", "down")
    repo.finish(first_id, target, _accepted_result(_identity(hostname="R9", alias_compare="DIFFERENT")))
    second_id = repo.start(device, target, "oob", "down")
    repo.finish(second_id, target, _accepted_result(_identity(hostname="R4", alias_compare="EXACT_MATCH")))
    events = repo.list_recent_events()
    assert "ALIAS_MATCH_RESTORED" in {row["event_code"] for row in events}


def test_schema_v10_and_export_identity_events(tmp_path):
    db, repo, device, target = _stack(tmp_path)
    run_id = repo.start(device, target, "oob", "down")
    repo.finish(run_id, target, _accepted_result(_identity(hostname="R9", alias_compare="DIFFERENT")))

    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 19
        tables = {row["name"] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert "device_identity_events" in tables
        views = {row["name"] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='view'")}
        assert "v_device_identity_events" in views

    export_dir = ExportService(db, ApplicationSettings(export_dir=str(tmp_path / "exports"))).export_all()
    events_path = export_dir / "device_identity_events.csv"
    assert events_path.exists()
    with events_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert {row["event_code"] for row in rows} >= {"IDENTITY_FIRST_VERIFIED", "ALIAS_MISMATCH"}
    current_header = (export_dir / "current_device_identities.csv").read_text(encoding="utf-8-sig").splitlines()[0]
    assert "verification_status" in current_header
    assert "identity_fingerprint" in current_header


def test_database_audit_detects_identity_fingerprint_tampering(tmp_path):
    db, repo, device, target = _stack(tmp_path)
    run_id = repo.start(device, target, "oob", "down")
    repo.finish(run_id, target, _accepted_result(_identity()))
    with db.transaction() as conn:
        # Temporarily remove validation triggers to simulate manual/offline tampering.
        conn.execute("DROP TRIGGER IF EXISTS trg_device_identities_validate_update")
        conn.execute("UPDATE device_identities SET identity_fingerprint='tampered' WHERE target_id=?", (target.id,))
    with db.read() as conn:
        codes = {item["issue_code"] for item in DatabaseAuditService.collect_issues(conn)}
    assert "CURRENT_IDENTITY_FINGERPRINT_MISMATCH" in codes


def test_v9_like_database_migrates_to_v10_without_synthetic_events(tmp_path):
    # Build a current v10 DB, then make it look like a pre-v10 schema by dropping
    # verification-only table/columns is not supported by SQLite ALTER. Instead,
    # verify idempotent migration/backfill semantics on legacy-style rows whose
    # verification metadata is blank/default.
    db, repo, device, target = _stack(tmp_path)
    run_id = repo.start(device, target, "oob", "down")
    repo.finish(run_id, target, _accepted_result(_identity()))
    with db.transaction() as conn:
        conn.execute("DELETE FROM device_identity_events")
        conn.execute("DROP TRIGGER IF EXISTS trg_device_identities_validate_update")
        conn.execute("DROP TRIGGER IF EXISTS trg_identity_runs_validate_update")
        conn.execute("UPDATE device_identities SET verification_source='LEGACY_BACKFILL_V1_1_6' WHERE target_id=?", (target.id,))
        conn.execute("UPDATE device_identity_runs SET verification_source='LEGACY_BACKFILL_V1_1_6' WHERE id=?", (run_id,))
        conn.execute("PRAGMA user_version=9")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 19
        assert conn.execute("SELECT COUNT(*) FROM device_identity_events").fetchone()[0] == 0
        assert conn.execute("SELECT identity_fingerprint FROM device_identities WHERE target_id=?", (target.id,)).fetchone()[0]
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_historical_identity_is_used_after_mapping_alias_change_invalidates_current(tmp_path):
    db, repo, device, target = _stack(tmp_path)
    first_id = repo.start(device, target, "oob", "down")
    repo.finish(first_id, target, _accepted_result(_identity()))

    # Simulate a trusted new baseline where only alias changed. TargetRepository
    # intentionally invalidates current identity, but preserves target_id/history.
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    oob_repo = OOBRepository(db)

    class AliasAdapter:
        def collect(self, _device, _credentials):
            changed = _target()
            changed.alias = "R4-NEW"
            changed.mapping_text_line = "menu OOB text [4] ----> R4-NEW"
            raw = (
                "menu OOB text [4] ----> R4-NEW\n"
                "menu OOB command 4 telnet 10.0.0.1 2004"
            )
            return VendorScanData(
                connection_success=True,
                login_mode="NORMAL_CLI",
                targets=[changed],
                raw_outputs=[RawCommandOutput("menu", "show run | i ^menu", raw, True, is_core=True)],
            )

    scan = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda _d, _s: AliasAdapter(),
    ).scan_one(device.id, SessionCredentials("u", "p"))
    assert scan.baseline_updated
    changed_target = target_repo.list_current(device.id)[0]
    assert changed_target.id == target.id
    assert repo.get_current_for_target(target.id) is None

    second_id = repo.start(device, changed_target, "oob", "down")
    identity = _identity(hostname="R4-NEW", serial="SERIAL-A", alias_compare="EXACT_MATCH")
    second = _accepted_result(identity)
    repo.finish(second_id, changed_target, second)
    assert second.verification.previous_identity_run_id == first_id
    assert second.verification.hardware_continuity == "UNCHANGED"
    assert second.verification.status == "VERIFIED_MATCH"
    assert "IDENTITY_FIRST_VERIFIED" not in {event["event_code"] for event in second.verification.events}


def test_alias_normalization_ignores_case_and_trailing_dot_only():
    result = verify_identity("R4.EXAMPLE.COM.", _identity(hostname="r4.example.com"), None)
    assert result.status == "VERIFIED_MATCH"
    assert result.alias_comparison == "EXACT_MATCH"
