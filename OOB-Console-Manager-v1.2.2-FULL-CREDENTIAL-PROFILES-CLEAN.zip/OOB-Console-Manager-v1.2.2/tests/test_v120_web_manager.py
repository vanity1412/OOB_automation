from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from oob_manager.web.auth import WebAuth
from oob_manager.web.app import create_app


def _env(monkeypatch, *, admin="admin-pass", operator="operator-pass", viewer="viewer-pass"):
    monkeypatch.setenv("OOB_WEB_ADMIN_PASSWORD", admin)
    monkeypatch.setenv("OOB_WEB_SECRET", "unit-test-secret")
    if operator:
        monkeypatch.setenv("OOB_WEB_OPERATOR_PASSWORD", operator)
    else:
        monkeypatch.delenv("OOB_WEB_OPERATOR_PASSWORD", raising=False)
    if viewer:
        monkeypatch.setenv("OOB_WEB_VIEWER_PASSWORD", viewer)
    else:
        monkeypatch.delenv("OOB_WEB_VIEWER_PASSWORD", raising=False)
    monkeypatch.delenv("OOB_WEB_PASSWORD", raising=False)


def _login(client: TestClient, username: str, password: str) -> str:
    response = client.post("/login", data={"username": username, "password": password})
    assert response.status_code == 303
    bootstrap = client.get("/api/bootstrap")
    assert bootstrap.status_code == 200
    return bootstrap.json()["csrf"]


def test_web_refuses_default_password(monkeypatch):
    for key in ("OOB_WEB_ADMIN_PASSWORD", "OOB_WEB_PASSWORD"):
        monkeypatch.delenv(key, raising=False)
    with pytest.raises(RuntimeError, match="OOB_WEB_ADMIN_PASSWORD"):
        WebAuth()


def test_root_redirect_login_and_health(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")
    with TestClient(app, follow_redirects=False) as client:
        response = client.get("/")
        assert response.status_code == 303
        assert response.headers["location"] == "/login"
        _login(client, "admin", "admin-pass")
        health = client.get("/api/health")
        assert health.status_code == 200
        assert health.json()["integrity"] == "ok"
        assert health.json()["foreign_key_violations"] == []
        assert health.json()["schema"] >= 18


def test_rbac_csrf_and_admin_oob_crud(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")
    with TestClient(app, follow_redirects=False) as viewer:
        viewer_csrf = _login(viewer, "viewer", "viewer-pass")
        denied = viewer.post(
            "/api/oobs",
            headers={"X-CSRF-Token": viewer_csrf},
            json={"name": "DENIED", "host": "192.0.2.1", "vendor": "CISCO"},
        )
        assert denied.status_code == 403

    with TestClient(app, follow_redirects=False) as admin:
        admin_csrf = _login(admin, "admin", "admin-pass")
        no_csrf = admin.post(
            "/api/oobs",
            json={"name": "NO-CSRF", "host": "192.0.2.2", "vendor": "CISCO"},
        )
        assert no_csrf.status_code == 403
        created = admin.post(
            "/api/oobs",
            headers={"X-CSRF-Token": admin_csrf},
            json={
                "name": "LAB-OOB", "host": "192.0.2.10", "ssh_port": 22,
                "vendor": "CISCO", "default_username": "noc", "enabled": True,
                "notes": "unit test",
            },
        )
        assert created.status_code == 200
        assert created.json()["name"] == "LAB-OOB"
        assert len(admin.get("/api/oobs").json()) == 1


def test_credentials_are_ram_only(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    db_path = tmp_path / "web.db"
    app = create_app(db_path=db_path)
    secret = "never-write-this-password-983745"
    with TestClient(app, follow_redirects=False) as client:
        csrf = _login(client, "operator", "operator-pass")
        saved = client.put(
            "/api/credentials",
            headers={"X-CSRF-Token": csrf},
            json={
                "scope": "default", "scope_id": "default", "username": "noc-net",
                "password": secret, "enable_password": "enable-secret",
            },
        )
        assert saved.status_code == 200
        status = saved.json()
        assert status["default"] == {"loaded": True, "username": "noc-net"}
        assert secret not in str(status)
        cleared = client.delete("/api/credentials", headers={"X-CSRF-Token": csrf})
        assert cleared.status_code == 200
        assert client.get("/api/credentials").json()["default"]["loaded"] is False
    assert secret.encode() not in db_path.read_bytes()
    assert b"enable-secret" not in db_path.read_bytes()


def test_operator_task_center_and_owner_scope(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")

    def fake_scan(ctx, session_id, oob_id, trigger_source):
        ctx.log("safe scan log")
        ctx.step(1, 1, "done")
        return {"oob_id": oob_id, "trigger": trigger_source, "session_present": bool(session_id)}

    app.state.core.scan_one = fake_scan
    with TestClient(app, follow_redirects=False) as client:
        csrf = _login(client, "operator", "operator-pass")
        started = client.post(
            "/api/tasks/scan",
            headers={"X-CSRF-Token": csrf},
            json={"oob_id": 7},
        )
        assert started.status_code == 200
        task_id = started.json()["id"]
        for _ in range(100):
            task = client.get(f"/api/tasks/{task_id}").json()
            if task["status"] in {"SUCCESS", "FAILED", "CANCELLED"}:
                break
            time.sleep(0.01)
        assert task["status"] == "SUCCESS"
        assert task["progress"] == 100
        assert task["result"]["oob_id"] == 7
        assert any(item["message"] == "safe scan log" for item in task["logs"])


def test_dashboard_and_inventory_are_empty_but_complete(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")
    with TestClient(app, follow_redirects=False) as client:
        _login(client, "admin", "admin-pass")
        dashboard = client.get("/api/dashboard")
        assert dashboard.status_code == 200
        stats = dashboard.json()["stats"]
        for key in (
            "oobs_total", "targets", "available", "busy", "unknown", "match",
            "mismatch", "no_hostname", "identity_accepted", "identity_observed",
            "critical_identity", "unviewed_changes",
        ):
            assert key in stats
        assert client.get("/api/inventory").json() == []


def test_frontend_hides_operator_actions_for_viewer():
    from oob_manager.web.templates import APP_HTML

    assert "state.me.role==='viewer'" in APP_HTML
    assert "document.querySelectorAll('.operator-only')" in APP_HTML

def test_daily_snapshot_mark_viewed_and_export(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")
    with TestClient(app, follow_redirects=False) as client:
        csrf = _login(client, "operator", "operator-pass")
        daily = client.get("/api/inventory/daily?day=2026-07-29")
        assert daily.status_code == 200 and daily.json() == []
        snapshot = client.get("/api/scans/999/snapshot")
        assert snapshot.status_code == 200 and snapshot.json() == []
        marked = client.post(
            "/api/history/mark-viewed",
            headers={"X-CSRF-Token": csrf},
            json={"kind": "changes", "ids": []},
        )
        assert marked.status_code == 200 and marked.json()["marked"] == 0
        exported = client.post(
            "/api/exports/daily",
            headers={"X-CSRF-Token": csrf},
            json={"day": "2026-07-29"},
        )
        assert exported.status_code == 200
        assert Path(exported.json()["path"]).is_file()


def test_connection_test_task_endpoint(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")

    def fake_test(ctx, session_id, oob_id):
        ctx.log("SSH negotiation and prompt verified", "SUCCESS")
        return {"success": True, "oob_id": oob_id}

    app.state.core.test_connection = fake_test
    with TestClient(app, follow_redirects=False) as client:
        csrf = _login(client, "operator", "operator-pass")
        started = client.post(
            "/api/tasks/test_connection",
            headers={"X-CSRF-Token": csrf},
            json={"oob_id": 2},
        )
        assert started.status_code == 200
        task_id = started.json()["id"]
        for _ in range(100):
            task = client.get(f"/api/tasks/{task_id}").json()
            if task["status"] in {"SUCCESS", "FAILED", "CANCELLED"}:
                break
            time.sleep(0.01)
        assert task["status"] == "SUCCESS"
        assert task["result"] == {"success": True, "oob_id": 2}

def test_login_throttle_blocks_repeated_failures(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    monkeypatch.setenv("OOB_WEB_LOGIN_MAX_FAILURES", "3")
    monkeypatch.setenv("OOB_WEB_LOGIN_WINDOW", "300")
    monkeypatch.setenv("OOB_WEB_LOGIN_BLOCK", "60")
    app = create_app(db_path=tmp_path / "web.db")
    with TestClient(app, follow_redirects=False) as client:
        for _ in range(3):
            response = client.post("/login", data={"username": "admin", "password": "wrong"})
            assert response.status_code == 401
        blocked = client.post("/login", data={"username": "admin", "password": "admin-pass"})
        assert blocked.status_code == 429
        assert int(blocked.headers["Retry-After"]) >= 1

def test_smart_verify_task_combines_ab_and_identity(tmp_path: Path, monkeypatch):
    _env(monkeypatch)
    app = create_app(db_path=tmp_path / "web.db")

    def fake_smart(ctx, session_id, oob_id, downstream, port_credentials):
        ctx.log("PHA 1/2")
        ctx.log("PHA 2/2")
        return {
            "workflow": "SMART_VERIFY", "oob_id": oob_id,
            "cable": {"counts": {"MATCH": 1}},
            "identity": {"items": [{"model": "MX204", "serial": "JN123"}]},
        }

    app.state.core.smart_verify = fake_smart
    with TestClient(app, follow_redirects=False) as client:
        csrf = _login(client, "operator", "operator-pass")
        started = client.post(
            "/api/tasks/smart_verify",
            headers={"X-CSRF-Token": csrf},
            json={
                "oob_id": 3,
                "downstream": {"username": "noc", "password": "secret"},
                "port_credentials": {"access_method": "CLI_CONNECT"},
            },
        )
        assert started.status_code == 200
        task_id = started.json()["id"]
        for _ in range(100):
            task = client.get(f"/api/tasks/{task_id}").json()
            if task["status"] in {"SUCCESS", "FAILED", "CANCELLED"}:
                break
            time.sleep(0.01)
        assert task["status"] == "SUCCESS"
        assert task["result"]["workflow"] == "SMART_VERIFY"
        assert task["result"]["identity"]["items"][0]["model"] == "MX204"
