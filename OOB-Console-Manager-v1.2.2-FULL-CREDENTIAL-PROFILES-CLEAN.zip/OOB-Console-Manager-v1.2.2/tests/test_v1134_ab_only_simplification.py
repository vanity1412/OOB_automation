from __future__ import annotations

import csv
from dataclasses import replace

import pytest

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamDiscoveryResult,
    OOBDevice,
    PortAuthenticationCredentials,
    SessionCredentials,
)
from oob_manager.services.cable_verification_service import CableVerificationService
from oob_manager.services.export_service import ExportService
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


class _Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value: str):
        self.sent.append(value)


class _Client:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class _MinimalSSH:
    def __init__(self):
        self.channel = _Channel()
        self.client = _Client()
        self.expected_prompt = "OOB#"
        self.host_key_policy = "TOFU_PERSISTENT"
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:TEST"

    def connect(self, *_args, **_kwargs):
        return self.client

    def open_shell(self, _client, **_kwargs):
        return self.channel

    def drain_channel(self, _channel):
        return ""


def _cisco_target(port: int = 30217) -> ConsoleTarget:
    return ConsoleTarget(
        id=1,
        oob_id=1,
        menu_name="OOB",
        menu_item=17,
        alias="EDGE-01",
        command=f"telnet 10.20.30.40 {port}",
        protocol="TELNET",
        target_host="10.20.30.40",
        target_port=port,
        console_line=17,
        console_line_source="REVERSE_TELNET_PORT_CONFIRMED",
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="LINE_AVAILABLE",
        is_complete=True,
        last_scan_id=99,
    )


def _vertiv_target(state: str = "AVAILABLE") -> ConsoleTarget:
    return ConsoleTarget(
        id=1,
        oob_id=1,
        menu_name="ACCESS",
        menu_item=7,
        alias="EDGE-01",
        command="connect EDGE-01",
        protocol="VERTIV_CLI",
        target_host="192.0.2.10",
        target_port=7,
        console_line=7,
        console_line_source="VERTIV_ACCESS_SHOW",
        state=state,
        state_confident=True,
        state_reason_code="VERTIV_ACCESS_IDLE" if state == "AVAILABLE" else "VERTIV_ACCESS_IN_USE",
        is_complete=True,
        last_scan_id=99,
    )


def _quick_result(hostname: str) -> DownstreamDiscoveryResult:
    return DownstreamDiscoveryResult(
        identity=DeviceIdentity(actual_hostname=hostname, quality="PARTIAL", confidence="MEDIUM"),
        metadata={"cable_identity_source": "DEVICE_PROMPT", "quick_ab_only": True},
        live_state="AVAILABLE",
        live_state_confident=True,
    )


def test_batch_ab_never_calls_full_identity_service(tmp_path):
    app = CLIApplication(db_path=tmp_path / "batch.db", pause_enabled=False)
    app.export_service = ExportService(app.db, ApplicationSettings(export_dir=str(tmp_path / "exports")))
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")
    target = _cisco_target(22099)
    app.target_repo.list_current = lambda _oob_id: [target]
    app._confirm = lambda _prompt: True

    class ForbiddenIdentityService:
        def discover(self, *_args, **_kwargs):
            raise AssertionError("Quick A/B must never call DeviceIdentityService.discover()")

    called: list[int] = []

    class QuickOnlyService:
        def probe(self, target_id, _credentials):
            called.append(target_id)
            return _quick_result("EDGE-01")

    app.identity_service = ForbiddenIdentityService()
    app.cable_verification_service = QuickOnlyService()
    app._run_batch_cable_verification(device, SessionCredentials("oob", "secret"))
    assert called == [1]


def test_verify_existing_mapping_action_forces_fresh_scan_first(tmp_path):
    app = CLIApplication(db_path=tmp_path / "fresh.db", pause_enabled=False)
    calls: list[str] = []
    app.scan_and_verify_cabling = lambda: calls.append("fresh-scan-and-ab")
    app.verify_available_ports_identity()
    assert calls == ["fresh-scan-and-ab"]


def test_batch_uses_only_four_operator_statuses_and_collapses_errors(tmp_path):
    app = CLIApplication(db_path=tmp_path / "status.db", pause_enabled=False)
    app.export_service = ExportService(app.db, ApplicationSettings(export_dir=str(tmp_path / "exports")))
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")
    target = _cisco_target(22099)
    app.target_repo.list_current = lambda _oob_id: [target]
    app._confirm = lambda _prompt: True

    class FailingQuickService:
        def probe(self, *_args, **_kwargs):
            raise InteractiveSessionError("busy now", error_code="CONSOLE_LINE_BUSY")

    app.cable_verification_service = FailingQuickService()
    app._run_batch_cable_verification(device, SessionCredentials("oob", "secret"))
    csv_path = next((tmp_path / "exports").rglob("cable_verification.csv"))
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["status"] == "SKIP/ERROR"
    assert rows[0]["device_b"] == ""


def test_cisco_quick_ab_uses_exact_arbitrary_telnet_port_after_runtime_verification(monkeypatch):
    adapter = CiscoOOBAdapter(
        ApplicationSettings(command_timeout=20),
        {
            "vendor": "CISCO",
            "prepare_commands": [],
            "optional_commands": {"show_line": "show line", "show_users": "show users"},
            "reverse_telnet_port_base": 2000,
        },
    )
    fake = _MinimalSSH()
    adapter.ssh = fake
    target = _cisco_target(30217)
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")

    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("OOB#", "NORMAL_CLI"))
    monkeypatch.setattr(adapter, "_prepare_readonly_cli", lambda *_a, **_k: [])
    monkeypatch.setattr(
        adapter,
        "_verify_runtime_mapping_normal_cli",
        lambda _ch, t: (t, "show run | i ^menu", "runtime mapping verified"),
    )
    monkeypatch.setattr(
        adapter,
        "_resolve_live_target_state",
        lambda _ch, t: replace(t, state="AVAILABLE", state_confident=True),
    )
    monkeypatch.setattr(
        adapter,
        "_read_console_transition",
        lambda *_a, **_k: ("[vrf:none] root@EDGE-01:~#", "TARGET_EVIDENCE"),
    )

    result = adapter.quick_probe_hostname(device, target, SessionCredentials("oob", "secret"))
    assert result.identity.actual_hostname == "EDGE-01"
    assert fake.channel.sent == ["telnet 10.20.30.40 30217\n"]
    assert result.metadata["downstream_login_used"] is False
    assert result.metadata["downstream_commands_used"] is False


def test_cisco_quick_ab_connection_refused_never_enters_clear_line_workflow(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "CISCO", "prepare_commands": []})
    fake = _MinimalSSH()
    adapter.ssh = fake
    target = _cisco_target(2017)
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")

    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("OOB#", "NORMAL_CLI"))
    monkeypatch.setattr(adapter, "_prepare_readonly_cli", lambda *_a, **_k: [])
    monkeypatch.setattr(
        adapter,
        "_verify_runtime_mapping_normal_cli",
        lambda _ch, t: (t, "show run | i ^menu", "runtime mapping verified"),
    )
    monkeypatch.setattr(
        adapter,
        "_resolve_live_target_state",
        lambda _ch, t: replace(t, state="AVAILABLE", state_confident=True),
    )
    monkeypatch.setattr(
        adapter,
        "_read_console_transition",
        lambda *_a, **_k: ("% Connection refused by remote host", "ERROR"),
    )
    adapter.clear_line_recovery_callback = lambda *_a, **_k: (_ for _ in ()).throw(
        AssertionError("clear-line callback must not be used by Quick A/B")
    )

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.quick_probe_hostname(device, target, SessionCredentials("oob", "secret"))
    assert caught.value.error_code == "TARGET_CONNECT_FAILED"
    assert fake.channel.sent == ["telnet 10.20.30.40 2017\n"]
    assert not any("clear line" in item.lower() for item in fake.channel.sent)


def test_cisco_quick_ab_busy_blocks_before_reverse_telnet(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "CISCO", "prepare_commands": []})
    fake = _MinimalSSH()
    adapter.ssh = fake
    target = _cisco_target(2017)
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")

    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("OOB#", "NORMAL_CLI"))
    monkeypatch.setattr(adapter, "_prepare_readonly_cli", lambda *_a, **_k: [])
    monkeypatch.setattr(
        adapter,
        "_verify_runtime_mapping_normal_cli",
        lambda _ch, t: (t, "show run | i ^menu", "runtime mapping verified"),
    )
    monkeypatch.setattr(
        adapter,
        "_resolve_live_target_state",
        lambda _ch, t: replace(t, state="BUSY", state_confident=True),
    )

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.quick_probe_hostname(device, target, SessionCredentials("oob", "secret"))
    assert caught.value.error_code == "CONSOLE_LINE_BUSY"
    assert fake.channel.sent == []


def test_vertiv_quick_ab_connects_once_and_stops_at_hostname(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    fake = _MinimalSSH()
    adapter.ssh = fake
    target = _vertiv_target()
    device = OOBDevice(id=1, name="ACS-01", host="192.0.2.10", vendor="VERTIV")

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify_basic", lambda _ch, _t: (_vertiv_target(), "access/show"))
    monkeypatch.setattr(
        adapter,
        "_read_connect_transition",
        lambda *_a, **_k: ("root@EDGE-01:~#", "TARGET_EVIDENCE"),
    )

    result = adapter.quick_probe_hostname(device, target, SessionCredentials("admin", "secret"))
    assert result.identity.actual_hostname == "EDGE-01"
    assert fake.channel.sent == ["connect EDGE-01\n"]
    assert result.metadata["downstream_login_used"] is False
    assert result.metadata["downstream_commands_used"] is False


def test_vertiv_quick_ab_explicit_serial_password_then_target_evidence(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    fake = _MinimalSSH()
    adapter.ssh = fake
    target = _vertiv_target()
    device = OOBDevice(id=1, name="ACS-01", host="192.0.2.10", vendor="VERTIV")

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify_basic", lambda _ch, _t: (_vertiv_target(), "access/show"))
    transitions = iter([
        ("Password:", "PORT_PASSWORD"),
        ("Type the hot key to suspend the connection\nEDGE-01#", "TARGET_EVIDENCE"),
    ])
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *_a, **_k: next(transitions))

    result = adapter.quick_probe_hostname(
        device,
        target,
        SessionCredentials("admin", "oob-secret"),
        PortAuthenticationCredentials(password="serial-secret"),
    )
    assert result.identity.actual_hostname == "EDGE-01"
    assert fake.channel.sent == ["connect EDGE-01\n", "serial-secret\n"]
    assert "oob-secret\n" not in fake.channel.sent
    assert result.metadata["vertiv_port_auth_used"] is True
    assert result.metadata["vertiv_port_auth_source"] == "DEDICATED_SERIAL_PASSWORD"


def test_vertiv_quick_ab_password_prompt_requires_explicit_policy(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    fake = _MinimalSSH()
    adapter.ssh = fake
    target = _vertiv_target()
    device = OOBDevice(id=1, name="ACS-01", host="192.0.2.10", vendor="VERTIV")

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify_basic", lambda _ch, _t: (_vertiv_target(), "access/show"))
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *_a, **_k: ("Password:", "PORT_PASSWORD"))

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.quick_probe_hostname(device, target, SessionCredentials("admin", "oob-secret"))
    assert caught.value.error_code == "VERTIV_PORT_AUTH_PASSWORD_REQUIRED"
    assert fake.channel.sent == ["connect EDGE-01\n"]
    assert "\n" not in fake.channel.sent


def test_vertiv_connect_transition_prefers_target_evidence_over_stale_password_line():
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    assert adapter._connect_transition_state("Password:\nEDGE-01 login:") == "TARGET_EVIDENCE"
    assert adapter._connect_transition_state("Password:\nEDGE-01#") == "TARGET_EVIDENCE"
    assert adapter._connect_transition_state("Password:\nroot@EDGE-01:~#") == "TARGET_EVIDENCE"


def test_cable_service_is_independent_of_identity_repository():
    device = OOBDevice(
        id=1,
        name="OOB-01",
        host="192.0.2.1",
        vendor="CISCO",
        connection_revision=3,
        baseline_revision=3
    )
    target = _cisco_target(22099)

    class OOBRepo:
        def get(self, _id):
            return device

        def sync_profile_fingerprint(self, _id, _fingerprint):
            return device

    class TargetRepo:
        def get(self, _id):
            return target

        def verify_open_provenance(self, _id):
            return True, "OK", ""

    class Adapter:
        profile = {}

        def quick_probe_hostname(self, _device, _target, _credentials):
            return _quick_result("EDGE-01")

    service = CableVerificationService(
        OOBRepo(),
        TargetRepo(),
        ApplicationSettings(),
        lock_repo=None,
        adapter_factory=lambda _device, _settings: Adapter(),
    )
    result = service.probe(1, SessionCredentials("oob", "secret"))
    assert result.identity.actual_hostname == "EDGE-01"
    assert result.metadata["quick_ab_only"] is True


def test_operator_help_keeps_quick_ab_out_of_full_identity_and_clear_line():
    from oob_manager.cli.help_text import get_help_text
    from oob_manager.cli.menus import render_main_menu

    menu = render_main_menu()
    assert "Scan + so sánh Device A/B" in menu
    assert "IDENTITY NÂNG CAO" in menu

    text = get_help_text("identity")
    assert "QUICK A/B (nằm ở [1] OOB & SCAN" in text
    assert "KHÔNG chạy show/version/inventory" in text
    assert "KHÔNG hỏi/không chạy clear line" in text
    assert "MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR" in text


def test_mismatch_csv_contains_ab_fields_not_clear_line_metadata(tmp_path):
    service = ExportService(
        None,
        ApplicationSettings(export_dir=str(tmp_path / "exports")),
    )
    paths = service.export_cable_verification(
        "OOB-01",
        [
            {
                "detected_at": "2026-07-27T20:00:00+07:00",
                "oob": "OOB-01",
                "vendor": "CISCO",
                "port": "2020",
                "device_a": "EDGE-01",
                "device_b": "EDGE-02",
                "status": "MISMATCH",
                "evidence_source": "DEVICE_PROMPT",
                "console_path": "172.28.200.11:2020 / line 20",
                # Legacy keys must not leak into the mismatch artifact even when
                # a caller accidentally supplies them.
                "clear_line_recovery_used": True,
                "clear_line_number": 20,
                "clear_line_result": "legacy",
            }
        ],
    )
    with paths["mismatch"].open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        assert reader.fieldnames == [
            "port",
            "device_a",
            "device_b",
            "detected_at",
            "oob",
            "vendor",
            "console_path",
            "evidence_source",
        ]
    assert rows[0]["device_a"] == "EDGE-01"
    assert rows[0]["device_b"] == "EDGE-02"


def test_scan_and_ab_only_probes_after_fresh_accepted_baseline(tmp_path):
    from oob_manager.models import ScanResult

    app = CLIApplication(db_path=tmp_path / "fresh_gate.db", pause_enabled=False)
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")
    creds = SessionCredentials("oob", "secret")
    app._select_oob = lambda _include_disabled=False: device
    app._credentials = lambda _device: creds
    app._export_scan_artifacts_safe = lambda _scan_id: None
    probes: list[int] = []
    app._run_batch_cable_verification = lambda selected, _creds: probes.append(int(selected.id))

    app.scan_service.scan_one = lambda *_args, **_kwargs: ScanResult(
        scan_id=1,
        oob_id=1,
        status="PARTIAL",
        mapping_quality="REJECTED",
        baseline_updated=False,
    )
    app.scan_and_verify_cabling()
    assert probes == []

    app.scan_service.scan_one = lambda *_args, **_kwargs: ScanResult(
        scan_id=2,
        oob_id=1,
        status="SUCCESS",
        mapping_quality="ACCEPTED",
        baseline_updated=True,
    )
    app.scan_and_verify_cabling()
    assert probes == [1]


def test_cisco_open_banner_followed_by_oob_prompt_is_not_device_b(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "CISCO", "prepare_commands": []})
    fake = _MinimalSSH()
    fake.expected_prompt = "HCM-OOB-01#"
    adapter.ssh = fake
    target = _cisco_target(2020)
    device = OOBDevice(id=1, name="HCM-OOB-01", host="192.0.2.1", vendor="CISCO")

    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("HCM-OOB-01#", "NORMAL_CLI"))
    monkeypatch.setattr(adapter, "_prepare_readonly_cli", lambda *_a, **_k: [])
    monkeypatch.setattr(
        adapter,
        "_verify_runtime_mapping_normal_cli",
        lambda _ch, t: (t, "show run | i ^menu", "runtime mapping verified"),
    )
    monkeypatch.setattr(
        adapter,
        "_resolve_live_target_state",
        lambda _ch, t: replace(t, state="AVAILABLE", state_confident=True),
    )
    # This is the dangerous transcript: generic Open text exists, but the final
    # prompt proves Telnet returned to the OOB rather than the downstream device.
    transcript = "Trying 10.20.30.40, 2020 ... Open\r\nHCM-OOB-01#"
    assert adapter._console_transition_state(transcript, "HCM-OOB-01#") == "OOB_PROMPT"
    monkeypatch.setattr(
        adapter,
        "_read_console_transition",
        lambda *_a, **_k: (transcript, "OOB_PROMPT"),
    )

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.quick_probe_hostname(device, target, SessionCredentials("oob", "secret"))
    assert caught.value.error_code == "DOWNSTREAM_CONSOLE_PATH_NOT_ENTERED"


def test_initial_busy_target_is_exported_as_skip_error_without_probe(tmp_path):
    app = CLIApplication(db_path=tmp_path / "busy_export.db", pause_enabled=False)
    app.export_service = ExportService(app.db, ApplicationSettings(export_dir=str(tmp_path / "exports")))
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")
    target = replace(_cisco_target(2020), state="BUSY", state_confident=True)
    app.target_repo.list_current = lambda _oob_id: [target]

    class ForbiddenQuickService:
        def probe(self, *_args, **_kwargs):
            raise AssertionError("BUSY target must never be probed")

    app.cable_verification_service = ForbiddenQuickService()
    app._run_batch_cable_verification(device, SessionCredentials("oob", "secret"))

    csv_path = next((tmp_path / "exports").rglob("cable_verification.csv"))
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 1
    assert rows[0]["device_a"] == "EDGE-01"
    assert rows[0]["device_b"] == ""
    assert rows[0]["status"] == "SKIP/ERROR"
    assert rows[0]["error_code"] == "CONSOLE_LINE_BUSY"



def test_ab_csv_preserves_fresh_scan_order_with_mixed_skip_and_match(tmp_path):
    app = CLIApplication(db_path=tmp_path / "ordered_ab.db", pause_enabled=False)
    app.export_service = ExportService(app.db, ApplicationSettings(export_dir=str(tmp_path / "exports")))
    device = OOBDevice(id=1, name="OOB-01", host="192.0.2.1", vendor="CISCO")
    busy = replace(
        _cisco_target(2020), id=1, alias="EDGE-BUSY", state="BUSY", state_confident=True
    )
    available = replace(_cisco_target(2021), id=2, alias="EDGE-02")
    app.target_repo.list_current = lambda _oob_id: [busy, available]
    app._confirm = lambda _prompt: True

    class QuickOnlyService:
        def probe(self, target_id, _credentials):
            assert target_id == 2
            return _quick_result("EDGE-02")

    app.cable_verification_service = QuickOnlyService()
    app._run_batch_cable_verification(device, SessionCredentials("oob", "secret"))

    csv_path = next((tmp_path / "exports").rglob("cable_verification.csv"))
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert [row["target_id"] for row in rows] == ["1", "2"]
    assert [row["status"] for row in rows] == ["SKIP/ERROR", "MATCH"]


def test_vertiv_scan_skips_active_sessions_when_all_access_ports_are_idle(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    fake = _MinimalSSH()
    adapter.ssh = fake
    device = OOBDevice(id=7, name="ACS-01", host="192.0.2.10", vendor="VERTIV")
    idle_access = """name               port  type    status
=================  ====  ======  ======
EDGE-01            1     serial  idle
EDGE-02            2     serial  idle
--:- access cli->
"""

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_show_access", lambda _ch: idle_access)
    monkeypatch.setattr(
        adapter,
        "_show_active_sessions",
        lambda _ch: (_ for _ in ()).throw(
            AssertionError("active_sessions must not run when every port is idle")
        ),
    )

    result = adapter.collect(device, SessionCredentials("admin", "secret"))
    assert len(result.targets) == 2
    assert all(target.state == "AVAILABLE" for target in result.targets)
    assert result.metadata["active_sessions_needed"] is False
    assert [raw.command_name for raw in result.raw_outputs] == ["menu"]


def test_vertiv_scan_reads_active_sessions_only_when_an_in_use_port_exists(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    fake = _MinimalSSH()
    adapter.ssh = fake
    device = OOBDevice(id=7, name="ACS-01", host="192.0.2.10", vendor="VERTIV")
    mixed_access = """name               port  type    status
=================  ====  ======  ======
EDGE-01            1     serial  in-use
EDGE-02            2     serial  idle
--:- access cli->
"""
    calls: list[str] = []

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_show_access", lambda _ch: mixed_access)

    def active_sessions(_ch):
        calls.append("show")
        # Even an unrecognized optional table must never make an In-Use port safe.
        return "--:- active_sessions cli->\n"

    monkeypatch.setattr(adapter, "_show_active_sessions", active_sessions)

    result = adapter.collect(device, SessionCredentials("admin", "secret"))
    assert calls == ["show"]
    assert result.metadata["active_sessions_needed"] is True
    assert result.targets[0].state == "BUSY_UNKNOWN_USER"
    assert result.targets[1].state == "AVAILABLE"
    assert [raw.command_name for raw in result.raw_outputs] == ["menu", "active_sessions"]
