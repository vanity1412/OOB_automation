from __future__ import annotations

from pathlib import Path

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.cable_check_repository import CableCheckRepository
from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamDiscoveryResult,
    OOBDevice,
    SessionCredentials,
)
from oob_manager.services.export_service import ExportService
from oob_manager.services.database_audit_service import DatabaseAuditService
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.cisco.parsers import parse_menu_config


PROFILE = {
    "vendor": "CISCO",
    "menu_commands": ["show run | i ^menu"],
    "optional_commands": {"show_line": "show line", "show_users": "show users"},
    "prepare_commands": ["terminal length 0"],
    "reverse_telnet_port_base": 2000,
}
MENU = "menu OOB text [9] HNI-BRAS-CTR-01-09\nmenu OOB command 9 telnet 172.29.10.19 2009"


def seed_mapping(tmp_path: Path):
    db = DatabaseConnection(tmp_path / "oob.db")
    MigrationManager(db).migrate()
    device = OOBRepository(db).create(
        OOBDevice(name="HNI-OOB-01", host="192.0.2.10", vendor="CISCO")
    )
    scan_id = ScanRepository(db).start(device, "1.1.37")
    with db.transaction() as conn:
        conn.execute(
            """UPDATE scan_runs SET status='SUCCESS',mapping_quality='ACCEPTED',
               baseline_updated=1,finished_at=started_at WHERE id=?""",
            (scan_id,),
        )
    target = ConsoleTarget(
        oob_id=int(device.id), menu_name="OOB", menu_item=9,
        alias="HNI-BRAS-CTR-01-09", command="telnet 172.29.10.19 2009",
        protocol="TELNET", target_host="172.29.10.19", target_port=2009,
        console_line=9, console_line_source="SHOW_LINE", state="AVAILABLE",
        state_confident=True, state_reason_code="AVAILABLE", source="CISCO_MENU",
        mapping_source_command="show run | i ^menu",
        mapping_text_line="menu OOB text [9] HNI-BRAS-CTR-01-09",
        mapping_command_line="menu OOB command 9 telnet 172.29.10.19 2009",
        is_complete=True, last_scan_id=scan_id,
    )
    TargetRepository(db).replace_current(int(device.id), scan_id, [target])
    current = TargetRepository(db).list_current(int(device.id))[0]
    return db, device, scan_id, current


def test_cable_repository_preserves_target_alias_and_no_hostname_is_partial(tmp_path: Path):
    db, device, scan_id, target = seed_mapping(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(
        run_id,
        int(device.id),
        {
            "target_id": target.id,
            "target_alias": "CANONICAL-TARGET-ALIAS",
            "device_a": "DEVICE-A-DISPLAY",
            "port": 2009,
            "console_path": "172.29.10.19:2009 / line 9",
            "status": "NO_HOSTNAME",
            "evidence_source": "NO_HOSTNAME",
        },
    )
    repo.finish(run_id)
    with db.read() as conn:
        result = conn.execute(
            "SELECT target_alias,device_a FROM cable_check_results WHERE run_id=?", (run_id,)
        ).fetchone()
        run = conn.execute("SELECT status FROM cable_check_runs WHERE id=?", (run_id,)).fetchone()
    assert result["target_alias"] == "CANONICAL-TARGET-ALIAS"
    assert result["device_a"] == "DEVICE-A-DISPLAY"
    assert run["status"] == "PARTIAL"


def test_inventory_surfaces_latest_partial_observation_without_promoting_current_identity(tmp_path: Path):
    db, device, _scan_id, target = seed_mapping(tmp_path)
    repo = DeviceIdentityRepository(db)
    run_id = repo.start(device, target, "oob-user", "downstream-user")
    repo.finish_failed(
        run_id,
        "SERIAL_COMMAND_UNSUPPORTED",
        "Model/version read successfully but hardware serial was unavailable.",
        identity=DeviceIdentity(
            actual_hostname="HNI-BRAS-CTR-01-09",
            vendor="JUNIPER",
            platform_family="JUNOS",
            model="MX204",
            serial_number="",
            software_version="23.4R2",
            quality="PARTIAL",
            confidence="MEDIUM",
            alias_comparison="EXACT_MATCH",
        ),
        runtime_mapping_verified=True,
        runtime_mapping_code="LIVE_MAPPING_VERIFIED",
        runtime_mapping_message="runtime mapping verified",
        live_state="AVAILABLE",
        live_state_confident=True,
        live_state_reason_code="AVAILABLE",
    )
    row = ExportService(db, ApplicationSettings()).current_inventory_rows()[0]
    assert row["identity_source"] == "LATEST_OBSERVED"
    assert row["identity"] == "PARTIAL"
    assert row["model"] == "MX204"
    assert row["version"] == "23.4R2"
    assert row["serial"] == ""
    assert row["identity_error_code"] == "SERIAL_COMMAND_UNSUPPORTED"
    with db.read() as conn:
        assert conn.execute("SELECT COUNT(*) FROM device_identities").fetchone()[0] == 0


class Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value: str):
        self.sent.append(value)


class Client:
    def close(self):
        pass


class QuickSSH:
    def __init__(self, menu: str = MENU):
        self.menu = menu
        self.channel = Channel()
        self.expected_prompt = None
        self.host_key_policy = "TOFU_PERSISTENT"
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:TEST"
        self.commands: list[str] = []
        self.reads = iter(["OOB#", "Trying 172.29.10.19, 2009 ... Open\n"])

    def connect(self, *args, **kwargs):
        return Client()

    def open_shell(self, _client):
        return self.channel

    def read_until_quiet(self, *_args, **_kwargs):
        return next(self.reads)

    def run_shell_command(self, _channel, command, timeout=None):
        self.commands.append(command)
        if command.startswith("terminal "):
            return command + "\nOOB#"
        if command == "show run | i ^menu":
            return self.menu + "\nOOB#"
        if command == "show line":
            return "Tty Line Typ Tx/Rx A Modem Roty AccO AccI Uses Noise Overruns Int\n0/0/1 9 TTY - - - - - 0 0 0/0\nOOB#"
        if command == "show users":
            return "Line User Host(s) Idle Location\n* 0 vty 0 admin 00:00:00 192.0.2.1\nOOB#"
        raise AssertionError(command)

    def drain_channel(self, *_args, **_kwargs):
        return ""


def target_from_menu() -> ConsoleTarget:
    target = parse_menu_config(MENU).targets[0]
    target.mapping_source_command = "show run | i ^menu"
    return target


def test_quick_ab_rechecks_runtime_menu_before_reverse_telnet(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), PROFILE)
    fake = QuickSSH()
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(
        "oob_manager.vendors.cisco.adapter.DownstreamIdentityCollector.collect_quick_hostname",
        lambda self, channel, initial, alias, max_wake_attempts=1: DownstreamDiscoveryResult(
            identity=DeviceIdentity(
                actual_hostname=alias,
                vendor="UNKNOWN",
                quality="PARTIAL",
                confidence="MEDIUM",
                alias_comparison="EXACT_MATCH",
            ),
            metadata={"cable_identity_source": "CONSOLE_BANNER_TTY"},
        ),
    )
    result = adapter.quick_probe_hostname(
        OOBDevice(id=1, name="OOB", host="127.0.0.1"),
        target_from_menu(),
        SessionCredentials("u", "p"),
    )
    assert "show run | i ^menu" in fake.commands
    assert result.runtime_mapping_verified
    assert result.runtime_mapping_verification_code == "LIVE_MAPPING_VERIFIED"
    assert fake.channel.sent == ["telnet 172.29.10.19 2009\n"]


def test_quick_ab_blocks_when_runtime_menu_endpoint_changed(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), PROFILE)
    fake = QuickSSH(
        "menu OOB text [9] HNI-BRAS-CTR-01-09\n"
        "menu OOB command 9 telnet 172.29.10.19 2010"
    )
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    with pytest.raises(InteractiveSessionError) as exc:
        adapter.quick_probe_hostname(
            OOBDevice(id=1, name="OOB", host="127.0.0.1"),
            target_from_menu(),
            SessionCredentials("u", "p"),
        )
    assert exc.value.error_code == "LIVE_MAPPING_ENDPOINT_MISMATCH"
    assert fake.channel.sent == []


def test_cable_repository_persists_runtime_mapping_and_live_state_evidence(tmp_path: Path):
    db, device, scan_id, target = seed_mapping(tmp_path)
    repo = CableCheckRepository(db)
    run_id = repo.start(device, scan_id)
    repo.record(
        run_id,
        int(device.id),
        {
            "target_id": target.id,
            "target_alias": target.alias,
            "device_a": target.alias,
            "device_b": target.alias,
            "port": 2009,
            "console_path": "172.29.10.19:2009 / line 9",
            "status": "MATCH",
            "evidence_source": "CONSOLE_BANNER_TTY",
            "runtime_mapping_verified": True,
            "runtime_mapping_verification_code": "LIVE_MAPPING_VERIFIED",
            "runtime_mapping_verification_message": "Exact menu/item/endpoint re-read.",
            "live_state": "AVAILABLE",
            "live_state_confident": True,
            "live_state_reason_code": "AVAILABLE",
            "live_state_evidence": '{"show_line":"idle"}',
            "live_state_checked_at": "2026-07-28T22:00:00+07:00",
        },
    )
    repo.finish(run_id)
    with db.read() as conn:
        saved = conn.execute(
            """SELECT runtime_mapping_verified,runtime_mapping_verification_code,
                      live_state,live_state_confident,live_state_reason_code,
                      live_state_evidence,live_state_checked_at
               FROM cable_check_results WHERE run_id=?""",
            (run_id,),
        ).fetchone()
    assert saved["runtime_mapping_verified"] == 1
    assert saved["runtime_mapping_verification_code"] == "LIVE_MAPPING_VERIFIED"
    assert saved["live_state"] == "AVAILABLE"
    assert saved["live_state_confident"] == 1
    assert saved["live_state_reason_code"] == "AVAILABLE"
    row = ExportService(db, ApplicationSettings()).current_inventory_rows()[0]
    assert row["cable_runtime_mapping_verified"] is True
    assert row["cable_runtime_mapping_verification_code"] == "LIVE_MAPPING_VERIFIED"
    assert row["cable_live_state"] == "AVAILABLE"
    assert row["cable_live_state_confident"] is True
    assert "Runtime mapping=VERIFIED" in row["action_summary"]
    with db.read() as conn:
        cable_issues = [
            issue for issue in DatabaseAuditService.collect_issues(conn)
            if str(issue["issue_code"]).startswith("CABLE_")
            or str(issue["issue_code"]).startswith("INVALID_CABLE")
        ]
    assert cable_issues == []


def test_migration_v18_adds_cable_runtime_audit_columns_to_v17_database(tmp_path: Path):
    import sqlite3

    path = tmp_path / "v17.db"
    conn = sqlite3.connect(path)
    conn.execute(
        """CREATE TABLE cable_check_results(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER NOT NULL,
            target_id INTEGER,
            oob_id INTEGER NOT NULL,
            target_alias TEXT NOT NULL DEFAULT '',
            port TEXT NOT NULL DEFAULT '',
            console_path TEXT NOT NULL DEFAULT '',
            device_a TEXT NOT NULL DEFAULT '',
            device_b TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL,
            evidence_source TEXT NOT NULL DEFAULT '',
            wake_count INTEGER NOT NULL DEFAULT 0,
            passive_wait_used INTEGER NOT NULL DEFAULT 0,
            error_code TEXT NOT NULL DEFAULT '',
            message TEXT NOT NULL DEFAULT '',
            detected_at TEXT NOT NULL,
            UNIQUE(run_id,target_id)
        )"""
    )
    conn.execute("PRAGMA user_version=17")
    conn.commit()
    conn.close()

    db = DatabaseConnection(path)
    MigrationManager(db).migrate()
    with db.read() as migrated:
        columns = {row["name"] for row in migrated.execute("PRAGMA table_info(cable_check_results)")}
        version = migrated.execute("PRAGMA user_version").fetchone()[0]
    assert version == 19
    assert {
        "runtime_mapping_verified",
        "runtime_mapping_verification_code",
        "runtime_mapping_verification_message",
        "live_state",
        "live_state_confident",
        "live_state_reason_code",
        "live_state_evidence",
        "live_state_checked_at",
    }.issubset(columns)
