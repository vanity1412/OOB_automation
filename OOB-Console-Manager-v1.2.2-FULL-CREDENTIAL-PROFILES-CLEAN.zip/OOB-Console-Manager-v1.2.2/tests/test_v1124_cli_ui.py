from __future__ import annotations

import os

from oob_manager.cli import tables
from oob_manager.cli.menus import render_main_menu, render_title
from oob_manager.cli import theme
from oob_manager.networking.terminal_bridge import TerminalBridge


def test_menu_is_compact_and_contains_core_actions(monkeypatch):
    monkeypatch.setattr('oob_manager.cli.menus.shutil.get_terminal_size', lambda fallback: os.terminal_size((110, 30)))
    text = render_main_menu()
    assert 'OOB & SCAN' in text
    assert 'TÌM & KẾT NỐI THIẾT BỊ' in text
    assert 'IDENTITY NÂNG CAO' in text
    assert 'INVENTORY & LỊCH SỬ' in text
    assert 'CẬP NHẬT OOB' in text
    assert '[H]' in text
    assert '1.2.0' in render_title()


def test_theme_does_not_emit_ansi_when_not_tty(monkeypatch):
    monkeypatch.setattr('oob_manager.cli.theme.sys.stdout.isatty', lambda: False)
    monkeypatch.delenv('OOB_FORCE_COLOR', raising=False)
    monkeypatch.delenv('NO_COLOR', raising=False)
    assert theme.ok('AVAILABLE') == 'AVAILABLE'


def test_status_table_keeps_readable_plain_output(capsys):
    tables.show_rows(['STATE'], [('AVAILABLE',), ('BUSY',), ('UNKNOWN',)], [12])
    out = capsys.readouterr().out
    assert 'AVAILABLE' in out
    assert 'BUSY' in out
    assert 'UNKNOWN' in out
    assert '┌' in out and '└' in out


def test_manual_console_warning_is_explicit(capsys):
    TerminalBridge._print_manual_console_warning()
    out = capsys.readouterr().out
    assert 'MANUAL CONSOLE ĐÃ MỞ' in out
    assert 'trực tiếp' in out.lower()
    assert 'không tự rollback' in out.lower()
    assert 'Ctrl+]' in out
