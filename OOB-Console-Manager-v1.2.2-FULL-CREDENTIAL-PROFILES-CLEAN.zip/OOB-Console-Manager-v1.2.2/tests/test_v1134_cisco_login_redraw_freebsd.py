from oob_manager.downstream.collector import DownstreamIdentityCollector


class _SSH:
    def __init__(self, chunks):
        self.chunks = list(chunks)

    def read_until_state(self, channel, state_detector, timeout, settle, initial=""):
        chunk = self.chunks.pop(0) if self.chunks else ""
        return chunk, state_detector(chunk)


class _Channel:
    def __init__(self):
        self.sent = []

    def send(self, value):
        self.sent.append(value)


def test_cisco_bare_login_first_then_freebsd_banner_on_second_enter():
    ssh = _SSH([
        "login: ",
        "\r\nFreeBSD/amd64 (HNI-BRAS-CTR-01-09) (ttyu0)\r\n\r\nlogin: ",
    ])
    channel = _Channel()
    collector = DownstreamIdentityCollector(ssh, command_timeout=5)

    result = collector.collect_quick_hostname(
        channel,
        "Trying 172.29.10.19, 2009 ... Open\r\n",
        "HNI-BRAS-CTR-01-09",
        passive_timeout=0,
        wake_timeout=1,
        max_wake_attempts=2,
    )

    assert channel.sent == ["\n", "\n"]
    assert result.identity.actual_hostname == "HNI-BRAS-CTR-01-09"
    assert result.identity.alias_comparison == "EXACT_MATCH"
    assert result.metadata["cable_identity_source"] == "CONSOLE_BANNER_TTY"
    assert result.metadata["quick_probe_wake_count"] == 2


def test_cisco_bare_login_after_all_wakes_returns_no_hostname():
    ssh = _SSH(["login: ", "\r\nlogin: "])
    channel = _Channel()
    collector = DownstreamIdentityCollector(ssh, command_timeout=5)

    result = collector.collect_quick_hostname(
        channel,
        "Trying 172.29.10.19, 2009 ... Open\r\n",
        "HNI-BRAS-CTR-01-09",
        passive_timeout=0,
        wake_timeout=1,
        max_wake_attempts=2,
    )

    assert channel.sent == ["\n", "\n"]
    assert result.identity.actual_hostname == ""
    assert result.metadata["cable_identity_source"] == "NO_HOSTNAME"
    assert result.metadata["quick_probe_wake_count"] == 2
