from __future__ import annotations

from types import SimpleNamespace

import pytest

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings
from oob_manager.models import (
    ConsoleOpenResult,
    ConsoleTarget,
    OOBDevice,
    SessionCredentials,
)
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


def _vertiv_device() -> OOBDevice:
    return OOBDevice(
        id=1,
        name="test",
        host="192.0.2.50",
        ssh_port=22,
        vendor="VERTIV",
        device_type="vertiv",
        default_username="admin",
        connection_mode="SSH",
        enabled=True,
    )


def _vertiv_target() -> ConsoleTarget:
    return ConsoleTarget(
        id=10,
        oob_id=1,
        alias="HPG-MP-02-01-N",
        command="connect HPG-MP-02-01-N",
        protocol="VERTIV_CLI",
        target_host="192.0.2.50",
        console_line=1,
        menu_item=1,
        state="AVAILABLE",
        state_confident=True,
        is_complete=True,
        last_scan_id=1,
    )


def test_vertiv_goto_access_is_noop_when_prompt_is_already_access(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    adapter._remember_cli_prompt("--:- access cli->")

    monkeypatch.setattr(
        adapter,
        "_run_cli_command",
        lambda *_a, **_k: (_ for _ in ()).throw(
            AssertionError("must not send cd access when already in access")
        ),
    )

    assert adapter._goto_access(object()) == "--:- access cli->"
    assert adapter._cli_location == "access"


def test_vertiv_goto_access_returns_to_root_from_active_sessions(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    adapter._remember_cli_prompt("--:- active_sessions cli->")
    commands: list[str] = []

    def run(_channel, command: str) -> str:
        commands.append(command)
        output = "--:- / cli->" if command == "cd /" else "--:- access cli->"
        adapter._remember_cli_prompt(output)
        return output

    monkeypatch.setattr(adapter, "_run_cli_command", run)

    assert adapter._goto_access(object()) == "--:- access cli->"
    assert commands == ["cd /", "cd access"]
    assert adapter._cli_location == "access"


def test_vertiv_manual_console_prompts_serial_password_only_after_acs_requests_it(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    device = _vertiv_device()
    target = _vertiv_target()

    class Channel:
        def __init__(self):
            self.sent: list[str] = []

        def send(self, value):
            self.sent.append(value.decode() if isinstance(value, bytes) else value)
            return len(value)

    class Client:
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    class SSH:
        last_host_key_algorithm = ""
        last_host_key_fingerprint = ""
        host_key_policy = "TOFU_PERSISTENT"

        def __init__(self):
            self.channel = Channel()
            self.client = Client()

        def connect(self, *args, **kwargs):
            return self.client

        def open_shell(self, *args, **kwargs):
            return self.channel

        def drain_channel(self, *args, **kwargs):
            return ""

    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda _ch, _target: (target, "access/show"))
    monkeypatch.setattr(adapter, "_goto_access", lambda _ch: "--:- access cli->")

    transitions = iter([
        ("Password:", "PORT_PASSWORD"),
        ("Type the hot key to suspend the connection\nHPG-MP-02-01-N login:", "TARGET_EVIDENCE"),
    ])
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *_a, **_k: next(transitions))
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.TerminalBridge.bridge", lambda *a, **k: None)

    prompts: list[dict] = []

    def serial_password(context):
        prompts.append(context)
        return "serial-only-secret"

    adapter.serial_port_password_callback = serial_password

    result = adapter.open_console(device, target, SessionCredentials("admin", "oob-secret"))

    assert result.console_path_verified is True
    assert len(prompts) == 1
    assert prompts[0]["port_name"] == "HPG-MP-02-01-N"
    assert prompts[0]["serial_port"] == 1
    assert "connect HPG-MP-02-01-N\n" in adapter.ssh.channel.sent
    assert "serial-only-secret\n" in adapter.ssh.channel.sent
    assert "oob-secret\n" not in adapter.ssh.channel.sent
    assert adapter.ssh.client.closed is True


def test_scan_success_caches_prompted_oob_credential_in_ram(tmp_path, monkeypatch):
    app = CLIApplication(db_path=tmp_path / "cli.db", pause_enabled=False)
    device = _vertiv_device()
    credentials = SessionCredentials("admin", "secret")

    monkeypatch.setattr(app, "_select_oob", lambda *_a, **_k: device)
    monkeypatch.setattr(app, "_credentials", lambda *_a, **_k: credentials)
    monkeypatch.setattr(
        app.scan_service,
        "scan_one",
        lambda *_a, **_k: SimpleNamespace(
            status="SUCCESS",
            mapping_quality="ACCEPTED",
            mapping_count=8,
            warning_count=0,
            baseline_updated=True,
            error_message="",
            scan_id=None,
        ),
    )

    app.scan_one()
    cached, source = app.session_credentials.resolve(device)
    assert source == "OOB_OVERRIDE"
    assert cached is not None
    assert cached.username == "admin"
    assert cached.password == "secret"


def test_manual_console_vertiv_has_no_mode_or_pre_auth_wizard(tmp_path, monkeypatch, capsys):
    password_answers = iter(["serial-secret"])
    app = CLIApplication(
        db_path=tmp_path / "cli.db",
        getpass_func=lambda _prompt="": next(password_answers),
        pause_enabled=False,
    )
    device = _vertiv_device()
    target = _vertiv_target()
    selected = SimpleNamespace(
        target=target,
        mapping_stale=False,
        oob_vendor="VERTIV",
        oob_name="test",
        actual_hostname="",
    )

    monkeypatch.setattr(app.search_service, "search_targets", lambda _q: [selected])
    app.search_service.last_truncated = False
    monkeypatch.setattr(app, "input", lambda _prompt="": "1")
    # Search select + confirmation are handled directly to keep the test focused
    # on the normal manual-console workflow.
    monkeypatch.setattr(app, "_read_choice", lambda *_a, **_k: 1)
    monkeypatch.setattr(app, "_confirm", lambda *_a, **_k: True)
    monkeypatch.setattr(app.oob_repo, "get", lambda _id: device)
    monkeypatch.setattr(
        app,
        "_credentials_with_source",
        lambda *_a, **_k: (SessionCredentials("admin", "oob-secret"), "PROMPT"),
    )
    monkeypatch.setattr(
        app,
        "_port_auth_credentials",
        lambda: (_ for _ in ()).throw(AssertionError("normal manual console must not open Vertiv mode/auth wizard")),
    )

    observed = {}

    def open_console(target_id, credentials, **kwargs):
        observed["target_id"] = target_id
        observed["credentials"] = credentials
        observed.update(kwargs)
        callback = kwargs.get("serial_port_password_callback")
        assert callable(callback)
        assert callback({"port_name": target.alias, "serial_port": 1}) == "serial-secret"
        return ConsoleOpenResult()

    monkeypatch.setattr(app.console_service, "open", open_console)

    app.search_and_connect()
    output = capsys.readouterr().out

    assert observed["target_id"] == 10
    assert observed["port_credentials"].access_method == "CLI_CONNECT"
    assert observed["allow_unverified_state"] is False
    assert "Phương thức truy cập serial Vertiv" not in output
    assert "Xác thực serial port Vertiv" not in output
    cached, source = app.session_credentials.resolve(device)
    assert source == "OOB_OVERRIDE"
    assert cached is not None and cached.password == "oob-secret"
