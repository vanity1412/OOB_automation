from __future__ import annotations

from dataclasses import replace

import pytest

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamDiscoveryResult,
    OOBDevice,
    PortAuthenticationCredentials,
    SessionCredentials,
)
from oob_manager.services.export_service import ExportService
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


class _Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value):
        text = value.decode() if isinstance(value, bytes) else str(value)
        self.sent.append(text)
        return len(text)


class _Client:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class _SSH:
    last_host_key_algorithm = "ssh-rsa"
    last_host_key_fingerprint = "SHA256:TEST"
    host_key_policy = "TOFU_PERSISTENT"

    def __init__(self):
        self.channel = _Channel()
        self.client = _Client()

    def connect(self, *_args, **_kwargs):
        return self.client

    def open_shell(self, *_args, **_kwargs):
        return self.channel

    def drain_channel(self, *_args, **_kwargs):
        return ""


def _device() -> OOBDevice:
    return OOBDevice(
        id=1,
        name="test",
        host="192.0.2.50",
        ssh_port=22,
        vendor="VERTIV",
        device_type="vertiv",
        default_username="admin",
        connection_mode="SSH",
        enabled=True,
    )


def _target(target_id: int = 1, alias: str = "HPG-SW-02-01-mem0", port: int = 5) -> ConsoleTarget:
    return ConsoleTarget(
        id=target_id,
        oob_id=1,
        menu_name="ACCESS",
        menu_item=port,
        alias=alias,
        command=f"connect {alias}",
        protocol="VERTIV_CLI",
        target_host="192.0.2.50",
        target_port=0,
        console_line=port,
        console_line_source="VERTIV_ACCESS_SHOW",
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="VERTIV_ACCESS_IDLE",
        is_complete=True,
        last_scan_id=9,
    )


def _prepare_adapter(monkeypatch) -> tuple[VertivOOBAdapter, _SSH]:
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=20), {"vendor": "VERTIV"})
    ssh = _SSH()
    adapter.ssh = ssh
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda _ch, initial: (initial, "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify_basic", lambda _ch, target: (target, "access/show"))
    return adapter, ssh


def test_real_authentication_error_and_port_alias_node_is_acs_error_not_device_b():
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    transcript = (
        "Password:\nPassword:\nPassword:\nPassword:\n\n"
        "Error: Authentication Error.\n\n"
        "--:- HPG-SW-02-01-mem0 cli->"
    )
    assert adapter._connect_transition_state(transcript) == "ERROR"


def test_quick_ab_never_uses_ctrl_c_or_blank_enter_as_password_bypass(monkeypatch):
    adapter, ssh = _prepare_adapter(monkeypatch)
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *_a, **_k: ("Password:", "PORT_PASSWORD"))

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.quick_probe_hostname(_device(), _target(), SessionCredentials("admin", "oob-secret"))

    assert caught.value.error_code == "VERTIV_PORT_AUTH_PASSWORD_REQUIRED"
    assert ssh.channel.sent == ["connect HPG-SW-02-01-mem0\n"]
    assert "\x03" not in "".join(ssh.channel.sent)
    assert "\n" not in ssh.channel.sent
    assert ssh.client.closed is True


def test_explicit_serial_auth_then_hotkey_enter_reaches_real_device_hostname(monkeypatch):
    adapter, ssh = _prepare_adapter(monkeypatch)
    transitions = iter([
        ("Password:", "PORT_PASSWORD"),
        ("Type the hot key to suspend the connection: <CTRL>z", "TARGET_EVIDENCE"),
    ])
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *_a, **_k: next(transitions))

    # After successful ACS serial authentication, the official flow requires one
    # Enter to continue into the downstream console.  First passive read is empty;
    # the second read follows the collector's Enter and returns Device B evidence.
    auth_reads = iter([
        ("", None),
        ("\nHPG-REAL-SW-01 login:", "USERNAME"),
    ])
    monkeypatch.setattr(
        "oob_manager.downstream.collector.DownstreamIdentityCollector._read_auth_transition",
        lambda *_a, **_k: next(auth_reads),
    )

    result = adapter.quick_probe_hostname(
        _device(),
        _target(),
        SessionCredentials("admin", "oob-secret"),
        PortAuthenticationCredentials(password="serial-secret"),
    )

    assert result.identity.actual_hostname == "HPG-REAL-SW-01"
    assert ssh.channel.sent == [
        "connect HPG-SW-02-01-mem0\n",
        "serial-secret\n",
        "\n",
    ]
    assert result.metadata["vertiv_port_auth_used"] is True
    assert result.metadata["vertiv_port_auth_source"] == "DEDICATED_SERIAL_PASSWORD"
    assert result.metadata["vertiv_ctrl_c_bypass_used"] is False
    assert ssh.client.closed is True


def test_wrong_serial_password_returns_auth_failed_and_never_alias_as_hostname(monkeypatch):
    adapter, ssh = _prepare_adapter(monkeypatch)
    failure = (
        "Password:\nPassword:\nPassword:\nPassword:\n\n"
        "Error: Authentication Error.\n\n"
        "--:- HPG-SW-02-01-mem0 cli->"
    )
    transitions = iter([
        ("Password:", "PORT_PASSWORD"),
        (failure, adapter._connect_transition_state(failure)),
    ])
    monkeypatch.setattr(adapter, "_read_connect_transition", lambda *_a, **_k: next(transitions))

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.quick_probe_hostname(
            _device(),
            _target(),
            SessionCredentials("admin", "oob-secret"),
            PortAuthenticationCredentials(password="wrong-secret"),
        )

    assert caught.value.error_code == "VERTIV_PORT_AUTHENTICATION_FAILED"
    assert ssh.channel.sent == [
        "connect HPG-SW-02-01-mem0\n",
        "wrong-secret\n",
    ]
    assert "\x03" not in "".join(ssh.channel.sent)
    assert ssh.client.closed is True


def test_quick_batch_asks_serial_auth_once_and_reuses_explicit_oob_password(tmp_path):
    answers = iter(["2"])
    app = CLIApplication(
        db_path=tmp_path / "batch.db",
        input_func=lambda _prompt="": next(answers),
        getpass_func=lambda _prompt="": "unused",
        pause_enabled=False,
    )
    app.export_service = ExportService(
        app.db,
        ApplicationSettings(export_dir=str(tmp_path / "exports")),
    )
    device = _device()
    targets = [
        _target(1, "HPG-SW-01", 1),
        _target(2, "HPG-SW-02", 2),
    ]
    app.target_repo.list_current = lambda _oob_id: targets
    app._confirm = lambda _prompt: True

    calls: list[tuple[int, bool | None]] = []

    class QuickService:
        def probe(self, target_id, _oob_credentials, port_credentials=None):
            calls.append((target_id, None if port_credentials is None else port_credentials.use_oob_password))
            if port_credentials is None:
                raise InteractiveSessionError(
                    "serial auth required",
                    error_code="VERTIV_PORT_AUTH_PASSWORD_REQUIRED",
                )
            alias = next(item.alias for item in targets if item.id == target_id)
            return DownstreamDiscoveryResult(
                identity=DeviceIdentity(actual_hostname=alias, quality="PARTIAL", confidence="MEDIUM"),
                metadata={"cable_identity_source": "CONSOLE_LOGIN_BANNER"},
            )

    app.cable_verification_service = QuickService()
    app._run_batch_cable_verification(device, SessionCredentials("admin", "oob-secret"))

    assert calls == [
        (1, None),
        (1, True),
        (2, True),
    ]
