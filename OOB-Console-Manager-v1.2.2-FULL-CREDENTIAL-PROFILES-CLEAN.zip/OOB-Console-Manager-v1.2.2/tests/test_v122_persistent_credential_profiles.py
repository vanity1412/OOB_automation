import os
import pytest
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.credential_profile_repository import CredentialProfileRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.models import OOBDevice

@pytest.mark.skipif(os.name != "nt" and not os.environ.get("OOB_CREDENTIAL_MASTER_KEY"), reason="persistent secret backend unavailable")
def test_profile_roundtrip_and_assignment(tmp_path):
    db=DatabaseConnection(tmp_path/'x.db'); MigrationManager(db).migrate()
    cp=CredentialProfileRepository(db); op=OOBRepository(db)
    p=cp.create(name='Shared Cisco',username='noc',password='secret',enable_password='enable',vendor_scope='CISCO')
    c=cp.resolve(p['id']); assert c.username=='noc' and c.password=='secret' and c.enable_password=='enable'
    dev=op.create(OOBDevice(name='OOB1',host='192.0.2.10',vendor='CISCO',device_type='cisco_ios',credential_profile_id=p['id']))
    assert op.get(dev.id).credential_profile_id==p['id']

def test_schema_19_has_profile_tables(tmp_path):
    db=DatabaseConnection(tmp_path/'x.db'); MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute('PRAGMA user_version').fetchone()[0] == 19
        assert conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='credential_profiles'").fetchone()
        assert 'credential_profile_id' in {r['name'] for r in conn.execute('PRAGMA table_info(oob_devices)').fetchall()}
