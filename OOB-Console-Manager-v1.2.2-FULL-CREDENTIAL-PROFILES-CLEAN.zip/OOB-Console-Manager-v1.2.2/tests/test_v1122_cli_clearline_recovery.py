from __future__ import annotations

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import OOBDevice, SessionCredentials
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.cisco.parsers import parse_menu_config


PROFILE = {
    "vendor": "CISCO",
    "menu_commands": ["show run | i ^menu"],
    "prepare_commands": ["terminal length 0", "terminal width 512"],
    "optional_commands": {"show_line": "show line", "show_users": "show users"},
    "reverse_telnet_port_base": 2000,
}
MENU = (
    "menu OOB text [8] ----> CTO-BRAS-CENTER-02-08\n"
    "menu OOB command 8 telnet 172.29.10.36 2010"
)


class Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value: str):
        self.sent.append(value)


class Client:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class RefusedSSH:
    def __init__(self, *, become_busy_after_refusal: bool = False):
        self.channel = Channel()
        self.client = Client()
        self.expected_prompt = None
        self.host_key_policy = "TOFU_PERSISTENT"
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:TEST"
        self.become_busy_after_refusal = become_busy_after_refusal
        self.state_checks = 0
        self.reads = iter(
            [
                "CTO-OOB-02#",
                "% Connection refused by remote host\nCTO-OOB-02#",
                "[confirm]",
                "[OK]\nCTO-OOB-02#",
                "Trying 172.29.10.36, 2010 ... Open\n",
            ]
        )

    def connect(self, *args, **kwargs):
        return self.client

    def open_shell(self, client):
        return self.channel

    def read_until_quiet(self, channel, timeout=None, quiet=None):
        return next(self.reads)

    def drain_channel(self, channel):
        return ""

    def run_shell_command(self, channel, command, timeout=None):
        if command.startswith("terminal "):
            return f"{command}\nCTO-OOB-02#"
        if command == "show run | i ^menu":
            return MENU + "\nCTO-OOB-02#"
        if command == "show line":
            self.state_checks += 1
            busy = self.become_busy_after_refusal and self.state_checks >= 2
            marker = "*" if busy else ""
            return (
                "Tty Line Typ Tx/Rx A Modem Roty AccO AccI Uses Noise Overruns Int\n"
                f"{marker}0/0/1   10 TTY - - - - - 0 0 0/0\nCTO-OOB-02#"
            )
        if command == "show users":
            busy = self.become_busy_after_refusal and self.state_checks >= 2
            extra = " 10 tty 1 noc.live 00:00:02 192.0.2.10\n" if busy else ""
            return (
                "Line User Host(s) Idle Location\n"
                "* 0 vty 0 operator 00:00:00 192.0.2.20\n"
                + extra
                + "CTO-OOB-02#"
            )
        raise AssertionError(command)


def _target():
    target = parse_menu_config(MENU).targets[0]
    target.mapping_source_command = "show run | i ^menu"
    return target


def _adapter(fake: RefusedSSH) -> CiscoOOBAdapter:
    settings = ApplicationSettings(command_timeout=1, retry_delay=0)
    adapter = CiscoOOBAdapter(settings, PROFILE)
    adapter.ssh = fake
    return adapter


def test_connection_refused_can_clear_confirmed_available_line_and_retry(monkeypatch):
    fake = RefusedSSH()
    adapter = _adapter(fake)
    adapter.clear_line_recovery_callback = lambda context: (True, "Lab stale line verified")
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.TerminalBridge.bridge", lambda *a, **k: None)

    result = adapter.open_console(
        OOBDevice(id=1, name="CTO-OOB-02", host="127.0.0.1"),
        _target(),
        SessionCredentials("operator", "secret"),
    )

    assert result.console_path_verified is True
    assert result.clear_line_recovery_requested is True
    assert result.clear_line_recovery_used is True
    assert result.clear_line_number == 10
    assert result.clear_line_reason == "Lab stale line verified"
    assert result.clear_line_result == "CLEAR_SUCCEEDED_TELNET_RETRY"
    assert fake.channel.sent == [
        "telnet 172.29.10.36 2010\n",
        "clear line 10\n",
        "\n",
        "telnet 172.29.10.36 2010\n",
    ]
    assert fake.client.closed is True


def test_connection_refused_decline_never_sends_clear_line(monkeypatch):
    fake = RefusedSSH()
    adapter = _adapter(fake)
    adapter.clear_line_recovery_callback = lambda context: (False, "")
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.open_console(
            OOBDevice(id=1, name="CTO-OOB-02", host="127.0.0.1"),
            _target(),
            SessionCredentials("operator", "secret"),
        )
    assert caught.value.error_code == "CLEAR_LINE_DECLINED"
    assert caught.value.clear_line_recovery_requested is True
    assert caught.value.clear_line_recovery_used is False
    assert fake.channel.sent == ["telnet 172.29.10.36 2010\n"]


def test_connection_refused_never_offers_clear_if_line_became_busy(monkeypatch):
    fake = RefusedSSH(become_busy_after_refusal=True)
    adapter = _adapter(fake)
    called = []
    adapter.clear_line_recovery_callback = lambda context: called.append(context) or (True, "bad")
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.open_console(
            OOBDevice(id=1, name="CTO-OOB-02", host="127.0.0.1"),
            _target(),
            SessionCredentials("operator", "secret"),
        )
    assert caught.value.error_code == "CONSOLE_LINE_BUSY"
    assert called == []
    assert "clear line 10\n" not in fake.channel.sent


def test_schema_v16_adds_clear_line_audit_fields(tmp_path):
    db = DatabaseConnection(tmp_path / "schema.db")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 19
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(connection_history)")}
    assert {
        "clear_line_recovery_requested",
        "clear_line_recovery_used",
        "clear_line_number",
        "clear_line_reason",
        "clear_line_result",
    } <= columns
