# OOB Control Center Web v1.2.0

Web v1.2.0 dùng **chung database, repository, service và vendor adapter** với CLI. Web không tự viết lại logic Cisco/Vertiv, vì vậy các quy tắc an toàn như BUSY/UNKNOWN fail-closed, fresh scan, runtime mapping verification, session lock, cleanup và audit vẫn được giữ nguyên.

## 1. Chức năng

### Dashboard

- Tổng số OOB/target, AVAILABLE/BUSY/UNKNOWN.
- MATCH/MISMATCH/NO_HOSTNAME.
- Identity ACCEPTED/LATEST_OBSERVED.
- Mapping change và identity anomaly chưa xem.
- Danh sách target cần chú ý.

### OOB & Scan

- Thêm, cập nhật, vô hiệu hóa OOB.
- Test SSH theo adapter Cisco/Vertiv thật.
- Scan mapping một OOB hoặc toàn bộ OOB.
- Quick A/B banner-only.
- **Xác minh đầy đủ**: Quick A/B → fresh scan lần hai → Full Inventory.
- Batch Full Inventory riêng: hostname/vendor/model/serial/version.
- Xem port/target trực tiếp từ unified inventory.

### Inventory

- Device A, Device B, trạng thái A/B và độ mới.
- Runtime mapping verification và live-state evidence.
- Vendor, model, serial, version, identity quality/source.
- Drawer chi tiết: overview, history, raw identity evidence, console sessions.
- Tìm theo Device A/B, IP, model hoặc serial.

### Browser Console

- Mở manual console trong trình duyệt qua WebSocket.
- Dùng đúng ConsoleService của CLI.
- Không tự clear line.
- Chỉ mở khi mapping/state đạt policy hoặc operator nhập override hợp lệ theo core.
- Session recorder và redaction giống CLI.

### Task Center

- Task nền có progress, log, kết quả và cancel checkpoint.
- Scan/Test SSH/Quick A/B/Full Inventory/Identity/Reconciliation/Backup.
- Task chỉ hiện cho owner; admin thấy toàn bộ.
- Lịch sử operation quan trọng vẫn lưu trong SQLite qua core services.

### History & Audit

- Scan runs, mapping changes, Quick A/B runs/results.
- Identity runs/events, console sessions, reconciliation, raw scan evidence.
- Inventory theo ngày.
- Snapshot theo Scan ID.
- Đánh dấu mapping/identity alerts đã xem.
- Export inventory hiện tại, theo ngày hoặc toàn bộ.

### Operations

- Credential OOB theo default/vendor/OOB, chỉ lưu RAM theo web session.
- Runtime settings whitelist.
- Database integrity, foreign-key và semantic audit.
- Backup database.

## 2. Cài dependency

```bash
python -m pip install -r requirements-web.txt
```

## 3. Chạy Windows

```powershell
cd D:\OOB-Console-Manager-v1.2.0
.\run_web_windows.ps1
```

Hoặc khai báo biến môi trường thủ công:

```powershell
$env:OOB_WEB_ADMIN_PASSWORD="mat-khau-rat-manh"
$env:OOB_WEB_SECRET="chuoi-ngau-nhien-dai-it-nhat-48-ky-tu"
python web_app.py
```

## 4. Chạy Linux

```bash
cd /opt/OOB-Console-Manager-v1.2.0
./run_web_linux.sh
```

Mặc định truy cập:

```text
http://127.0.0.1:5000
```

## 5. Tài khoản và RBAC

Tài khoản được khai báo bằng environment variable; không có `admin/admin` mặc định và không có bảng password trong OOB database.

```text
OOB_WEB_ADMIN_PASSWORD      → admin
OOB_WEB_OPERATOR_PASSWORD   → operator (tùy chọn)
OOB_WEB_VIEWER_PASSWORD     → viewer (tùy chọn)
```

- `viewer`: chỉ xem dashboard, inventory, history và evidence.
- `operator`: viewer + credential RAM, Test SSH, scan, A/B, identity, console.
- `admin`: operator + OOB CRUD, settings, backup, reconciliation.

## 6. Triển khai mạng ngoài

Mặc định server từ chối bind ra IP mạng ngoài. Khuyến nghị:

```text
Browser → HTTPS reverse proxy → 127.0.0.1:5000 → OOB Control Center
```

Cần cấu hình:

- TLS tại reverse proxy.
- Firewall/VPN/management VLAN.
- `OOB_WEB_COOKIE_SECURE=1` khi dùng HTTPS.
- Secret cố định và đủ dài.
- Không publish trực tiếp port 5000 ra Internet.

Chỉ khi đã có lớp bảo vệ bên ngoài mới đặt:

```text
OOB_WEB_ALLOW_INSECURE_REMOTE=1
```

## 7. Credential và dữ liệu

- Password OOB/downstream không ghi DB, export hoặc task result.
- Credential RAM bị xóa khi logout, hết TTL hoặc server restart.
- Database vẫn là `data/oob_manager.db` dùng chung với CLI.
- Không chạy CLI và web task ghi cùng OOB đồng thời; operation lock của core sẽ chặn xung đột.
- Full package sạch không được chứa database/log/export/session của người dùng.

## 8. Quy trình operator khuyến nghị

```text
Nạp Credential RAM
→ Test SSH
→ Scan live
→ kiểm tra bảng port và mapping quality
→ Quick A/B hoặc Full Inventory
→ xem Task Center
→ kiểm tra Unified Inventory
→ mở Browser Console khi cần
```

## 9. Chế độ dashboard cũ

`python web_dashboard.py` nay mở full web manager.

Dashboard read-only cũ vẫn giữ tại:

```bash
python web_dashboard_readonly.py
```
