@echo off
setlocal
cd /d "%~dp0"
title OOB Monitor Web

echo.
echo ==========================================
echo        OOB MONITOR - WEB LOCAL
echo ==========================================
echo.

set "OOB_WEB_LOCAL_MODE=1"
set "OOB_WEB_HOST=127.0.0.1"
set "OOB_WEB_PORT=5000"

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo [LOI] Khong tim thay Python 3.
        echo Hay cai Python va chon Add Python to PATH.
        pause
        exit /b 1
    )
    set "PYTHON_CMD=python"
)

if not exist "web_app.py" (
    echo [LOI] Khong tim thay web_app.py.
    pause
    exit /b 1
)

%PYTHON_CMD% -c "import fastapi,uvicorn" >nul 2>nul
if errorlevel 1 (
    echo [1/2] Cai thu vien web lan dau...
    %PYTHON_CMD% -m pip install -r requirements-web.txt
    if errorlevel 1 (
        echo [LOI] Khong cai duoc thu vien.
        pause
        exit /b 1
    )
)

echo [2/2] Dang mo giao dien...
start "" "http://127.0.0.1:5000"
echo.
echo Web: http://127.0.0.1:5000
echo Khong can tai khoan trong che do local.
echo Nhan Ctrl+C de dung.
echo.

%PYTHON_CMD% web_app.py

echo.
echo Web da dung.
pause
