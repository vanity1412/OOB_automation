# Dùng Credential Profile trên Web

1. Double-click `START_WEB.bat`.
2. Mở `Credential Profiles`.
3. Chọn `Tạo profile`.
4. Nhập:
   - Tên: ví dụ `NOC-OOB-CISCO`
   - Vendor: `CISCO`, `VERTIV`, hoặc `ANY`
   - Username/password
   - Cisco enable password nếu cần
5. Vào `OOB & Scan` → thêm/sửa OOB → chọn Credential Profile.
6. Search alias/IP rồi bấm:
   - Test SSH
   - Scan live
   - Quick A/B
   - Xác minh đầy đủ
   - Identity only
   - Browser Console
7. Push mapping chỉ thực hiện qua Reconciliation có preview/diff/ticket/reason.

## Lưu ý bảo mật Windows
Credential được mã hóa bằng Windows DPAPI theo user Windows chạy web. Không chạy web dưới nhiều tài khoản Windows khác nhau nếu muốn dùng cùng profile. Khi backup/restore sang máy khác, cần nhập lại password profile.
