# Release v1.2.1 — Simple Web

- One-click `START_WEB.bat`.
- Local-only no-login mode by default.
- Removed PowerShell cryptography launcher dependency.
- Preserved all CLI service/repository/vendor safety logic.
- Web UI remains full-featured for OOB, scan, Quick A/B, Full Identity, inventory, console, tasks, history and audit.
- Remote multi-user mode remains opt-in.
