# Release v1.2.0 — Full Web Control Center

- Full FastAPI web manager dùng chung core CLI và SQLite schema 18.
- Dashboard, OOB CRUD, Test SSH, Scan, Quick A/B, Smart Verify và Full Inventory.
- Unified Inventory gồm Device A/B, mapping/live evidence, model/serial/version.
- Browser console WebSocket dùng ConsoleService và recorder/redaction hiện hữu.
- Task Center async, RBAC viewer/operator/admin, CSRF và signed cookie.
- Credential RAM-only theo session/default/vendor/OOB.
- History/Audit, daily inventory, scan snapshot, export và DB health.
- Không có password mặc định; localhost-only mặc định.
- Legacy read-only dashboard được giữ ở `web_dashboard_readonly.py`.
