# UAT v1.1.37

## 1. Cisco Quick A/B runtime mapping

- Fresh scan port 2009.
- Trước probe, đổi menu runtime sang port/endpoint khác trong môi trường test.
- Kỳ vọng: `LIVE_MAPPING_ENDPOINT_MISMATCH`, không gửi Telnet.
- Trả menu đúng; kỳ vọng runtime mapping code `LIVE_MAPPING_VERIFIED`.

## 2. FreeBSD redraw

`Open -> login: -> Enter lần 2 -> FreeBSD/amd64 (HOST) (ttyu0)` phải lấy Device B.
Không gửi username/password downstream.

## 3. Run status

- Tất cả MATCH/MISMATCH: run SUCCESS.
- Có NO_HOSTNAME hoặc SKIP/ERROR: run PARTIAL.
- Không có kết quả: FAILED.

## 4. Full Inventory

Chạy Batch Full Inventory với thiết bị Cisco/Juniper/Huawei mẫu.
Kiểm tra hostname, vendor, model, serial, version, quality, source và checked_at.
PARTIAL phải hiển thị `LATEST_OBSERVED` nhưng không tạo/ghi đè current ACCEPTED.

## 5. Vertiv

Kiểm tra access/show, Idle/In-Use, active_sessions, serial password, cleanup về ACS prompt.
BUSY/UNKNOWN không được connect.

## 6. Packaging

FULL ZIP không được chứa `.db`, `.db-*`, `ssh_known_hosts`, `.log`, CSV runtime hoặc
thư mục backup/export có dữ liệu ngoài `.gitkeep`.

## 7. Data audit schema 18

- Backup DB v17 rồi chạy v1.1.37; kỳ vọng `PRAGMA user_version=18`, integrity `ok`, FK violations `0`.
- Mỗi Quick A/B port phải có runtime mapping code, live state/confidence/reason/evidence/checked_at.
- Port chưa probe phải ghi `FRESH_SCAN_ONLY_NOT_RUNTIME_RECHECKED`, không được giả là runtime verified.
- Inventory, CSV full audit và dashboard phải show cùng model/serial/version và runtime evidence.
- Chạy DB audit; không được có issue `CABLE_*` trên dữ liệu v1.1.37 hợp lệ.
