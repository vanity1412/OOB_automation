# Chức năng, Workflow và Hướng phát triển OOB Console Manager

**Phiên bản hiện tại: v1.1.34**

Tài liệu này giải thích tool theo góc nhìn vận hành. Người chưa biết code vẫn có thể đọc để hiểu tool đang giải quyết vấn đề gì, dữ liệu đi qua những bước nào, safety gate nằm ở đâu và sau này nên phát triển theo hướng nào.

---

# 1. Tool giải quyết bài toán gì?

Trong hệ thống mạng lớn, router/switch/PE/BRAS thường có cổng console vật lý nối vào một OOB Console Server. Khi management network hoặc routing của thiết bị gặp lỗi, operator vẫn có thể đi theo đường:

```text
Laptop/NOC PC
     │
     │ SSH
     ▼
OOB Console Server
     │
     │ physical serial console
     ▼
Router / Switch / PE / BRAS
```

Vấn đề khi làm thủ công:

```text
phải nhớ OOB nào
phải nhớ line/port nào
phải nhớ menu item nào
phải kiểm tra ai đang dùng line
phải tránh vào nhầm thiết bị
phải tự đối chiếu mapping sau khi có thay đổi
```

Tool biến quy trình đó thành:

```text
Search tên thiết bị
        ↓
Tool biết OOB/path dự kiến
        ↓
Tool kiểm tra lại runtime mapping
        ↓
Tool kiểm tra line AVAILABLE/BUSY
        ↓
Tool mới mở console
        ↓
Toàn bộ operation có audit
```

---

# 2. Topology vật lý tổng thể

```text
┌──────────────────────────────────────────────────┐
│               OPERATOR PC                        │
│ Windows / Linux                                  │
│ python main.py                                   │
└───────────────────────┬──────────────────────────┘
                        │
                        ▼
┌──────────────────────────────────────────────────┐
│            OOB CONSOLE MANAGER                   │
│                                                  │
│ Inventory / Scan / Parser / Quality Gate         │
│ Search / Safety Gate / Identity / Audit          │
│ Terminal Bridge / Reconciliation                 │
└───────────────┬────────────────┬─────────────────┘
                │                │
             SSH│                │SSH
                ▼                ▼
       ┌────────────────┐   ┌──────────────────┐
       │ Cisco OOB      │   │ Vertiv ACS8000  │
       │ Terminal Server│   │ Console Server   │
       └───────┬────────┘   └────────┬─────────┘
               │                     │
        Reverse Telnet          Serial CAS
               │                     │
               └──────────┬──────────┘
                          ▼
                ┌────────────────────┐
                │ Downstream Device  │
                │ Cisco/Juniper/...  │
                └────────────────────┘
```

---

# 3. Các lớp logic chính

```text
CLI
 ↓
Service Layer
 ↓
Vendor Adapter
 ↓
SSH / TCP / Terminal
 ↓
Physical OOB
```

Song song:

```text
Service Layer
 ↓
Repository
 ↓
SQLite
```

Service không nên tự viết raw SQL/SSH tùy ý; mỗi lớp có trách nhiệm riêng.

---

# 4. Những chức năng tool ĐÃ có

## 4.1 OOB inventory

- Add/update/disable/delete OOB.
- Cisco hoặc Vertiv vendor profile.
- SSH management host/port.
- Test connection trước khi lưu.
- Connection revision để phát hiện cấu hình OOB đã đổi sau baseline.

## 4.2 Scan

- Scan một OOB.
- Scan All tuần tự.
- Thu raw evidence.
- Parse console mapping.
- State resolver.
- Snapshot từng scan.
- Quality Gate trước khi update trusted baseline.

## 4.3 Cisco

- NORMAL_CLI.
- AUTO_MENU.
- Enable mode.
- Slow banner/prompt state-driven reader.
- `menu text` + `menu command` parser.
- Reverse Telnet mapping.
- `show line` + `show users`.
- Runtime mapping verify.

## 4.4 Vertiv ACS800/8000

- ACS CLI/root-shell handling.
- `cd access` + `show`.
- Idle/In-Use.
- `active_sessions`.
- CLI_CONNECT.
- Serial port-auth password.
- Direct SSH Port Name.

## 4.5 Console safety

- BUSY block tuyệt đối.
- BUSY_UNKNOWN_USER block.
- UNKNOWN block mặc định.
- AUTO_MENU UNKNOWN override phải nhập lý do.
- Mapping STALE block.
- Runtime endpoint mismatch block.
- Operation lock lease/heartbeat trong cùng DB.

## 4.6 Search

Có thể tìm target dựa trên alias/hostname/IP/serial tùy dữ liệu hiện có.

## 4.7 Downstream Identity Discovery

Read-only login vào thiết bị phía sau và chuẩn hóa:

```text
hostname
vendor
model/platform
serial
version
```

Hỗ trợ identity parser cho:

```text
Cisco
Juniper
Huawei
```

## 4.8 Identity anomaly

Có thể phát hiện:

```text
VERIFIED_MATCH
VERIFIED_MISMATCH
SERIAL_CHANGED
DEVICE_CHANGE_SUSPECTED
```

Tool không tự kết luận “cắm sai dây” vì mismatch cũng có thể là RMA/change hợp lệ.

## 4.9 Audit

- Scan history.
- Connection history.
- Operator username.
- Mapping provenance.
- Raw evidence.
- Change events.
- Identity events.
- Reconciliation history.
- Session recording.

## 4.10 Local alert

Khi mở tool, Main Menu có thể nhắc:

```text
có mapping change chưa xem
có identity anomaly chưa xem
```

## 4.11 Controlled Reconciliation

Tool đã có human-approved reconciliation cho trường hợp thiết bị thay hợp lệ nhưng alias OOB chưa cập nhật.

Không auto-push.

Flow:

```text
Identity mismatch
      ↓
Operator review
      ↓
Ticket + reason
      ↓
Verify đúng physical path + AVAILABLE
      ↓
Alias-only write
      ↓
Read-back
      ↓
Save/commit
      ↓
Rescan
      ↓
New trusted baseline
```

---

# 5. Workflow SCAN

```text
START
  │
  ▼
Load OOB
  │
  ▼
Acquire operation lock
  │
  ▼
Snapshot connection revision + profile fingerprint
  │
  ▼
TCP probe
  │
  ▼
SSH login
  │
  ▼
Vendor Adapter
 ┌┴───────────────┐
 ▼                ▼
Cisco            Vertiv
 │                │
 ▼                ▼
menu/show line   access/show
 │                │
 └───────┬────────┘
         ▼
      Parser
         │
         ▼
 State Resolver
         │
         ▼
   Quality Gate
      ┌──┴──┐
      │     │
    FAIL   PASS
      │     │
      ▼     ▼
 snapshot  compare previous baseline
 giữ old            │
 baseline           ▼
               change detection
                    │
                    ▼
             re-check revision/profile
                    │
                    ▼
               atomic commit
                    │
                    ▼
              trusted baseline
```

Điểm quan trọng: scan lỗi/partial không được phép phá baseline tốt đang tồn tại.

---

# 6. Workflow Cisco Connect

```text
Search target
   │
   ▼
Baseline valid?
   │ NO → BLOCK
   ▼
Acquire CONSOLE lock
   │
   ▼
SSH Cisco OOB
   │
   ▼
NORMAL_CLI?
   │
   ▼
Read runtime menu mapping
   │
   ▼
Alias/host/port/command giống baseline?
   │ NO → BLOCK
   ▼
show line
show users
   │
   ▼
State
 ┌─┼─────────────────────────┐
 ▼ ▼                         ▼
BUSY UNKNOWN              AVAILABLE
 │     │                      │
BLOCK  BLOCK/default          ▼
                         reverse Telnet
                              │
                              ▼
                        TerminalBridge
```

AUTO_MENU không nhìn được hidden endpoint, vì vậy chỉ xác minh item + alias và không được ghi nhận là full runtime mapping verified.

---

# 7. Workflow Vertiv Connect

```text
Search target
   │
   ▼
Acquire lock
   │
   ▼
SSH ACS management
   │
   ▼
cd access
show
   │
   ▼
Alias + physical serial port đúng?
   │ NO → BLOCK
   ▼
Idle?
 ┌─┴─┐
NO  YES
│     │
BLOCK ▼
     chọn path
    ┌─┴─────────────────────┐
    ▼                       ▼
CLI_CONNECT          DIRECT_SSH_PORT_NAME
    │                       │
connect alias         SSH user:port_name
    │                       │
port password?              │
    └────────────┬──────────┘
                 ▼
          Downstream Console
```

---

# 8. Workflow Identity Discovery

```text
Target
  │
  ▼
Mapping valid + live verify
  │
  ▼
AVAILABLE only
  │
  ▼
Open console
  │
  ▼
Detect downstream state
  │
  ├─ existing CLI
  ├─ username
  └─ password
  │
  ▼
Read-only commands
  │
  ▼
Parser
  │
  ▼
hostname/model/serial/version
  │
  ▼
Compare previous accepted identity
  │
  ▼
MATCH / MISMATCH / DEVICE_CHANGE_SUSPECTED
```

Identity automation nghiêm ngặt hơn manual console: không override UNKNOWN/BUSY.

---

# 9. Workflow Controlled Reconciliation

```text
OOB alias = PE01
Actual identity = PE05
        │
        ▼
Operator xác nhận change hợp lệ
        │
        ▼
Menu 17
        │
        ├─ Ticket ID
        ├─ Reason
        └─ Confirm alias
        │
        ▼
RECONCILE lock
        │
        ▼
Live mapping verify + AVAILABLE
        │
        ▼
Mark baseline STALE trước write
        │
        ▼
Alias-only write
        │
        ▼
Read-back + save/commit
        │
        ▼
Rescan
        │
        ▼
Accepted baseline mới
```

### Tại sao mark STALE trước write?

Nếu OOB đã nhận lệnh nhưng PC mất mạng ngay sau đó, baseline cũ không được tiếp tục xem là hợp lệ.

---

# 10. Database topology

```text
                    oob_devices
                        │
        ┌───────────────┼─────────────────┐
        ▼               ▼                 ▼
    scan_runs       connections       identity_runs
        │               │                 │
        ▼               ▼                 ▼
   raw_outputs     session_logs     identity_raw
        │                                 │
        ▼                                 ▼
 snapshots                       identity_snapshots
        │                                 │
        ▼                                 ▼
 console_targets                 current_identity
        │                                 │
        ▼                                 ▼
 change_events                  identity_events
        │
        ▼
 reconciliation_history
```

SQLite hiện là local source of truth.

---

# 11. Nền móng đã vững ở đâu?

Điểm quan trọng không phải số lượng feature mà là các lớp safety đã có:

```text
Evidence
  ↓
Parser
  ↓
Quality Gate
  ↓
Baseline
  ↓
Runtime Re-verification
  ↓
Safety State
  ↓
Action
  ↓
Audit
```

Tool phân biệt rõ:

```text
Data đọc được
≠ Data đủ tin cậy
≠ Data được phép dùng để action
```

Đây là nền tảng cần giữ khi phát triển automation sâu hơn.

---

# 12. Những hạn chế hiện tại

## 12.1 SQLite local

Nếu 5 operator dùng 5 PC khác nhau thì có 5 DB và 5 local lock khác nhau. Đây là giới hạn lớn khi chuyển sang NOC multi-user.

## 12.2 Scan All tuần tự

Hiện phù hợp số lượng OOB nhỏ/vừa. Chưa bounded parallel scan.

## 12.3 Chưa phân biệt stale session chắc chắn

Có AVAILABLE/BUSY/UNKNOWN nhưng chưa có:

```text
BUSY_ACTIVE
BUSY_IDLE
STALE_SUSPECTED
```

## 12.4 Chưa có external inventory

Chưa đồng bộ:

```text
NetBox
CMDB
NMS
CSV/Excel inventory
```

## 12.5 Chưa có scheduler

Scan/identity chủ yếu do operator gọi thủ công.

## 12.6 Chưa có external alerts

Chưa Email/Teams/Slack/Zalo/Syslog webhook dispatcher.

## 12.7 Chưa có PDU path

Chưa map device ↔ PDU outlet.

## 12.8 Chưa có RBAC/Vault

Secret không lưu là nền tảng tốt, nhưng chưa có centralized credential vault hoặc viewer/operator/admin.

## 12.9 Vendor scope

OOB adapter hiện tập trung Cisco + Vertiv. Chưa Opengear/Raritan.

## 12.10 Chưa generic remediation

Không auto reboot, auto kick session, auto config router, auto resolve incident.

---

# 13. Roadmap khuyến nghị

## Giai đoạn 0 – Việc phải làm ngay

**Physical-device UAT.**

Không thêm feature trước khi test:

```text
Cisco OOB thật
Vertiv ACS thật
Windows Terminal thật
AAA/TACACS thật
Downstream router/switch thật
```

Thu raw transcript của output khác parser hiện tại và harden theo dữ liệu thật.

---

## Giai đoạn 1 – Stale Session Classification

Nâng state model:

```text
AVAILABLE
BUSY_ACTIVE
BUSY_IDLE
STALE_SUSPECTED
UNKNOWN
```

Chỉ classify, chưa auto kick.

---

## Giai đoạn 2 – Multi-source Inventory

Ưu tiên:

```text
CSV/Excel import
      ↓
NetBox
      ↓
CMDB/NMS
```

Mục tiêu cross-check:

```text
OOB expected alias
Actual serial/hostname
NetBox
CMDB
```

---

## Giai đoạn 3 – Scheduler + bounded scan

Khi số OOB nhiều:

```text
Scan All concurrency 3-5
jitter AAA login
per-OOB lock vẫn giữ
```

Sau đó thêm scheduler giờ/ngày.

---

## Giai đoạn 4 – Active Alerting

Bắt đầu đơn giản:

```text
Syslog hoặc Teams webhook
```

Severity:

```text
CRITICAL: serial/device change suspected
HIGH: host/port/physical mapping changed
MEDIUM: target added/missing/alias mismatch
INFO: state/menu cosmetic change
```

Nên dùng outbox/retry thay vì gửi webhook bên trong DB transaction.

---

## Giai đoạn 5 – Centralized Database

Khi >1 operator:

```text
SQLite local
    ↓
PostgreSQL shared
```

Mục tiêu:

```text
baseline chung
operation lock chung
history chung
identity chung
alerts chung
```

Giữ SQLite mode cho lab/single-user nếu thiết kế backend abstraction.

---

## Giai đoạn 6 – Multi-user / RBAC / AAA identity

```text
viewer
operator
admin
```

Audit giữ operator identity, không giữ password.

Có thể tích hợp TACACS/RADIUS/LDAP/AD ở policy/environment level và Vault/CyberArk/HashiCorp Vault nếu cần.

---

## Giai đoạn 7 – Topology Map

Visualization:

```text
Site
 ├─ Rack
 │   ├─ OOB
 │   │   ├─ Line → Device → State
 │   │   └─ ...
 │   └─ PDU → Outlet → Device
```

Backend hiện đã có một phần dữ liệu console/identity để xây lớp này.

---

## Giai đoạn 8 – PDU Integration

Chỉ thực hiện sau khi power mapping tin cậy.

```text
Device
 ├─ Console path
 └─ Power path
```

Chưa auto reboot.

---

## Giai đoạn 9 – Controlled stale-session clear

Trước khi có `clear/kick`, phải có:

```text
session age
idle duration
client IP
operator identity
approval
reason/ticket
post-check
```

Không auto kill chỉ vì session tồn tại lâu.

---

## Giai đoạn 10 – Auto Diagnostics

Tool tự thu operational evidence:

```text
BGP status
interface state
routing summary
hardware alarms
log snippets
```

Normalize theo vendor và đưa ra chẩn đoán/gợi ý.

Mô hình nên là:

```text
Auto Diagnose
Human Decide
```

trước khi nghĩ tới auto fix.

---

## Giai đoạn 11 – Limited Human-approved Remediation

Chỉ sau khi nền tảng ở trên trưởng thành:

```text
alert
 ↓
diagnostics
 ↓
proposed action
 ↓
human approval
 ↓
execute narrowly scoped action
 ↓
verify result
 ↓
audit
```

Auto reboot/config/incident resolution hoàn toàn nên để cuối roadmap.

---

# 14. Các mục từ roadmap cũ và trạng thái hiện tại

| Ý tưởng | Trạng thái v1.1.22 |
|---|---|
| Tự đi console lấy model/serial/version/hostname | Đã có cho Cisco/Juniper/Huawei identity |
| Phát hiện alias khác thiết bị thật | Đã có mismatch/identity event |
| Line AVAILABLE/BUSY/UNKNOWN | Đã có |
| Phân biệt stale session thật | Chưa hoàn chỉnh |
| Session recording | Đã có |
| Auto sửa mapping | Có controlled alias-only reconciliation, không auto |
| Alert local | Đã có |
| External alert | Chưa |
| Scheduled scan | Chưa |
| PDU mapping | Chưa |
| Multi-source inventory | Chưa |
| Multi-user RBAC | Chưa |
| Central shared DB | Chưa |
| Auto kick session | Chưa, cố tình |
| Auto power-cycle | Chưa, cố tình |
| Auto config downstream | Chưa, cố tình |
| Auto resolve incident | Chưa, cố tình |

---

# 15. Cách chạy thực tế khuyến nghị

## Windows

```text
1. Cài Python >= 3.10
2. Giải nén project
3. Double-click run_windows.bat
```

Launcher tự tạo `.venv` và cài runtime dependencies nếu thiếu.

Trước thiết bị production:

```powershell
.\.venv\Scripts\python.exe main.py --check
```

## Linux

```bash
./run_linux.sh
```

---

# 16. Quy trình triển khai lần đầu

```text
1. Add 1 OOB không critical
2. Test SSH
3. Scan One
4. Kiểm tra target mapping
5. Test BUSY target → phải BLOCK
6. Test AVAILABLE target → connect
7. Ctrl+] thoát
8. Kiểm tra session_logs
9. Identity Discovery trên 1 target
10. Đối chiếu model/serial/hostname thật
11. Sau khi Cisco/Vertiv read-only flow ổn mới mở rộng OOB khác
12. Menu 17 chỉ test lab/non-critical sau cùng
```

---

# 17. Triết lý cần giữ khi phát triển

```text
Fail closed > đoán
Evidence > assumption
Read before write
Verify before action
Human approval trước high-impact action
Audit mọi operation quan trọng
Không lưu secret
Không hợp thức hóa drift chưa xác minh
```

Nếu tiếp tục giữ các nguyên tắc này, tool có thể phát triển từ OOB Console Manager thành nền tảng OOB Operations mà không phá safety foundation hiện tại.


## Bổ sung v1.1.22 - CLI UX & Cisco Clear-Line Recovery

- CLI clear màn hình khi bước vào workflow mới; kết quả/lỗi được giữ lại đến khi operator nhấn Enter.
- Main Menu được nhóm OOB / Console / Audit / Management / Identity / Reconciliation để dễ đọc.
- Cisco NORMAL_CLI: nếu reverse Telnet trả `% Connection refused by remote host`, tool **không tự clear line**. Tool chỉ offer khi line được suy ra từ reverse-Telnet port và `show line` xác nhận đúng line, đồng thời `show line/show users` sau lỗi vẫn xác nhận `AVAILABLE`.
- Khi đủ điều kiện, tool hỏi Y/N. Nếu Yes, bắt buộc nhập lý do audit, chạy đúng `clear line <N>`, xử lý `[confirm]`, hậu kiểm trạng thái và retry Telnet đúng một lần.
- BUSY, BUSY_UNKNOWN_USER, UNKNOWN hoặc line không được xác minh sẽ không được clear.
- connection_history/CSV ghi lại clear-line requested/used, line number, lý do và kết quả.


## Bổ sung v1.1.30 - Session Credential UX

- `[C]` nạp credential phiên làm việc vào RAM; không ghi password/enable password xuống DB/log/CSV.
- Resolution order: `OOB override -> vendor -> session default -> prompt`.
- `default_username` được lưu như metadata không bí mật để Scan One/operation có thể Enter dùng lại username.
- Scan All dùng credential session đã phủ đủ OOB mà không hỏi lại. Nếu chưa đủ, operator chọn common / per-vendor / per-OOB.
- Khi một OOB bị SSH/Cisco-enable authentication failure: retry riêng OOB đó, skip, hoặc cancel batch. Retry riêng không thay credential chung của các OOB còn lại.
- Credential phiên bị clear reference khi thoát CLI; Python không bảo đảm secure-memory wipe cho string immutable.


## Bổ sung v1.1.30 - Session Credential Stability

- Không promote retry credential thành OOB override nếu final scan vẫn FAILED/CANCELLED.
- Add OOB: username operator nhập rõ ràng không bị credential session có username khác ghi đè khi Test Connection.
- Không thay đổi Cisco/Vertiv/SSH/DB schema/reconciliation core.


## Bổ sung v1.1.31 - CLI Form Resilience

- Update OOB: Vendor/Enabled sai được retry ngay tại field, không làm mất form.
- Delete OOB: trim khoảng trắng ngoài tên xác nhận, vẫn exact/case-sensitive.
- Add OOB: Test Connection fail giữ nguyên form và hỗ trợ Retry / credential khác / sửa Host-Port-Vendor / lưu chưa kiểm tra / hủy.
- CLI runtime dùng thông báo trung tính, không xưng hô cá nhân.
- Không thay đổi Cisco/Vertiv adapter, SSH transport, DB schema, identity hay reconciliation engine.


## Bổ sung v1.1.32 - Real Device Connection Stability

- Vertiv ACS800/8000: loại bỏ BEL/C0 terminal control byte không in được trước khi match prompt. Evidence thiết bị thật cho thấy `show` đã trả đủ access table nhưng prompt kết thúc bằng `--:- access cli-> \x07`, trước đây bị hiểu nhầm là timeout.
- Vertiv Connection Test chỉ chứng minh TCP -> SSH authentication -> interactive shell -> ACS CLI/root-shell-to-CLI. Không chạy `cd access`/`show`; inventory thuộc Scan.
- Vertiv Scan từ root ACS CLI đi trực tiếp `cd access -> show`, tránh `cd /` no-op vì một số firmware/profile không redraw prompt ổn định.
- Không thay đổi Cisco adapter, DB schema, Quick Cable A/B, reconciliation hoặc multi-OOB concurrency.

## Bổ sung v1.1.33 - Quick Cable Verification Stability

- Quick Cable Check giữ đúng mục tiêu **Device A (mapping OOB) vs Device B (hostname thật trên console)**; không chạy downstream `show version`, không gửi username/password.
- Parser Device B nhận thêm prompt thực tế: `root@HOST:~#`, `[vrf:none] root@HOST:~#`, shell có current-working-directory, IOS-XR `RP/0/...:HOST#`, và prompt có ANSI/BEL/C0 terminal bytes.
- Quick probe ưu tiên đọc thụ động một khoảng ngắn khi serial đã có output; nếu chưa có hostname/login/prompt mới gửi **đúng một Enter** để wake console. Gặp `Username:`, `login:` hoặc `Password:` mà không có hostname thì dừng `NO_HOSTNAME`, không login sâu.
- Vertiv Quick A/B: sau `access/show` xác minh port Idle/AVAILABLE, nếu `connect <port_name>` chuyển sang serial im lặng mà không trả ACS prompt/error thì cho phép quick hostname probe thực hiện one-Enter wake. Full Identity Discovery vẫn yêu cầu TARGET_EVIDENCE và fail-closed như trước.
- Vertiv bỏ `cd access` thứ hai ngay sau `_runtime_verify()` khi port đã AVAILABLE; runtime verify đã kết thúc ở `/access`, nên connect trực tiếp để giảm một command/prompt wait trên mỗi port.
- Không thay đổi Cisco controlled clear-line, reconciliation write safety, DB schema, credential persistence hay multi-OOB concurrency. Parallel multi-OOB được dời sang v1.1.35 để ưu tiên đơn giản hóa A/B trước.
- Regression baseline: v1.1.32 = 309/309 pass; v1.1.33 thêm 10 test Quick Cable và đạt 319/319 pass.



## Bổ sung v1.1.34 - A/B Scan Simplification

- Quick Cable Check không còn đi qua `DeviceIdentityService.discover()`; batch A/B là workflow riêng, chỉ lấy hostname Device B.
- Mọi lệnh "dò hàng loạt" đều fresh-scan trước rồi mới so A/B.
- Cisco: không lặp `show run | i ^menu` cho từng port; chỉ live-check `show line/show users` trước reverse Telnet. Không clear-line trong batch.
- Vertiv: live `access/show` -> `connect <port_name>`; không direct SSH và không downstream login. Nếu ACS yêu cầu serial-access authentication do SSO tắt, Quick A/B hỏi đúng một lần cho batch và chỉ dùng credential RAM-only do operator chọn rõ ràng.
- Chỉ 4 trạng thái vận hành: MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR.
- Full identity, reconciliation và manual console vẫn tồn tại riêng nhưng không nằm trên đường đi của Quick A/B.
- Cisco không coi chuỗi `Open` là đủ bằng chứng nếu transcript cuối cùng quay về đúng prompt OOB; tránh lấy hostname OOB làm Device B.
- Batch A/B xuất đủ mọi mapping của fresh scan: target không an toàn để mở được ghi `SKIP/ERROR`, không bị mất dòng; CSV giữ thứ tự fresh scan.
- Vertiv `active_sessions/show` chỉ chạy khi access table có ít nhất một port `In-Use`; all-idle scan bỏ bước phụ này. Quick A/B chỉ cần `access/show` để block BUSY nên không lookup session-user.
- Main menu đổi nhãn workflow chuyên sâu thành `IDENTITY NÂNG CAO`; đường đi thường dùng để so A/B nằm rõ ở `[1] OOB & SCAN`.
- Regression full suite: **336/336 pass**; focused historical regression: **121/121 pass**.
- Multi-OOB bounded parallel chuyển sang v1.1.35 sau UAT thực tế v1.1.34.
