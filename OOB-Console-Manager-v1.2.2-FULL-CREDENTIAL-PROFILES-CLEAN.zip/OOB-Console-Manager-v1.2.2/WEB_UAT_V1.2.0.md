# UAT OOB Control Center Web v1.2.0

## A. Security/RBAC

- [ ] Không đặt admin password → server từ chối chạy.
- [ ] Sai password → HTTP 401.
- [ ] Viewer không thấy và không gọi được Scan/Identity/Console/OOB CRUD.
- [ ] Operator không sửa settings/OOB/reconciliation.
- [ ] Request write thiếu CSRF → HTTP 403.
- [ ] Logout xóa credential RAM và session cookie.
- [ ] DB không chứa password vừa nhập.

## B. Cisco OOB

- [ ] Test SSH nhận đúng prompt/enable state.
- [ ] Scan đọc đúng menu text/command, show line và show users.
- [ ] BUSY/UNKNOWN không mở console.
- [ ] Runtime mapping đổi giữa scan và connect → bị chặn.
- [ ] FreeBSD banner cần hai Enter → lấy đúng Device B.
- [ ] Connection refused → ghi error, không clear line.
- [ ] Browser console đóng sạch và quay về OOB/đóng management session.

## C. Vertiv ACS800/8000

- [ ] Test SSH vào root shell hoặc CLI đúng profile.
- [ ] `cd access` → `show` lấy đúng bảng port live.
- [ ] In-Use/active_sessions được fail-closed.
- [ ] Serial password none/dedicated/reuse OOB đúng explicit selection.
- [ ] `connect <port_name>` và cleanup hoạt động.
- [ ] Direct SSH port-name chỉ dùng khi profile đã bật.

## D. Data

- [ ] Quick A/B ghi một row cho mọi port kể cả SKIP/ERROR.
- [ ] MATCH/MISMATCH/NO_HOSTNAME đúng Device A/B.
- [ ] Mapping runtime verification + live-state evidence có đủ code/time.
- [ ] Full Inventory lưu hostname/vendor/model/serial/version/raw evidence.
- [ ] PARTIAL vẫn hiện ở LATEST_OBSERVED nhưng không ghi đè ACCEPTED.
- [ ] Mapping đổi → A/B/Identity cũ hiện STALE/CẦN CHECK LẠI.
- [ ] Inventory ngày và Snapshot Scan ID không dùng nhầm dữ liệu hiện tại.
- [ ] Database health: integrity=ok, foreign_key=0, semantic issues=0.

## E. Task/UI

- [ ] Task Center cập nhật progress/log/result.
- [ ] Cancel chỉ dừng tại checkpoint an toàn.
- [ ] Tìm Device A/B/IP/model/serial trả đúng target.
- [ ] Drawer hiển thị overview/history/evidence/console sessions.
- [ ] Export current/daily/all tải đúng file.
- [ ] Responsive desktop 1366x768 và 1920x1080.
