#!/usr/bin/env python3
"""Compatibility launcher for the full OOB Control Center web application.

Use ``python web_dashboard_readonly.py`` only when the legacy read-only view is
explicitly required. The default dashboard now exposes the complete, RBAC-
protected web workflow backed by the same services and SQLite database as CLI.
"""
from web_app import main


if __name__ == "__main__":
    main()
