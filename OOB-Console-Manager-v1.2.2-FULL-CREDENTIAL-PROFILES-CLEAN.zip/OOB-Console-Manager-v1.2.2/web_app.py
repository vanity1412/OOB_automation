#!/usr/bin/env python3
"""Start the full OOB Control Center web application."""
from __future__ import annotations

import os


def main() -> None:
    try:
        import uvicorn
    except ImportError as exc:
        raise SystemExit("Thiếu dependency web. Chạy: python -m pip install -r requirements-web.txt") from exc
    from oob_manager.web.app import create_app

    host = os.environ.get("OOB_WEB_HOST", "127.0.0.1")
    port = int(os.environ.get("OOB_WEB_PORT", "5000"))
    if host not in {"127.0.0.1", "localhost", "::1"} and os.environ.get("OOB_WEB_ALLOW_INSECURE_REMOTE", "0") != "1":
        raise SystemExit(
            "Từ chối bind web ra mạng ngoài khi chưa đặt OOB_WEB_ALLOW_INSECURE_REMOTE=1. "
            "Khuyến nghị dùng reverse proxy HTTPS + firewall."
        )
    try:
        app = create_app()
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from None
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
