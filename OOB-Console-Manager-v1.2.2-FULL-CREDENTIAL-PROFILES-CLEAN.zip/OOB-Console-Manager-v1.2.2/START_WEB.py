import os, webbrowser, threading, time
os.environ.setdefault("OOB_WEB_LOCAL_MODE","1")
os.environ.setdefault("OOB_WEB_HOST","127.0.0.1")
os.environ.setdefault("OOB_WEB_PORT","5000")
threading.Thread(target=lambda:(time.sleep(1.5),webbrowser.open("http://127.0.0.1:5000")),daemon=True).start()
from web_app import main
main()
