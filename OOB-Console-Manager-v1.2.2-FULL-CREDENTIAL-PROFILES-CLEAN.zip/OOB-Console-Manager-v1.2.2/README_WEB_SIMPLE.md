# OOB Monitor Web v1.2.2

## Mục tiêu

Bản này giữ nguyên toàn bộ core CLI và database, nhưng cách dùng web được rút gọn:

1. Double-click `START_WEB.bat`.
2. Trình duyệt tự mở `http://127.0.0.1:5000`.
3. Không cần tài khoản trong chế độ local.
4. Tất cả thao tác chính nằm trên web:
   - Thêm/sửa OOB.
   - Test SSH.
   - Scan mapping.
   - Quick A/B.
   - Full Identity.
   - Unified Inventory.
   - Console.
   - Task progress.
   - History/Audit.
   - Export/Backup.

## An toàn mặc định

- Chỉ bind `127.0.0.1`.
- Máy khác không truy cập được.
- Credential OOB/downstream chỉ giữ trong RAM phiên chạy.
- Không auto clear line.
- BUSY/UNKNOWN fail closed.
- Cisco và Vertiv dùng workflow riêng.
- Quick A/B không đăng nhập downstream nếu banner đã đủ hostname.

## Chạy

Windows:
`START_WEB.bat`

Linux:
`./run_web_linux.sh`

Dừng:
nhấn `Ctrl+C` tại cửa sổ server.

## Chế độ nhiều người dùng

Chỉ dùng khi triển khai thật qua reverse proxy HTTPS. Đặt:
- `OOB_WEB_LOCAL_MODE=0`
- `OOB_WEB_ADMIN_PASSWORD=<strong password>`
- `OOB_WEB_SECRET=<random secret>`
