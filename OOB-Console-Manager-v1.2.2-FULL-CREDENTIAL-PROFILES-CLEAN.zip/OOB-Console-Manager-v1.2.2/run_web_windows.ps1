﻿Set-Location -LiteralPath $PSScriptRoot
& ".\START_WEB.bat"
