# OOB Console Manager v1.1.37 — Production Data Hardening

## Mục tiêu

Giữ nguyên core Cisco/Vertiv fail-closed của v1.1.36, vá lỗi runtime mapping/data,
hiển thị Full Inventory rõ ràng và bổ sung workflow batch read-only.

## Sửa lỗi bắt buộc

1. Cisco Quick A/B đọc lại exact menu mapping ngay trước từng reverse-Telnet:
   menu name/item, alias, protocol, target host/port và canonical command.
2. Sau runtime mapping mới đọc lại `show line`/`show users`; BUSY/UNKNOWN bị chặn.
3. `cable_check_results.target_alias` lưu đúng alias riêng, không ghi nhầm Device A.
4. Run có `NO_HOSTNAME` được đánh dấu `PARTIAL`, không báo `SUCCESS` gây hiểu nhầm.
5. Full ZIP được đóng theo whitelist, không chứa DB backup, known-hosts, log, session log
   hay export của người dùng.

## Dữ liệu / Inventory

- Mỗi Quick A/B result lưu `runtime_mapping_verified`, verification code/message, live state/confidence/reason/evidence và checked_at.
- Semantic DB audit kiểm tra counter của run, Device B theo status, runtime verification, confident AVAILABLE và JSON evidence; không chỉ dựa vào SQLite integrity.

- Inventory hiển thị Device A, Device B, MATCH/MISMATCH/NO_HOSTNAME, nguồn và độ mới.
- Hiển thị vendor/model/serial/version từ identity ACCEPTED.
- Nếu lần Full Identity mới nhất chỉ PARTIAL/FAILED nhưng đọc được model/version,
  Inventory hiển thị dưới nguồn `LATEST_OBSERVED` và lỗi tương ứng; không ghi đè
  identity ACCEPTED.
- Thêm `Batch Full Inventory một OOB`: fresh scan, chọn COMPLETE+AVAILABLE,
  discovery tuần tự, commit sau từng target.

## Web dashboard read-only

`web_dashboard.py` dùng Python standard library, mặc định bind `127.0.0.1`, bắt buộc
`OOB_WEB_PASSWORD`, không có API scan/push/config/clear-line/credential.

## Kiểm tra

- `python main.py --version` phải trả `OOB Console Manager CLI 1.1.37`.
- Schema nâng từ 17 lên 18 bằng migration idempotent; giữ nguyên dữ liệu cũ và bổ sung audit runtime mapping/live-state cho từng port.
- Regression: 369/369 PASS; fresh DB và DB v17 copy đều integrity OK, foreign-key violations 0.
