# Web UI design references

OOB Control Center v1.2.0 không sao chép giao diện của một sản phẩm cụ thể. Thiết kế tổng hợp các pattern vận hành phổ biến từ tài liệu chính thức của những nền tảng sau:

- **Opengear Lighthouse**: centralized OOB node/port management, role-scoped access, templates/groups và single-pane operations.
- **ZPE Nodegrid Manager**: dashboard tập trung, vendor-neutral device view và quản lý OOB/serial từ một console.
- **Vertiv Avocent DSView**: browser-based console sessions, rack/device overview, discovery, audit và quyền truy cập tập trung.
- **NetBox**: inventory có cấu trúc, extensible fields, asset/inventory item relationships và source-of-truth model.
- **LibreNMS**: dashboard tile, trạng thái up/warn/down, device/port summaries và alert-oriented navigation.
- **Cisco NSO**: device view, transaction-oriented operation, grouping/templates và compliance/audit workflow.

Các pattern được áp dụng:

```text
Dashboard → OOB nodes → live ports → unified target inventory
          → async tasks → browser console → history/audit
```

Điểm khác biệt có chủ đích:

- Web gọi lại đúng service/repository/vendor adapter của CLI.
- Credential OOB/downstream chỉ lưu RAM của session.
- Không có `admin/admin` mặc định.
- Không tự clear line/reboot/push generic command.
- Mapping/state phải qua safety checks hiện hữu trước khi console/identity.
- Device A/B, runtime mapping evidence, model/serial/version và history dùng chung SQLite.
