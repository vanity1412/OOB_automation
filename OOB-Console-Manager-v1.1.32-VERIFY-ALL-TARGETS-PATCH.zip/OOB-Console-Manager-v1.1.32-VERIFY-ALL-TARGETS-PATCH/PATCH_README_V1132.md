# v1.1.32 - Verify All Targets of One OOB

## Mục tiêu
Scan OOB chỉ phản ánh configured mapping. v1.1.32 bổ sung workflow read-only để live-verify từng console path và lấy identity thật từ thiết bị downstream.

## CLI
`[3] KIỂM TRA THIẾT BỊ -> [2] Xác minh TOÀN BỘ target của một OOB`

Workflow:
- chọn OOB có baseline mapping VALID;
- lấy credential OOB một lần trong RAM;
- chọn downstream credential dùng chung cho batch hoặc nhập riêng từng target;
- Vertiv có thể dùng một serial access/auth policy chung cho batch hoặc nhập riêng từng target;
- với mỗi target: live verify mapping + AVAILABLE/Idle -> mở đúng console path -> login downstream -> whitelist show/display identity -> compare alias với actual hostname;
- BUSY/UNKNOWN fail-closed, không clear/kick session;
- downstream auth fail có Retry riêng / Skip / Cancel;
- OOB auth fail có thể nhập lại credential; chỉ sau retry thành công mới lưu OOB_OVERRIDE trong RAM;
- không tự reconcile/update alias;
- cuối batch xuất lại `latest/current_inventory.csv` để có configured alias + actual hostname/model/serial/version.

## Không thay đổi
- Cisco/Vertiv adapter core;
- SSH transport;
- DB schema (v16);
- baseline/quality gate;
- reconciliation/write path;
- clear-line recovery.
