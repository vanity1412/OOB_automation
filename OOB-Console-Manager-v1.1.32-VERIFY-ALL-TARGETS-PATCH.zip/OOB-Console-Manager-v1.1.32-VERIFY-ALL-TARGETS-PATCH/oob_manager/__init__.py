"""OOB Console Manager CLI."""

__version__ = "1.1.32"
