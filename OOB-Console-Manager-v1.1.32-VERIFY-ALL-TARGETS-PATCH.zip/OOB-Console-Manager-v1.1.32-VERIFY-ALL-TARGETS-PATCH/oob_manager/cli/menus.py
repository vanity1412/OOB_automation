"""Menu CLI đơn giản cho operator; toàn bộ chức năng cũ nằm trong submenu."""
from __future__ import annotations

import shutil

from oob_manager.cli.theme import accent, muted, section, title

VERSION = "1.1.32"


def render_title() -> str:
    width = min(max(shutil.get_terminal_size(fallback=(96, 30)).columns, 76), 108)
    label = f" OOB CONSOLE MANAGER v{VERSION} "
    side = max(2, (width - len(label)) // 2)
    return title("=" * side + label + "=" * max(2, width - side - len(label)))


def _menu_row(token: str, label: str, note: str = "") -> str:
    left = f"{accent(f'[{token}]')} {label}"
    if not note:
        return left
    return f"{left}\n    {muted(note)}"


def render_main_menu() -> str:
    """Main menu chỉ hiển thị 5 workflow thường dùng."""
    width = min(max(shutil.get_terminal_size(fallback=(96, 30)).columns, 76), 108)
    bar = muted("─" * width)
    rows = [bar, section("  CÔNG VIỆC CHÍNH")]
    rows.extend(
        [
            _menu_row("1", "OOB & SCAN", "Thêm/list/update OOB • Scan một hoặc tất cả OOB"),
            _menu_row("2", "TÌM & KẾT NỐI THIẾT BỊ", "Xem target • Tìm linh hoạt • Mở manual console"),
            _menu_row("3", "KIỂM TRA THIẾT BỊ", "Identity read-only • Hostname/model/serial/version • Mismatch"),
            _menu_row("4", "INVENTORY & LỊCH SỬ", "Hiện tại • Theo ngày • Changes • Scan/connection history • CSV"),
            _menu_row("5", "CẬP NHẬT OOB", "Đồng bộ alias/name OOB có kiểm soát sau khi đã xác minh"),
        ]
    )
    rows.extend(
        [
            bar,
            f"{accent('[C]')} Credential phiên làm việc (RAM only)",
            f"{accent('[A]')} Nâng cao / Backup / Settings / Database Health",
            f"{accent('[H]')} Hướng dẫn nhanh",
            f"{accent('[0]')} Thoát",
            bar,
        ]
    )
    return "\n".join(rows)


def render_submenu(title_text: str, items: list[tuple[str, str]]) -> str:
    width = min(max(shutil.get_terminal_size(fallback=(96, 30)).columns, 76), 108)
    bar = muted("─" * width)
    rows = ["", bar, section(f"  {title_text}"), bar]
    for token, label in items:
        rows.append(f"{accent(f'[{token}]')} {label}")
    rows.append(f"{accent('[0]')} Quay lại")
    rows.append(bar)
    return "\n".join(rows)


# Tài liệu tương thích: các chức năng của menu 1..18 cũ vẫn còn trong các workflow mới.
LEGACY_MENU_COVERAGE = {
    1: "OOB & SCAN > Thêm OOB",
    2: "OOB & SCAN > Danh sách OOB",
    3: "OOB & SCAN > Scan một OOB",
    4: "OOB & SCAN > Scan tất cả OOB",
    5: "TÌM & KẾT NỐI > Xem thiết bị phía sau OOB",
    6: "TÌM & KẾT NỐI > Tìm / mở console",
    7: "INVENTORY & LỊCH SỬ > Thay đổi mapping",
    8: "INVENTORY & LỊCH SỬ > Lịch sử scan",
    9: "INVENTORY & LỊCH SỬ > Lịch sử kết nối",
    10: "OOB & SCAN > Cập nhật thông tin OOB",
    11: "OOB & SCAN > Xóa / vô hiệu hóa OOB",
    12: "NÂNG CAO > Backup database",
    13: "NÂNG CAO > Settings / Export / Database Health",
    14: "KIỂM TRA THIẾT BỊ > Xác minh identity",
    15: "KIỂM TRA THIẾT BỊ > Identity đã xác minh",
    16: "KIỂM TRA THIẾT BỊ > Bất thường identity",
    17: "CẬP NHẬT OOB > Đồng bộ alias OOB có kiểm soát",
    18: "INVENTORY & LỊCH SỬ > Xem inventory theo ngày / CSV",
}


TITLE = f"OOB CONSOLE MANAGER v{VERSION}"
MAIN_MENU = "Dùng render_main_menu() để hiển thị menu operator đơn giản."
