from __future__ import annotations

from pathlib import Path

from oob_manager.cli.application import CLIApplication
from oob_manager.exceptions import InputCancelledError, InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamDiscoveryResult,
    IdentityVerification,
    OOBDevice,
    PortAuthenticationCredentials,
    SessionCredentials,
)


def _device(app: CLIApplication, *, vendor: str = "CISCO"):
    return app.oob_service.create(
        OOBDevice(
            name=f"LAB-{vendor}-OOB",
            host="192.0.2.10",
            ssh_port=22,
            vendor=vendor,
            device_type="cisco_ios" if vendor == "CISCO" else "vertiv",
            default_username="noc-net",
            connection_mode="SSH",
        )
    )


def _target(target_id: int, oob_id: int, alias: str, *, vendor: str = "CISCO") -> ConsoleTarget:
    if vendor == "CISCO":
        return ConsoleTarget(
            id=target_id,
            oob_id=oob_id,
            menu_name="OOB",
            menu_item=target_id,
            alias=alias,
            command=f"telnet 10.0.0.1 {2000 + target_id}",
            protocol="TELNET",
            target_host="10.0.0.1",
            target_port=2000 + target_id,
            console_line=target_id,
            state="AVAILABLE",
            state_confident=True,
            is_complete=True,
        )
    return ConsoleTarget(
        id=target_id,
        oob_id=oob_id,
        menu_name="access",
        menu_item=target_id,
        alias=alias,
        command=f"connect {alias}",
        protocol="VERTIV_CLI",
        target_host="",
        target_port=None,
        console_line=target_id,
        state="AVAILABLE",
        state_confident=True,
        is_complete=True,
    )


def _result(actual: str, status: str, *, serial: str = "SER123") -> DownstreamDiscoveryResult:
    return DownstreamDiscoveryResult(
        identity=DeviceIdentity(
            actual_hostname=actual,
            vendor="CISCO",
            platform_family="IOS_FAMILY",
            model="MODEL-X",
            serial_number=serial,
            software_version="1.0",
            quality="ACCEPTED",
            confidence="HIGH",
            alias_comparison="EXACT_MATCH" if status == "VERIFIED_MATCH" else "DIFFERENT",
        ),
        verification=IdentityVerification(
            status=status,
            severity="INFO" if status == "VERIFIED_MATCH" else "WARNING",
            reason_codes=["ALIAS_MATCH" if status == "VERIFIED_MATCH" else "ALIAS_MISMATCH"],
        ),
        live_state="AVAILABLE",
        live_state_confident=True,
    )


def _prepare_app(tmp_path, monkeypatch, targets, *, vendor="CISCO", answers=(), passwords=()):
    answer_iter = iter(answers)
    password_iter = iter(passwords)
    app = CLIApplication(
        db_path=tmp_path / "verify-all.db",
        input_func=lambda _p="": next(answer_iter),
        getpass_func=lambda _p="": next(password_iter),
        pause_enabled=False,
    )
    device = _device(app, vendor=vendor)
    for t in targets:
        t.oob_id = device.id
    monkeypatch.setattr(app, "_select_oob", lambda _include_disabled=False: device)
    monkeypatch.setattr(app.target_repo, "list_current", lambda _oob_id=None: targets)
    monkeypatch.setattr(app.export_service, "export_current_inventory", lambda: Path("current_inventory.csv"))
    monkeypatch.setattr(
        app.export_service,
        "export_identity_verification_batch",
        lambda _name, _vendor, _rows: Path("verify_batch.csv"),
    )
    app.session_credentials.set_default(SessionCredentials("noc-net", "oob-pass", "enable-pass"))
    return app, device


def test_verify_all_targets_classifies_match_and_mismatch(tmp_path, monkeypatch, capsys):
    targets = [_target(1, 0, "R1"), _target(2, 0, "R2")]
    app, _device_obj = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        answers=("c", "1", "downstream-user"),
        passwords=("downstream-pass",),
    )
    calls = []

    def discover(target_id, oob_credentials, downstream_credentials, port_credentials):
        calls.append((target_id, oob_credentials.username, downstream_credentials.username))
        if target_id == 1:
            return _result("R1", "VERIFIED_MATCH", serial="S1")
        return _result("REAL-R2", "VERIFIED_MISMATCH", serial="S2")

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()

    assert [c[0] for c in calls] == [1, 2]
    out = capsys.readouterr().out
    assert "MATCH" in out
    assert "MISMATCH" in out
    assert "REAL-R2" in out
    assert "Current inventory" in out


def test_verify_all_targets_busy_is_fail_closed_and_batch_continues(tmp_path, monkeypatch, capsys):
    targets = [_target(1, 0, "R1"), _target(2, 0, "R2")]
    app, _device_obj = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        answers=("c", "1", "downstream-user"),
        passwords=("downstream-pass",),
    )
    calls = []

    def discover(target_id, *_args):
        calls.append(target_id)
        if target_id == 1:
            raise InteractiveSessionError("busy", error_code="CONSOLE_LINE_BUSY")
        return _result("R2", "VERIFIED_MATCH")

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()

    assert calls == [1, 2]
    out = capsys.readouterr().out
    assert "BUSY" in out
    assert "không mở console" in out


def test_verify_all_downstream_retry_is_target_local_and_shared_credential_remains(tmp_path, monkeypatch):
    targets = [_target(1, 0, "R1"), _target(2, 0, "R2")]
    app, _device_obj = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        answers=(
            "c", "1", "common-user",  # confirm, shared mode, shared user
            "1", "special-user",       # retry target1, replacement user
        ),
        passwords=("common-pass", "special-pass"),
    )
    seen = []

    def discover(target_id, _oob, downstream, _port):
        seen.append((target_id, downstream.username, downstream.password))
        if target_id == 1 and downstream.username == "common-user":
            raise InteractiveSessionError("auth", error_code="DOWNSTREAM_AUTHENTICATION_FAILED")
        return _result("R1" if target_id == 1 else "R2", "VERIFIED_MATCH")

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()

    assert seen == [
        (1, "common-user", "common-pass"),
        (1, "special-user", "special-pass"),
        (2, "common-user", "common-pass"),
    ]


def test_verify_all_cancel_stops_before_later_targets(tmp_path, monkeypatch, capsys):
    targets = [_target(1, 0, "R1"), _target(2, 0, "R2"), _target(3, 0, "R3")]
    app, _device_obj = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        answers=("c", "1", "common-user"),
        passwords=("common-pass",),
    )
    calls = []

    def discover(target_id, *_args):
        calls.append(target_id)
        raise InputCancelledError("cancel")

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()

    assert calls == [1]
    out = capsys.readouterr().out
    assert "ĐÃ HỦY" in out
    assert "BATCH_CANCELLED" in out


def test_verify_all_oob_auth_retry_updates_only_after_success_and_reuses_for_remaining(tmp_path, monkeypatch):
    targets = [_target(1, 0, "R1"), _target(2, 0, "R2")]
    app, device = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        answers=(
            "c", "1", "downstream-user",
            "1", "new-oob-user",  # OOB auth failure -> retry; prompt new OOB username
        ),
        passwords=(
            "downstream-pass",
            "new-oob-pass", "new-enable",
        ),
    )
    seen = []

    def discover(target_id, oob, *_args):
        seen.append((target_id, oob.username, oob.password))
        if target_id == 1 and oob.username == "noc-net":
            raise InteractiveSessionError("bad", error_code="SSH_AUTHENTICATION_FAILED")
        return _result("R1" if target_id == 1 else "R2", "VERIFIED_MATCH")

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()

    assert seen == [
        (1, "noc-net", "oob-pass"),
        (1, "new-oob-user", "new-oob-pass"),
        (2, "new-oob-user", "new-oob-pass"),
    ]
    saved, source = app.session_credentials.resolve(device)
    assert source == "OOB_OVERRIDE"
    assert saved is not None and saved.username == "new-oob-user"


def test_verify_all_vertiv_can_reuse_one_port_auth_policy_for_whole_batch(tmp_path, monkeypatch):
    targets = [_target(1, 0, "V1", vendor="VERTIV"), _target(2, 0, "V2", vendor="VERTIV")]
    app, _device_obj = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        vendor="VERTIV",
        answers=(
            "c", "1", "downstream-user",  # confirm/shared downstream
            "1",                            # shared Vertiv port auth mode
        ),
        passwords=("downstream-pass",),
    )
    shared_port = PortAuthenticationCredentials(password="serial-pass")
    port_prompt_calls = []

    def port_credentials():
        port_prompt_calls.append(True)
        return shared_port

    monkeypatch.setattr(app, "_port_auth_credentials", port_credentials)
    seen_ports = []

    def discover(target_id, _oob, _downstream, port):
        seen_ports.append(port)
        return _result("V1" if target_id == 1 else "V2", "VERIFIED_MATCH")

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()

    assert len(port_prompt_calls) == 1
    assert seen_ports == [shared_port, shared_port]


def test_verify_all_vertiv_busy_runtime_evidence_is_reported_busy(tmp_path, monkeypatch, capsys):
    targets = [_target(1, 0, "V1", vendor="VERTIV")]
    app, _device_obj = _prepare_app(
        tmp_path,
        monkeypatch,
        targets,
        vendor="VERTIV",
        answers=("c", "1", "downstream-user", "1"),
        passwords=("downstream-pass",),
    )
    monkeypatch.setattr(app, "_port_auth_credentials", lambda: PortAuthenticationCredentials())

    def discover(*_args):
        exc = InteractiveSessionError(
            "busy",
            error_code="DOWNSTREAM_LINE_NOT_CONFIRMED_AVAILABLE",
        )
        exc.live_state = "BUSY_UNKNOWN_USER"
        exc.live_state_confident = True
        raise exc

    monkeypatch.setattr(app.identity_service, "discover", discover)
    app.verify_all_targets_of_oob()
    out = capsys.readouterr().out
    assert "BUSY" in out
    assert "UNKNOWN         : 0" in out


def test_export_identity_verification_batch_is_timestamped_and_preserves_batch_outcome(tmp_path):
    app = CLIApplication(db_path=tmp_path / "export-verify.db", pause_enabled=False)
    app.settings.export_dir = tmp_path / "exports"
    app.export_service.settings = app.settings
    rows = [{
        "configured_alias": "R1",
        "console_path": "10.0.0.1:2001",
        "actual_hostname": "REAL-R1",
        "model": "MX204",
        "serial": "SER-1",
        "result": "MISMATCH",
        "reason": "ALIAS_MISMATCH",
    }]
    first = app.export_service.export_identity_verification_batch("HNI/OOB:01", "CISCO", rows)
    second = app.export_service.export_identity_verification_batch("HNI/OOB:01", "CISCO", rows)
    assert first.exists() and second.exists()
    assert first != second
    assert first.parent.name == "verification"
    assert "HNI_OOB_01" in first.name
    text = first.read_text(encoding=app.settings.export_encoding)
    assert "configured_alias" in text
    assert "REAL-R1" in text
    assert "MISMATCH" in text
