from __future__ import annotations

import hashlib
import json
import sqlite3

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.downstream.collector import DownstreamIdentityCollector
from oob_manager.downstream.parsers import parse_identity
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    OOBDevice,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.database_audit_service import DatabaseAuditService
from oob_manager.services.device_identity_service import DeviceIdentityService
from oob_manager.services.scan_service import ScanService


MENU = (
    "menu OOB text [4] ----> R4\n"
    "menu OOB command 4 telnet 10.0.0.1 2004"
)


def _mapping_target(alias: str = "R4") -> ConsoleTarget:
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=4,
        alias=alias,
        command="telnet 10.0.0.1 2004",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=2004,
        console_line=4,
        console_line_source="REVERSE_TELNET_PORT_CONFIRMED",
        state="AVAILABLE",
        session_user="",
        state_confident=True,
        state_reason_code="NO_ACTIVE_TTY_SESSION_ON_CONFIRMED_LINE",
        state_evidence='{"test":true}',
        source="CISCO_MENU",
        mapping_source_command="show run | i ^menu",
        mapping_text_line="menu OOB text [4] ----> R4",
        mapping_text_line_no=1,
        mapping_command_line="menu OOB command 4 telnet 10.0.0.1 2004",
        mapping_command_line_no=2,
        is_complete=True,
    )


def _setup_current_target(tmp_path):
    db = DatabaseConnection(tmp_path / "identity.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    identity_repo = DeviceIdentityRepository(db)
    device = oob_repo.create(
        OOBDevice(
            name="OOB-A",
            host="192.0.2.10",
            device_type="cisco_ios",
            vendor="CISCO",
        )
    )

    class ScanAdapter:
        def collect(self, device, credentials):
            return VendorScanData(
                connection_success=True,
                login_mode="NORMAL_CLI",
                targets=[_mapping_target()],
                raw_outputs=[
                    RawCommandOutput(
                        "menu",
                        "show run | i ^menu",
                        MENU,
                        True,
                        is_core=True,
                    )
                ],
            )

    result = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda _device, _settings: ScanAdapter(),
    ).scan_one(device.id, SessionCredentials("oob-admin", "oob-secret"))
    assert result.baseline_updated
    target = target_repo.list_current(device.id)[0]
    return db, oob_repo, target_repo, identity_repo, device, target


def _accepted_result(hostname: str = "R4") -> DownstreamDiscoveryResult:
    identity = DeviceIdentity(
        actual_hostname=hostname,
        vendor="CISCO",
        platform_family="IOS_FAMILY",
        model="ISR4451-X/K9",
        serial_number="FGL1234ABCD",
        software_version="17.09.04a",
        quality="ACCEPTED",
        confidence="HIGH",
        alias_comparison="EXACT_MATCH" if hostname == "R4" else "DIFFERENT",
        source_evidence={
            "actual_hostname": "show_version_or_prompt",
            "model": "show_inventory_or_show_version",
            "serial_number": "show_inventory_or_show_version",
            "software_version": "show_version",
        },
    )
    return DownstreamDiscoveryResult(
        identity=identity,
        raw_outputs=[
            RawCommandOutput(
                "show_version",
                "show version",
                "Cisco IOS XE Software, Version 17.09.04a\nR4 uptime is 1 day\nR4#",
                True,
                is_core=True,
            ),
            RawCommandOutput(
                "show_inventory",
                "show inventory",
                'NAME: "Chassis"\nPID: ISR4451-X/K9, VID: V05, SN: FGL1234ABCD\nR4#',
                True,
                is_core=True,
            ),
        ],
        login_method="USERNAME_PASSWORD",
        downstream_prompt="R4#",
        runtime_mapping_verified=True,
        runtime_mapping_verification_code="LIVE_MAPPING_VERIFIED",
        runtime_mapping_verification_message="runtime mapping verified",
        live_state="AVAILABLE",
        live_state_confident=True,
        live_state_reason_code="NO_ACTIVE_TTY_SESSION_ON_CONFIRMED_LINE",
        live_state_evidence='{"console_line":4}',
        live_state_checked_at="2026-07-25T10:00:00+00:00",
    )


def test_schema_v9_contains_identity_tables_and_views(tmp_path):
    db = DatabaseConnection(tmp_path / "schema.db")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16
        tables = {
            row["name"]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        assert {
            "device_identity_runs",
            "device_identity_raw_outputs",
            "device_identities",
            "device_identity_snapshots",
        } <= tables
        views = {
            row["name"]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='view'")
        }
        assert {"v_current_device_identity", "v_device_identity_trace"} <= views
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("PRAGMA foreign_key_check").fetchall() == []


def test_cisco_identity_parser_collects_hostname_model_serial_version():
    identity = parse_identity(
        "CISCO",
        {
            "show_version": (
                "Cisco IOS XE Software, Version 17.09.04a\n"
                "R4 uptime is 3 weeks, 1 day\n"
            ),
            "show_inventory": (
                'NAME: "Chassis", DESCR: "Cisco ISR4451 Chassis"\n'
                "PID: ISR4451-X/K9, VID: V05, SN: FGL1234ABCD\n"
            ),
        },
        "R4#",
        "R4",
    )
    assert identity.vendor == "CISCO"
    assert identity.actual_hostname == "R4"
    assert identity.model == "ISR4451-X/K9"
    assert identity.serial_number == "FGL1234ABCD"
    assert identity.software_version == "17.09.04a"
    assert identity.quality == "ACCEPTED"
    assert identity.confidence == "HIGH"
    assert identity.alias_comparison == "EXACT_MATCH"


def test_juniper_identity_parser_collects_identity():
    identity = parse_identity(
        "JUNIPER",
        {
            "show_version": (
                "Hostname: MX-EDGE-01\n"
                "Model: mx480\n"
                "Junos: 23.4R2-S2.1\n"
            ),
            "show_chassis_hardware": (
                "Hardware inventory:\n"
                "Item             Version  Part number  Serial number     Description\n"
                "Chassis                                JN1234AA          MX480\n"
            ),
        },
        "user@MX-EDGE-01>",
        "MX-EDGE-01",
    )
    assert identity.vendor == "JUNIPER"
    assert identity.actual_hostname == "MX-EDGE-01"
    assert identity.model == "mx480"
    assert identity.serial_number == "JN1234AA"
    assert identity.software_version == "23.4R2-S2.1"
    assert identity.quality == "ACCEPTED"
    assert identity.alias_comparison == "EXACT_MATCH"


def test_huawei_identity_parser_collects_identity():
    identity = parse_identity(
        "HUAWEI",
        {
            "display_version": (
                "Huawei Versatile Routing Platform Software\n"
                "VRP (R) software, Version 8.220 (NetEngine 8000 V800R022C00SPC600)\n"
                "HUAWEI NetEngine 8000 F1A uptime is 12 days\n"
            ),
            "display_esn": "ESN : 2102352ABC10XYZ00001\n",
        },
        "<PE-HN-01>",
        "PE-HN-01",
    )
    assert identity.vendor == "HUAWEI"
    assert identity.actual_hostname == "PE-HN-01"
    assert identity.model.startswith("NetEngine")
    assert identity.serial_number == "2102352ABC10XYZ00001"
    assert identity.software_version.startswith("8.220")
    assert identity.quality == "ACCEPTED"
    assert identity.alias_comparison == "EXACT_MATCH"


def test_cisco_parser_does_not_use_transceiver_serial_as_device_serial():
    identity = parse_identity(
        "CISCO",
        {
            "show_version": (
                "Cisco IOS XE Software, Version 17.09.04a\n"
                "R4 uptime is 3 weeks\n"
                "Processor board ID FGLCHASSIS01\n"
            ),
            "show_inventory": (
                'NAME: "GigabitEthernet0/0/0", DESCR: "SFP"\n'
                "PID: GLC-LH-SMD, VID: V01, SN: SFP-SERIAL-DO-NOT-USE\n"
                'NAME: "Chassis", DESCR: "Cisco ISR4451 Chassis"\n'
                "PID: ISR4451-X/K9, VID: V05, SN: FGLCHASSIS01\n"
            ),
        },
        "R4#",
        "R4",
    )
    assert identity.serial_number == "FGLCHASSIS01"
    assert identity.model == "ISR4451-X/K9"
    assert identity.quality == "ACCEPTED"


def test_hostname_and_version_without_hardware_serial_stays_partial():
    identity = parse_identity(
        "CISCO",
        {
            "show_version": (
                "Cisco IOS XE Software, Version 17.09.04a\n"
                "R4 uptime is 1 day\n"
            ),
            "show_inventory": "",
        },
        "R4#",
        "R4",
    )
    assert identity.actual_hostname == "R4"
    assert identity.software_version == "17.09.04a"
    assert identity.serial_number == ""
    assert identity.quality == "PARTIAL"
    assert identity.confidence == "LOW"


def test_identity_repository_only_promotes_accepted_identity(tmp_path):
    db, _oob_repo, _target_repo, repo, device, target = _setup_current_target(tmp_path)
    run_id = repo.start(device, target, "oob-admin", "down-user")
    accepted = _accepted_result()
    repo.finish(run_id, target, accepted)

    current = repo.get_current_for_target(target.id)
    assert current is not None
    assert current["actual_hostname"] == "R4"
    assert current["identity_quality"] == "ACCEPTED"

    partial_identity = DeviceIdentity(
        actual_hostname="R4",
        vendor="CISCO",
        software_version="17.9.5",
        quality="PARTIAL",
        confidence="MEDIUM",
        alias_comparison="EXACT_MATCH",
        source_evidence={"actual_hostname": "prompt"},
    )
    partial = DownstreamDiscoveryResult(
        identity=partial_identity,
        raw_outputs=[RawCommandOutput("show_version", "show version", "partial", True, is_core=True)],
        login_method="EXISTING_CLI",
        downstream_prompt="R4#",
        runtime_mapping_verified=True,
        runtime_mapping_verification_code="LIVE_MAPPING_VERIFIED",
        live_state="AVAILABLE",
        live_state_confident=True,
        live_state_reason_code="TEST_AVAILABLE",
        live_state_evidence="{}",
        live_state_checked_at="2026-07-25T10:01:00+00:00",
    )
    second = repo.start(device, target, "oob-admin", "")
    repo.finish(second, target, partial)

    # PARTIAL remains historical evidence and must not overwrite accepted current identity.
    current_after = repo.get_current_for_target(target.id)
    assert current_after["actual_hostname"] == "R4"
    assert current_after["software_version"] == "17.09.04a"
    with db.read() as conn:
        assert conn.execute(
            "SELECT status FROM device_identity_runs WHERE id=?", (second,)
        ).fetchone()[0] == "PARTIAL"
        assert conn.execute(
            "SELECT COUNT(*) FROM device_identity_snapshots WHERE identity_run_id=?", (second,)
        ).fetchone()[0] == 1


def test_identity_raw_hash_tampering_is_detected(tmp_path):
    db, _oob_repo, _target_repo, repo, device, target = _setup_current_target(tmp_path)
    run_id = repo.start(device, target, "oob-admin", "down-user")
    repo.finish(run_id, target, _accepted_result())

    with db.transaction() as conn:
        row = conn.execute(
            "SELECT id,raw_output,stored_output_sha256 FROM device_identity_raw_outputs "
            "WHERE identity_run_id=? ORDER BY id LIMIT 1",
            (run_id,),
        ).fetchone()
        assert row["stored_output_sha256"] == hashlib.sha256(
            row["raw_output"].encode("utf-8")
        ).hexdigest()
        conn.execute(
            "UPDATE device_identity_raw_outputs SET raw_output=raw_output || ' TAMPERED' WHERE id=?",
            (row["id"],),
        )

    with db.read() as conn:
        issues = DatabaseAuditService.collect_issues(conn)
    assert any(
        issue["issue_code"] == "IDENTITY_RAW_OUTPUT_INTEGRITY_MISMATCH"
        for issue in issues
    )


def test_mapping_change_invalidates_current_identity_but_keeps_history(tmp_path):
    db, _oob_repo, target_repo, repo, device, target = _setup_current_target(tmp_path)
    run_id = repo.start(device, target, "oob-admin", "down-user")
    repo.finish(run_id, target, _accepted_result())
    assert repo.get_current_for_target(target.id) is not None

    changed = _mapping_target(alias="R4-RENAMED")

    class ChangedScanAdapter:
        def collect(self, _device, _credentials):
            return VendorScanData(
                connection_success=True,
                login_mode="NORMAL_CLI",
                targets=[changed],
                raw_outputs=[
                    RawCommandOutput(
                        "menu",
                        "show run | i ^menu",
                        "menu OOB text [4] ----> R4-RENAMED\n"
                        "menu OOB command 4 telnet 10.0.0.1 2004",
                        True,
                        is_core=True,
                    )
                ],
            )

    result = ScanService(
        _oob_repo,
        target_repo,
        ScanRepository(db),
        ChangeRepository(db),
        ScanLockRepository(db),
        ApplicationSettings(),
        adapter_factory=lambda _device, _settings: ChangedScanAdapter(),
    ).scan_one(device.id, SessionCredentials("oob-admin", "oob-secret"))
    assert result.baseline_updated

    assert repo.get_current_for_target(target.id) is None
    with db.read() as conn:
        assert conn.execute(
            "SELECT COUNT(*) FROM device_identity_runs WHERE id=?", (run_id,)
        ).fetchone()[0] == 1
        assert conn.execute(
            "SELECT COUNT(*) FROM device_identity_snapshots WHERE identity_run_id=?", (run_id,)
        ).fetchone()[0] == 1


def test_search_can_find_actual_hostname_model_and_serial(tmp_path):
    _db, _oob_repo, target_repo, repo, device, target = _setup_current_target(tmp_path)
    run_id = repo.start(device, target, "oob-admin", "down-user")
    repo.finish(run_id, target, _accepted_result(hostname="ACTUAL-R4"))

    by_hostname = target_repo.search("ACTUAL-R4")
    by_model = target_repo.search("ISR4451")
    by_serial = target_repo.search("FGL1234")
    assert [row["id"] for row in by_hostname] == [target.id]
    assert [row["id"] for row in by_model] == [target.id]
    assert [row["id"] for row in by_serial] == [target.id]


def test_device_identity_service_rejects_mapping_changed_during_network_io(tmp_path):
    db, oob_repo, target_repo, repo, device, target = _setup_current_target(tmp_path)

    class MutatingAdapter:
        def discover_downstream_identity(self, _device, _target, _oob_creds, _down_creds):
            with db.transaction() as conn:
                conn.execute(
                    "UPDATE console_targets SET target_port=2999 WHERE id=?", (target.id,)
                )
            return _accepted_result()

    service = DeviceIdentityService(
        oob_repo,
        target_repo,
        repo,
        ApplicationSettings(),
        adapter_factory=lambda _device, _settings: MutatingAdapter(),
    )
    with pytest.raises(InteractiveSessionError) as exc:
        service.discover(
            target.id,
            SessionCredentials("oob-admin", "top-secret-oob"),
            DownstreamCredentials("down-user", "top-secret-down"),
        )
    assert exc.value.error_code == "IDENTITY_MAPPING_CHANGED_DURING_DISCOVERY"
    assert repo.get_current_for_target(target.id) is None
    with db.read() as conn:
        row = conn.execute(
            "SELECT status,error_code FROM device_identity_runs ORDER BY id DESC LIMIT 1"
        ).fetchone()
        assert row["status"] == "FAILED"
        assert row["error_code"] == "IDENTITY_MAPPING_CHANGED_DURING_DISCOVERY"


def test_device_identity_service_does_not_persist_passwords_on_failure(tmp_path):
    db, oob_repo, target_repo, repo, _device, target = _setup_current_target(tmp_path)
    oob_password = "OOB-PASSWORD-NEVER-STORE"
    downstream_password = "DOWNSTREAM-PASSWORD-NEVER-STORE"

    class FailingAdapter:
        def discover_downstream_identity(self, *_args, **_kwargs):
            raise InteractiveSessionError(
                f"simulated error {oob_password} {downstream_password}",
                error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
            )

    service = DeviceIdentityService(
        oob_repo,
        target_repo,
        repo,
        ApplicationSettings(),
        adapter_factory=lambda _device, _settings: FailingAdapter(),
    )
    with pytest.raises(InteractiveSessionError):
        service.discover(
            target.id,
            SessionCredentials("oob-admin", oob_password),
            DownstreamCredentials("down-user", downstream_password),
        )

    with db.read() as conn:
        rows = conn.execute("SELECT * FROM device_identity_runs").fetchall()
        raw_rows = conn.execute("SELECT * FROM device_identity_raw_outputs").fetchall()
        snapshot_rows = conn.execute("SELECT * FROM device_identity_snapshots").fetchall()
    serialized = json.dumps(
        [dict(row) for row in [*rows, *raw_rows, *snapshot_rows]],
        ensure_ascii=False,
        default=str,
    )
    assert oob_password not in serialized
    assert downstream_password not in serialized
    assert "***ĐÃ_CHE***" in serialized


class _CommandChannel:
    def __init__(self):
        self.sent: list[str] = []
        self._recv_queue: list[bytes] = []

    def send(self, value: str):
        self.sent.append(value)
        command = value.strip()
        if command == "show version":
            self._recv_queue.append(
                b"show version\r\nCisco IOS XE Software, Version 17.09.04a\r\n"
                b"R4 uptime is 1 day\r\nR4#"
            )
        elif command == "show inventory":
            self._recv_queue.append(
                b"show inventory\r\nNAME: \"Chassis\", DESCR: \"Cisco ISR Chassis\"\r\nPID: ISR4451-X/K9, VID: V05, SN: FGL1234ABCD\r\nR4#"
            )

    def recv_ready(self):
        return bool(self._recv_queue)

    def recv(self, _size: int):
        return self._recv_queue.pop(0) if self._recv_queue else b""


class _CommandSSH:
    def read_until_quiet(self, _channel, timeout=None, quiet=None):
        return ""

    def drain_channel(self, _channel):
        return ""


def test_collector_uses_readonly_whitelist_and_never_sends_credentials_when_cli_exists():
    channel = _CommandChannel()
    collector = DownstreamIdentityCollector(_CommandSSH(), command_timeout=1)
    result = collector.collect(
        channel,
        "R4#",
        DownstreamCredentials("should-not-be-sent", "password-should-not-be-sent"),
        "R4",
    )
    assert result.identity.quality == "ACCEPTED"
    assert result.identity.actual_hostname == "R4"
    assert channel.sent == ["show version\n", "show inventory\n"]
    sent = "".join(channel.sent)
    assert "should-not-be-sent" not in sent
    assert "password-should-not-be-sent" not in sent
    assert {row.command_text for row in result.raw_outputs} == {"show version", "show inventory"}



def test_identity_trace_snapshots_oob_mapping_and_collector_version(tmp_path):
    _db, _oob_repo, _target_repo, repo, device, target = _setup_current_target(tmp_path)
    run_id = repo.start(device, target, "oob-admin", "down-user")
    repo.finish(run_id, target, _accepted_result())

    row = repo.list_recent_runs(limit=1)[0]
    assert row["identity_run_id"] == run_id
    assert row["collector_version"] == "1.1.32"
    assert row["oob_name_at_run"] == "OOB-A"
    assert row["oob_host_at_run"] == "192.0.2.10"
    assert row["oob_ssh_port_at_run"] == 22
    assert row["target_command_at_run"] == "telnet 10.0.0.1 2004"
    assert row["target_protocol_at_run"] == "TELNET"
    assert row["mapping_scan_quality"] == "ACCEPTED"
    assert row["mapping_scan_baseline_updated"] == 1
    assert row["raw_output_count"] == 2
    assert row["successful_command_count"] == 2
    assert row["snapshot_count"] == 1


def test_database_trigger_rejects_nonaccepted_current_identity(tmp_path):
    db, _oob_repo, _target_repo, repo, device, target = _setup_current_target(tmp_path)
    run_id = repo.start(device, target, "oob-admin", "down-user")
    # A PARTIAL run is valid historical evidence, but must never be promoted
    # into device_identities (the current verified identity table).
    partial = DownstreamDiscoveryResult(
        identity=DeviceIdentity(
            actual_hostname="R4",
            vendor="CISCO",
            software_version="17.9",
            quality="PARTIAL",
            confidence="LOW",
            alias_comparison="EXACT_MATCH",
            source_evidence={"actual_hostname": "prompt"},
        ),
        raw_outputs=[RawCommandOutput("show_version", "show version", "ok", True, is_core=True)],
        runtime_mapping_verified=True,
        live_state="AVAILABLE",
        live_state_confident=True,
    )
    repo.finish(run_id, target, partial)

    with pytest.raises(sqlite3.IntegrityError):
        with db.transaction() as conn:
            conn.execute(
                """
                INSERT INTO device_identities(
                    target_id,oob_id,configured_alias,actual_hostname,vendor,platform_family,
                    model,serial_number,software_version,identity_quality,identity_confidence,
                    alias_comparison,source_evidence_json,last_identity_run_id,verified_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    target.id,device.id,target.alias,"R4","CISCO","IOS_FAMILY","","",
                    "17.9","PARTIAL","LOW","EXACT_MATCH","{}",run_id,
                    "2026-07-25T10:00:00+00:00",
                ),
            )


def test_collector_fails_closed_after_command_timeout(monkeypatch):
    collector = DownstreamIdentityCollector(_CommandSSH(), command_timeout=1)
    channel = _CommandChannel()
    calls: list[str] = []

    def fail_first(_channel, command: str, _prompt: str):
        calls.append(command)
        exc = InteractiveSessionError(
            "simulated unsynchronized command",
            error_code="DOWNSTREAM_COMMAND_TIMEOUT",
        )
        # _try_command treats CommandExecutionError specially; use the real type.
        from oob_manager.exceptions import CommandExecutionError
        real = CommandExecutionError(
            "simulated timeout",
            error_code="DOWNSTREAM_COMMAND_TIMEOUT",
        )
        real.raw_output = "partial output without prompt"
        raise real

    monkeypatch.setattr(collector, "_run_readonly_command", fail_first)
    with pytest.raises(Exception) as exc:
        collector.collect(channel, "R4#", DownstreamCredentials(), "R4")
    assert getattr(exc.value, "error_code", "") == "DOWNSTREAM_COMMAND_TIMEOUT"
    assert calls == ["show version"]
    assert "display version" not in channel.sent
    raw = getattr(exc.value, "raw_outputs", [])
    assert len(raw) == 1
    assert raw[0].success is False


def test_failed_discovery_preserves_nonsecret_login_audit_context(tmp_path):
    db, oob_repo, target_repo, repo, _device, target = _setup_current_target(tmp_path)

    class FailingAdapter:
        def discover_downstream_identity(self, *_args, **_kwargs):
            exc = InteractiveSessionError(
                "identity rejected",
                error_code="DOWNSTREAM_IDENTITY_REJECTED",
            )
            exc.login_method = "USERNAME_PASSWORD"
            exc.downstream_prompt = "R4#"
            exc.identity = DeviceIdentity(
                actual_hostname="R4",
                vendor="CISCO",
                quality="REJECTED",
                confidence="LOW",
            )
            exc.raw_outputs = [
                RawCommandOutput("show_version", "show version", "R4#", False, is_core=True)
            ]
            raise exc

    service = DeviceIdentityService(
        oob_repo,
        target_repo,
        repo,
        ApplicationSettings(),
        adapter_factory=lambda _device, _settings: FailingAdapter(),
    )
    with pytest.raises(InteractiveSessionError):
        service.discover(
            target.id,
            SessionCredentials("oob-admin", "secret1"),
            DownstreamCredentials("down-user", "secret2"),
        )

    with db.read() as conn:
        row = conn.execute(
            "SELECT status,login_method,downstream_prompt FROM device_identity_runs ORDER BY id DESC LIMIT 1"
        ).fetchone()
    assert row["status"] == "FAILED"
    assert row["login_method"] == "USERNAME_PASSWORD"
    assert row["downstream_prompt"] == "R4#"
