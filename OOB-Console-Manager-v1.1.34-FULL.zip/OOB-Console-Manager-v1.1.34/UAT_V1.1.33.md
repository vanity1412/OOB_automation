# UAT v1.1.33 - Quick Cable Verification Stability

## Mục tiêu

Xác nhận Device A (mapping OOB) và Device B (hostname thật nhìn thấy trên console) hoạt động ổn định trên Cisco OOB và Vertiv ACS800/ACS8000 mà không login sâu xuống downstream.

## Cisco OOB

1. Scan OOB phải ra mapping ACCEPTED.
2. Chạy Quick Cable Check trên vài port AVAILABLE.
3. Kiểm tra các dạng console:
   - `HOST#` / `HOST>` -> lấy HOST ngay.
   - `root@HOST:~#` -> lấy HOST ngay.
   - `[vrf:none] root@HOST:~#` -> lấy HOST ngay.
   - `HOST (ttyd0)` + `login:` -> lấy HOST từ banner, không login.
   - chỉ `Username:` / `login:` / `Password:` -> NO_HOSTNAME, không gửi credential.
   - console im lặng -> tối đa một Enter, sau đó MATCH/MISMATCH/NO_HOSTNAME.
4. BUSY/UNKNOWN phải SKIP, không reverse Telnet tự động.
5. `Connection refused` vẫn chỉ offer controlled clear-line đúng cơ chế cũ.

## Vertiv ACS800/ACS8000

1. Scan phải đọc `cd access -> show` và parse đúng port/status.
2. Quick Cable Check chỉ chạy port Idle/AVAILABLE.
3. Sau live `access/show`, tool connect trực tiếp `connect <port_name>`; không chạy `cd access` lặp lần hai.
4. Nếu serial im lặng sau connect, Quick A/B được phép một Enter để wake.
5. Nếu thấy ACS CLI/root shell quay lại, phải ERROR `DOWNSTREAM_CONSOLE_PATH_NOT_ENTERED`, không coi đó là Device B.
6. Nếu ACS yêu cầu port-auth password, phải báo `VERTIV_PORT_AUTH_PASSWORD_REQUIRED`; không tự dùng password khác.
7. Full Identity Discovery vẫn fail-closed nếu không có TARGET_EVIDENCE.

## Kết quả cần lưu lại

- `exports/.../cable_verification.csv`
- `exports/.../cable_mismatch.csv`
- `logs/oob_manager.log`
- session log liên quan nếu có
- ảnh màn hình/prompt thật cho các case tool trả sai hostname hoặc NO_HOSTNAME

## Regression code

Baseline v1.1.32: 309/309 pass.

v1.1.33: 319/319 pass (thêm 10 test Quick Cable stability).
