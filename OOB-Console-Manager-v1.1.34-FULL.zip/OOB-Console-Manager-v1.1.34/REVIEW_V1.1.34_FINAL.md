# Final Review v1.1.34 - Device A vs Device B

## Primary workflow

```text
Fresh Scan OOB
  -> Device A = expected alias/mapping
  -> live AVAILABLE safety verification
  -> open exact console path
  -> Device B = hostname observed from banner/prompt
  -> MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR
```

Quick A/B is intentionally separate from Full Identity Discovery.

## Confirmed simplifications

- No downstream username/password in Quick A/B.
- No downstream `show version`, `show inventory`, `display version`, chassis/ESN commands in Quick A/B.
- No automatic Cisco clear-line, Vertiv kill session, or alias reconciliation in batch A/B.
- Cisco uses the exact reverse-Telnet host/port accepted by the fresh scan; it does not infer a port from the console line and does not rerun menu mapping for every target.
- Cisco re-checks line safety with `show line` / `show users` immediately before opening the console.
- `Trying/Open` followed by the known OOB prompt is rejected as downstream evidence, preventing the OOB hostname from being reported as Device B.
- Vertiv Quick A/B uses `access/show` to verify the exact port-name and Idle state, then `connect <port_name>` once.
- Vertiv Quick A/B does not navigate to `active_sessions`; an In-Use port is already unsafe and is blocked.
- Vertiv normal Scan only reads `active_sessions` when at least one access row is In-Use. An all-idle access table skips that extra command/navigation.
- Silent downstream console: passive read first, then at most one bare Enter; no Enter spam.
- Login-only prompts with no hostname return NO_HOSTNAME; the tool does not guess Device B from Device A.
- Every mapping from the fresh scan is represented in the A/B CSV. BUSY/UNKNOWN/INCOMPLETE targets become SKIP/ERROR instead of disappearing.
- CSV rows are sorted back to the accepted fresh-scan target order.
- Operator UI uses `[1] OOB & SCAN` for the normal A/B workflow. `[3] IDENTITY NÂNG CAO` is explicitly separate.

## Regression evidence

- Full automated regression: **336/336 PASS**.
- Focused historical regression: **121/121 PASS**.
- Python compileall: PASS.
- Runtime database `PRAGMA integrity_check`: **ok**.
- Runtime database semantic audit: **0 issues**.

## Real-device regressions covered

- Vertiv ACS800/ACS8000 BEL/C0 prompt suffix (`--:- access cli-> \x07`).
- Vertiv SSH authentication succeeds but CLI prompt/command phase previously timed out.
- Vertiv root-shell -> `cli` transition.
- Vertiv access table Idle/In-Use behavior.
- Cisco arbitrary reverse-Telnet TCP ports.
- Cisco transcript `Trying ... Open` and downstream Linux/VRF prompt such as `[vrf:none] root@HOST:~#`.
- Cisco OOB-prompt false-positive after `Open`.
- BUSY/UNKNOWN fail-closed.
- Session credential and Ctrl+C batch regressions.

## Intentional boundary of v1.1.34

Quick A/B currently keeps one management SSH session per target for isolation and deterministic cleanup. It does **not** yet reuse one SSH session across all ports and does not parallelize OOBs. Those performance changes should be introduced only after real Cisco/Vertiv UAT confirms this simplified A/B path, so speed optimization does not reintroduce state leakage or console-session race conditions.

## Environment note

The build container used for this review does not have `paramiko==3.5.1` and `colorama==0.4.6` preinstalled, so `python main.py --check` correctly reports those dependencies missing in this environment. `run_windows.bat` and `run_linux.sh` retain the existing pinned-dependency bootstrap from `requirements.txt`.
