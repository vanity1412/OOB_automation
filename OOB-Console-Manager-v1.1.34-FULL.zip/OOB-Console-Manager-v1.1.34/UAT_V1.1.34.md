# UAT v1.1.34 - A/B Scan Simplification

## Mục tiêu

Xác nhận workflow thường dùng chỉ làm đúng một việc:

```text
Fresh Scan OOB
  -> Device A (mapping/alias cấu hình)
  -> live safety check
  -> mở đúng console port
  -> Device B (hostname nhìn thấy thật)
  -> MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR
```

Quick A/B không được login downstream, không chạy downstream show version/inventory,
không tự clear line, không tự kill session và không tự sửa mapping.

---

## 1. Kiểm tra trước khi UAT

```bash
python main.py --version
python main.py --check
```

Kỳ vọng version:

```text
1.1.34
```

Trong tool, nạp credential OOB ở `[C]` nếu muốn tránh hỏi lại giữa các lần scan.

---

## 2. Cisco - MATCH

Chọn một Cisco OOB có target AVAILABLE và biết chắc dây console đang đúng.

Chạy:

```text
OOB & SCAN
-> Scan + so sánh Device A/B
```

Kỳ vọng:

```text
Device A : <alias từ menu OOB>
Device B : <hostname thật từ console>
Status   : MATCH
```

Xác nhận log/session không có downstream:

```text
show version
show inventory
display version
username/password tự động
```

---

## 3. Cisco - prompt Linux/VRF thực tế

Case cần xác nhận vì đã từng lỗi trong lịch sử:

```text
[vrf:none] root@HCM-CDN-GW-02-01:~#
```

hoặc:

```text
root@HCM-CDN-GW-02-01:/var/tmp#
```

Kỳ vọng:

```text
Device B = HCM-CDN-GW-02-01
```

Không được trả `NO_HOSTNAME` khi hostname đã hiện rõ trong prompt.

---

## 4. Cisco - arbitrary reverse-Telnet port

Chọn target có port không theo quy luật 2001/2002, ví dụ 2020 hoặc port thực tế khác.

Kỳ vọng tool dùng chính xác endpoint đã scan:

```text
telnet <target_host> <target_port>
```

Không được tự suy ra port từ console line.
Không được rerun menu mapping command cho từng target chỉ để tìm lại port.

Nếu transcript có `Trying ... Open` nhưng sau đó quay về đúng prompt của OOB, kỳ vọng:

```text
SKIP/ERROR / console path not entered
```

Không được lấy hostname của chính OOB làm Device B chỉ vì đã thấy chữ `Open`.

---

## 5. Cisco - BUSY / UNKNOWN

### BUSY

Tạo/chọn line đang có người dùng.

Kỳ vọng:

```text
SKIP/ERROR
CONSOLE_LINE_BUSY
```

Tool không reverse-Telnet vào line đó.

### UNKNOWN / không confident

Kỳ vọng:

```text
SKIP/ERROR
```

Tool không tự override safety và không gõ vào console.

---

## 6. Cisco - Connection refused

Nếu reverse Telnet trả:

```text
% Connection refused by remote host
```

Trong **batch Quick A/B** kỳ vọng:

```text
SKIP/ERROR / TARGET_CONNECT_FAILED
```

Tool KHÔNG được mở workflow hỏi clear line, không tự `clear line`, không retry write action.
Controlled Clear-Line chỉ tồn tại ở manual workflow riêng.

---

## 7. Console im lặng

Chọn AVAILABLE port có console không tự in prompt.

Kỳ vọng:

```text
connect console
-> passive read
-> nếu hoàn toàn im lặng: gửi đúng 1 Enter
-> đọc lại
```

Không được spam nhiều Enter.

Nếu sau một Enter vẫn không thấy hostname:

```text
NO_HOSTNAME
```

---

## 8. Login prompt không có hostname

Các case:

```text
Username:
login:
Password:
```

Nếu trước đó không có hostname đáng tin cậy:

```text
NO_HOSTNAME
```

Tool không được gửi downstream username/password và không đoán Device B từ Device A.

---

## 9. Cisco - MISMATCH thật

Chọn port mà alias OOB cố tình/đã biết khác hostname thật.

Ví dụ:

```text
Device A : HCM-CDNGW-01
console  : [vrf:none] root@HCM-CDNGW-02:~#
```

Kỳ vọng:

```text
Device B : HCM-CDNGW-02
Status   : MISMATCH
```

Tool chỉ báo sai lệch, không tự đổi alias.

---

## 10. Vertiv ACS800/ACS8000 - Connection Test

Connection Test chỉ cần:

```text
TCP
-> SSH authentication
-> interactive shell
-> ACS CLI hoặc root shell -> cli
-> SUCCESS
```

Không được chạy `cd access` / `show` trong Connection Test.

---

## 11. Vertiv - Scan access table

Kỳ vọng:

```text
ACS CLI
-> cd access
-> show
```

Phải parse đủ Name / Port / Type / Status.

Ví dụ:

```text
idle   -> AVAILABLE
In-Use -> BUSY_UNKNOWN_USER (trừ khi active_sessions enrich được user)
```

Nếu `active_sessions` lỗi, port In-Use tuyệt đối không được biến thành AVAILABLE.

Tối ưu v1.1.34 cần kiểm tra:

- Nếu **tất cả port đều `idle`**: Scan chỉ cần `access/show`, **không** đi tiếp `active_sessions/show`.
- Nếu có ít nhất một port **`In-Use`**: Scan mới đọc `active_sessions` để enrich username; thất bại vẫn giữ BUSY.
- Quick A/B không cần `active_sessions`: thấy In-Use từ `access/show` là block ngay.

---

## 12. Vertiv - BEL/control-character regression

Thiết bị thật từng trả prompt dạng:

```text
--:- access cli-> \x07
```

Kỳ vọng:

- Không `VERTIV_CLI_PROMPT_TIMEOUT` chỉ vì BEL/C0 character.
- Không `VERTIV_CLI_COMMAND_TIMEOUT` khi access table đã trả đủ và prompt thực tế đã xuất hiện.
- Scan kết thúc bình thường và mapping đủ số port thực tế.

---

## 13. Vertiv Quick A/B - AVAILABLE

Kỳ vọng tối thiểu:

```text
SSH management
-> ACS CLI
-> access/show live verify
-> target Idle/AVAILABLE
-> connect <port_name>
-> banner/prompt hostname
-> stop
```

Không chạy lại `cd access` lần thứ hai sau runtime verify.
Không dùng DIRECT_SSH_PORT_NAME trong Quick A/B.
Không login downstream.

---

## 14. Vertiv - serial port password

Nếu sau `connect <port_name>` ACS yêu cầu port password:

```text
Password:
```

mà đó là ACS port-auth:

Kỳ vọng:

```text
SKIP/ERROR
VERTIV_PORT_AUTH_PASSWORD_REQUIRED
```

Batch không hỏi operator nhập thêm port password giữa chừng.

---

## 15. Vertiv - In-Use

Kỳ vọng:

```text
In-Use / BUSY_UNKNOWN_USER
-> SKIP/ERROR
```

Không `connect <port_name>`.
Không kill session.

---

## 16. Mapping thay đổi giữa scan và probe

Trong lúc Quick A/B đang chạy, nếu OOB/target mapping hoặc baseline revision thay đổi:

Kỳ vọng:

```text
CABLE_MAPPING_CHANGED_DURING_PROBE
```

Kết quả hostname vừa đọc phải bị loại bỏ thay vì so sánh với Device A cũ.

---

## 17. Batch nhiều port

Chạy trên một OOB có nhiều AVAILABLE target.

Kỳ vọng mỗi target chỉ trả một trong bốn trạng thái vận hành:

```text
MATCH
MISMATCH
NO_HOSTNAME
SKIP/ERROR
```

Không xuất thêm trạng thái full-identity gây khó hiểu trong màn hình Quick A/B.

Đồng thời kiểm tra:

- Số dòng `cable_verification.csv` phải bằng số mapping của fresh scan (trừ trường hợp operator hủy trước khi chạy).
- BUSY/UNKNOWN/INCOMPLETE vẫn phải xuất dòng `SKIP/ERROR`, không được biến mất.
- Thứ tự CSV phải giữ đúng thứ tự target/port của fresh scan, kể cả SKIP xen giữa MATCH.

Sau batch phải có summary rõ:

```text
Total
MATCH
MISMATCH
NO_HOSTNAME
SKIP/ERROR
```

---

## 18. CSV A/B

Kiểm tra CSV Quick Cable.

Thông tin trọng tâm cần có:

```text
detected_at
oob
vendor
port
device_a
device_b
status
evidence_source
console_path
error_code
message
```

Mismatch CSV phải ưu tiên:

```text
port, device_a, device_b, detected_at, oob, vendor, console_path, evidence_source
```

Không cần clear-line/full-identity columns trong CSV Quick A/B.

---

## 19. Regression chức năng an toàn

Xác nhận các chức năng sau vẫn giữ nguyên nhưng nằm ngoài Quick A/B:

- Manual console.
- Full Identity Discovery.
- Controlled Cisco Clear-Line có confirm + reason.
- Controlled Reconciliation có verify/backup/read-back/audit.
- Credential password RAM-only.
- Scan All cancellation an toàn.
- DB history/inventory hiện tại.

---

## 20. Tiêu chí PASS production UAT

Chỉ coi v1.1.34 đạt UAT khi ít nhất:

```text
Cisco:
[ ] 1 MATCH thật
[ ] 1 Linux/VRF prompt thật
[ ] 1 arbitrary reverse-Telnet port
[ ] 1 BUSY/UNKNOWN bị block
[ ] 1 silent/login-only case

Vertiv:
[ ] Connection Test không chạy inventory
[ ] Scan access table đủ port
[ ] 1 AVAILABLE quick A/B
[ ] 1 In-Use bị block
[ ] không tái hiện BEL/prompt timeout cũ

Cross-check:
[ ] Không downstream login trong Quick A/B
[ ] Không downstream show command trong Quick A/B
[ ] Không auto clear/kill/update alias
[ ] CSV A/B đúng Device A và Device B
```

Nếu một case fail, lưu `logs/`, `session_logs/`, thời điểm, OOB, port và error_code để sửa đúng phase; không tăng timeout/retry mù quáng.
