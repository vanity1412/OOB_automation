from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from oob_manager.utils.datetime_utils import utc_now


@dataclass(slots=True)
class ReconciliationPlan:
    target_id: int
    oob_id: int
    vendor: str
    old_alias: str
    new_alias: str
    physical_path: str
    proposed_commands: list[str] = field(default_factory=list)
    identity_run_id: int | None = None


@dataclass(slots=True)
class ReconciliationResult:
    success: bool
    old_alias: str
    new_alias: str
    verification_code: str = "UNVERIFIED"
    verification_message: str = ""
    applied_commands: list[str] = field(default_factory=list)
    rollback_attempted: bool = False
    rollback_succeeded: bool = False
    started_at: datetime = field(default_factory=utc_now)
    finished_at: datetime = field(default_factory=utc_now)
