from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from oob_manager.models.scan_result import RawCommandOutput


@dataclass(slots=True, repr=False)
class PortAuthenticationCredentials:
    """Optional ACS serial-port authentication credential held only in RAM.

    This is intentionally separate from the OOB management credential and the
    downstream device credential. ``use_oob_password`` must be an explicit
    operator choice; adapters never infer it from a generic ``Password:`` prompt.
    """

    password: str = ""
    use_oob_password: bool = False
    # Optional base credential for direct serial SSH.  These values are held only
    # in RAM and are useful when the account allowed to run ``access/show`` is
    # different from the operator account allowed to enter a serial target.
    direct_username: str = ""
    direct_password: str = ""
    use_oob_credentials_for_direct: bool = True
    # ``CLI_CONNECT``: management SSH -> cd access -> connect <port_name>.
    # ``DIRECT_SSH_PORT_NAME``: after a fresh management-session safety check,
    # open a second SSH session with username ``user:port_name`` as documented
    # by ACS800/8000. The direct path is explicit opt-in; it is never fallback.
    access_method: str = "CLI_CONNECT"

    def resolved_password(self, oob_password: str) -> str:
        return oob_password if self.use_oob_password else self.password

    def resolved_direct_username(self, oob_username: str) -> str:
        return oob_username if self.use_oob_credentials_for_direct else self.direct_username

    def resolved_direct_password(self, oob_password: str) -> str:
        return oob_password if self.use_oob_credentials_for_direct else self.direct_password

    def normalized_access_method(self) -> str:
        method = (self.access_method or "CLI_CONNECT").strip().upper()
        if method not in {"CLI_CONNECT", "DIRECT_SSH_PORT_NAME"}:
            return "INVALID"
        return method

    def __repr__(self) -> str:
        return (
            "PortAuthenticationCredentials(password='***ĐÃ_CHE***', "
            f"use_oob_password={self.use_oob_password!r}, "
            "direct_username='***ĐÃ_CHE***', direct_password='***ĐÃ_CHE***', "
            f"use_oob_credentials_for_direct={self.use_oob_credentials_for_direct!r}, "
            f"access_method={self.normalized_access_method()!r})"
        )


@dataclass(slots=True, repr=False)
class DownstreamCredentials:
    """Credential tạm thời của thiết bị phía sau OOB.

    Password chỉ tồn tại trong RAM và không được repository lưu xuống database.
    Username có thể để trống nếu console đã ở sẵn CLI prompt.
    """

    username: str = ""
    password: str = ""

    def __repr__(self) -> str:
        return (
            f"DownstreamCredentials(username={self.username!r}, "
            "password='***ĐÃ_CHE***')"
        )


@dataclass(slots=True)
class DeviceIdentity:
    actual_hostname: str = ""
    vendor: str = "UNKNOWN"
    platform_family: str = ""
    model: str = ""
    serial_number: str = ""
    software_version: str = ""
    quality: str = "REJECTED"
    confidence: str = "LOW"
    alias_comparison: str = "UNKNOWN"
    source_evidence: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class IdentityVerification:
    status: str = "INCONCLUSIVE"
    alias_comparison: str = "UNKNOWN"
    severity: str = "INFO"
    hardware_continuity: str = "UNKNOWN"
    previous_identity_run_id: int | None = None
    changed_fields: list[str] = field(default_factory=list)
    reason_codes: list[str] = field(default_factory=list)
    summary: str = ""
    identity_fingerprint: str = ""
    previous_identity_fingerprint: str = ""
    source: str = "LIVE_V1_1_6"
    events: list[dict[str, str]] = field(default_factory=list)


@dataclass(slots=True)
class DownstreamDiscoveryResult:
    identity: DeviceIdentity = field(default_factory=DeviceIdentity)
    verification: IdentityVerification = field(default_factory=IdentityVerification)
    raw_outputs: list[RawCommandOutput] = field(default_factory=list)
    login_method: str = "UNKNOWN"
    downstream_prompt: str = ""
    runtime_mapping_verified: bool = False
    runtime_mapping_verification_code: str = "UNVERIFIED"
    runtime_mapping_verification_message: str = ""
    live_state: str = "UNKNOWN"
    live_state_confident: bool = False
    live_state_reason_code: str = ""
    live_state_evidence: str = "{}"
    live_state_checked_at: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
