from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from oob_manager.utils.datetime_utils import utc_now


@dataclass(slots=True)
class ConsoleTarget:
    id: int | None = None
    oob_id: int = 0
    menu_name: str = ""
    menu_item: int | None = None
    alias: str = ""
    command: str = ""
    protocol: str = "UNKNOWN"
    target_host: str = ""
    target_port: int = 0
    console_line: int | None = None
    console_line_source: str = "UNRESOLVED"
    state: str = "UNKNOWN"
    session_user: str = ""
    state_confident: bool = False
    state_reason_code: str = ""
    state_evidence: str = "{}"
    source: str = "MENU_CONFIG"
    mapping_source_command: str = ""
    mapping_text_line: str = ""
    mapping_text_line_no: int | None = None
    mapping_command_line: str = ""
    mapping_command_line_no: int | None = None
    is_complete: bool = False
    first_seen_at: datetime = field(default_factory=utc_now)
    last_seen_at: datetime = field(default_factory=utc_now)
    last_scan_id: int = 0
