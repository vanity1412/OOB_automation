from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from oob_manager.models.console_target import ConsoleTarget
from oob_manager.utils.datetime_utils import utc_now


@dataclass(slots=True, repr=False)
class SessionCredentials:
    username: str
    password: str
    enable_password: str | None = None

    def __repr__(self) -> str:
        return (
            f"SessionCredentials(username={self.username!r}, password='***ĐÃ_CHE***', "
            f"enable_password={'***ĐÃ_CHE***' if self.enable_password else None!r})"
        )


@dataclass(slots=True)
class ConnectionTestResult:
    success: bool
    login_mode: str = "UNKNOWN"
    message: str = ""
    error_code: str = ""


@dataclass(slots=True)
class ConsoleOpenResult:
    """Kết quả phiên console kèm evidence ngay trước khi mở target thật.

    ``runtime_mapping_verified`` nói rằng mapping được kiểm tra lại trong chính
    phiên SSH đang dùng để mở console. ``live_state`` là observation mới nhất
    ngay trước reverse-Telnet/menu selection; nó không được dùng như trạng thái
    vĩnh viễn của inventory.
    """

    console_path_verified: bool = False
    path_verification_code: str = "UNVERIFIED"
    path_verification_message: str = ""
    runtime_menu_verified: bool = False
    runtime_mapping_verified: bool = False
    runtime_mapping_verification_code: str = "UNVERIFIED"
    runtime_mapping_verification_message: str = ""
    live_state: str = "UNKNOWN"
    live_state_confident: bool = False
    live_session_user: str = ""
    live_state_reason_code: str = ""
    live_state_evidence: str = "{}"
    live_state_checked_at: str = ""
    clear_line_recovery_requested: bool = False
    clear_line_recovery_used: bool = False
    clear_line_number: int | None = None
    clear_line_reason: str = ""
    clear_line_result: str = ""


@dataclass(slots=True)
class RawCommandOutput:
    command_name: str
    command_text: str
    raw_output: str
    success: bool
    error_message: str = ""
    is_core: bool = False
    redaction_applied: bool = False


@dataclass(slots=True)
class VendorScanData:
    connection_success: bool
    login_mode: str
    targets: list[ConsoleTarget] = field(default_factory=list)
    raw_outputs: list[RawCommandOutput] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    parser_errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ScanQualityResult:
    status: str
    mapping_quality: str = "REJECTED"
    mapping_accepted: bool = False
    warnings: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    complete_ratio: float = 0.0


@dataclass(slots=True)
class ScanResult:
    scan_id: int | None
    oob_id: int
    status: str
    mapping_count: int = 0
    warning_count: int = 0
    mapping_quality: str = "REJECTED"
    baseline_updated: bool = False
    error_code: str = ""
    error_message: str = ""
    started_at: datetime = field(default_factory=utc_now)
    finished_at: datetime | None = None
