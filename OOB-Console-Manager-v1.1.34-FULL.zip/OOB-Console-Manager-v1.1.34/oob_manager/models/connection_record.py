from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from oob_manager.utils.datetime_utils import utc_now

@dataclass(slots=True)
class ConnectionRecord:
    id: int | None = None
    oob_id: int = 0
    target_id: int | None = None
    username: str = ""
    started_at: datetime = field(default_factory=utc_now)
    ended_at: datetime | None = None
    status: str = "RUNNING"
    error_code: str = ""
    error_message: str = ""
