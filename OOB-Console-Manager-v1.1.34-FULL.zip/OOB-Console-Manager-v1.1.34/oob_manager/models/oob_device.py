from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from oob_manager.utils.datetime_utils import utc_now


@dataclass(slots=True)
class OOBDevice:
    id: int | None = None
    name: str = ""
    host: str = ""
    ssh_port: int = 22
    vendor: str = "CISCO"
    device_type: str = ""
    default_username: str = ""
    connection_mode: str = "SSH"
    enabled: bool = True
    notes: str = ""
    created_at: datetime = field(default_factory=utc_now)
    updated_at: datetime = field(default_factory=utc_now)
    last_scan_at: datetime | None = None
    connection_revision: int = 1
    baseline_revision: int = 1
    baseline_stale_reason: str = ""
    baseline_stale_at: datetime | None = None
    current_profile_fingerprint: str = ""
    baseline_profile_fingerprint: str = ""

    @property
    def mapping_stale(self) -> bool:
        """True khi mapping chưa được xác nhận với cả OOB config và vendor profile hiện tại."""
        connection_stale = self.baseline_revision != self.connection_revision
        profile_stale = bool(
            self.baseline_profile_fingerprint
            and self.current_profile_fingerprint != self.baseline_profile_fingerprint
        )
        return connection_stale or profile_stale
