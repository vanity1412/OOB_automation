from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from oob_manager.utils.datetime_utils import utc_now

@dataclass(slots=True)
class ChangeEvent:
    id: int | None = None
    oob_id: int = 0
    scan_id: int = 0
    event_code: str = ""
    target_identity: str = ""
    old_data: dict[str, Any] | None = None
    new_data: dict[str, Any] | None = None
    detected_at: datetime = field(default_factory=utc_now)
