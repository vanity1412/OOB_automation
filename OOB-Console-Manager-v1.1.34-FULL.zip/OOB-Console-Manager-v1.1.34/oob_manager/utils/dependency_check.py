from __future__ import annotations

import importlib.util
from importlib import metadata as importlib_metadata
import os
import sqlite3
import subprocess
import sys

from oob_manager.utils.paths import DB_PATH, PROJECT_ROOT, ensure_directories

REQUIRED_PACKAGES = {
    "paramiko": "3.5.1",
    "colorama": "0.4.6",
}


def dependency_issues() -> list[str]:
    """Return missing or wrong-version runtime dependencies.

    Presence-only checks are not enough for OOB UAT: an old ``.venv`` may still
    import Paramiko/Colorama while using a different major/minor version than the
    release was tested with.  Keep the deployment reproducible by enforcing the
    versions pinned in ``requirements.txt``.
    """

    issues: list[str] = []
    for module_name, expected_version in REQUIRED_PACKAGES.items():
        if importlib.util.find_spec(module_name) is None:
            issues.append(f"{module_name} (thiếu; cần {expected_version})")
            continue
        try:
            actual_version = importlib_metadata.version(module_name)
        except importlib_metadata.PackageNotFoundError:
            issues.append(f"{module_name} (không đọc được version; cần {expected_version})")
            continue
        if actual_version != expected_version:
            issues.append(
                f"{module_name}=={actual_version} (cần {module_name}=={expected_version})"
            )
    return issues


def missing_dependencies() -> list[str]:
    """Backward-compatible name; now also reports version mismatches."""

    return dependency_issues()


def ensure_dependencies(*, interactive: bool = True) -> bool:
    missing = missing_dependencies()
    if not missing:
        return True
    print("Runtime dependency đang thiếu hoặc sai phiên bản:\n")
    for name in missing:
        print(f"- {name}")
    if not interactive:
        return False
    print("\n1. Cài đặt tự động")
    print("0. Thoát")
    try:
        choice = input("Nhập lựa chọn: ").strip()
    except (EOFError, KeyboardInterrupt):
        return False
    if choice != "1":
        return False
    try:
        subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "-r",
                str(PROJECT_ROOT / "requirements.txt"),
            ],
            check=True,
        )
    except (subprocess.CalledProcessError, OSError):
        print("[LỖI] Cài thư viện thất bại.")
        return False
    if os.environ.get("OOB_MANAGER_RESTARTED") == "1":
        return not missing_dependencies()
    env = os.environ.copy()
    env["OOB_MANAGER_RESTARTED"] = "1"
    os.execve(sys.executable, [sys.executable, *sys.argv], env)
    return False


def _check_database_read_only() -> tuple[bool, str]:
    """Inspect an existing database without creating or migrating it."""

    if not DB_PATH.exists():
        return True, "Chưa có DB; sẽ tạo/migrate khi chạy ứng dụng"
    uri = f"file:{DB_PATH.resolve().as_posix()}?mode=ro"
    try:
        conn = sqlite3.connect(uri, uri=True, timeout=5)
        try:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            version = int(conn.execute("PRAGMA user_version").fetchone()[0])
        finally:
            conn.close()
    except sqlite3.Error as exc:
        return False, f"Không mở được DB read-only ({type(exc).__name__})"
    return integrity == "ok", f"schema={version}; integrity={integrity}; {DB_PATH}"


def run_environment_check(version: str) -> bool:
    ensure_directories()
    checks: list[tuple[str, bool, str]] = []
    checks.append(("Python >= 3.10", sys.version_info >= (3, 10), sys.version.split()[0]))
    missing = missing_dependencies()
    checks.append(
        ("Thư viện", not missing, "Đúng phiên bản" if not missing else "Thiếu/sai: " + ", ".join(missing))
    )
    try:
        from oob_manager.config import validate_all_profiles

        validate_all_profiles()
        checks.append(("Profiles", True, "Cisco và Vertiv hợp lệ"))
    except Exception as exc:
        checks.append(("Profiles", False, f"Lỗi {type(exc).__name__}"))
    database_ok, database_detail = _check_database_read_only()
    checks.append(("Cơ sở dữ liệu (read-only)", database_ok, database_detail))

    print(f"OOB Console Manager CLI {version}\n")
    for name, ok, detail in checks:
        print(f"[{'OK' if ok else 'LỖI'}] {name}: {detail}")
    return all(ok for _, ok, _ in checks)
