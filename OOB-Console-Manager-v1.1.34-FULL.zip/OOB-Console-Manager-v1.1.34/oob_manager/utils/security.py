from __future__ import annotations

import getpass
import re
from collections.abc import Mapping, Sequence
from typing import Any

from oob_manager.constants import SECRET_KEYS

REDACTED = "***ĐÃ_CHE***"
# Kept only so old databases/tests can recognize the historical marker. v1.1.20+
# no longer redacts audit usernames on write.
REDACTED_USERNAME = "***ĐÃ_CHE_USERNAME***"


def audit_username(value: object) -> str:
    """Return an audit-safe account identifier without hiding the identity.

    Usernames/operator identifiers are *audit data*, not credentials.  They are
    kept in internal SQLite history so an incident can answer who opened a
    console.  Passwords/tokens/secrets remain redacted by ``sanitize_text`` and
    ``sanitize_value``.
    """

    try:
        text = str(value or "").strip()
    except Exception:
        return ""
    # Keep rows bounded and single-line. Do not run the secret-pattern regex on
    # the identifier itself because a legitimate username could contain words
    # such as "token" or "secret".
    return text.replace("\r", " ").replace("\n", " ")[:256]


def redact_username(value: object) -> str:
    """Backward-compatible alias for old callers.

    Before v1.1.20 this function returned ``***ĐÃ_CHE_USERNAME***``.  The audit
    policy changed: usernames are now retained, while only credentials/secrets
    are redacted.
    """

    return audit_username(value)


def current_process_user() -> str:
    """Best-effort local OS account for audit metadata."""

    try:
        return audit_username(getpass.getuser())
    except Exception:
        return ""


def username_text_secret(value: object) -> str:
    """Deprecated compatibility helper.

    Usernames are no longer treated as secrets in v1.1.20+. Returning an empty
    value prevents legacy call-sites from removing account identifiers from
    audit/evidence text while those call-sites are migrated.
    """

    return ""


# Defense-in-depth for text that reaches logs/audit without an explicit list of
# runtime credentials. Explicit secret values are still replaced first by
# ``sanitize_text`` because a bare password cannot be recognized reliably.
_NAMED_SECRET_RE = re.compile(
    r"(?ix)\b("
    r"password|passwd|passphrase|secret|token|authorization|api[_-]?key|"
    r"enable[_-]?password|port[_-]?password|private[_-]?key"
    r")\b\s*([:=])\s*(?:\"[^\"\r\n]*\"|'[^'\r\n]*'|[^,;\s\]\}\)]+)"
)
_BEARER_RE = re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+")
_URL_CREDENTIAL_RE = re.compile(r"(?i)(\b(?:ssh|https?)://[^:/\s]+:)[^@/\s]+(@)")


def redact_secrets(data: Mapping[str, object]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in data.items():
        lower = str(key).casefold()
        if any(secret in lower for secret in SECRET_KEYS):
            result[str(key)] = REDACTED
        elif isinstance(value, Mapping):
            result[str(key)] = redact_secrets(value)
        elif isinstance(value, (list, tuple)):
            result[str(key)] = [sanitize_value(item) for item in value]
        else:
            result[str(key)] = value
    return result


def sanitize_text(value: object, secrets: Sequence[str] = ()) -> str:
    """Remove known runtime secrets and common credential notation.

    Account identifiers are intentionally *not* redacted. Secret replacement is
    deterministic and longest-first, preventing a short secret from partially
    masking a longer one. The function never raises while processing an error
    path.
    """

    try:
        cleaned = str(value or "")
    except Exception:
        return "[NỘI DUNG KHÔNG THỂ CHUYỂN THÀNH CHUỖI]"

    unique = sorted({str(secret) for secret in secrets if secret}, key=len, reverse=True)
    for secret in unique:
        cleaned = cleaned.replace(secret, REDACTED)
    cleaned = _NAMED_SECRET_RE.sub(lambda m: f"{m.group(1)}{m.group(2)}{REDACTED}", cleaned)
    cleaned = _BEARER_RE.sub(lambda m: f"{m.group(1)} {REDACTED}", cleaned)
    cleaned = _URL_CREDENTIAL_RE.sub(rf"\1{REDACTED}\2", cleaned)
    return cleaned


def sanitize_value(value: Any, secrets: Sequence[str] = ()) -> Any:
    """Recursively sanitize credential-bearing structures before persistence/export."""

    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key, item in value.items():
            key_text = str(key)
            if any(secret in key_text.casefold() for secret in SECRET_KEYS):
                result[key_text] = REDACTED
            else:
                result[key_text] = sanitize_value(item, secrets)
        return result
    if isinstance(value, list):
        return [sanitize_value(item, secrets) for item in value]
    if isinstance(value, tuple):
        return tuple(sanitize_value(item, secrets) for item in value)
    if isinstance(value, str):
        return sanitize_text(value, secrets)
    return value


def safe_exception_summary(exc: BaseException, secrets: Sequence[str] = ()) -> str:
    """Return a one-line technical summary without traceback/local variables."""

    return sanitize_text(
        f"{type(exc).__name__} code={getattr(exc, 'error_code', 'UNHANDLED_ERROR')} message={exc}",
        secrets,
    )
