from __future__ import annotations
from datetime import datetime, timezone

def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)

def to_db(value: datetime | None) -> str | None:
    return value.isoformat() if value else None

def from_db(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None

def format_local(value: datetime | str | None) -> str:
    if not value:
        return "Chưa có"
    dt = datetime.fromisoformat(value) if isinstance(value, str) else value
    return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")
