from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
LOG_DIR = PROJECT_ROOT / "logs"
SESSION_LOG_DIR = PROJECT_ROOT / "session_logs"
BACKUP_DIR = PROJECT_ROOT / "backups"
EXPORT_DIR = PROJECT_ROOT / "exports"
PROFILE_DIR = PROJECT_ROOT / "profiles"
DB_PATH = DATA_DIR / "oob_manager.db"
SSH_KNOWN_HOSTS_PATH = DATA_DIR / "ssh_known_hosts"

def ensure_directories() -> None:
    for path in (DATA_DIR, LOG_DIR, SESSION_LOG_DIR, BACKUP_DIR, EXPORT_DIR, PROFILE_DIR):
        path.mkdir(parents=True, exist_ok=True)
