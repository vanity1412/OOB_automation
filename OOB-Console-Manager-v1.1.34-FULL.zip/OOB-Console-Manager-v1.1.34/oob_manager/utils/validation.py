from __future__ import annotations
import ipaddress
import re
from oob_manager.exceptions import ValidationError

HOST_LABEL = re.compile(r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)$")
DANGEROUS_COMMAND_PARTS = (";", "&&", "||", "|", ">", "<", "`", "$(", "\x00", "\r", "\n")

def is_valid_host(value: str) -> bool:
    value = value.strip()
    if not value or len(value) > 253:
        return False
    try:
        ipaddress.ip_address(value.strip("[]"))
        return True
    except ValueError:
        pass
    if value.endswith("."):
        value = value[:-1]
    return all(HOST_LABEL.fullmatch(label) for label in value.split("."))

def normalize_host(value: str) -> str:
    """Chuẩn hóa host để cùng một endpoint không có nhiều cách ghi khác nhau.

    - IPv4/IPv6 được canonicalize bằng :mod:`ipaddress`; dấu ``[]`` quanh IPv6
      chỉ là ký pháp URL và không được lưu vì ``socket``/Cisco CLI nhận địa chỉ
      không có ngoặc.
    - DNS hostname bỏ dấu chấm cuối và chuyển lowercase vì DNS không phân biệt hoa
      thường.

    Hàm này chỉ chuẩn hóa cú pháp; caller vẫn phải dùng :func:`is_valid_host` để
    xác nhận input trước khi tin dùng.
    """
    value = value.strip()
    bare = value.strip("[]")
    try:
        return ipaddress.ip_address(bare).compressed
    except ValueError:
        pass
    if value.endswith("."):
        value = value[:-1]
    return value.casefold()


def validate_host(value: str) -> str:
    value = value.strip()
    if not is_valid_host(value):
        raise ValidationError("IP hoặc hostname không hợp lệ.")
    return normalize_host(value)

def validate_port(value: int | str) -> int:
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError("Cổng phải là số.") from exc
    if not 1 <= port <= 65535:
        raise ValidationError("Cổng phải nằm trong khoảng 1 đến 65535.")
    return port

def validate_nonempty(value: str, field_name: str) -> str:
    value = value.strip()
    if not value:
        raise ValidationError(f"{field_name} không được để trống.")
    return value

def contains_dangerous_control(value: str) -> bool:
    return any(part in value for part in DANGEROUS_COMMAND_PARTS)

def normalize_alias(value: str) -> str:
    return " ".join(value.strip().split()).casefold()
