from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from oob_manager.utils.paths import LOG_DIR, ensure_directories
from oob_manager.utils.security import sanitize_text


class SecretRedactionFilter(logging.Filter):
    """Sanitize every log message and deliberately suppress raw tracebacks.

    Python tracebacks may contain exception messages, command buffers or local
    values that include credentials.  Production logs therefore record only the
    exception type/error code supplied by the caller.  Services that know the
    runtime credentials may log an explicitly sanitized traceback as plain text
    in debug mode.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "operation"):
            record.operation = "general"
        try:
            message = sanitize_text(record.getMessage())
            if record.exc_info:
                exc = record.exc_info[1]
                message += (
                    f" exception_type={type(exc).__name__}"
                    f" code={getattr(exc, 'error_code', 'UNHANDLED_ERROR')}"
                )
            record.msg = message
            record.args = ()
            record.exc_info = None
            record.exc_text = None
            record.stack_info = None
        except Exception:
            record.msg = "[NỘI DUNG LOG ĐÃ ĐƯỢC CHE DO LỖI REDACTION]"
            record.args = ()
            record.exc_info = None
            record.exc_text = None
            record.stack_info = None
        return True


def configure_logging(*, debug: bool = False) -> None:
    ensure_directories()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s operation=%(operation)s %(message)s"
    )
    normal = RotatingFileHandler(
        LOG_DIR / "oob_manager.log",
        maxBytes=2_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    normal.setLevel(logging.INFO)
    normal.setFormatter(fmt)
    normal.addFilter(SecretRedactionFilter())
    logger.addHandler(normal)
    if debug:
        debug_handler = RotatingFileHandler(
            LOG_DIR / "oob_manager_debug.log",
            maxBytes=5_000_000,
            backupCount=3,
            encoding="utf-8",
        )
        debug_handler.setLevel(logging.DEBUG)
        debug_handler.setFormatter(fmt)
        debug_handler.addFilter(SecretRedactionFilter())
        logger.addHandler(debug_handler)


class LogContext(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        extra = kwargs.setdefault("extra", {})
        extra.setdefault("operation", self.extra.get("operation", "general"))
        return msg, kwargs


def get_logger(name: str, operation: str = "general") -> LogContext:
    return LogContext(logging.getLogger(name), {"operation": operation})
