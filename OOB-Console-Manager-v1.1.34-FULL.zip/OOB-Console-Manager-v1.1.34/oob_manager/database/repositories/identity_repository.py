from __future__ import annotations

import errno
import hashlib
import json
import os
import socket
import sqlite3

from oob_manager import __version__
from oob_manager.database.connection import DatabaseConnection
from oob_manager.models import ConsoleTarget, DeviceIdentity, DownstreamDiscoveryResult, OOBDevice, RawCommandOutput
from oob_manager.downstream.verification import verify_identity
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import current_process_user, redact_username, sanitize_text


class DeviceIdentityRepository:
    """Audit + current identity cho downstream discovery.

    Raw outputs chỉ là whitelist identity commands, không chứa password do collector
    không persist login transcript. Current identity chỉ cập nhật khi quality=ACCEPTED;
    PARTIAL/REJECTED vẫn được giữ trong run/snapshot để điều tra.
    """

    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def start(
        self,
        device: OOBDevice,
        target: ConsoleTarget,
        oob_username: str,
        downstream_username: str,
    ) -> int:
        with self.db.transaction() as conn:
            cursor = conn.execute(
                """
                INSERT INTO device_identity_runs(
                    oob_id,target_id,mapping_scan_id,collector_version,
                    oob_name_at_run,oob_host_at_run,oob_ssh_port_at_run,oob_vendor_at_run,
                    oob_connection_mode_at_run,oob_connection_revision_at_run,oob_baseline_revision_at_run,
                    target_alias_at_run,target_command_at_run,target_protocol_at_run,target_host_at_run,
                    target_port_at_run,menu_name_at_run,menu_item_at_run,console_line_at_run,
                    oob_username,downstream_username,started_at,status,
                    process_pid,process_hostname,process_user
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    device.id,
                    target.id,
                    target.last_scan_id,
                    __version__,
                    device.name,
                    device.host,
                    device.ssh_port,
                    device.vendor,
                    device.connection_mode,
                    device.connection_revision,
                    device.baseline_revision,
                    target.alias,
                    target.command,
                    target.protocol,
                    target.target_host,
                    target.target_port,
                    target.menu_name,
                    target.menu_item,
                    target.console_line,
                    redact_username(oob_username),
                    redact_username(downstream_username),
                    to_db(utc_now()),
                    "RUNNING",
                    os.getpid(),
                    socket.gethostname(),
                    current_process_user(),
                ),
            )
            return int(cursor.lastrowid)

    def update_ssh_host_key(self, run_id: int, algorithm: str, fingerprint: str, policy: str) -> None:
        if not (algorithm or fingerprint or policy):
            return
        with self.db.transaction() as conn:
            cursor = conn.execute(
                """
                UPDATE device_identity_runs
                SET oob_ssh_host_key_algorithm=?,oob_ssh_host_key_fingerprint=?,oob_ssh_host_key_policy=?
                WHERE id=?
                """,
                (algorithm, fingerprint, policy, run_id),
            )
            if cursor.rowcount != 1:
                raise sqlite3.IntegrityError("device_identity_runs row not found for SSH audit")

    @staticmethod
    def _insert_raw_outputs(conn: sqlite3.Connection, run_id: int, outputs: list[RawCommandOutput]) -> None:
        now = to_db(utc_now())
        for item in outputs:
            raw = sanitize_text(item.raw_output)
            conn.execute(
                """
                INSERT INTO device_identity_raw_outputs(
                    identity_run_id,command_name,command_text,raw_output,success,error_message,
                    stored_output_sha256,stored_output_length,created_at
                ) VALUES(?,?,?,?,?,?,?,?,?)
                """,
                (
                    run_id,
                    sanitize_text(item.command_name),
                    sanitize_text(item.command_text),
                    raw,
                    int(item.success),
                    sanitize_text(item.error_message),
                    hashlib.sha256(raw.encode("utf-8")).hexdigest(),
                    len(raw),
                    now,
                ),
            )

    @staticmethod
    def _identity_values(identity: DeviceIdentity) -> tuple[object, ...]:
        return (
            identity.actual_hostname,
            identity.vendor,
            identity.platform_family,
            identity.model,
            identity.serial_number,
            identity.software_version,
            identity.quality,
            identity.confidence,
            identity.alias_comparison,
            json.dumps(identity.source_evidence, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        )

    def finish(
        self,
        run_id: int,
        target: ConsoleTarget,
        result: DownstreamDiscoveryResult,
    ) -> None:
        identity = result.identity
        status = "SUCCESS" if identity.quality == "ACCEPTED" else "PARTIAL"
        source_json = json.dumps(
            identity.source_evidence,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        with self.db.transaction() as conn:
            # Read the previous accepted identity inside the same IMMEDIATE
            # transaction that will commit the new one. This avoids two concurrent
            # discovery runs both comparing against an already stale snapshot.
            previous = conn.execute(
                "SELECT * FROM device_identities WHERE target_id=?",
                (target.id,),
            ).fetchone()
            if previous is None:
                # Mapping updates intentionally invalidate current identity. Keep
                # hardware continuity auditable by falling back to the latest
                # historical ACCEPTED run for the same preserved target_id. A full
                # baseline reset creates new target IDs, so identities from a different
                # OOB generation are not silently compared.
                previous = conn.execute(
                    """
                    SELECT id AS last_identity_run_id, target_alias_at_run AS configured_alias,
                           actual_hostname, detected_vendor AS vendor, model, serial_number,
                           software_version, alias_comparison, identity_fingerprint
                    FROM device_identity_runs
                    WHERE target_id=? AND id<>? AND status='SUCCESS' AND identity_quality='ACCEPTED'
                    ORDER BY id DESC LIMIT 1
                    """,
                    (target.id, run_id),
                ).fetchone()
            verification = verify_identity(target.alias, identity, previous)
            identity.alias_comparison = verification.alias_comparison
            result.verification = verification
            changed_fields = ",".join(verification.changed_fields)
            reason_codes_json = json.dumps(
                verification.reason_codes,
                ensure_ascii=False,
                sort_keys=False,
                separators=(",", ":"),
            )

            self._insert_raw_outputs(conn, run_id, result.raw_outputs)
            conn.execute(
                """
                UPDATE device_identity_runs
                SET finished_at=?,status=?,login_method=?,downstream_prompt=?,detected_vendor=?,
                    identity_quality=?,identity_confidence=?,actual_hostname=?,platform_family=?,
                    model=?,serial_number=?,software_version=?,alias_comparison=?,source_evidence_json=?,
                    verification_status=?,verification_severity=?,hardware_continuity=?,
                    previous_identity_run_id=?,changed_fields=?,verification_reason_codes=?,
                    verification_summary=?,identity_fingerprint=?,previous_identity_fingerprint=?,
                    verification_source=?,
                    runtime_mapping_verified=?,runtime_mapping_verification_code=?,
                    runtime_mapping_verification_message=?,live_state=?,live_state_confident=?,
                    live_state_reason_code=?,live_state_evidence=?,live_state_checked_at=?,
                    oob_ssh_host_key_algorithm=COALESCE(NULLIF(?,''),oob_ssh_host_key_algorithm),
                    oob_ssh_host_key_fingerprint=COALESCE(NULLIF(?,''),oob_ssh_host_key_fingerprint),
                    oob_ssh_host_key_policy=COALESCE(NULLIF(?,''),oob_ssh_host_key_policy)
                WHERE id=?
                """,
                (
                    to_db(utc_now()), status, result.login_method, result.downstream_prompt,
                    identity.vendor, identity.quality, identity.confidence,
                    identity.actual_hostname, identity.platform_family, identity.model,
                    identity.serial_number, identity.software_version, identity.alias_comparison,
                    source_json, verification.status, verification.severity,
                    verification.hardware_continuity, verification.previous_identity_run_id,
                    changed_fields, reason_codes_json, verification.summary,
                    verification.identity_fingerprint, verification.previous_identity_fingerprint,
                    verification.source, int(result.runtime_mapping_verified),
                    result.runtime_mapping_verification_code,
                    result.runtime_mapping_verification_message, result.live_state,
                    int(result.live_state_confident), result.live_state_reason_code,
                    result.live_state_evidence, result.live_state_checked_at or None,
                    str(result.metadata.get("oob_ssh_host_key_algorithm", "")),
                    str(result.metadata.get("oob_ssh_host_key_fingerprint", "")),
                    str(result.metadata.get("oob_ssh_host_key_policy", "")),
                    run_id,
                ),
            )
            captured_at = to_db(utc_now())
            conn.execute(
                """
                INSERT INTO device_identity_snapshots(
                    identity_run_id,target_id,oob_id,configured_alias,actual_hostname,vendor,
                    platform_family,model,serial_number,software_version,identity_quality,
                    identity_confidence,alias_comparison,source_evidence_json,
                    verification_status,verification_severity,hardware_continuity,
                    previous_identity_run_id,changed_fields,verification_reason_codes,
                    verification_summary,identity_fingerprint,previous_identity_fingerprint,
                    verification_source,captured_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    run_id,target.id,target.oob_id,target.alias,identity.actual_hostname,
                    identity.vendor,identity.platform_family,identity.model,identity.serial_number,
                    identity.software_version,identity.quality,identity.confidence,
                    identity.alias_comparison,source_json,verification.status,
                    verification.severity,verification.hardware_continuity,
                    verification.previous_identity_run_id,changed_fields,reason_codes_json,
                    verification.summary,verification.identity_fingerprint,
                    verification.previous_identity_fingerprint,verification.source,captured_at,
                ),
            )
            if identity.quality == "ACCEPTED":
                conn.execute(
                    """
                    INSERT INTO device_identities(
                        target_id,oob_id,configured_alias,actual_hostname,vendor,platform_family,
                        model,serial_number,software_version,identity_quality,identity_confidence,
                        alias_comparison,source_evidence_json,verification_status,
                        verification_severity,hardware_continuity,previous_identity_run_id,
                        changed_fields,verification_reason_codes,verification_summary,
                        identity_fingerprint,verification_source,last_identity_run_id,verified_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(target_id) DO UPDATE SET
                        oob_id=excluded.oob_id,configured_alias=excluded.configured_alias,
                        actual_hostname=excluded.actual_hostname,vendor=excluded.vendor,
                        platform_family=excluded.platform_family,model=excluded.model,
                        serial_number=excluded.serial_number,software_version=excluded.software_version,
                        identity_quality=excluded.identity_quality,identity_confidence=excluded.identity_confidence,
                        alias_comparison=excluded.alias_comparison,source_evidence_json=excluded.source_evidence_json,
                        verification_status=excluded.verification_status,
                        verification_severity=excluded.verification_severity,
                        hardware_continuity=excluded.hardware_continuity,
                        previous_identity_run_id=excluded.previous_identity_run_id,
                        changed_fields=excluded.changed_fields,
                        verification_reason_codes=excluded.verification_reason_codes,
                        verification_summary=excluded.verification_summary,
                        identity_fingerprint=excluded.identity_fingerprint,
                        verification_source=excluded.verification_source,
                        last_identity_run_id=excluded.last_identity_run_id,verified_at=excluded.verified_at
                    """,
                    (
                        target.id,target.oob_id,target.alias,identity.actual_hostname,identity.vendor,
                        identity.platform_family,identity.model,identity.serial_number,
                        identity.software_version,identity.quality,identity.confidence,
                        identity.alias_comparison,source_json,verification.status,
                        verification.severity,verification.hardware_continuity,
                        verification.previous_identity_run_id,changed_fields,reason_codes_json,
                        verification.summary,verification.identity_fingerprint,verification.source,
                        run_id,captured_at,
                    ),
                )

                evidence_json = json.dumps(
                    {
                        "configured_alias": target.alias,
                        "actual_hostname": identity.actual_hostname,
                        "vendor": identity.vendor,
                        "model": identity.model,
                        "serial_number": identity.serial_number,
                        "software_version": identity.software_version,
                        "identity_fingerprint": verification.identity_fingerprint,
                        "previous_identity_fingerprint": verification.previous_identity_fingerprint,
                        "verification_status": verification.status,
                        "hardware_continuity": verification.hardware_continuity,
                        "reason_codes": verification.reason_codes,
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                for event in verification.events:
                    conn.execute(
                        """
                        INSERT INTO device_identity_events(
                            identity_run_id,target_id,oob_id,event_code,severity,field_name,
                            old_value,new_value,reason,evidence_json,detected_at
                        ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                        """,
                        (
                            run_id,target.id,target.oob_id,event["event_code"],event["severity"],
                            event["field_name"],event["old_value"],event["new_value"],
                            event["reason"],evidence_json,captured_at,
                        ),
                    )

    def finish_failed(
        self,
        run_id: int,
        error_code: str,
        error_message: str,
        *,
        raw_outputs: list[RawCommandOutput] | None = None,
        identity: DeviceIdentity | None = None,
        runtime_mapping_verified: bool = False,
        runtime_mapping_code: str = "UNVERIFIED",
        runtime_mapping_message: str = "",
        live_state: str = "UNKNOWN",
        live_state_confident: bool = False,
        live_state_reason_code: str = "",
        live_state_evidence: str = "{}",
        live_state_checked_at: str = "",
        login_method: str = "UNKNOWN",
        downstream_prompt: str = "",
    ) -> None:
        identity = identity or DeviceIdentity()
        source_json = json.dumps(identity.source_evidence, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        with self.db.transaction() as conn:
            self._insert_raw_outputs(conn, run_id, raw_outputs or [])
            conn.execute(
                """
                UPDATE device_identity_runs
                SET finished_at=?,status='FAILED',error_code=?,error_message=?,
                    login_method=?,downstream_prompt=?,detected_vendor=?,
                    identity_quality=?,identity_confidence=?,actual_hostname=?,platform_family=?,
                    model=?,serial_number=?,software_version=?,alias_comparison=?,source_evidence_json=?,
                    runtime_mapping_verified=?,runtime_mapping_verification_code=?,
                    runtime_mapping_verification_message=?,live_state=?,live_state_confident=?,
                    live_state_reason_code=?,live_state_evidence=?,live_state_checked_at=?
                WHERE id=?
                """,
                (
                    to_db(utc_now()),error_code,error_message,login_method,downstream_prompt,
                    identity.vendor,identity.quality,identity.confidence,identity.actual_hostname,
                    identity.platform_family,identity.model,
                    identity.serial_number,identity.software_version,identity.alias_comparison,source_json,
                    int(runtime_mapping_verified),runtime_mapping_code,runtime_mapping_message,
                    live_state,int(live_state_confident),live_state_reason_code,live_state_evidence,
                    live_state_checked_at or None,run_id,
                ),
            )

    def get_current_for_target(self, target_id: int) -> sqlite3.Row | None:
        with self.db.read() as conn:
            return conn.execute(
                "SELECT * FROM v_current_device_identity WHERE target_id=?", (target_id,)
            ).fetchone()

    def list_current(self, limit: int = 500) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                "SELECT * FROM v_current_device_identity ORDER BY oob_name COLLATE NOCASE, configured_alias COLLATE NOCASE LIMIT ?",
                (limit,),
            ).fetchall()

    def list_recent_runs(self, limit: int = 100) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                "SELECT * FROM v_device_identity_trace ORDER BY identity_run_id DESC LIMIT ?",
                (limit,),
            ).fetchall()

    def list_recent_events(self, limit: int = 200) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                "SELECT * FROM v_device_identity_events ORDER BY identity_event_id DESC LIMIT ?",
                (limit,),
            ).fetchall()

    def count_unviewed_critical_events(self) -> int:
        """Count new hardware-identity anomalies worth surfacing at Main Menu."""
        with self.db.read() as conn:
            row = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM device_identity_events
                WHERE viewed_at IS NULL
                  AND event_code IN ('SERIAL_CHANGED','DEVICE_REPLACED_SUSPECTED')
                """
            ).fetchone()
            return int(row["count"] if row else 0)

    def mark_events_viewed(self, event_ids: list[int]) -> None:
        ids = sorted({int(value) for value in event_ids if int(value) > 0})
        if not ids:
            return
        placeholders = ",".join("?" for _ in ids)
        with self.db.transaction() as conn:
            conn.execute(
                f"UPDATE device_identity_events SET viewed_at=COALESCE(viewed_at, ?) "
                f"WHERE id IN ({placeholders})",
                (to_db(utc_now()), *ids),
            )

    def recover_abandoned_same_host(self) -> int:
        hostname = socket.gethostname()
        recovered = 0
        with self.db.transaction() as conn:
            rows = conn.execute(
                "SELECT id,process_pid FROM device_identity_runs WHERE status='RUNNING' AND process_hostname=?",
                (hostname,),
            ).fetchall()
            for row in rows:
                pid = int(row["process_pid"] or 0)
                if not self._pid_alive(pid):
                    conn.execute(
                        """
                        UPDATE device_identity_runs
                        SET finished_at=?,status='ABANDONED',error_code='PROCESS_TERMINATED',
                            error_message='Discovery trước kết thúc bất thường; được đánh dấu khi ứng dụng khởi động lại.'
                        WHERE id=?
                        """,
                        (to_db(utc_now()),row["id"]),
                    )
                    recovered += 1
        return recovered

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError as exc:
            if exc.errno == errno.ESRCH:
                return False
            if exc.errno == errno.EPERM:
                return True
            return False
