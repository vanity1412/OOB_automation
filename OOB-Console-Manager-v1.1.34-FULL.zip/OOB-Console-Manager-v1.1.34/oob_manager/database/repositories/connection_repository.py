"""Repository lưu metadata phiên console, không lưu nội dung phiên."""
from __future__ import annotations

import errno
import os
import socket
import sqlite3

from oob_manager.database.connection import DatabaseConnection
from oob_manager.models.console_target import ConsoleTarget
from oob_manager.models.oob_device import OOBDevice
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import current_process_user, redact_username, sanitize_text


class ConnectionRepository:
    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def start(
        self,
        oob_id: int,
        target: ConsoleTarget | None,
        username: str,
        *,
        device: OOBDevice | None = None,
        safety_override_requested: bool = False,
        safety_override_reason: str = "",
    ) -> int:
        with self.db.transaction() as conn:
            if device is None:
                row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (oob_id,)).fetchone()
                if row:
                    device = OOBDevice(
                        id=row["id"],
                        name=row["name"],
                        host=row["host"],
                        ssh_port=row["ssh_port"],
                        vendor=row["vendor"],
                        device_type=row["device_type"],
                        connection_mode=row["connection_mode"],
                        connection_revision=row["connection_revision"],
                        baseline_revision=row["baseline_revision"],
                    )
            cursor = conn.execute(
                """
                INSERT INTO connection_history(
                    oob_id, target_id, target_alias, target_host, target_port,
                    menu_name, menu_item, target_command, console_line,
                    mapping_last_scan_id, username, started_at, status,
                    oob_name_at_connection, oob_host_at_connection,
                    oob_ssh_port_at_connection, vendor_at_connection,
                    connection_mode_at_connection, connection_revision,
                    baseline_revision, config_snapshot_source,
                    console_path_verified, path_verification_code, path_verification_message,
                    runtime_menu_verified, process_pid, process_hostname, process_user,
                    safety_override_requested, safety_override_reason
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    oob_id,
                    target.id if target else None,
                    target.alias if target else "",
                    target.target_host if target else "",
                    target.target_port if target else 0,
                    target.menu_name if target else "",
                    target.menu_item if target else None,
                    target.command if target else "",
                    target.console_line if target else None,
                    target.last_scan_id if target else None,
                    redact_username(username),
                    to_db(utc_now()),
                    "RUNNING",
                    device.name if device else "",
                    device.host if device else "",
                    device.ssh_port if device else 0,
                    device.vendor if device else "",
                    device.connection_mode if device else "",
                    device.connection_revision if device else 1,
                    device.baseline_revision if device else 1,
                    "LIVE_CAPTURE" if device else "MISSING_OOB_SNAPSHOT",
                    0,
                    "UNVERIFIED",
                    "",
                    0,
                    os.getpid(),
                    socket.gethostname(),
                    current_process_user(),
                    int(bool(safety_override_requested)),
                    sanitize_text(safety_override_reason),
                ),
            )
            return int(cursor.lastrowid)

    def set_session_log_path(self, connection_id: int, path: str) -> None:
        with self.db.transaction() as conn:
            cursor = conn.execute(
                "UPDATE connection_history SET session_log_path=? WHERE id=?",
                (sanitize_text(path), connection_id),
            )
            if cursor.rowcount != 1:
                raise sqlite3.IntegrityError("connection_history row not found for session log audit")


    def update_ssh_host_key(
        self,
        connection_id: int,
        algorithm: str,
        fingerprint: str,
        policy: str,
    ) -> None:
        """Persist SSH server identity as soon as transport authentication completes.

        This intentionally happens before the interactive bridge so an abrupt process
        termination still leaves evidence of which OOB SSH host key was reached.
        """
        if not (algorithm or fingerprint or policy):
            return
        with self.db.transaction() as conn:
            cursor = conn.execute(
                """UPDATE connection_history
                   SET ssh_host_key_algorithm=?, ssh_host_key_fingerprint=?, ssh_host_key_policy=?
                   WHERE id=?""",
                (algorithm, fingerprint, policy, connection_id),
            )
            if cursor.rowcount != 1:
                raise sqlite3.IntegrityError("connection_history row not found for SSH audit")

    def finish(
        self,
        connection_id: int,
        status: str,
        error_code: str = "",
        error_message: str = "",
        *,
        console_path_verified: bool = False,
        path_verification_code: str = "UNVERIFIED",
        path_verification_message: str = "",
        runtime_menu_verified: bool = False,
        runtime_mapping_verified: bool = False,
        runtime_mapping_verification_code: str = "UNVERIFIED",
        runtime_mapping_verification_message: str = "",
        live_state: str = "UNKNOWN",
        live_state_confident: bool = False,
        live_session_user: str = "",
        live_state_reason_code: str = "",
        live_state_evidence: str = "{}",
        live_state_checked_at: str = "",
        ssh_host_key_algorithm: str = "",
        ssh_host_key_fingerprint: str = "",
        ssh_host_key_policy: str = "",
        safety_override_used: bool = False,
        clear_line_recovery_requested: bool = False,
        clear_line_recovery_used: bool = False,
        clear_line_number: int | None = None,
        clear_line_reason: str = "",
        clear_line_result: str = "",
    ) -> None:
        with self.db.transaction() as conn:
            conn.execute(
                """
                UPDATE connection_history
                SET ended_at=?, status=?, error_code=?, error_message=?,
                    console_path_verified=?, path_verification_code=?, path_verification_message=?,
                    runtime_menu_verified=?,
                    runtime_mapping_verified=?,
                    runtime_mapping_verification_code=?,
                    runtime_mapping_verification_message=?,
                    live_state=?, live_state_confident=?, live_session_user=?,
                    live_state_reason_code=?, live_state_evidence=?,
                    live_state_checked_at=COALESCE(NULLIF(?,''), live_state_checked_at),
                    ssh_host_key_algorithm=COALESCE(NULLIF(?,''), ssh_host_key_algorithm),
                    ssh_host_key_fingerprint=COALESCE(NULLIF(?,''), ssh_host_key_fingerprint),
                    ssh_host_key_policy=COALESCE(NULLIF(?,''), ssh_host_key_policy),
                    safety_override_used=?,
                    clear_line_recovery_requested=?,
                    clear_line_recovery_used=?,
                    clear_line_number=?,
                    clear_line_reason=?,
                    clear_line_result=?
                WHERE id=?
                """,
                (
                    to_db(utc_now()),
                    status,
                    sanitize_text(error_code),
                    sanitize_text(error_message),
                    int(console_path_verified),
                    path_verification_code,
                    sanitize_text(path_verification_message),
                    int(runtime_menu_verified),
                    int(runtime_mapping_verified),
                    runtime_mapping_verification_code,
                    sanitize_text(runtime_mapping_verification_message),
                    live_state,
                    int(live_state_confident),
                    redact_username(live_session_user),
                    live_state_reason_code,
                    sanitize_text(live_state_evidence),
                    live_state_checked_at,
                    ssh_host_key_algorithm,
                    ssh_host_key_fingerprint,
                    ssh_host_key_policy,
                    int(bool(safety_override_used)),
                    int(bool(clear_line_recovery_requested)),
                    int(bool(clear_line_recovery_used)),
                    clear_line_number,
                    sanitize_text(clear_line_reason),
                    sanitize_text(clear_line_result),
                    connection_id,
                ),
            )

    def recover_abandoned_same_host(self) -> int:
        """Đóng các row RUNNING của process cũ trên chính máy hiện tại."""
        hostname = socket.gethostname()
        recovered = 0
        with self.db.transaction() as conn:
            rows = conn.execute(
                """
                SELECT id, process_pid FROM connection_history
                WHERE status='RUNNING' AND process_hostname=?
                """,
                (hostname,),
            ).fetchall()
            for row in rows:
                pid = int(row["process_pid"] or 0)
                if not self._pid_alive(pid):
                    conn.execute(
                        """
                        UPDATE connection_history
                        SET ended_at=?, status='ABANDONED',
                            error_code='PROCESS_TERMINATED',
                            error_message='Phiên trước kết thúc bất thường; được đánh dấu khi ứng dụng khởi động lại.'
                        WHERE id=?
                        """,
                        (to_db(utc_now()), row["id"]),
                    )
                    recovered += 1
        return recovered

    def list_recent(self, limit: int = 100) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                """
                SELECT h.*,
                       COALESCE(NULLIF(h.oob_name_at_connection,''), o.name) AS oob_name,
                       COALESCE(NULLIF(h.target_alias, ''), t.alias) AS target_alias_display
                FROM connection_history h
                JOIN oob_devices o ON o.id=h.oob_id
                LEFT JOIN console_targets t ON t.id=h.target_id
                ORDER BY h.id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError as exc:
            if exc.errno == errno.ESRCH:
                return False
            if exc.errno == errno.EPERM:
                return True
            return False
