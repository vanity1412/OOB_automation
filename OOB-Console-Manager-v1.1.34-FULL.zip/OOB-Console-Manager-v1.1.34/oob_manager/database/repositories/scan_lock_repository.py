"""Leased per-OOB operation lock for scan, console and identity workflows."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import timedelta
import errno
import os
import socket
import threading
from collections.abc import Iterator

from oob_manager.database.connection import DatabaseConnection
from oob_manager.exceptions import ScanLockError
from oob_manager.utils.datetime_utils import from_db, to_db, utc_now


class OperationLease:
    """Explicit lease handle for services whose existing control flow is not a with-block."""

    def __init__(self, repo: "ScanLockRepository", oob_id: int, operation: str) -> None:
        self.repo = repo
        self.oob_id = oob_id
        self.operation = operation.strip().upper()
        self.stop = threading.Event()
        self.errors: list[BaseException] = []
        self.closed = False
        repo.acquire(oob_id, self.operation)

        def worker() -> None:
            while not self.stop.wait(repo.heartbeat_seconds):
                try:
                    if not repo.heartbeat(oob_id, self.operation):
                        self.errors.append(RuntimeError("Operation lock ownership lost"))
                        return
                except BaseException as exc:
                    self.errors.append(exc)
                    return

        self.thread = threading.Thread(
            target=worker,
            name=f"oob-lock-{oob_id}-{self.operation}",
            daemon=True,
        )
        self.thread.start()

    def ensure_owned(self) -> None:
        if self.errors or not self.repo.is_owned(self.oob_id, self.operation):
            raise ScanLockError(
                "Operation lock đã hết hạn hoặc mất ownership; từ chối commit kết quả."
            )

    def close(self, *, raise_on_heartbeat_error: bool = True) -> None:
        if self.closed:
            return
        self.closed = True
        self.stop.set()
        self.thread.join(timeout=max(1.0, self.repo.heartbeat_seconds / 2))
        self.repo.release(self.oob_id, self.operation)
        if self.errors and raise_on_heartbeat_error:
            raise ScanLockError(
                "Operation lock heartbeat thất bại; operation không còn độc quyền."
            ) from self.errors[0]


class ScanLockRepository:
    """Backward-compatible name; v1.1.8 protects every OOB operation.

    The table remains ``scan_locks`` to avoid destructive migration, but one row
    now represents an exclusive lease for SCAN, CONSOLE or IDENTITY_DISCOVERY.
    A heartbeat prevents long interactive sessions from being mistaken as stale.
    """

    def __init__(
        self,
        db: DatabaseConnection,
        *,
        lease_seconds: int = 180,
        heartbeat_seconds: int = 15,
    ) -> None:
        self.db = db
        self.lease_seconds = max(60, int(lease_seconds))
        self.heartbeat_seconds = max(5, int(heartbeat_seconds))

    def start_lease(self, oob_id: int, operation: str) -> OperationLease:
        return OperationLease(self, oob_id, operation)

    def acquire(self, oob_id: int, operation: str = "SCAN") -> None:
        hostname = socket.gethostname()
        pid = os.getpid()
        now = utc_now()
        operation = (operation or "SCAN").strip().upper()
        with self.db.transaction() as conn:
            row = conn.execute(
                "SELECT * FROM scan_locks WHERE oob_id=?",
                (oob_id,),
            ).fetchone()
            if row:
                expired = self._expired(row, now)
                same_host_dead = (
                    row["hostname"] == hostname and not self._pid_alive(int(row["pid"] or 0))
                )
                if expired or same_host_dead:
                    conn.execute("DELETE FROM scan_locks WHERE oob_id=?", (oob_id,))
                else:
                    raise ScanLockError(
                        f"Operation={row['operation'] or 'SCAN'}; PID={row['pid']}; "
                        f"Máy={row['hostname']}; Bắt đầu={row['started_at']}; "
                        f"Lease đến={row['expires_at'] or '-'}"
                    )
            expires = now + timedelta(seconds=self.lease_seconds)
            conn.execute(
                """
                INSERT INTO scan_locks(
                    oob_id,pid,hostname,started_at,operation,heartbeat_at,expires_at
                ) VALUES(?,?,?,?,?,?,?)
                """,
                (
                    oob_id,
                    pid,
                    hostname,
                    to_db(now),
                    operation,
                    to_db(now),
                    to_db(expires),
                ),
            )

    def is_owned(self, oob_id: int, operation: str | None = None) -> bool:
        params: list[object] = [oob_id, os.getpid(), socket.gethostname()]
        sql = "SELECT expires_at, operation FROM scan_locks WHERE oob_id=? AND pid=? AND hostname=?"
        if operation:
            sql += " AND operation=?"
            params.append(operation.strip().upper())
        with self.db.read() as conn:
            row = conn.execute(sql, tuple(params)).fetchone()
        return bool(row and not self._expired(row, utc_now()))

    def heartbeat(self, oob_id: int, operation: str | None = None) -> bool:
        now = utc_now()
        expires = now + timedelta(seconds=self.lease_seconds)
        params: list[object] = [to_db(now), to_db(expires), oob_id, os.getpid(), socket.gethostname()]
        sql = """
            UPDATE scan_locks
            SET heartbeat_at=?, expires_at=?
            WHERE oob_id=? AND pid=? AND hostname=?
        """
        if operation:
            sql += " AND operation=?"
            params.append(operation.strip().upper())
        with self.db.transaction() as conn:
            cursor = conn.execute(sql, tuple(params))
            return cursor.rowcount == 1

    def release(self, oob_id: int, operation: str | None = None) -> None:
        params: list[object] = [oob_id, os.getpid(), socket.gethostname()]
        sql = """
            DELETE FROM scan_locks
            WHERE oob_id=? AND pid=? AND hostname=?
        """
        if operation:
            sql += " AND operation=?"
            params.append(operation.strip().upper())
        with self.db.transaction() as conn:
            conn.execute(sql, tuple(params))

    @contextmanager
    def hold(self, oob_id: int, operation: str) -> Iterator[None]:
        """Acquire a lock and keep its lease alive until the operation exits."""

        self.acquire(oob_id, operation)
        stop = threading.Event()
        heartbeat_error: list[BaseException] = []

        def worker() -> None:
            while not stop.wait(self.heartbeat_seconds):
                try:
                    if not self.heartbeat(oob_id, operation):
                        heartbeat_error.append(RuntimeError("Operation lock ownership lost"))
                        return
                except BaseException as exc:  # daemon path; surfaced after operation
                    heartbeat_error.append(exc)
                    return

        thread = threading.Thread(
            target=worker,
            name=f"oob-lock-{oob_id}-{operation}",
            daemon=True,
        )
        thread.start()
        try:
            yield
            if heartbeat_error:
                raise ScanLockError(
                    "Operation lock heartbeat thất bại; kết quả không còn an toàn để commit."
                ) from heartbeat_error[0]
        finally:
            stop.set()
            thread.join(timeout=max(1.0, self.heartbeat_seconds / 2))
            self.release(oob_id, operation)

    def recover_stale_same_host(self) -> int:
        """Recover expired leases on any host and dead PIDs on the current host."""

        hostname = socket.gethostname()
        now = utc_now()
        recovered = 0
        with self.db.transaction() as conn:
            rows = conn.execute("SELECT * FROM scan_locks").fetchall()
            for row in rows:
                expired = self._expired(row, now)
                same_host_dead = (
                    row["hostname"] == hostname and not self._pid_alive(int(row["pid"] or 0))
                )
                if expired or same_host_dead:
                    conn.execute("DELETE FROM scan_locks WHERE oob_id=?", (row["oob_id"],))
                    recovered += 1
        return recovered

    def list_all(self):
        with self.db.read() as conn:
            return conn.execute(
                "SELECT * FROM scan_locks ORDER BY started_at"
            ).fetchall()

    @staticmethod
    def _expired(row, now) -> bool:
        try:
            expires = from_db(row["expires_at"] or None)
        except (ValueError, TypeError, IndexError, KeyError):
            expires = None
        return expires is None or expires <= now

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError as exc:
            if exc.errno == errno.ESRCH:
                return False
            if exc.errno == errno.EPERM:
                return True
            return False
