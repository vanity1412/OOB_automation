"""Audit repository cho controlled OOB mapping reconciliation."""
from __future__ import annotations

import os
import socket

from oob_manager.database.connection import DatabaseConnection
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import current_process_user, sanitize_text


class ReconciliationRepository:
    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def start(
        self,
        *,
        oob_id: int,
        target_id: int,
        identity_run_id: int | None,
        vendor: str,
        operator_username: str,
        ticket_id: str,
        reason: str,
        old_alias: str,
        new_alias: str,
        physical_path: str,
        proposed_commands: list[str],
    ) -> int:
        now = to_db(utc_now())
        with self.db.transaction() as conn:
            cur = conn.execute(
                """
                INSERT INTO oob_reconciliation_history(
                    oob_id,target_id,identity_run_id,vendor,operator_username,
                    ticket_id,reason,old_alias,new_alias,physical_path,
                    proposed_commands,status,started_at,process_pid,
                    process_hostname,process_user
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    oob_id,target_id,identity_run_id,vendor,
                    operator_username.strip(),ticket_id.strip(),reason.strip(),
                    old_alias.strip(),new_alias.strip(),physical_path.strip(),
                    "\n".join(proposed_commands),"RUNNING",now,os.getpid(),
                    socket.gethostname(),current_process_user(),
                ),
            )
            return int(cur.lastrowid)

    def finish(
        self,
        reconciliation_id: int,
        *,
        status: str,
        verification_code: str = "",
        verification_message: str = "",
        rollback_attempted: bool = False,
        rollback_succeeded: bool = False,
        error_code: str = "",
        error_message: str = "",
        baseline_refresh_status: str = "NOT_RUN",
        applied_commands: list[str] | None = None,
    ) -> None:
        with self.db.transaction() as conn:
            conn.execute(
                """
                UPDATE oob_reconciliation_history
                SET status=?,finished_at=?,verification_code=?,verification_message=?,
                    rollback_attempted=?,rollback_succeeded=?,error_code=?,error_message=?,
                    baseline_refresh_status=?,applied_commands=?
                WHERE id=?
                """,
                (
                    status,to_db(utc_now()),verification_code,
                    sanitize_text(verification_message),int(rollback_attempted),
                    int(rollback_succeeded),error_code,sanitize_text(error_message),
                    baseline_refresh_status,"\n".join(applied_commands or []),reconciliation_id,
                ),
            )

    def update_baseline_refresh(self, reconciliation_id: int, status: str) -> None:
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE oob_reconciliation_history SET baseline_refresh_status=? WHERE id=?",
                (status, reconciliation_id),
            )

    def list_recent(self, limit: int = 100):
        with self.db.read() as conn:
            return conn.execute(
                """
                SELECT r.*, o.name AS oob_name
                FROM oob_reconciliation_history r
                JOIN oob_devices o ON o.id=r.oob_id
                ORDER BY r.id DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
