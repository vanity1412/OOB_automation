"""Repository lưu scan run, raw command output và finding audit."""
from __future__ import annotations

from contextlib import nullcontext
import errno
import hashlib
import os
import socket
import sqlite3

from oob_manager.database.connection import DatabaseConnection
from oob_manager.models.oob_device import OOBDevice
from oob_manager.models.scan_result import RawCommandOutput
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import current_process_user, redact_username, sanitize_text


class ScanRepository:
    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def start(
        self,
        device: OOBDevice,
        scanner_version: str,
        connection_revision: int = 1,
        profile_fingerprint: str = "",
        *,
        ssh_username: str = "",
        trigger_source: str = "SERVICE",
        profile_snapshot_json: str = "{}",
        scan_policy_snapshot_json: str = "{}",
    ) -> int:
        if device.id is None:
            raise ValueError("OOB chưa có ID.")
        with self.db.transaction() as conn:
            cursor = conn.execute(
                """
                INSERT INTO scan_runs(
                    oob_id, started_at, status, scanner_version, connection_revision,
                    oob_name_at_scan, oob_host_at_scan, oob_ssh_port_at_scan,
                    vendor_at_scan, connection_mode_at_scan, device_type_at_scan,
                    profile_fingerprint, config_snapshot_source, ssh_username_at_scan,
                    trigger_source, process_pid, process_hostname, process_user,
                    profile_snapshot_json, scan_policy_snapshot_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    device.id,
                    to_db(utc_now()),
                    "RUNNING",
                    scanner_version,
                    connection_revision,
                    device.name,
                    device.host,
                    device.ssh_port,
                    device.vendor,
                    device.connection_mode,
                    device.device_type,
                    profile_fingerprint,
                    "LIVE_CAPTURE",
                    redact_username(ssh_username),
                    trigger_source,
                    os.getpid(),
                    socket.gethostname(),
                    current_process_user(),
                    profile_snapshot_json,
                    scan_policy_snapshot_json,
                ),
            )
            return int(cursor.lastrowid)

    def update_ssh_host_key(
        self,
        scan_id: int,
        algorithm: str,
        fingerprint: str,
        policy: str,
    ) -> None:
        if not (algorithm or fingerprint or policy):
            return
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE scan_runs
                   SET ssh_host_key_algorithm=?, ssh_host_key_fingerprint=?, ssh_host_key_policy=?
                   WHERE id=?""",
                (algorithm, fingerprint, policy, scan_id),
            )

    def save_raw_outputs(
        self,
        scan_id: int,
        outputs: list[RawCommandOutput],
    ) -> None:
        if not outputs:
            return
        created_at = to_db(utc_now())
        with self.db.transaction() as conn:
            conn.executemany(
                """
                INSERT INTO raw_outputs(
                    scan_id, command_name, command_text, raw_output,
                    success, error_message, is_core, redaction_applied, stored_output_sha256,
                    stored_output_length, created_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,
                [
                    (
                        scan_id,
                        sanitize_text(output.command_name),
                        sanitize_text(output.command_text),
                        safe_raw,
                        int(output.success),
                        sanitize_text(output.error_message),
                        int(output.is_core),
                        int(
                            output.redaction_applied
                            or safe_raw != str(output.raw_output or "")
                            or sanitize_text(output.error_message) != str(output.error_message or "")
                        ),
                        hashlib.sha256(safe_raw.encode("utf-8")).hexdigest(),
                        len(safe_raw),
                        created_at,
                    )
                    for output in outputs
                    for safe_raw in (sanitize_text(output.raw_output),)
                ],
            )

    def save_findings(
        self,
        scan_id: int,
        findings: list[dict[str, str]],
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        if not findings:
            return
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            now = to_db(utc_now())
            active_conn.executemany(
                """
                INSERT INTO scan_findings(
                    scan_id, finding_type, severity, code, source, message, created_at
                ) VALUES(?,?,?,?,?,?,?)
                """,
                [
                    (
                        scan_id,
                        item.get("finding_type", "WARNING"),
                        item.get("severity", "WARNING"),
                        item.get("code", ""),
                        item.get("source", ""),
                        item.get("message", ""),
                        now,
                    )
                    for item in findings
                ],
            )

    def finish(
        self,
        scan_id: int,
        status: str,
        mapping_count: int = 0,
        warning_count: int = 0,
        complete_count: int = 0,
        complete_ratio: float = 0.0,
        change_count: int = 0,
        error_code: str = "",
        error_message: str = "",
        mapping_quality: str = "REJECTED",
        baseline_updated: bool = False,
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            active_conn.execute(
                """
                UPDATE scan_runs
                SET finished_at=?, status=?, mapping_count=?, warning_count=?,
                    complete_count=?, complete_ratio=?, change_count=?,
                    error_code=?, error_message=?, mapping_quality=?, baseline_updated=?
                WHERE id=?
                """,
                (
                    to_db(utc_now()),
                    status,
                    mapping_count,
                    warning_count,
                    complete_count,
                    complete_ratio,
                    change_count,
                    sanitize_text(error_code),
                    sanitize_text(error_message),
                    mapping_quality,
                    int(baseline_updated),
                    scan_id,
                ),
            )

    def list_recent(self, limit: int = 100) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                """
                SELECT s.*, COALESCE(NULLIF(s.oob_name_at_scan,''), o.name) AS oob_name
                FROM scan_runs s
                JOIN oob_devices o ON o.id=s.oob_id
                ORDER BY s.id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()


    def recover_abandoned_same_host(self) -> int:
        """Đóng scan RUNNING của process đã chết trên chính máy hiện tại.

        Nếu app/terminal bị kill, để scan RUNNING mãi sẽ làm audit sai. Chỉ
        recover cùng hostname vì không thể xác minh PID của máy khác an toàn.
        """
        hostname = socket.gethostname()
        recovered = 0
        with self.db.transaction() as conn:
            rows = conn.execute(
                """
                SELECT id, process_pid FROM scan_runs
                WHERE status='RUNNING' AND process_hostname=?
                """,
                (hostname,),
            ).fetchall()
            for row in rows:
                pid = int(row["process_pid"] or 0)
                if not self._pid_alive(pid):
                    conn.execute(
                        """
                        UPDATE scan_runs
                        SET finished_at=?, status='FAILED', mapping_quality='REJECTED',
                            baseline_updated=0, error_code='PROCESS_TERMINATED',
                            error_message='Scan trước kết thúc bất thường; được đánh dấu khi ứng dụng khởi động lại.'
                        WHERE id=? AND status='RUNNING'
                        """,
                        (to_db(utc_now()), row["id"]),
                    )
                    recovered += 1
        return recovered

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError as exc:
            if exc.errno == errno.ESRCH:
                return False
            if exc.errno == errno.EPERM:
                return True
            return False

    def list_findings(self, scan_id: int) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                "SELECT * FROM scan_findings WHERE scan_id=? ORDER BY id",
                (scan_id,),
            ).fetchall()
