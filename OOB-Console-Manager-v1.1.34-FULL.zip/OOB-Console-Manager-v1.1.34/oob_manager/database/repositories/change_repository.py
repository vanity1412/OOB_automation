"""Repository lưu và đọc change event."""
from __future__ import annotations

from contextlib import nullcontext
import json
import sqlite3

from oob_manager.database.connection import DatabaseConnection
from oob_manager.models.change_event import ChangeEvent
from oob_manager.utils.datetime_utils import to_db, utc_now


class ChangeRepository:
    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def save_all(
        self,
        events: list[ChangeEvent],
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        if not events:
            return
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            active_conn.executemany(
                """
                INSERT INTO change_events(
                    oob_id, scan_id, event_code, target_identity,
                    old_data, new_data, detected_at
                ) VALUES(?,?,?,?,?,?,?)
                """,
                [
                    (
                        event.oob_id,
                        event.scan_id,
                        event.event_code,
                        event.target_identity,
                        json.dumps(event.old_data, ensure_ascii=False)
                        if event.old_data is not None
                        else None,
                        json.dumps(event.new_data, ensure_ascii=False)
                        if event.new_data is not None
                        else None,
                        to_db(event.detected_at),
                    )
                    for event in events
                ],
            )


    def count_unviewed(self) -> int:
        with self.db.read() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS count FROM change_events WHERE viewed_at IS NULL"
            ).fetchone()
            return int(row["count"] if row else 0)

    def mark_viewed(self, event_ids: list[int]) -> None:
        ids = sorted({int(value) for value in event_ids if int(value) > 0})
        if not ids:
            return
        placeholders = ",".join("?" for _ in ids)
        with self.db.transaction() as conn:
            conn.execute(
                f"UPDATE change_events SET viewed_at=COALESCE(viewed_at, ?) WHERE id IN ({placeholders})",
                (to_db(utc_now()), *ids),
            )

    def list_recent(self, limit: int = 100) -> list[sqlite3.Row]:
        with self.db.read() as conn:
            return conn.execute(
                """
                SELECT e.*, o.name AS oob_name
                FROM change_events e
                JOIN oob_devices o ON o.id=e.oob_id
                ORDER BY e.id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
