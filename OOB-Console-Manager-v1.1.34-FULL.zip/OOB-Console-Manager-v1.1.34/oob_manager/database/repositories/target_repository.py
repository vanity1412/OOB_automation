"""Repository cho current target, snapshot và tìm kiếm."""
from __future__ import annotations

from contextlib import nullcontext
import hashlib
import re
import sqlite3

from oob_manager.database.connection import DatabaseConnection
from oob_manager.models.console_target import ConsoleTarget
from oob_manager.services.target_matching import TargetMatcher
from oob_manager.utils.datetime_utils import from_db, to_db, utc_now
from oob_manager.utils.security import redact_username, sanitize_text


class TargetRepository:
    """Truy cập dữ liệu console target bằng SQL parameterized."""

    def __init__(self, db: DatabaseConnection, matcher: TargetMatcher | None = None) -> None:
        self.db = db
        self.matcher = matcher or TargetMatcher()

    @staticmethod
    def _private_state(target: ConsoleTarget) -> tuple[str, str]:
        """Return persistence-safe session user/evidence without mutating live data."""
        username = str(target.session_user or "")
        return redact_username(username), sanitize_text(target.state_evidence)

    @staticmethod
    def _map(row: sqlite3.Row) -> ConsoleTarget:
        keys = set(row.keys())
        return ConsoleTarget(
            id=row["id"],
            oob_id=row["oob_id"],
            menu_name=row["menu_name"],
            menu_item=row["menu_item"],
            alias=row["alias"],
            command=row["command"],
            protocol=row["protocol"],
            target_host=row["target_host"],
            target_port=row["target_port"],
            console_line=row["console_line"],
            console_line_source=row["console_line_source"] if "console_line_source" in keys else "LEGACY_UNKNOWN",
            state=row["state"],
            session_user="" if str(row["session_user"] or "").startswith("***ĐÃ_CHE") else row["session_user"],
            state_confident=bool(row["state_confident"]),
            state_reason_code=row["state_reason_code"] if "state_reason_code" in keys else "",
            state_evidence=row["state_evidence"] if "state_evidence" in keys else "{}",
            source=row["source"],
            mapping_source_command=row["mapping_source_command"] if "mapping_source_command" in keys else "",
            mapping_text_line=row["mapping_text_line"] if "mapping_text_line" in keys else "",
            mapping_text_line_no=row["mapping_text_line_no"] if "mapping_text_line_no" in keys else None,
            mapping_command_line=row["mapping_command_line"] if "mapping_command_line" in keys else "",
            mapping_command_line_no=row["mapping_command_line_no"] if "mapping_command_line_no" in keys else None,
            is_complete=bool(row["is_complete"]),
            first_seen_at=from_db(row["first_seen_at"]),
            last_seen_at=from_db(row["last_seen_at"]),
            last_scan_id=row["last_scan_id"],
        )

    def list_current(self, oob_id: int | None = None) -> list[ConsoleTarget]:
        with self.db.read() as conn:
            return self._list_current_conn(conn, oob_id)

    def _list_current_conn(
        self,
        conn: sqlite3.Connection,
        oob_id: int | None = None,
    ) -> list[ConsoleTarget]:
        sql = "SELECT * FROM console_targets"
        params: tuple[object, ...] = ()
        if oob_id is not None:
            sql += " WHERE oob_id=?"
            params = (oob_id,)
        sql += " ORDER BY oob_id, menu_name, menu_item, alias COLLATE NOCASE"
        return [self._map(row) for row in conn.execute(sql, params).fetchall()]

    def get(self, target_id: int) -> ConsoleTarget | None:
        with self.db.read() as conn:
            row = conn.execute(
                "SELECT * FROM console_targets WHERE id=?",
                (target_id,),
            ).fetchone()
            return self._map(row) if row else None

    def verify_open_provenance(self, target_id: int) -> tuple[bool, str, str]:
        """Xác minh current target còn truy ngược được tới raw evidence hợp lệ.

        Đây là guard read-only trước khi mở console thật. Nó không chỉ tin row
        ``console_targets`` mà kiểm tra cả scan nguồn, mapping quality và exact
        menu lines/hash đã tạo target. Nếu evidence chain bị thiếu hoặc bị sửa,
        caller phải fail closed và yêu cầu scan lại.
        """
        with self.db.read() as conn:
            target = conn.execute(
                "SELECT * FROM console_targets WHERE id=?", (target_id,)
            ).fetchone()
            if target is None:
                return False, "TARGET_NOT_FOUND", "Không tìm thấy current target."

            scan_id = int(target["last_scan_id"] or 0)
            if scan_id <= 0:
                return False, "MAPPING_SCAN_MISSING", "Target không có scan nguồn hợp lệ."
            scan = conn.execute(
                "SELECT id,oob_id,mapping_quality,baseline_updated FROM scan_runs WHERE id=?",
                (scan_id,),
            ).fetchone()
            if scan is None:
                return False, "MAPPING_SCAN_MISSING", f"Scan nguồn {scan_id} không tồn tại."
            if int(scan["oob_id"]) != int(target["oob_id"]):
                return False, "MAPPING_SCAN_OOB_MISMATCH", "Scan nguồn thuộc OOB khác."
            if scan["mapping_quality"] != "ACCEPTED" or int(scan["baseline_updated"] or 0) != 1:
                return False, "MAPPING_NOT_ACCEPTED", "Target không đến từ baseline mapping đã được ACCEPTED."

            source_command = str(target["mapping_source_command"] or "").strip()
            text_line = str(target["mapping_text_line"] or "").strip()
            command_line = str(target["mapping_command_line"] or "").strip()
            source_type = str(target["source"] or "").strip().upper()
            if not source_command or not text_line or not command_line:
                # Cisco parser hiện tại luôn lưu exact menu evidence. Legacy/custom
                # adapters không có contract này vẫn phải chứng minh scan nguồn đã
                # ACCEPTED, nhưng không giả vờ có exact line provenance.
                if source_type != "CISCO_MENU":
                    return (
                        True,
                        "MAPPING_PROVENANCE_ACCEPTED_SCAN_ONLY",
                        f"Target truy vết tới accepted scan {scan_id}; adapter nguồn chưa cung cấp exact raw-line provenance.",
                    )
                return (
                    False,
                    "MAPPING_SOURCE_EVIDENCE_MISSING",
                    "Cisco target thiếu command/dòng nguồn để truy vết; cần scan lại bằng phiên bản mới.",
                )

            raw = conn.execute(
                """
                SELECT id,raw_output,stored_output_sha256,stored_output_length
                FROM raw_outputs
                WHERE scan_id=? AND command_name='menu' AND command_text=?
                  AND is_core=1 AND success=1
                ORDER BY id DESC LIMIT 1
                """,
                (scan_id, source_command),
            ).fetchone()
            if raw is None:
                return False, "MAPPING_RAW_EVIDENCE_MISSING", "Không tìm thấy raw menu evidence của target."

            raw_output = str(raw["raw_output"] or "")
            stored_length = int(raw["stored_output_length"] or 0)
            stored_hash = str(raw["stored_output_sha256"] or "")
            actual_hash = hashlib.sha256(raw_output.encode("utf-8")).hexdigest()
            if stored_length != len(raw_output) or not stored_hash or stored_hash != actual_hash:
                return False, "MAPPING_RAW_EVIDENCE_TAMPERED", "Raw menu evidence không còn khớp hash/length đã lưu."

            lines = raw_output.splitlines()

            def exact_line_matches(line_no_value, expected: str) -> bool:
                if not expected:
                    return False
                if line_no_value is not None:
                    try:
                        index = int(line_no_value) - 1
                    except (TypeError, ValueError):
                        return False
                    return 0 <= index < len(lines) and lines[index].strip() == expected
                return sum(1 for line in lines if line.strip() == expected) == 1

            if not exact_line_matches(target["mapping_text_line_no"], text_line):
                return False, "MAPPING_TEXT_EVIDENCE_MISMATCH", "Dòng menu text không còn khớp raw evidence nguồn."
            if not exact_line_matches(target["mapping_command_line_no"], command_line):
                return False, "MAPPING_COMMAND_EVIDENCE_MISMATCH", "Dòng menu command không còn khớp raw evidence nguồn."

            return True, "MAPPING_PROVENANCE_VERIFIED", f"Target truy vết hợp lệ tới scan {scan_id}, raw_output {raw['id']}."

    def replace_current(
        self,
        oob_id: int,
        scan_id: int,
        targets: list[ConsoleTarget],
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        """Cập nhật current target và giữ nguyên ID của target đã ghép được."""
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            previous = self._list_current_conn(active_conn, oob_id)
            match_result = self.matcher.match(previous, targets)
            now = utc_now()

            for old_target, new_target in match_result.pairs:
                # Downstream identity chỉ có giá trị cho đúng console mapping đã
                # được discovery. Bất kỳ thay đổi mapping/alias nào cũng invalidate
                # current identity; run/snapshot lịch sử vẫn được giữ để audit.
                identity_mapping_changed = any((
                    old_target.menu_name.casefold() != new_target.menu_name.casefold(),
                    old_target.menu_item != new_target.menu_item,
                    old_target.alias.casefold() != new_target.alias.casefold(),
                    old_target.command.strip() != new_target.command.strip(),
                    old_target.protocol != new_target.protocol,
                    old_target.target_host.casefold() != new_target.target_host.casefold(),
                    old_target.target_port != new_target.target_port,
                    old_target.console_line != new_target.console_line,
                ))
                if identity_mapping_changed and old_target.id is not None:
                    active_conn.execute(
                        "DELETE FROM device_identities WHERE target_id=?",
                        (old_target.id,),
                    )
                new_target.id = old_target.id
                new_target.oob_id = oob_id
                new_target.first_seen_at = old_target.first_seen_at
                new_target.last_seen_at = now
                new_target.last_scan_id = scan_id
                active_conn.execute(
                    """
                    UPDATE console_targets
                    SET menu_name=?, menu_item=?, alias=?, command=?, protocol=?,
                        target_host=?, target_port=?, console_line=?, console_line_source=?,
                        state=?, session_user=?, state_confident=?, state_reason_code=?,
                        state_evidence=?, source=?, mapping_source_command=?,
                        mapping_text_line=?, mapping_text_line_no=?,
                        mapping_command_line=?, mapping_command_line_no=?, is_complete=?,
                        first_seen_at=?, last_seen_at=?, last_scan_id=?
                    WHERE id=? AND oob_id=?
                    """,
                    (
                        new_target.menu_name,
                        new_target.menu_item,
                        new_target.alias,
                        new_target.command,
                        new_target.protocol,
                        new_target.target_host,
                        new_target.target_port,
                        new_target.console_line,
                        new_target.console_line_source,
                        new_target.state,
                        self._private_state(new_target)[0],
                        int(new_target.state_confident),
                        new_target.state_reason_code,
                        self._private_state(new_target)[1],
                        new_target.source,
                        new_target.mapping_source_command,
                        new_target.mapping_text_line,
                        new_target.mapping_text_line_no,
                        new_target.mapping_command_line,
                        new_target.mapping_command_line_no,
                        int(new_target.is_complete),
                        to_db(new_target.first_seen_at),
                        to_db(new_target.last_seen_at),
                        scan_id,
                        old_target.id,
                        oob_id,
                    ),
                )

            self._insert_current(
                active_conn,
                oob_id,
                scan_id,
                match_result.current_unmatched,
                now,
            )

            missing_ids = [
                target.id
                for target in match_result.previous_unmatched
                if target.id is not None
            ]
            if missing_ids:
                placeholders = ",".join("?" for _ in missing_ids)
                active_conn.execute(
                    f"DELETE FROM console_targets WHERE oob_id=? AND id IN ({placeholders})",
                    (oob_id, *missing_ids),
                )

    def reset_current(
        self,
        oob_id: int,
        scan_id: int,
        targets: list[ConsoleTarget],
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        """Bắt đầu baseline generation mới, không ghép identity với mapping stale cũ."""
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            active_conn.execute("DELETE FROM console_targets WHERE oob_id=?", (oob_id,))
            self._insert_current(active_conn, oob_id, scan_id, targets, utc_now())

    @staticmethod
    def _insert_current(
        conn: sqlite3.Connection,
        oob_id: int,
        scan_id: int,
        targets: list[ConsoleTarget],
        now,
    ) -> None:
        for target in targets:
            target.oob_id = oob_id
            target.first_seen_at = now
            target.last_seen_at = now
            target.last_scan_id = scan_id
            cursor = conn.execute(
                """
                INSERT INTO console_targets(
                    oob_id, menu_name, menu_item, alias, command, protocol,
                    target_host, target_port, console_line, console_line_source,
                    state, session_user, state_confident, state_reason_code,
                    state_evidence, source, mapping_source_command,
                    mapping_text_line, mapping_text_line_no, mapping_command_line,
                    mapping_command_line_no, is_complete,
                    first_seen_at, last_seen_at, last_scan_id
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    oob_id,
                    target.menu_name,
                    target.menu_item,
                    target.alias,
                    target.command,
                    target.protocol,
                    target.target_host,
                    target.target_port,
                    target.console_line,
                    target.console_line_source,
                    target.state,
                    TargetRepository._private_state(target)[0],
                    int(target.state_confident),
                    target.state_reason_code,
                    TargetRepository._private_state(target)[1],
                    target.source,
                    target.mapping_source_command,
                    target.mapping_text_line,
                    target.mapping_text_line_no,
                    target.mapping_command_line,
                    target.mapping_command_line_no,
                    int(target.is_complete),
                    to_db(target.first_seen_at),
                    to_db(target.last_seen_at),
                    scan_id,
                ),
            )
            target.id = int(cursor.lastrowid)

    def save_snapshot(
        self,
        oob_id: int,
        scan_id: int,
        targets: list[ConsoleTarget],
        *,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        manager = nullcontext(conn) if conn is not None else self.db.transaction()
        with manager as active_conn:
            assert active_conn is not None
            captured_at = to_db(utc_now())
            active_conn.executemany(
                """
                INSERT INTO console_snapshots(
                    target_id, scan_id, oob_id, menu_name, menu_item, alias,
                    command, protocol, target_host, target_port, console_line,
                    console_line_source, state, session_user, state_confident,
                    state_reason_code, state_evidence, source,
                    mapping_source_command, mapping_text_line, mapping_text_line_no,
                    mapping_command_line, mapping_command_line_no, is_complete, captured_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                [
                    (
                        target.id,
                        scan_id,
                        oob_id,
                        target.menu_name,
                        target.menu_item,
                        target.alias,
                        target.command,
                        target.protocol,
                        target.target_host,
                        target.target_port,
                        target.console_line,
                        target.console_line_source,
                        target.state,
                        TargetRepository._private_state(target)[0],
                        int(target.state_confident),
                        target.state_reason_code,
                        TargetRepository._private_state(target)[1],
                        target.source,
                        target.mapping_source_command,
                        target.mapping_text_line,
                        target.mapping_text_line_no,
                        target.mapping_command_line,
                        target.mapping_command_line_no,
                        int(target.is_complete),
                        captured_at,
                    )
                    for target in targets
                ],
            )

    def search(self, query: str, limit: int = 100) -> list[sqlite3.Row]:
        """Smart token search không phụ thuộc thứ tự từ.

        Ví dụ ``bras-HCM``, ``HCM BRAS`` và ``hcm_bras`` đều sinh hai token
        HCM + BRAS. Mỗi token phải xuất hiện ở ít nhất một field searchable,
        nhưng các token có thể nằm ở các field khác nhau.
        """
        raw = query.strip()
        if not raw:
            return []
        tokens = re.findall(r"[^\W_]+", raw, flags=re.UNICODE)
        if not tokens:
            tokens = [raw]
        # Giới hạn token để query nhập nhầm không tạo SQL quá lớn.
        tokens = tokens[:8]

        searchable = [
            "t.alias LIKE ? COLLATE NOCASE",
            "o.name LIKE ? COLLATE NOCASE",
            "o.host LIKE ? COLLATE NOCASE",
            "t.target_host LIKE ? COLLATE NOCASE",
            "CAST(t.target_port AS TEXT) LIKE ?",
            "t.menu_name LIKE ? COLLATE NOCASE",
            "CAST(t.menu_item AS TEXT) LIKE ?",
            "CAST(t.console_line AS TEXT) LIKE ?",
            "t.command LIKE ? COLLATE NOCASE",
            "i.actual_hostname LIKE ? COLLATE NOCASE",
            "i.model LIKE ? COLLATE NOCASE",
            "i.serial_number LIKE ? COLLATE NOCASE",
            "i.software_version LIKE ? COLLATE NOCASE",
        ]
        token_clause = "(" + " OR ".join(searchable) + ")"
        where_tokens = " AND ".join(token_clause for _ in tokens)
        params: list[object] = []
        for token in tokens:
            like_query = f"%{token}%"
            params.extend([like_query] * len(searchable))
        params.append(limit)

        sql = f"""
            SELECT t.*, o.name AS oob_name, o.host AS oob_host,
                   o.vendor AS oob_vendor,
                   o.connection_revision, o.baseline_revision,
                   o.baseline_stale_reason, o.baseline_stale_at,
                   o.current_profile_fingerprint, o.baseline_profile_fingerprint,
                   i.actual_hostname AS actual_hostname,
                   i.vendor AS actual_vendor, i.model AS actual_model,
                   i.serial_number AS actual_serial_number,
                   i.software_version AS actual_software_version,
                   i.identity_confidence AS identity_confidence,
                   i.alias_comparison AS alias_comparison
            FROM console_targets t
            JOIN oob_devices o ON o.id=t.oob_id
            LEFT JOIN device_identities i ON i.target_id=t.id
            WHERE o.enabled=1 AND {where_tokens}
            ORDER BY t.alias COLLATE NOCASE, o.name COLLATE NOCASE
            LIMIT ?
        """
        with self.db.read() as conn:
            return conn.execute(sql, tuple(params)).fetchall()
