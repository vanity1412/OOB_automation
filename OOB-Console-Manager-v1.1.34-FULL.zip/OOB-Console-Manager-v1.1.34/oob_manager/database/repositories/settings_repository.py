"""Repository cho cấu hình không nhạy cảm."""
from __future__ import annotations

from oob_manager.database.connection import DatabaseConnection
from oob_manager.utils.datetime_utils import to_db, utc_now


class SettingsRepository:
    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db

    def get_all(self) -> dict[str, str]:
        with self.db.read() as conn:
            return {
                row["key"]: row["value"]
                for row in conn.execute("SELECT key, value FROM application_settings")
            }

    def set(self, key: str, value: str) -> None:
        self.set_many({key: value})

    def set_many(self, values: dict[str, str]) -> None:
        if not values:
            return
        updated_at = to_db(utc_now())
        with self.db.transaction() as conn:
            conn.executemany(
                """
                INSERT INTO application_settings(key, value, updated_at)
                VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET
                    value=excluded.value,
                    updated_at=excluded.updated_at
                """,
                [(key, value, updated_at) for key, value in values.items()],
            )
