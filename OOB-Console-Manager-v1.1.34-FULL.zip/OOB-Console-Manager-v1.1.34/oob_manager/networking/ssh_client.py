from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path
import re
import socket
import time
from typing import Any, Callable

from oob_manager.exceptions import (
    CommandExecutionError,
    DependencyError,
    SSHAuthenticationError,
    SSHNegotiationError,
)
from oob_manager.utils.paths import SSH_KNOWN_HOSTS_PATH

PROMPT_RE = re.compile(r"^\S{1,120}[#>]\s*$")
PAGER_RE = re.compile(
    r"(?i)(--\s*more\s*--|<---\s*more\s*--->|press\s+(?:any\s+key|return)\s+to\s+continue)"
)


def extract_prompt(value: str) -> str | None:
    """Accept only a stable non-whitespace Cisco-style prompt on the last line."""

    lines = [line.strip() for line in value.replace("\r", "").split("\n") if line.strip()]
    if not lines:
        return None
    return lines[-1] if PROMPT_RE.fullmatch(lines[-1]) else None


def _ends_with_prompt(value: str, expected_prompt: str | None = None) -> bool:
    lines = [line.strip() for line in value.replace("\r", "").split("\n") if line.strip()]
    if not lines:
        return False
    if expected_prompt:
        return lines[-1] == expected_prompt.strip()
    return bool(PROMPT_RE.fullmatch(lines[-1]))


class SSHClientWrapper:
    """Paramiko wrapper with phase-specific timeouts and bounded transient retry."""

    def __init__(
        self,
        connect_timeout: int = 10,
        command_timeout: int = 20,
        known_hosts_path: Path | str | None = SSH_KNOWN_HOSTS_PATH,
        *,
        banner_timeout: int | None = None,
        auth_timeout: int | None = None,
        shell_timeout: int | None = None,
        max_attempts: int = 2,
        retry_delay: float = 1.0,
    ):
        self.connect_timeout = int(connect_timeout)
        self.banner_timeout = int(banner_timeout or max(connect_timeout, 20))
        self.auth_timeout = int(auth_timeout or max(connect_timeout, 15))
        self.shell_timeout = int(shell_timeout or max(connect_timeout, 15))
        self.command_timeout = int(command_timeout)
        self.max_attempts = max(1, min(int(max_attempts), 3))
        self.retry_delay = max(0.0, float(retry_delay))
        self.expected_prompt: str | None = None
        self.known_hosts_path = Path(known_hosts_path) if known_hosts_path else None
        self.host_key_policy = "TOFU_PERSISTENT" if self.known_hosts_path else "AUTO_ADD_MEMORY_ONLY"
        self.last_host_key_algorithm = ""
        self.last_host_key_fingerprint = ""
        self.last_connect_attempts = 0

    @staticmethod
    def _fingerprint_sha256(key: Any) -> str:
        digest = hashlib.sha256(key.asbytes()).digest()
        return "SHA256:" + base64.b64encode(digest).decode("ascii").rstrip("=")

    def _configure_host_keys(self, client, paramiko) -> None:
        client.load_system_host_keys()
        if self.known_hosts_path is None:
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            return
        self.known_hosts_path.parent.mkdir(parents=True, exist_ok=True)
        self.known_hosts_path.touch(exist_ok=True)
        try:
            os.chmod(self.known_hosts_path, 0o600)
        except OSError:
            pass
        client.load_host_keys(str(self.known_hosts_path))
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    @staticmethod
    def _is_transient(exc: BaseException, paramiko) -> bool:
        # Authentication/host-key failures are never retryable.  Network reset,
        # banner timeout and temporary SSH negotiation failures may be retried once.
        if isinstance(exc, getattr(paramiko, "AuthenticationException", ())):
            return False
        if isinstance(exc, getattr(paramiko, "BadHostKeyException", ())):
            return False
        return isinstance(
            exc,
            (
                socket.timeout,
                TimeoutError,
                ConnectionResetError,
                ConnectionAbortedError,
                EOFError,
                OSError,
                getattr(paramiko, "SSHException", Exception),
            ),
        )

    def connect(self, host: str, port: int, username: str, password: str):
        self.last_host_key_algorithm = ""
        self.last_host_key_fingerprint = ""
        self.last_connect_attempts = 0
        try:
            import paramiko
        except ImportError as exc:
            raise DependencyError("Thiếu thư viện paramiko.") from exc

        last_exc: BaseException | None = None
        for attempt in range(1, self.max_attempts + 1):
            self.last_connect_attempts = attempt
            client = paramiko.SSHClient()
            try:
                self._configure_host_keys(client, paramiko)
                client.connect(
                    hostname=host,
                    port=port,
                    username=username,
                    password=password,
                    timeout=self.connect_timeout,
                    banner_timeout=self.banner_timeout,
                    auth_timeout=self.auth_timeout,
                    look_for_keys=False,
                    allow_agent=False,
                )
                transport = client.get_transport()
                if transport is None or not getattr(transport, "is_active", lambda: True)():
                    raise getattr(paramiko, "SSHException", RuntimeError)(
                        "SSH transport không active sau authentication"
                    )
                key = transport.get_remote_server_key()
                self.last_host_key_algorithm = str(key.get_name() or "")
                self.last_host_key_fingerprint = self._fingerprint_sha256(key)
                return client
            except getattr(paramiko, "BadHostKeyException", paramiko.SSHException) as exc:
                client.close()
                raise SSHNegotiationError(
                    "SSH host key không khớp key đã tin cậy; từ chối kết nối.",
                    error_code="SSH_HOST_KEY_MISMATCH",
                ) from exc
            except paramiko.AuthenticationException as exc:
                client.close()
                raise SSHAuthenticationError(
                    "SSH authentication failed",
                    error_code="SSH_AUTHENTICATION_FAILED",
                ) from exc
            except Exception as exc:
                client.close()
                last_exc = exc
                if attempt >= self.max_attempts or not self._is_transient(exc, paramiko):
                    break
                time.sleep(self.retry_delay)

        detail = str(last_exc or "").casefold()
        if "banner" in detail:
            code = "SSH_BANNER_TIMEOUT"
        elif isinstance(last_exc, (socket.timeout, TimeoutError)):
            code = "SSH_PHASE_TIMEOUT"
        else:
            code = "SSH_NEGOTIATION_FAILED"
        raise SSHNegotiationError(
            f"SSH negotiation failed sau {self.last_connect_attempts} lần thử: "
            f"{type(last_exc).__name__ if last_exc else 'UNKNOWN'}",
            error_code=code,
        ) from last_exc

    def open_shell(self, client, *, width: int = 160, height: int = 48):
        safe_width = min(max(int(width), 80), 500)
        safe_height = min(max(int(height), 24), 2000)
        try:
            transport = client.get_transport()
            if transport is not None and hasattr(transport, "set_keepalive"):
                transport.set_keepalive(30)

            # Real Paramiko path: ``open_session(timeout=...)`` gives the shell
            # phase its own deadline. Test doubles/older implementations fall
            # back to ``invoke_shell`` for compatibility.
            if transport is not None and callable(getattr(transport, "open_session", None)):
                channel = transport.open_session(timeout=self.shell_timeout)
                channel.get_pty(term="vt100", width=safe_width, height=safe_height)
                channel.invoke_shell()
            else:
                channel = client.invoke_shell(width=safe_width, height=safe_height)
            channel.settimeout(0.2)
            return channel
        except Exception as exc:
            raise SSHNegotiationError(
                "Không mở được SSH interactive shell trong thời gian cho phép.",
                error_code="SSH_SHELL_OPEN_FAILED",
            ) from exc

    @staticmethod
    def _channel_closed(channel) -> bool:
        return bool(getattr(channel, "closed", False) or getattr(channel, "eof_received", False))

    @staticmethod
    def _send(channel, data: str | bytes) -> None:
        try:
            payload = data
            offset = 0
            while offset < len(payload):
                sent = channel.send(payload[offset:])
                if sent is None:  # compatible test double accepted the payload
                    return
                if not isinstance(sent, int) or sent <= 0:
                    raise EOFError("SSH channel đã đóng khi gửi dữ liệu")
                offset += sent
        except (EOFError, OSError) as exc:
            raise CommandExecutionError(
                "SSH channel bị ngắt khi gửi dữ liệu.",
                error_code="SSH_CHANNEL_CLOSED",
            ) from exc

    def drain_channel(self, channel, quiet: float = 0.15, max_wait: float = 0.5) -> str:
        deadline = time.monotonic() + max_wait
        last_data = time.monotonic()
        chunks: list[str] = []
        while time.monotonic() < deadline:
            if channel.recv_ready():
                try:
                    data = channel.recv(65535)
                except (EOFError, OSError):
                    break
                if not data:
                    break
                chunks.append(data.decode("utf-8", errors="replace"))
                last_data = time.monotonic()
            elif chunks and time.monotonic() - last_data >= quiet:
                break
            elif self._channel_closed(channel):
                break
            else:
                time.sleep(0.02)
        return "".join(chunks)

    def read_until_state(
        self,
        channel,
        detector: Callable[[str], str | None],
        timeout: float | None = None,
        *,
        settle: float = 0.2,
        initial: str = "",
        max_bytes: int = 2 * 1024 * 1024,
    ) -> tuple[str, str | None]:
        """Read until a semantic terminal state is observed.

        Unlike :meth:`read_until_quiet`, this method never treats a short gap in
        network/device output as proof that a login or transition completed.
        Real OOB equipment may emit a banner, pause while AAA/MOTD processing
        finishes, then emit the actual CLI/menu prompt. The detector therefore
        decides completion and ``settle`` is used only *after* a state exists to
        collect trailing bytes from the same response.

        The detector must be side-effect free and return a stable state name or
        ``None``. A timeout returns the partial transcript with state ``None`` so
        the caller can fail closed or hand control to an operator as appropriate.
        """

        deadline = time.monotonic() + float(timeout or self.command_timeout)
        text = initial or ""
        state = detector(text) if text else None
        last_data = time.monotonic()
        state_seen_at = last_data if state is not None else None

        while time.monotonic() < deadline:
            if channel.recv_ready():
                try:
                    data = channel.recv(65535)
                except (EOFError, OSError) as exc:
                    if text:
                        break
                    raise CommandExecutionError(
                        "SSH channel bị ngắt khi chờ trạng thái terminal.",
                        error_code="SSH_CHANNEL_CLOSED",
                    ) from exc
                if not data:
                    break
                text += data.decode("utf-8", errors="replace")
                if len(text.encode("utf-8", errors="replace")) > max_bytes:
                    error = CommandExecutionError(
                        "SSH output vượt giới hạn an toàn khi chờ trạng thái terminal.",
                        error_code="SSH_OUTPUT_LIMIT_EXCEEDED",
                    )
                    error.raw_output = text[-65535:]
                    raise error
                last_data = time.monotonic()
                detected = detector(text)
                if detected is None:
                    state = None
                    state_seen_at = None
                else:
                    state = detected
                    state_seen_at = last_data
            elif state is not None and state_seen_at is not None:
                if (
                    self._channel_closed(channel)
                    or time.monotonic() - last_data >= max(0.0, float(settle))
                ):
                    return text, state
                time.sleep(0.02)
            elif self._channel_closed(channel):
                break
            else:
                time.sleep(0.04)

        # One final detector pass matters when the peer closes immediately after
        # writing the prompt/state and the last recv/close events are adjacent.
        final_state = detector(text) if text else None
        return text, final_state

    def read_until_quiet(
        self,
        channel,
        timeout: float | None = None,
        quiet: float = 0.5,
    ) -> str:
        deadline = time.monotonic() + float(timeout or self.command_timeout)
        last = time.monotonic()
        chunks: list[str] = []
        while time.monotonic() < deadline:
            if channel.recv_ready():
                try:
                    data = channel.recv(65535)
                except (EOFError, OSError) as exc:
                    if chunks:
                        break
                    raise CommandExecutionError(
                        "SSH channel bị ngắt khi đọc dữ liệu.",
                        error_code="SSH_CHANNEL_CLOSED",
                    ) from exc
                if not data:
                    break
                chunks.append(data.decode("utf-8", errors="replace"))
                last = time.monotonic()
            elif chunks and time.monotonic() - last >= quiet:
                break
            elif self._channel_closed(channel):
                break
            else:
                time.sleep(0.05)
        return "".join(chunks)

    def run_shell_command(self, channel, command: str, timeout: float | None = None) -> str:
        self.drain_channel(channel)
        self._send(channel, command + "\n")
        deadline = time.monotonic() + float(timeout or self.command_timeout)
        chunks: list[str] = []
        prompt_seen_at: float | None = None
        while time.monotonic() < deadline:
            if channel.recv_ready():
                try:
                    data = channel.recv(65535)
                except (EOFError, OSError) as exc:
                    error = CommandExecutionError(
                        f"SSH channel bị ngắt khi chạy command: {command}",
                        error_code="SSH_CHANNEL_CLOSED",
                    )
                    error.raw_output = "".join(chunks)
                    raise error from exc
                if not data:
                    break
                chunks.append(data.decode("utf-8", errors="replace"))
                joined = "".join(chunks)
                if PAGER_RE.search(joined):
                    exc = CommandExecutionError(
                        f"Command gặp paging; output không đủ tin cậy: {command}",
                        error_code="COMMAND_PAGING_DETECTED",
                    )
                    exc.raw_output = joined
                    raise exc
                prompt_seen_at = (
                    time.monotonic()
                    if _ends_with_prompt(joined, self.expected_prompt)
                    else None
                )
            elif prompt_seen_at is not None and time.monotonic() - prompt_seen_at >= 0.25:
                break
            elif self._channel_closed(channel):
                break
            else:
                time.sleep(0.05)
        output = "".join(chunks)
        if not output:
            raise CommandExecutionError(
                f"Command không trả output: {command}",
                error_code="COMMAND_NO_OUTPUT",
            )
        if not _ends_with_prompt(output, self.expected_prompt):
            exc = CommandExecutionError(
                f"Command có thể bị timeout, channel đóng hoặc output bị cắt: {command}",
                error_code="COMMAND_TIMEOUT",
            )
            exc.raw_output = output
            raise exc
        return output
