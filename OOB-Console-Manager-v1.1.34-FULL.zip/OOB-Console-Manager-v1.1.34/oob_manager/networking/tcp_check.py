from __future__ import annotations

import socket
import time

from oob_manager.exceptions import TCPConnectionError


def check_tcp(
    host: str,
    port: int,
    timeout: int = 10,
    *,
    attempts: int = 2,
    retry_delay: float = 0.5,
) -> float:
    """Verify TCP reachability with one bounded retry for transient failures."""

    started = time.monotonic()
    last_exc: BaseException | None = None
    attempts = max(1, min(int(attempts), 3))
    for attempt in range(1, attempts + 1):
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return time.monotonic() - started
        except socket.gaierror as exc:
            raise TCPConnectionError(
                "Không phân giải được hostname OOB.",
                error_code="DNS_RESOLUTION_FAILED",
            ) from exc
        except ConnectionRefusedError as exc:
            raise TCPConnectionError(
                "Connection refused",
                error_code="CONNECTION_REFUSED",
            ) from exc
        except (socket.timeout, TimeoutError, ConnectionResetError, OSError) as exc:
            last_exc = exc
            if attempt < attempts:
                time.sleep(max(0.0, retry_delay))
                continue
            break

    if isinstance(last_exc, (socket.timeout, TimeoutError)):
        raise TCPConnectionError("TCP timeout", error_code="TCP_TIMEOUT") from last_exc
    raise TCPConnectionError(
        f"Không thể kết nối TCP sau {attempts} lần thử: {type(last_exc).__name__ if last_exc else 'UNKNOWN'}",
        error_code="TCP_CONNECTION_ERROR",
    ) from last_exc
