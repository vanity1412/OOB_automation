"""Bridge terminal local với SSH channel trên POSIX và Windows.

Ctrl+] được giữ làm escape local của tool. Byte này không được chuyển tới thiết bị.
Mọi đường thoát đều khôi phục terminal POSIX; SSH client/channel được adapter đóng
trong ``finally`` ngay sau khi bridge trả về hoặc ném lỗi.

v1.1.20 có session recording text tối giản. Input/output được ghi song song vào
``session_logs/<connection_id>.log`` khi ConsoleService cung cấp đường dẫn. Recorder
không ghi raw password khi nhận diện prompt password/passphrase/secret và tiếp tục
chạy ``sanitize_text`` trên nội dung log như lớp phòng vệ bổ sung.
"""
from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path
import re
import signal
import sys
import threading
import time

from oob_manager.exceptions import InteractiveSessionError
from oob_manager.utils.security import REDACTED, sanitize_text


_ANSI_RE = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")
_SECRET_PROMPT_RE = re.compile(
    r"(?is)(?:password|passphrase|enable\s+password|secret|pin)\s*:\s*$"
)


class _SessionRecorder:
    """Thread-safe, best-effort text recorder for an interactive console."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._input = bytearray()
        self._sensitive_input = False
        self._output_tail = ""
        self._closed = False
        self._runtime_secrets: list[str] = []
        self._handle = self.path.open("a", encoding="utf-8", newline="\n")
        try:
            os.chmod(self.path, 0o600)
        except (OSError, PermissionError):
            pass
        self._write("META", "SESSION_START")

    @staticmethod
    def _timestamp() -> str:
        return datetime.now().astimezone().isoformat(timespec="milliseconds")

    def _clean_text(self, text: str) -> str:
        # Session log is meant to be readable text, not a terminal byte dump.
        # Password entered at a recognized secret prompt is kept only in RAM and
        # used to mask a rare remote echo of that value.
        return _ANSI_RE.sub(
            "", sanitize_text(text, tuple(self._runtime_secrets))
        ).replace("\x00", "")

    def _write(self, direction: str, text: str) -> None:
        if self._closed:
            return
        cleaned = self._clean_text(text)
        # Keep one timestamp/direction prefix per logical line. Empty strings are
        # still useful for Enter events, therefore preserve one line.
        lines = cleaned.splitlines() or [""]
        with self._lock:
            for line in lines:
                self._handle.write(f"{self._timestamp()} [{direction}] {line}\n")
            self._handle.flush()

    def output(self, payload: bytes | str) -> None:
        if isinstance(payload, bytes):
            text = payload.decode("utf-8", errors="replace")
        else:
            text = str(payload or "")

        # Once a secret prompt has been seen, do not persist subsequent remote
        # echo while the operator is still typing the secret. Most network
        # devices disable password echo, but a broken/misconfigured endpoint
        # may echo characters before Enter. At that moment the recorder does
        # not know the complete secret value yet, so the only safe choice is to
        # suppress that sensitive-window output.
        if self._sensitive_input:
            if text.strip():
                self._write("OUT", "[SENSITIVE_REMOTE_OUTPUT_REDACTED]")
            return

        self._write("OUT", text)
        # Keep enough tail to recognize split prompts such as "Pass" + "word:".
        combined = (self._output_tail + text)[-512:]
        self._output_tail = combined
        if _SECRET_PROMPT_RE.search(_ANSI_RE.sub("", combined).strip()):
            self._sensitive_input = True

    def input(self, payload: bytes) -> None:
        """Record operator input as lines while preserving password secrecy."""
        if not payload:
            return
        for byte in payload:
            if byte in (10, 13):  # Enter
                self._flush_input_line()
                continue
            if byte in (8, 127):  # Backspace/Delete in canonical command editing
                if self._input:
                    self._input.pop()
                continue
            if byte == 3:  # Ctrl+C
                self._flush_input_line()
                self._write("IN", "[CTRL+C]")
                continue
            if byte == 26:  # Ctrl+Z
                self._flush_input_line()
                self._write("IN", "[CTRL+Z]")
                continue
            # Arrow/function escape sequences are harmless to retain in the input
            # buffer; they are stripped from the human-readable log on flush.
            self._input.append(byte)
            # Bound memory if an application sends a huge stream without newline.
            if len(self._input) >= 8192:
                self._flush_input_line(partial=True)

    def _flush_input_line(self, *, partial: bool = False) -> None:
        if self._sensitive_input:
            secret_value = self._input.decode("utf-8", errors="ignore")
            if secret_value:
                self._runtime_secrets.append(secret_value)
                self._runtime_secrets = self._runtime_secrets[-5:]
            self._write("IN", f"[{REDACTED}_SECRET_INPUT]")
        else:
            text = self._input.decode("utf-8", errors="replace")
            text = _ANSI_RE.sub("", text)
            suffix = " [PARTIAL]" if partial else ""
            self._write("IN", f"{sanitize_text(text)}{suffix}")
        self._input.clear()
        if not partial:
            self._sensitive_input = False
            self._output_tail = ""

    def local(self, text: str) -> None:
        self._write("LOCAL", text)

    def close(self) -> None:
        if self._closed:
            return
        if self._input:
            self._flush_input_line(partial=True)
        self._write("META", "SESSION_END")
        self._closed = True
        with self._lock:
            self._handle.close()


class TerminalBridge:
    ESCAPE = "\x1d"  # Ctrl+]

    def __init__(self, session_log_path: Path | str | None = None) -> None:
        self._recorder = _SessionRecorder(session_log_path) if session_log_path else None

    def _record_output(self, payload: bytes | str) -> None:
        if self._recorder is not None:
            self._recorder.output(payload)

    def _record_input(self, payload: bytes) -> None:
        if self._recorder is not None:
            self._recorder.input(payload)

    def _record_local(self, text: str) -> None:
        if self._recorder is not None:
            self._recorder.local(text)

    @staticmethod
    def _print_manual_console_warning() -> None:
        """Hiển thị ranh giới rõ giữa UI tool và console thiết bị thật."""
        try:
            from colorama import Fore, Style, just_fix_windows_console
            just_fix_windows_console()
            yellow = Fore.YELLOW + Style.BRIGHT
            red = Fore.RED + Style.BRIGHT
            cyan = Fore.CYAN + Style.BRIGHT
            reset = Style.RESET_ALL
        except Exception:  # pragma: no cover
            yellow = red = cyan = reset = ""
        print(cyan + "\n┌" + "─" * 78 + "┐" + reset)
        print(cyan + "│" + " MANUAL CONSOLE ĐÃ MỞ - ĐANG THAO TÁC TRỰC TIẾP TRÊN THIẾT BỊ ".center(78) + "│" + reset)
        print(cyan + "├" + "─" * 78 + "┤" + reset)
        print("│ " + yellow + "Mọi lệnh nhập từ đây được gửi trực tiếp tới thiết bị thật." + reset)
        print("│ " + red + "Tool không tự rollback cấu hình downstream do operator nhập." + reset)
        print("│ Thoát phiên tool: Ctrl+] rồi chọn quit.")
        print(cyan + "└" + "─" * 78 + "┘" + reset)

    def bridge(self, channel, initial_output: str = "") -> None:
        try:
            self._print_manual_console_warning()
            if initial_output:
                self._record_output(initial_output)
                sys.stdout.write(initial_output)
                sys.stdout.flush()
            self._resize_remote_pty(channel)
            if os.name == "nt":
                self._windows(channel)
            else:
                self._posix(channel)
        except InteractiveSessionError:
            raise
        except (EOFError, OSError) as exc:
            raise InteractiveSessionError(
                "Kênh console đã đóng hoặc kết nối mạng bị ngắt.",
                error_code="SSH_CHANNEL_CLOSED",
            ) from exc
        except Exception as exc:
            # Do not include arbitrary exception text: terminal/driver exceptions
            # may contain buffers or credentials supplied by a third party.
            raise InteractiveSessionError(
                f"Lỗi bridge terminal ({type(exc).__name__}).",
                error_code="INTERACTIVE_SESSION_ERROR",
            ) from exc
        finally:
            if self._recorder is not None:
                self._recorder.close()

    @staticmethod
    def _remote_closed(channel) -> bool:
        return bool(
            getattr(channel, "closed", False)
            or getattr(channel, "eof_received", False)
            or (
                callable(getattr(channel, "exit_status_ready", None))
                and channel.exit_status_ready()
            )
        )

    @staticmethod
    def _send_all(channel, payload: bytes) -> None:
        """Send all bytes and fail if the SSH channel stops accepting data."""

        offset = 0
        while offset < len(payload):
            sent = channel.send(payload[offset:])
            # Some lightweight test doubles return None after accepting all data.
            if sent is None:
                return
            if not isinstance(sent, int) or sent <= 0:
                raise EOFError("SSH channel closed while sending")
            offset += sent

    @staticmethod
    def _resize_remote_pty(channel) -> None:
        resize = getattr(channel, "resize_pty", None)
        if not callable(resize):
            return
        try:
            size = os.get_terminal_size(sys.stdout.fileno())
            resize(width=max(80, size.columns), height=max(24, size.lines))
        except (OSError, ValueError, AttributeError):
            # Redirection/non-TTY is valid; retain the PTY size opened by adapter.
            return

    def _posix(self, channel) -> None:
        import select
        import termios
        import tty

        file_descriptor = sys.stdin.fileno()
        old_settings = termios.tcgetattr(file_descriptor)
        previous_winch = None
        winch_installed = False

        def on_resize(_signum, _frame) -> None:
            self._resize_remote_pty(channel)

        try:
            if threading.current_thread() is threading.main_thread() and hasattr(signal, "SIGWINCH"):
                previous_winch = signal.getsignal(signal.SIGWINCH)
                signal.signal(signal.SIGWINCH, on_resize)
                winch_installed = True
            tty.setraw(file_descriptor)
            sys.stdout.write("\r\n")
            sys.stdout.flush()
            while True:
                if self._remote_closed(channel):
                    break
                ready, _, _ = select.select([channel, sys.stdin], [], [], 0.2)
                if channel in ready:
                    data = channel.recv(65535)
                    if not data:
                        break
                    self._record_output(data)
                    sys.stdout.buffer.write(data)
                    sys.stdout.buffer.flush()
                if sys.stdin in ready:
                    data = os.read(file_descriptor, 1)
                    if data == self.ESCAPE.encode("ascii"):
                        termios.tcsetattr(file_descriptor, termios.TCSADRAIN, old_settings)
                        try:
                            command = input(
                                "\nLệnh tool (quit để thoát, resume để tiếp tục): "
                            ).strip().casefold()
                        except (EOFError, KeyboardInterrupt):
                            command = "quit"
                        self._record_local(f"Ctrl+] {command or 'resume'}")
                        if command == "quit":
                            break
                        tty.setraw(file_descriptor)
                    elif data:
                        self._record_input(data)
                        self._send_all(channel, data)
        finally:
            termios.tcsetattr(file_descriptor, termios.TCSADRAIN, old_settings)
            if winch_installed:
                signal.signal(signal.SIGWINCH, previous_winch)

    def _windows(self, channel) -> None:
        import msvcrt

        stop_event = threading.Event()
        receiver_errors: list[BaseException] = []

        def receiver() -> None:
            try:
                while not stop_event.is_set():
                    if self._remote_closed(channel):
                        break
                    if channel.recv_ready():
                        data = channel.recv(65535)
                        if not data:
                            break
                        self._record_output(data)
                        sys.stdout.write(data.decode("utf-8", errors="replace"))
                        sys.stdout.flush()
                    else:
                        time.sleep(0.03)
            except (EOFError, OSError):
                pass
            except Exception as exc:
                receiver_errors.append(exc)
            finally:
                stop_event.set()

        receiver_thread = threading.Thread(
            target=receiver,
            name="oob-console-receiver",
            daemon=True,
        )
        receiver_thread.start()
        try:
            while not stop_event.is_set():
                if self._remote_closed(channel):
                    break
                if not msvcrt.kbhit():
                    time.sleep(0.03)
                    continue
                character = msvcrt.getwch()
                if character == self.ESCAPE:
                    sys.stdout.write(
                        "\nLệnh tool (quit để thoát, resume để tiếp tục): "
                    )
                    sys.stdout.flush()
                    command = self._read_windows_tool_command(msvcrt)
                    self._record_local(f"Ctrl+] {command.strip().casefold() or 'resume'}")
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    if command.strip().casefold() == "quit":
                        break
                elif character in {"\x00", "\xe0"}:
                    extended = msvcrt.getwch()
                    sequence = self._windows_extended_sequence(extended)
                    if sequence:
                        self._record_input(sequence)
                        self._send_all(channel, sequence)
                else:
                    payload = character.encode("utf-8", errors="ignore")
                    if payload:
                        self._record_input(payload)
                        self._send_all(channel, payload)
        finally:
            stop_event.set()
            receiver_thread.join(timeout=1.5)

        if receiver_errors:
            raise InteractiveSessionError(
                f"Luồng nhận console lỗi ({type(receiver_errors[0]).__name__}).",
                error_code="SSH_CHANNEL_CLOSED",
            ) from receiver_errors[0]

    @staticmethod
    def _windows_extended_sequence(code: str) -> bytes:
        mapping = {
            "H": b"\x1b[A",   # Up
            "P": b"\x1b[B",   # Down
            "M": b"\x1b[C",   # Right
            "K": b"\x1b[D",   # Left
            "G": b"\x1b[H",   # Home
            "O": b"\x1b[F",   # End
            "S": b"\x1b[3~",  # Delete
            "I": b"\x1b[5~",  # Page Up
            "Q": b"\x1b[6~",  # Page Down
        }
        return mapping.get(code, b"")

    @staticmethod
    def _read_windows_tool_command(msvcrt_module) -> str:
        command = ""
        while True:
            character = msvcrt_module.getwch()
            if character in ("\r", "\n"):
                return command
            if character == "\x03":  # Ctrl+C while in local tool prompt
                return "quit"
            if character == "\b":
                command = command[:-1]
            elif character not in {"\x00", "\xe0"}:
                command += character
