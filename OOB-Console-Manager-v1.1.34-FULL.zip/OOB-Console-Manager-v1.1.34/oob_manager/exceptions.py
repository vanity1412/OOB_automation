"""Exception có mã lỗi ổn định để ánh xạ sang tiếng Việt."""
from __future__ import annotations

class OOBManagerError(Exception):
    error_code = "OOB_MANAGER_ERROR"
    def __init__(self, message: str = "", *, error_code: str | None = None) -> None:
        super().__init__(message)
        if error_code:
            self.error_code = error_code

class ValidationError(OOBManagerError): error_code = "VALIDATION_ERROR"
class DatabaseError(OOBManagerError): error_code = "DATABASE_ERROR"
class ConnectionError(OOBManagerError): error_code = "CONNECTION_ERROR"
class TCPConnectionError(ConnectionError): error_code = "TCP_CONNECTION_ERROR"
class SSHAuthenticationError(ConnectionError): error_code = "SSH_AUTHENTICATION_FAILED"
class SSHNegotiationError(ConnectionError): error_code = "SSH_NEGOTIATION_FAILED"
class CommandExecutionError(OOBManagerError): error_code = "COMMAND_EXECUTION_ERROR"
class ParserError(OOBManagerError): error_code = "PARSER_ERROR"
class ScanRejectedError(OOBManagerError): error_code = "SCAN_REJECTED"
class UnsupportedVendorError(OOBManagerError): error_code = "UNSUPPORTED_VENDOR"
class InteractiveSessionError(OOBManagerError): error_code = "INTERACTIVE_SESSION_ERROR"
class DependencyError(OOBManagerError): error_code = "DEPENDENCY_ERROR"
class ProfileError(OOBManagerError): error_code = "PROFILE_ERROR"
class ScanLockError(OOBManagerError): error_code = "SCAN_LOCKED"
class OOBConfigurationChangedError(OOBManagerError): error_code = "OOB_CONFIGURATION_CHANGED"
class InputCancelledError(OOBManagerError): error_code = "INPUT_CANCELLED"

ERROR_MESSAGES_VI = {
    "INPUT_CANCELLED": "Thao tác đã được hủy an toàn.",
    "SSH_AUTHENTICATION_FAILED": "Sai tên đăng nhập hoặc mật khẩu.",
    "SSH_BANNER_TIMEOUT": "SSH banner không đến trong thời gian cho phép sau các lần thử.",
    "SSH_PHASE_TIMEOUT": "Một giai đoạn SSH bị timeout sau các lần thử được phép.",
    "CONNECTION_MODE_UNSUPPORTED": "Phiên bản này chỉ hỗ trợ SSH Management CLI; API/SSH_AND_API đang bị vô hiệu hóa.",
    "SSH_SHELL_OPEN_FAILED": "SSH đã xác thực nhưng không mở được interactive shell.",
    "SSH_CHANNEL_CLOSED": "SSH channel bị đóng hoặc mất kết nối trong lúc thao tác.",
    "DNS_RESOLUTION_FAILED": "Không phân giải được hostname OOB.",
    "CONSOLE_STATE_UNVERIFIED": "Không chứng minh được console line/serial port đang AVAILABLE; kết nối tự động đã bị chặn.",
    "VERTIV_PORT_AUTH_PASSWORD_REQUIRED": "ACS8000 yêu cầu password xác thực serial port; cần nhập riêng hoặc chọn dùng OOB password một cách rõ ràng.",
    "VERTIV_PORT_AUTHENTICATION_FAILED": "Xác thực serial port Vertiv thất bại hoặc chưa vào được downstream console.",
    "SSH_HOST_KEY_MISMATCH": "SSH host key của OOB đã thay đổi so với key đã tin cậy; tool đã chặn kết nối để tránh nhầm/MITM.",
    "TCP_TIMEOUT": "Thiết bị không phản hồi trong thời gian cho phép.",
    "CONNECTION_REFUSED": "Thiết bị đã từ chối kết nối.",
    "PARSER_ERROR": "Không thể phân tích dữ liệu trả về từ OOB.",
    "SCAN_REJECTED": "Dữ liệu quét không đủ tin cậy nên không cập nhật kết quả hiện tại.",
    "AUTO_MENU_SCAN_UNAVAILABLE": "Tài khoản hiện tại chỉ vào menu và không thể quét cấu hình. Cần dùng tài khoản có quyền đọc cấu hình.",
    "ENABLE_PASSWORD_REQUIRED": "OOB đang ở chế độ user EXEC; cần enable password để quét.",
    "API_NOT_CONFIGURED": "API Vertiv chưa được cấu hình trong profile.",
    "API_UNSUPPORTED": "Chức năng API Vertiv chưa được hỗ trợ với profile hiện tại.",
    "SCAN_LOCKED": "OOB này đang được quét bởi một tiến trình khác.",
    "OOB_CONFIGURATION_CHANGED": "Cấu hình kết nối OOB đã thay đổi trong lúc quét; kết quả scan không được dùng để cập nhật mapping.",
    "STALE_MAPPING": "Mapping console đã cũ do cấu hình kết nối OOB thay đổi. Cần scan lại OOB và xác nhận mapping đủ tin cậy trước khi mở console.",
    "RUNTIME_MENU_UNVERIFIED": "Không xác minh được menu runtime nên tool từ chối gửi lựa chọn tự động.",
    "RUNTIME_MENU_ITEM_MISSING": "Menu item đã lưu không xuất hiện trong menu runtime hiện tại.",
    "RUNTIME_MENU_ALIAS_MISMATCH": "Menu item runtime có label khác alias đã lưu; tool chặn để tránh kết nối nhầm thiết bị.",
    "TARGET_CONNECT_FAILED": "OOB báo lỗi khi mở đường console tới target.",
    "MAPPING_PROVENANCE_INVALID": "Mapping không truy vết được tới evidence nguồn; cần scan lại OOB trước khi mở console.",
    "MAPPING_SOURCE_EVIDENCE_MISSING": "Target thiếu evidence nguồn để truy vết; cần scan lại OOB bằng phiên bản mới.",
    "MAPPING_RAW_EVIDENCE_MISSING": "Không tìm thấy raw menu evidence của mapping; cần scan lại OOB.",
    "MAPPING_RAW_EVIDENCE_TAMPERED": "Raw menu evidence không khớp hash/length đã lưu; tool đã chặn mở console.",
    "MAPPING_TEXT_EVIDENCE_MISMATCH": "Dòng menu text không còn khớp evidence nguồn; tool đã chặn mở console.",
    "MAPPING_COMMAND_EVIDENCE_MISMATCH": "Dòng menu command không còn khớp evidence nguồn; tool đã chặn mở console.",
    "MAPPING_SCAN_MISSING": "Scan nguồn của target không tồn tại; cần scan lại OOB.",
    "MAPPING_SCAN_OOB_MISMATCH": "Scan nguồn của target thuộc OOB khác; tool đã chặn mở console.",
    "MAPPING_NOT_ACCEPTED": "Target không đến từ baseline mapping đã được ACCEPTED; cần scan lại OOB.",
    "LIVE_MAPPING_COMMAND_UNAVAILABLE": "Không có command read-only để xác minh mapping ngay trước kết nối.",
    "LIVE_MAPPING_PROFILE_MISMATCH": "Profile runtime không còn khớp command nguồn của mapping.",
    "LIVE_MAPPING_AMBIGUOUS": "Mapping runtime có duplicate/ambiguous definition; tool đã chặn kết nối.",
    "LIVE_MAPPING_ITEM_MISSING": "Menu/item runtime không còn tồn tại như baseline.",
    "LIVE_MAPPING_INCOMPLETE": "Mapping runtime của target chưa đầy đủ; tool đã chặn kết nối.",
    "LIVE_MAPPING_ALIAS_MISMATCH": "Alias runtime khác baseline; tool đã chặn kết nối.",
    "LIVE_MAPPING_PROTOCOL_MISMATCH": "Protocol runtime khác baseline; tool đã chặn kết nối.",
    "LIVE_MAPPING_ENDPOINT_MISMATCH": "Endpoint/command runtime khác baseline; tool đã chặn kết nối.",
    "LIVE_MAPPING_UNVERIFIED": "Không xác minh lại được mapping trong phiên SSH hiện tại.",
    "PRECONNECT_PROMPT_UNVERIFIED": "Không xác minh được prompt Cisco trước live verification.",
    "PRECONNECT_PREPARE_FAILED": "Không chuẩn bị được terminal để live-verify mapping an toàn.",
    "CONSOLE_LINE_BUSY": "Console line đang được xác nhận BUSY; tool không gửi reverse Telnet tự động.",
    "COMMAND_PAGING_DETECTED": "Command gặp paging nên output có thể bị cắt; dữ liệu không được coi là đầy đủ.",
    "COMMAND_TIMEOUT": "Command không trở về prompt trong thời gian cho phép; output được giữ để audit nhưng không được coi là đầy đủ.",
    "DOWNSTREAM_TARGET_UNSUPPORTED": "Target chưa đủ điều kiện để downstream discovery tự động.",
    "DOWNSTREAM_OOB_VENDOR_UNSUPPORTED": "Downstream discovery chưa hỗ trợ vendor OOB này.",
    "VERTIV_LOGIN_MODE_UNVERIFIED": "SSH thành công nhưng không xác minh được CLI/root shell của Avocent ACS800/8000.",
    "VERTIV_CLI_PROMPT_TIMEOUT": "ACS8000 CLI không trở về prompt đúng hạn; tool đã fail-closed.",
    "VERTIV_CLI_COMMAND_FAILED": "ACS8000 từ chối command read-only được yêu cầu.",
    "VERTIV_ACCESS_NOT_AUTHORIZED": "Account Vertiv không có quyền đọc Access level/serial ports.",
    "VERTIV_TARGET_UNSUPPORTED": "Target không phải Vertiv ACS access serial port được hỗ trợ.",
    "VERTIV_TARGET_INCOMPLETE": "Vertiv target chưa đủ mapping serial port an toàn.",
    "VERTIV_PORT_NAME_UNSAFE": "Tên serial port Vertiv chứa ký tự ngoài whitelist; tool không tạo connect command.",
    "VERTIV_CONNECT_COMMAND_MISMATCH": "Vertiv connect command không khớp port-name đã parse.",
    "VERTIV_LIVE_MAPPING_ITEM_MISSING": "Serial port Vertiv baseline không còn xuất hiện duy nhất ở access/show runtime.",
    "VERTIV_LIVE_MAPPING_ALIAS_MISMATCH": "Port-name Vertiv runtime khác baseline; tool đã chặn kết nối.",
    "VERTIV_LIVE_MAPPING_COMMAND_MISMATCH": "Vertiv connect command/protocol runtime khác baseline.",
    "VERTIV_LIVE_MAPPING_AMBIGUOUS": "Vertiv access/show runtime có duplicate port/alias; mapping mơ hồ.",
    "VERTIV_LIVE_MAPPING_INCOMPLETE": "Vertiv runtime target chưa đủ dữ liệu an toàn.",
    "VERTIV_CONSOLE_PATH_NOT_ENTERED": "connect không chứng minh được đã rời ACS CLI và vào serial target.",
    "DOWNSTREAM_DISCOVERY_REQUIRES_NORMAL_CLI": "Downstream discovery tự động yêu cầu Cisco OOB ở NORMAL_CLI để kiểm tra live line an toàn.",
    "DOWNSTREAM_LINE_NOT_CONFIRMED_AVAILABLE": "Không chứng minh được console line đang AVAILABLE; tool đã chặn discovery để tránh ảnh hưởng phiên khác.",
    "DOWNSTREAM_USERNAME_REQUIRED": "Thiết bị downstream yêu cầu username nhưng chưa được cung cấp.",
    "DOWNSTREAM_PASSWORD_REQUIRED": "Thiết bị downstream yêu cầu password nhưng chưa được cung cấp.",
    "DOWNSTREAM_AUTHENTICATION_FAILED": "Đăng nhập thiết bị downstream thất bại.",
    "DOWNSTREAM_PROMPT_UNVERIFIED": "Không xác minh được CLI prompt của thiết bị downstream.",
    "DOWNSTREAM_CONSOLE_PATH_NOT_ENTERED": "Không chứng minh được reverse-console đã rời OOB và vào thiết bị downstream; tool đã chặn discovery.",
    "DOWNSTREAM_COMMAND_TIMEOUT": "Command read-only downstream không trở về đúng prompt trong thời gian cho phép.",
    "DOWNSTREAM_OUTPUT_TOO_LARGE": "Output downstream vượt giới hạn an toàn và đã bị từ chối.",
    "DOWNSTREAM_PAGING_LIMIT": "Output downstream có quá nhiều trang; tool đã dừng để tránh session treo.",
    "DOWNSTREAM_IDENTITY_REJECTED": "Đã vào downstream CLI nhưng identity thu được chưa đủ tin cậy để lưu current identity.",
    "DOWNSTREAM_DISCOVERY_UNSUPPORTED": "Adapter hiện tại chưa hỗ trợ downstream identity discovery.",
    "QUICK_CABLE_PROBE_UNSUPPORTED": "Adapter hiện tại chưa hỗ trợ quick A/B hostname probe.",
    "CABLE_MAPPING_CHANGED_DURING_PROBE": "Mapping OOB/target thay đổi trong lúc quick A/B; kết quả đã bị loại bỏ.",
    "IDENTITY_MAPPING_CHANGED_DURING_DISCOVERY": "Mapping OOB/target thay đổi trong lúc discovery; kết quả đã bị loại bỏ để tránh gắn nhầm identity.",
    "RECONCILE_TARGET_NOT_FOUND": "Không tìm thấy current target để đồng bộ alias OOB.",
    "RECONCILE_IDENTITY_REQUIRED": "Controlled reconciliation yêu cầu identity hiện tại đạt ACCEPTED/VALID và có actual hostname.",
    "RECONCILE_NOT_NEEDED": "Alias OOB đã khớp identity hiện tại; không có gì cần đồng bộ.",
    "RECONCILE_ALIAS_INVALID": "Alias mới không thuộc whitelist an toàn cho OOB vendor này.",
    "RECONCILE_VENDOR_UNSUPPORTED": "Vendor OOB này chưa hỗ trợ controlled reconciliation.",
    "RECONCILE_MAPPING_UNVERIFIED": "Mapping/physical console path chưa đủ tin cậy để cho phép write reconciliation.",
    "RECONCILE_PLAN_STALE": "Target/identity đã thay đổi sau lúc preview; cần tạo kế hoạch reconciliation mới.",
    "RECONCILE_TICKET_REQUIRED": "Controlled reconciliation bắt buộc Change/Ticket ID.",
    "RECONCILE_REASON_REQUIRED": "Controlled reconciliation bắt buộc lý do thay đổi.",
    "RECONCILE_NORMAL_CLI_REQUIRED": "Cisco reconciliation yêu cầu account NORMAL_CLI có quyền cấu hình.",
    "RECONCILE_WRITE_REJECTED": "OOB đã từ chối command controlled reconciliation.",
    "RECONCILE_PROMPT_UNVERIFIED": "Không xác minh được CLI state sau command reconciliation; operation đã fail-closed.",
    "RECONCILE_READBACK_FAILED": "Read-back sau reconciliation không khớp dữ liệu mong đợi; baseline phải tiếp tục STALE cho tới khi scan lại.",
    "RECONCILE_SCOPE_VIOLATION": "Read-back cho thấy dữ liệu ngoài alias/name đã thay đổi; tool đã chặn operation.",
    "RECONCILE_SAVE_FAILED": "Không chứng minh được cấu hình reconciliation đã được lưu/persist; cần kiểm tra OOB và scan lại.",
    "RECONCILE_WRITE_FAILED": "Controlled OOB reconciliation không hoàn tất; cần kiểm tra OOB và scan lại trước khi mở console.",
}

def friendly_error(exc: BaseException) -> str:
    code = getattr(exc, "error_code", "")
    if code in ERROR_MESSAGES_VI:
        return ERROR_MESSAGES_VI[code]
    if isinstance(exc, OOBManagerError):
        return str(exc) or f"Thao tác thất bại ({code or type(exc).__name__})."
    return (
        f"Lỗi kỹ thuật {type(exc).__name__}/"
        f"{code or 'UNHANDLED_ERROR'}. Xem log an toàn để khoanh vùng."
    )
