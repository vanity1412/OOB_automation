from __future__ import annotations

import hashlib
import json
import re
from typing import Mapping, Any

from oob_manager.models.device_identity import DeviceIdentity, IdentityVerification


VERIFICATION_STATUSES = (
    "INCONCLUSIVE",
    "VERIFIED_IDENTITY",
    "VERIFIED_MATCH",
    "VERIFIED_MISMATCH",
    "DEVICE_CHANGE_SUSPECTED",
)
VERIFICATION_SEVERITIES = ("INFO", "WARNING", "HIGH")
HARDWARE_CONTINUITIES = ("UNKNOWN", "FIRST_SEEN", "UNCHANGED", "CHANGED")


def _collapse_space(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def normalize_hostname(value: str) -> str:
    # Conservative normalization only: case, surrounding whitespace, final DNS dot.
    # Do not drop domain suffixes because that could hide a real mismatch.
    return _collapse_space(value).rstrip(".").casefold()


def normalize_alias(value: str) -> str:
    return normalize_hostname(value)


def normalize_serial(value: str) -> str:
    # Keep punctuation because it may be meaningful in a vendor serial; only remove
    # incidental whitespace/case differences.
    return re.sub(r"\s+", "", str(value or "")).upper()


def normalize_generic(value: str) -> str:
    return _collapse_space(value).casefold()


def identity_fingerprint(identity: DeviceIdentity) -> str:
    canonical = {
        "vendor": str(identity.vendor or "UNKNOWN").strip().upper(),
        "hostname": normalize_hostname(identity.actual_hostname),
        "model": normalize_generic(identity.model),
        "serial": normalize_serial(identity.serial_number),
    }
    encoded = json.dumps(canonical, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _row_value(row: Mapping[str, Any] | None, key: str, default: str = "") -> str:
    if row is None:
        return default
    try:
        value = row[key]
    except (KeyError, IndexError, TypeError):
        value = default
    return str(value or default)


def _row_int(row: Mapping[str, Any] | None, key: str) -> int | None:
    if row is None:
        return None
    try:
        value = row[key]
    except (KeyError, IndexError, TypeError):
        return None
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _event(code: str, severity: str, field: str, old: str, new: str, reason: str) -> dict[str, str]:
    return {
        "event_code": code,
        "severity": severity,
        "field_name": field,
        "old_value": old,
        "new_value": new,
        "reason": reason,
    }


def verify_identity(
    configured_alias: str,
    identity: DeviceIdentity,
    previous: Mapping[str, Any] | None,
) -> IdentityVerification:
    """Đối chiếu identity theo cách fail-closed, deterministic và audit-friendly."""

    current_fp = identity_fingerprint(identity) if identity.quality == "ACCEPTED" else ""
    previous_fp = _row_value(previous, "identity_fingerprint")
    if not previous_fp and previous is not None:
        legacy_identity = DeviceIdentity(
            actual_hostname=_row_value(previous, "actual_hostname"),
            vendor=_row_value(previous, "vendor", "UNKNOWN"),
            model=_row_value(previous, "model"),
            serial_number=_row_value(previous, "serial_number"),
            quality="ACCEPTED",
        )
        previous_fp = identity_fingerprint(legacy_identity)

    result = IdentityVerification(
        identity_fingerprint=current_fp,
        previous_identity_fingerprint=previous_fp,
        previous_identity_run_id=_row_int(previous, "last_identity_run_id"),
    )

    if identity.quality != "ACCEPTED":
        result.status = "INCONCLUSIVE"
        result.severity = "WARNING"
        result.reason_codes.append("IDENTITY_NOT_ACCEPTED")
        result.summary = "Identity chưa đạt ACCEPTED; không đủ cơ sở để xác minh continuity/mismatch."
        return result

    alias_norm = normalize_alias(configured_alias)
    hostname_norm = normalize_hostname(identity.actual_hostname)
    if alias_norm and hostname_norm and alias_norm == hostname_norm:
        alias_match = True
    elif alias_norm and hostname_norm:
        alias_match = False
    else:
        alias_match = None

    result.alias_comparison = (
        "EXACT_MATCH" if alias_match is True else "DIFFERENT" if alias_match is False else "UNKNOWN"
    )

    if previous is None:
        result.hardware_continuity = "FIRST_SEEN"
        result.reason_codes.append("FIRST_VERIFIED_IDENTITY")
        result.events.append(
            _event(
                "IDENTITY_FIRST_VERIFIED",
                "INFO",
                "identity",
                "",
                current_fp,
                "Lần đầu target có identity ACCEPTED.",
            )
        )
    else:
        prev_serial = normalize_serial(_row_value(previous, "serial_number"))
        cur_serial = normalize_serial(identity.serial_number)
        if prev_serial and cur_serial and prev_serial != cur_serial:
            result.hardware_continuity = "CHANGED"
            result.changed_fields.append("serial_number")
            result.reason_codes.append("SERIAL_CHANGED")
            result.events.append(
                _event(
                    "SERIAL_CHANGED",
                    "HIGH",
                    "serial_number",
                    _row_value(previous, "serial_number"),
                    identity.serial_number,
                    "Hardware serial khác identity ACCEPTED trước đó.",
                )
            )
            result.events.append(
                _event(
                    "DEVICE_REPLACED_SUSPECTED",
                    "HIGH",
                    "serial_number",
                    _row_value(previous, "serial_number"),
                    identity.serial_number,
                    "Serial thay đổi; có thể RMA/thay thiết bị hợp lệ hoặc sai console mapping. Cần operator xác nhận.",
                )
            )
        elif prev_serial and cur_serial:
            result.hardware_continuity = "UNCHANGED"
        else:
            result.hardware_continuity = "UNKNOWN"
            result.reason_codes.append("SERIAL_CONTINUITY_UNKNOWN")

        comparisons = (
            ("actual_hostname", normalize_hostname, "HOSTNAME_CHANGED", "WARNING"),
            ("vendor", lambda x: str(x or "").strip().upper(), "VENDOR_CHANGED", "WARNING"),
            ("model", normalize_generic, "MODEL_CHANGED", "WARNING"),
            ("software_version", normalize_generic, "SOFTWARE_VERSION_CHANGED", "INFO"),
        )
        for field_name, normalizer, event_code, severity in comparisons:
            old_value = _row_value(previous, field_name)
            new_value = str(getattr(identity, field_name) or "")
            old_norm = normalizer(old_value)
            new_norm = normalizer(new_value)
            if old_norm and new_norm and old_norm != new_norm:
                if field_name not in result.changed_fields:
                    result.changed_fields.append(field_name)
                result.reason_codes.append(event_code)
                result.events.append(
                    _event(event_code, severity, field_name, old_value, new_value, f"{field_name} khác identity ACCEPTED trước đó.")
                )

    previous_alias_comparison = _row_value(previous, "alias_comparison", "UNKNOWN")
    if alias_match is False:
        result.reason_codes.append("ALIAS_MISMATCH")
        # Avoid repeating the same mismatch event on every verification run.
        if previous is None or previous_alias_comparison != "DIFFERENT":
            result.events.append(
                _event(
                    "ALIAS_MISMATCH",
                    "WARNING",
                    "configured_alias_vs_actual_hostname",
                    configured_alias,
                    identity.actual_hostname,
                    "Alias cấu hình OOB khác hostname thực tế đã đọc từ thiết bị.",
                )
            )
    elif alias_match is True and previous is not None and previous_alias_comparison == "DIFFERENT":
        result.reason_codes.append("ALIAS_MATCH_RESTORED")
        result.events.append(
            _event(
                "ALIAS_MATCH_RESTORED",
                "INFO",
                "configured_alias_vs_actual_hostname",
                _row_value(previous, "configured_alias"),
                identity.actual_hostname,
                "Alias/hostname đã khớp trở lại sau lần xác minh trước bị mismatch.",
            )
        )

    if result.hardware_continuity == "CHANGED":
        result.status = "DEVICE_CHANGE_SUSPECTED"
        result.severity = "HIGH"
        result.summary = (
            "Serial thiết bị khác identity ACCEPTED trước đó. Không tự kết luận nguyên nhân; "
            "cần kiểm tra RMA/change ticket và console mapping."
        )
    elif alias_match is False:
        result.status = "VERIFIED_MISMATCH"
        result.severity = "WARNING"
        result.summary = "Identity đã xác minh nhưng hostname thực tế khác alias cấu hình OOB."
    else:
        result.status = "VERIFIED_MATCH" if alias_match is True else "VERIFIED_IDENTITY"
        # Non-serial metadata changes are noteworthy but do not break physical continuity.
        warning_fields = {"actual_hostname", "vendor", "model"}.intersection(result.changed_fields)
        result.severity = "WARNING" if warning_fields else "INFO"
        if alias_match is None:
            result.reason_codes.append("ALIAS_COMPARISON_UNAVAILABLE")
            result.summary = "Identity đã xác minh nhưng alias/hostname không đủ để kết luận MATCH/MISMATCH."
        elif previous is None:
            result.summary = "Identity ACCEPTED lần đầu; alias và hostname khớp."
        elif warning_fields:
            result.summary = "Serial không đổi nhưng có metadata identity thay đổi; cần kiểm tra thay đổi hợp lệ."
        elif "software_version" in result.changed_fields:
            result.summary = "Cùng thiết bị theo serial; software version đã thay đổi."
        else:
            result.summary = "Identity khớp alias và hardware serial ổn định."

    return result
