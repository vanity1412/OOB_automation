"""Controlled, human-approved reconciliation of an OOB display alias.

This is deliberately *not* remediation automation.  The service only updates the
human-readable alias/name on the already-verified physical console path.  It
never moves a Cisco reverse-Telnet endpoint, never changes a Vertiv serial port
number, and never runs automatically from change detection.
"""
from __future__ import annotations

import re

from oob_manager.config import profile_fingerprint
from oob_manager.exceptions import InteractiveSessionError, ValidationError
from oob_manager.models import ReconciliationPlan, ReconciliationResult, SessionCredentials
from oob_manager.utils.validation import normalize_alias
from oob_manager.vendors.factory import create_vendor_adapter
from oob_manager.vendors.vertiv.parsers import is_safe_vertiv_port_name

_CISCO_ALIAS_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")


class ReconciliationService:
    """Coordinate a narrow OOB-side alias update with full audit and locking."""

    def __init__(
        self,
        oob_repo,
        target_repo,
        identity_repo,
        reconciliation_repo,
        settings,
        lock_repo=None,
        adapter_factory=create_vendor_adapter,
    ) -> None:
        self.oob_repo = oob_repo
        self.target_repo = target_repo
        self.identity_repo = identity_repo
        self.reconciliation_repo = reconciliation_repo
        self.settings = settings
        self.lock_repo = lock_repo
        self.adapter_factory = adapter_factory

    @staticmethod
    def _physical_path(device, target) -> str:
        if device.vendor == "CISCO":
            line = f"line {target.console_line}" if target.console_line else "line chưa xác định"
            return (
                f"{target.menu_name}[{target.menu_item}] -> "
                f"{target.target_host}:{target.target_port} ({line})"
            )
        return f"serial port {target.console_line}"

    @staticmethod
    def _validate_alias(vendor: str, alias: str) -> str:
        value = (alias or "").strip()
        if not value:
            raise ValidationError("Alias mới không được để trống.", error_code="RECONCILE_ALIAS_INVALID")
        if vendor == "CISCO":
            if not _CISCO_ALIAS_RE.fullmatch(value):
                raise ValidationError(
                    "Alias Cisco chỉ được chứa chữ, số, '.', '_', ':', '-' và tối đa 128 ký tự.",
                    error_code="RECONCILE_ALIAS_INVALID",
                )
        elif vendor == "VERTIV":
            if not is_safe_vertiv_port_name(value) or ":" in value:
                raise ValidationError(
                    "Port Name Vertiv mới không thuộc whitelist an toàn cho CLI/direct SSH.",
                    error_code="RECONCILE_ALIAS_INVALID",
                )
        else:
            raise ValidationError(
                f"Reconciliation chưa hỗ trợ vendor OOB {vendor}.",
                error_code="RECONCILE_VENDOR_UNSUPPORTED",
            )
        return value

    def build_plan(self, target_id: int, new_alias: str | None = None) -> ReconciliationPlan:
        target = self.target_repo.get(target_id)
        if not target or not target.id:
            raise ValidationError("Không tìm thấy current target.", error_code="RECONCILE_TARGET_NOT_FOUND")
        if not target.is_complete:
            raise ValidationError("Target chưa có mapping hoàn chỉnh.", error_code="RECONCILE_MAPPING_UNVERIFIED")
        device = self.oob_repo.get(target.oob_id)
        if not device or not device.enabled:
            raise ValidationError("OOB không tồn tại hoặc đang bị vô hiệu hóa.")
        if device.mapping_stale:
            raise ValidationError(
                "Mapping OOB đang STALE; cần scan lại trước khi reconcile.",
                error_code="STALE_MAPPING",
            )
        provenance_ok, provenance_code, provenance_message = self.target_repo.verify_open_provenance(target_id)
        if not provenance_ok:
            raise ValidationError(
                provenance_message,
                error_code=provenance_code or "MAPPING_PROVENANCE_INVALID",
            )

        identity = self.identity_repo.get_current_for_target(target_id)
        if not identity:
            raise ValidationError(
                "Target chưa có identity ACCEPTED hiện tại; cần chạy chức năng xác minh identity trước.",
                error_code="RECONCILE_IDENTITY_REQUIRED",
            )
        if str(identity["identity_quality"] or "") != "ACCEPTED":
            raise ValidationError(
                "Identity hiện tại chưa đạt ACCEPTED.",
                error_code="RECONCILE_IDENTITY_REQUIRED",
            )
        if str(identity["mapping_validity"] or "") != "VALID":
            raise ValidationError(
                "Identity dựa trên mapping đã STALE; cần scan/discover lại.",
                error_code="STALE_MAPPING",
            )
        actual = (str(identity["actual_hostname"] or "")).strip()
        if not actual:
            raise ValidationError(
                "Identity chưa có actual hostname để đề xuất alias mới.",
                error_code="RECONCILE_IDENTITY_REQUIRED",
            )
        requested = self._validate_alias(device.vendor, new_alias if new_alias is not None else actual)
        if normalize_alias(requested) == normalize_alias(target.alias):
            raise ValidationError(
                "Alias OOB đã khớp identity; không có gì cần reconcile.",
                error_code="RECONCILE_NOT_NEEDED",
            )

        if device.vendor == "CISCO":
            if target.protocol != "TELNET" or target.menu_item is None or not target.menu_name:
                raise ValidationError(
                    "Cisco reconciliation chỉ hỗ trợ menu reverse-Telnet hoàn chỉnh.",
                    error_code="RECONCILE_MAPPING_UNVERIFIED",
                )
            proposed = [
                "configure terminal",
                f"menu {target.menu_name} text {target.menu_item} <giữ-prefix-hiển-thị>{requested}",
                "end",
                "copy system:running-config nvram:startup-config",
            ]
        else:
            if target.protocol != "VERTIV_CLI" or not target.console_line:
                raise ValidationError(
                    "Vertiv reconciliation yêu cầu serial port number đã xác minh.",
                    error_code="RECONCILE_MAPPING_UNVERIFIED",
                )
            proposed = [
                f"cd /ports/serial_ports/{target.console_line}/cas",
                f"set port_name={requested}",
                "commit",
            ]

        return ReconciliationPlan(
            target_id=int(target.id),
            oob_id=int(device.id),
            vendor=device.vendor,
            old_alias=target.alias,
            new_alias=requested,
            physical_path=self._physical_path(device, target),
            proposed_commands=proposed,
            identity_run_id=int(identity["last_identity_run_id"] or 0) or None,
        )

    def apply(
        self,
        plan: ReconciliationPlan,
        credentials: SessionCredentials,
        *,
        ticket_id: str,
        reason: str,
    ) -> tuple[int, ReconciliationResult]:
        ticket_id = (ticket_id or "").strip()
        reason = (reason or "").strip()
        if not ticket_id:
            raise ValidationError("Change/Ticket ID là bắt buộc.", error_code="RECONCILE_TICKET_REQUIRED")
        if not reason:
            raise ValidationError("Lý do reconciliation là bắt buộc.", error_code="RECONCILE_REASON_REQUIRED")
        if len(ticket_id) > 120 or len(reason) > 1000:
            raise ValidationError("Ticket/lý do vượt giới hạn độ dài an toàn.")

        # Rebuild immediately before the write so a stale UI selection cannot be
        # used after another scan/identity update.
        fresh = self.build_plan(plan.target_id, plan.new_alias)
        if (
            fresh.oob_id != plan.oob_id
            or fresh.vendor != plan.vendor
            or normalize_alias(fresh.old_alias) != normalize_alias(plan.old_alias)
            or fresh.identity_run_id != plan.identity_run_id
            or fresh.physical_path != plan.physical_path
        ):
            raise ValidationError(
                "Target/identity đã thay đổi sau khi preview; cần tạo preview mới.",
                error_code="RECONCILE_PLAN_STALE",
            )

        device = self.oob_repo.get(plan.oob_id)
        target = self.target_repo.get(plan.target_id)
        if not device or not target:
            raise ValidationError("OOB/target không còn tồn tại.", error_code="RECONCILE_PLAN_STALE")
        adapter = self.adapter_factory(device, self.settings)
        runtime_profile = getattr(adapter, "profile", None)
        if isinstance(runtime_profile, dict):
            device = self.oob_repo.sync_profile_fingerprint(
                int(device.id), profile_fingerprint(runtime_profile)
            )
            if device.mapping_stale:
                raise ValidationError(
                    "Vendor profile vừa thay đổi; phải scan lại trước reconcile.",
                    error_code="STALE_MAPPING",
                )

        lease = (
            self.lock_repo.start_lease(int(device.id), "RECONCILE")
            if self.lock_repo is not None
            else None
        )
        baseline_invalidated = False
        reconciliation_id: int | None = None
        try:
            reconciliation_id = self.reconciliation_repo.start(
                oob_id=int(device.id),
                target_id=int(target.id),
                identity_run_id=plan.identity_run_id,
                vendor=device.vendor,
                operator_username=credentials.username,
                ticket_id=ticket_id,
                reason=reason,
                old_alias=plan.old_alias,
                new_alias=plan.new_alias,
                physical_path=plan.physical_path,
                proposed_commands=plan.proposed_commands,
            )

            # One final provenance check while the exclusive OOB lease is held.
            ok, code, message = self.target_repo.verify_open_provenance(plan.target_id)
            if not ok:
                raise InteractiveSessionError(
                    message,
                    error_code=code or "MAPPING_PROVENANCE_INVALID",
                )

            # Invalidate the baseline *before* the first device write.  This is
            # deliberately conservative: if the process/DB/network fails after
            # the appliance accepted a command, no other operation may trust the
            # old baseline.  Even a successful rollback therefore requires a
            # fresh scan before console operations are allowed again.
            self.oob_repo.mark_mapping_reconciliation_pending(
                int(device.id),
                old_alias=plan.old_alias,
                new_alias=plan.new_alias,
                physical_path=plan.physical_path,
            )
            baseline_invalidated = True

            result = adapter.reconcile_alias(device, target, credentials, plan.new_alias)
            if not result.success:
                raise InteractiveSessionError(
                    result.verification_message or "OOB alias reconciliation failed.",
                    error_code=result.verification_code or "RECONCILE_WRITE_FAILED",
                )
            if lease is not None:
                lease.ensure_owned()

            self.reconciliation_repo.finish(
                reconciliation_id,
                status="APPLIED_VERIFIED",
                verification_code=result.verification_code,
                verification_message=result.verification_message,
                rollback_attempted=result.rollback_attempted,
                rollback_succeeded=result.rollback_succeeded,
                baseline_refresh_status="PENDING_RESCAN",
                applied_commands=result.applied_commands,
            )
            return reconciliation_id, result
        except Exception as exc:
            if reconciliation_id is not None:
                try:
                    self.reconciliation_repo.finish(
                        reconciliation_id,
                        status="FAILED",
                        verification_code=str(getattr(exc, "error_code", "RECONCILE_FAILED")),
                        verification_message=str(exc),
                        rollback_attempted=bool(getattr(exc, "rollback_attempted", False)),
                        rollback_succeeded=bool(getattr(exc, "rollback_succeeded", False)),
                        error_code=str(getattr(exc, "error_code", "RECONCILE_FAILED")),
                        error_message=str(exc),
                        baseline_refresh_status=(
                            "RESCAN_REQUIRED_AFTER_FAILURE" if baseline_invalidated else "NOT_RUN"
                        ),
                    )
                except Exception:
                    # Never mask the device/provenance failure with a secondary
                    # audit-write error. The baseline was already invalidated
                    # before any device write, so fail-closed safety is preserved.
                    pass
            raise
        finally:
            if lease is not None:
                lease.close(raise_on_heartbeat_error=False)

    def update_baseline_refresh(self, reconciliation_id: int, status: str) -> None:
        self.reconciliation_repo.update_baseline_refresh(reconciliation_id, status)
