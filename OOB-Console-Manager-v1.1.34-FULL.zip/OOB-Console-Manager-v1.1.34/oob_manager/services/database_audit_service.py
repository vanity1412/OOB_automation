"""Read-only semantic audit for OOB Console Manager database.

SQLite ``integrity_check`` only proves the database pages/b-tree structure are
valid.  This service additionally verifies application-level evidence chains so
an operator can trace a target back to the exact scan/raw command that created
it and detect accidental/tampered data changes.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from typing import Any

from oob_manager.config import profile_fingerprint
from oob_manager.downstream.verification import identity_fingerprint
from oob_manager.models.device_identity import DeviceIdentity
from oob_manager.utils.validation import is_valid_host, normalize_host


class DatabaseAuditService:
    """Collect deterministic, read-only data-quality findings."""

    SCAN_STATUSES = {"RUNNING", "SUCCESS", "PARTIAL", "FAILED", "REJECTED"}
    MAPPING_QUALITIES = {"ACCEPTED", "PARTIAL", "REJECTED"}
    TARGET_STATES = {"AVAILABLE", "BUSY", "BUSY_UNKNOWN_USER", "UNKNOWN", "INCOMPLETE"}
    TARGET_PROTOCOLS = {"TELNET", "SSH", "VERTIV_CLI", "OTHER", "UNKNOWN"}
    CONNECTION_STATUSES = {"RUNNING", "SUCCESS", "FAILED", "ABANDONED"}
    REQUIRED_POLICY_KEYS = {
        "connect_timeout",
        "command_timeout",
        "minimum_complete_ratio",
        "maximum_drop_ratio",
    }

    @classmethod
    def collect_issues(cls, conn: sqlite3.Connection) -> list[dict[str, object]]:
        issues = [
            dict(row)
            for row in conn.execute(
                """
                SELECT issue_code, severity, oob_id, scan_id, target_id, message
                FROM v_data_quality_issues
                """
            ).fetchall()
        ]

        def add(
            code: str,
            severity: str,
            message: str,
            *,
            oob_id: int | None = None,
            scan_id: int | None = None,
            target_id: int | None = None,
        ) -> None:
            issues.append(
                {
                    "issue_code": code,
                    "severity": severity,
                    "oob_id": oob_id,
                    "scan_id": scan_id,
                    "target_id": target_id,
                    "message": message,
                }
            )

        cls._audit_oob_hosts(conn, add)
        cls._audit_scan_metadata(conn, add)
        cls._audit_raw_outputs(conn, add)
        cls._audit_target_rows(conn, "console_targets", True, add)
        cls._audit_target_rows(conn, "console_snapshots", False, add)
        cls._audit_connection_rows(conn, add)
        cls._audit_identity_rows(conn, add)

        # Keep output stable and most actionable first.
        unique: dict[tuple[object, ...], dict[str, object]] = {}
        for item in issues:
            key = (
                item.get("issue_code"),
                item.get("severity"),
                item.get("oob_id"),
                item.get("scan_id"),
                item.get("target_id"),
                item.get("message"),
            )
            unique[key] = item
        result = list(unique.values())
        result.sort(
            key=lambda item: (
                0 if item.get("severity") == "ERROR" else 1,
                item.get("oob_id") or 0,
                item.get("scan_id") or 0,
                item.get("target_id") or 0,
                str(item.get("issue_code") or ""),
            )
        )
        return result

    @classmethod
    def _audit_identity_rows(cls, conn: sqlite3.Connection, add) -> None:
        tables = {row["name"] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "device_identity_runs" not in tables:
            return

        valid_status = {"RUNNING", "SUCCESS", "PARTIAL", "FAILED", "ABANDONED"}
        for row in conn.execute(
            """
            SELECT r.id,r.oob_id,r.target_id,r.mapping_scan_id,r.collector_version,
                   r.oob_host_at_run,r.oob_ssh_port_at_run,r.target_protocol_at_run,
                   r.status,r.identity_quality,r.identity_confidence,
                   r.runtime_mapping_verified,r.live_state,r.live_state_confident,
                   r.source_evidence_json,r.verification_status,r.verification_severity,
                   r.hardware_continuity,r.previous_identity_run_id,r.changed_fields,
                   r.verification_reason_codes,r.identity_fingerprint,r.previous_identity_fingerprint,
                   r.actual_hostname,r.detected_vendor,r.model,r.serial_number,
                   s.oob_id AS mapping_scan_oob_id,s.mapping_quality AS mapping_scan_quality,
                   s.baseline_updated AS mapping_scan_baseline_updated
            FROM device_identity_runs r
            LEFT JOIN scan_runs s ON s.id=r.mapping_scan_id
            ORDER BY r.id
            """
        ):
            run_id = int(row["id"])
            oob_id = int(row["oob_id"])
            target_id = row["target_id"]
            if row["status"] not in valid_status:
                add(
                    "INVALID_IDENTITY_RUN_STATUS", "ERROR",
                    f"Identity run {run_id} có status không hợp lệ.",
                    oob_id=oob_id, target_id=target_id,
                )
            valid_verification_status = {"INCONCLUSIVE","VERIFIED_IDENTITY","VERIFIED_MATCH","VERIFIED_MISMATCH","DEVICE_CHANGE_SUSPECTED"}
            if row["verification_status"] not in valid_verification_status:
                add(
                    "INVALID_IDENTITY_VERIFICATION_STATUS", "ERROR",
                    f"Identity run {run_id} có verification_status không hợp lệ.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["verification_severity"] not in {"INFO","WARNING","HIGH"}:
                add(
                    "INVALID_IDENTITY_VERIFICATION_SEVERITY", "ERROR",
                    f"Identity run {run_id} có verification_severity không hợp lệ.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["hardware_continuity"] not in {"UNKNOWN","FIRST_SEEN","UNCHANGED","CHANGED"}:
                add(
                    "INVALID_HARDWARE_CONTINUITY", "ERROR",
                    f"Identity run {run_id} có hardware_continuity không hợp lệ.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["status"] == "SUCCESS" and row["verification_status"] == "INCONCLUSIVE":
                add(
                    "SUCCESS_IDENTITY_NOT_VERIFIED", "ERROR",
                    f"Identity run {run_id} SUCCESS nhưng verification còn INCONCLUSIVE.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["status"] == "PARTIAL" and row["verification_status"] != "INCONCLUSIVE":
                add(
                    "PARTIAL_IDENTITY_HAS_VERIFIED_STATUS", "ERROR",
                    f"Identity run {run_id} PARTIAL nhưng có verification status xác quyết.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["verification_status"] == "DEVICE_CHANGE_SUSPECTED" and (
                row["hardware_continuity"] != "CHANGED" or row["verification_severity"] != "HIGH"
            ):
                add(
                    "DEVICE_CHANGE_VERIFICATION_INCONSISTENT", "ERROR",
                    f"Identity run {run_id} nghi thay thiết bị nhưng continuity/severity không nhất quán.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["status"] in {"SUCCESS", "PARTIAL"}:
                if not str(row["collector_version"] or "").strip():
                    add(
                        "IDENTITY_COLLECTOR_VERSION_MISSING", "ERROR",
                        f"Identity run {run_id} thiếu collector_version để tái dựng parser/policy.",
                        oob_id=oob_id, target_id=target_id,
                    )
                if not is_valid_host(str(row["oob_host_at_run"] or "")) or not (
                    1 <= int(row["oob_ssh_port_at_run"] or 0) <= 65535
                ):
                    add(
                        "IDENTITY_OOB_SNAPSHOT_INVALID", "ERROR",
                        f"Identity run {run_id} thiếu/không hợp lệ OOB endpoint snapshot.",
                        oob_id=oob_id, target_id=target_id,
                    )
                if row["mapping_scan_id"] is None:
                    add(
                        "IDENTITY_MAPPING_SCAN_MISSING", "ERROR",
                        f"Identity run {run_id} không trỏ tới scan mapping nguồn.",
                        oob_id=oob_id, target_id=target_id,
                    )
                elif (
                    row["mapping_scan_oob_id"] is None
                    or int(row["mapping_scan_oob_id"]) != oob_id
                    or row["mapping_scan_quality"] != "ACCEPTED"
                    or int(row["mapping_scan_baseline_updated"] or 0) != 1
                ):
                    add(
                        "IDENTITY_MAPPING_SCAN_PROVENANCE_INVALID", "ERROR",
                        f"Identity run {run_id} trỏ tới mapping scan không phải ACCEPTED baseline cùng OOB.",
                        oob_id=oob_id, scan_id=row["mapping_scan_id"], target_id=target_id,
                    )
                if int(row["runtime_mapping_verified"] or 0) != 1:
                    add(
                        "IDENTITY_RUN_MAPPING_NOT_VERIFIED", "ERROR",
                        f"Identity run {run_id} thành công nhưng runtime mapping chưa verified.",
                        oob_id=oob_id, target_id=target_id,
                    )
                if row["live_state"] != "AVAILABLE" or int(row["live_state_confident"] or 0) != 1:
                    add(
                        "IDENTITY_RUN_LINE_NOT_AVAILABLE", "ERROR",
                        f"Identity run {run_id} thành công nhưng live line không AVAILABLE/confident.",
                        oob_id=oob_id, target_id=target_id,
                    )
            _obj, valid = cls._json_object(row["source_evidence_json"])
            if not valid:
                add(
                    "INVALID_IDENTITY_SOURCE_JSON", "ERROR",
                    f"Identity run {run_id} có source_evidence_json không hợp lệ.",
                    oob_id=oob_id, target_id=target_id,
                )
            try:
                reasons = json.loads(str(row["verification_reason_codes"] or "[]"))
                reasons_valid = isinstance(reasons, list) and all(isinstance(item, str) for item in reasons)
            except (TypeError, ValueError, json.JSONDecodeError):
                reasons_valid = False
            if not reasons_valid:
                add(
                    "INVALID_IDENTITY_VERIFICATION_REASON_JSON", "ERROR",
                    f"Identity run {run_id} có verification_reason_codes không hợp lệ.",
                    oob_id=oob_id, target_id=target_id,
                )
            if row["status"] == "SUCCESS":
                expected_fp = identity_fingerprint(DeviceIdentity(
                    actual_hostname=str(row["actual_hostname"] or ""),
                    vendor=str(row["detected_vendor"] or "UNKNOWN"),
                    model=str(row["model"] or ""),
                    serial_number=str(row["serial_number"] or ""),
                    quality="ACCEPTED",
                ))
                if str(row["identity_fingerprint"] or "") != expected_fp:
                    add(
                        "IDENTITY_FINGERPRINT_MISMATCH", "ERROR",
                        f"Identity run {run_id} fingerprint không khớp dữ liệu identity đã lưu.",
                        oob_id=oob_id, target_id=target_id,
                    )
            if row["previous_identity_run_id"] is not None:
                previous = conn.execute(
                    "SELECT id,target_id,status,identity_quality FROM device_identity_runs WHERE id=?",
                    (row["previous_identity_run_id"],),
                ).fetchone()
                if (
                    previous is None
                    or int(previous["id"]) >= run_id
                    or previous["target_id"] != target_id
                    or previous["status"] != "SUCCESS"
                    or previous["identity_quality"] != "ACCEPTED"
                ):
                    add(
                        "PREVIOUS_IDENTITY_RUN_PROVENANCE_INVALID", "ERROR",
                        f"Identity run {run_id} trỏ previous_identity_run_id không phải SUCCESS/ACCEPTED run cũ cùng target.",
                        oob_id=oob_id, target_id=target_id,
                    )
            if row["status"] in {"SUCCESS", "PARTIAL"}:
                snapshot_count = int(conn.execute(
                    "SELECT COUNT(*) FROM device_identity_snapshots WHERE identity_run_id=?",
                    (run_id,),
                ).fetchone()[0])
                success_command_count = int(conn.execute(
                    "SELECT COUNT(*) FROM device_identity_raw_outputs WHERE identity_run_id=? AND success=1",
                    (run_id,),
                ).fetchone()[0])
                if snapshot_count != 1:
                    add(
                        "IDENTITY_SNAPSHOT_COUNT_INVALID", "ERROR",
                        f"Identity run {run_id} phải có đúng 1 snapshot, thực tế={snapshot_count}.",
                        oob_id=oob_id, target_id=target_id,
                    )
                if success_command_count < 1:
                    add(
                        "IDENTITY_SUCCESS_WITHOUT_RAW_EVIDENCE", "ERROR",
                        f"Identity run {run_id} thành công nhưng không có command evidence thành công.",
                        oob_id=oob_id, target_id=target_id,
                    )

        for row in conn.execute(
            """
            SELECT x.id,x.identity_run_id,x.raw_output,x.stored_output_sha256,x.stored_output_length,
                   r.oob_id,r.target_id
            FROM device_identity_raw_outputs x
            JOIN device_identity_runs r ON r.id=x.identity_run_id
            ORDER BY x.id
            """
        ):
            raw = str(row["raw_output"] or "")
            digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            if (
                int(row["stored_output_length"] or 0) != len(raw)
                or str(row["stored_output_sha256"] or "") != digest
            ):
                add(
                    "IDENTITY_RAW_OUTPUT_INTEGRITY_MISMATCH", "ERROR",
                    f"Identity raw output {row['id']} không khớp SHA256/length.",
                    oob_id=int(row["oob_id"]), target_id=row["target_id"],
                )

        for row in conn.execute(
            """
            SELECT i.target_id,i.oob_id,i.last_identity_run_id,i.identity_quality,i.source_evidence_json,
                   i.verification_status,i.verification_severity,i.hardware_continuity,i.identity_fingerprint,
                   i.actual_hostname,i.vendor,i.model,i.serial_number,
                   r.status AS run_status,r.identity_quality AS run_quality,r.target_id AS run_target_id,
                   r.verification_status AS run_verification_status,r.identity_fingerprint AS run_identity_fingerprint
            FROM device_identities i
            LEFT JOIN device_identity_runs r ON r.id=i.last_identity_run_id
            """
        ):
            if (
                row["run_status"] != "SUCCESS"
                or row["run_quality"] != "ACCEPTED"
                or int(row["run_target_id"] or 0) != int(row["target_id"])
                or row["identity_quality"] != "ACCEPTED"
                or row["verification_status"] == "INCONCLUSIVE"
                or row["verification_status"] != row["run_verification_status"]
                or str(row["identity_fingerprint"] or "") != str(row["run_identity_fingerprint"] or "")
            ):
                add(
                    "CURRENT_IDENTITY_PROVENANCE_INVALID", "ERROR",
                    "Current downstream identity không trỏ tới SUCCESS/ACCEPTED run cùng target.",
                    oob_id=int(row["oob_id"]), target_id=int(row["target_id"]),
                )
            _obj, valid = cls._json_object(row["source_evidence_json"])
            if not valid:
                add(
                    "INVALID_CURRENT_IDENTITY_SOURCE_JSON", "ERROR",
                    "Current downstream identity có source_evidence_json không hợp lệ.",
                    oob_id=int(row["oob_id"]), target_id=int(row["target_id"]),
                )
            expected_fp = identity_fingerprint(DeviceIdentity(
                actual_hostname=str(row["actual_hostname"] or ""),
                vendor=str(row["vendor"] or "UNKNOWN"),
                model=str(row["model"] or ""),
                serial_number=str(row["serial_number"] or ""),
                quality="ACCEPTED",
            ))
            if str(row["identity_fingerprint"] or "") != expected_fp:
                add(
                    "CURRENT_IDENTITY_FINGERPRINT_MISMATCH", "ERROR",
                    "Current downstream identity fingerprint không khớp identity fields.",
                    oob_id=int(row["oob_id"]), target_id=int(row["target_id"]),
                )

        if "device_identity_events" in tables:
            for row in conn.execute(
                """
                SELECT e.id,e.identity_run_id,e.target_id,e.oob_id,e.event_code,e.severity,e.evidence_json,
                       r.oob_id AS run_oob_id,r.target_id AS run_target_id,r.status AS run_status,
                       r.identity_quality AS run_quality
                FROM device_identity_events e
                LEFT JOIN device_identity_runs r ON r.id=e.identity_run_id
                ORDER BY e.id
                """
            ):
                if (
                    row["run_oob_id"] is None
                    or int(row["run_oob_id"]) != int(row["oob_id"])
                    or row["run_target_id"] != row["target_id"]
                    or row["run_status"] != "SUCCESS"
                    or row["run_quality"] != "ACCEPTED"
                ):
                    add(
                        "IDENTITY_EVENT_PROVENANCE_INVALID", "ERROR",
                        f"Identity event {row['id']} không trỏ tới SUCCESS/ACCEPTED run cùng OOB/target.",
                        oob_id=int(row["oob_id"]), target_id=row["target_id"],
                    )
                _event_obj, event_json_valid = cls._json_object(row["evidence_json"])
                if not event_json_valid:
                    add(
                        "INVALID_IDENTITY_EVENT_EVIDENCE_JSON", "ERROR",
                        f"Identity event {row['id']} có evidence_json không hợp lệ.",
                        oob_id=int(row["oob_id"]), target_id=row["target_id"],
                    )

    @staticmethod
    def _audit_oob_hosts(conn: sqlite3.Connection, add) -> None:
        canonical_endpoints: dict[tuple[str, int], list[tuple[int, str]]] = {}
        for row in conn.execute("SELECT id,host,ssh_port FROM oob_devices ORDER BY id"):
            oob_id = int(row["id"])
            host = str(row["host"] or "")
            port = int(row["ssh_port"] or 0)
            if not is_valid_host(host):
                add(
                    "INVALID_OOB_HOST",
                    "ERROR",
                    f"OOB host không hợp lệ: {host!r}",
                    oob_id=oob_id,
                )
                continue
            canonical = normalize_host(host)
            if host != canonical:
                add(
                    "NON_CANONICAL_OOB_HOST",
                    "WARNING",
                    f"OOB host nên chuẩn hóa từ {host!r} thành {canonical!r}; chỉnh/saving lại OOB để tránh endpoint trùng cách viết.",
                    oob_id=oob_id,
                )
            canonical_endpoints.setdefault((canonical, port), []).append((oob_id, host))
        for (host, port), entries in canonical_endpoints.items():
            if len(entries) > 1:
                ids = ", ".join(str(item[0]) for item in entries)
                for oob_id, _ in entries:
                    add(
                        "DUPLICATE_CANONICAL_OOB_ENDPOINT",
                        "ERROR",
                        f"Nhiều OOB cùng trỏ endpoint canonical {host}:{port} (OOB IDs: {ids}).",
                        oob_id=oob_id,
                    )

    @classmethod
    def _audit_scan_metadata(cls, conn: sqlite3.Connection, add) -> None:
        for row in conn.execute(
            """
            SELECT id,oob_id,status,mapping_quality,mapping_count,complete_count,
                   complete_ratio,warning_count,change_count,baseline_updated,
                   scanner_version,profile_fingerprint,profile_snapshot_json,
                   scan_policy_snapshot_json,config_snapshot_source
            FROM scan_runs ORDER BY id
            """
        ):
            scan_id = int(row["id"])
            oob_id = int(row["oob_id"])
            status = str(row["status"] or "")
            quality = str(row["mapping_quality"] or "")
            if status not in cls.SCAN_STATUSES:
                add(
                    "INVALID_SCAN_STATUS",
                    "ERROR",
                    f"Scan status không hợp lệ: {status!r}",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )
            if quality not in cls.MAPPING_QUALITIES:
                add(
                    "INVALID_MAPPING_QUALITY",
                    "ERROR",
                    f"Mapping quality không hợp lệ: {quality!r}",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )
            mapping_count = int(row["mapping_count"] or 0)
            complete_count = int(row["complete_count"] or 0)
            complete_ratio = float(row["complete_ratio"] or 0)
            if (
                mapping_count < 0
                or complete_count < 0
                or complete_count > mapping_count
                or not 0 <= complete_ratio <= 1
                or int(row["warning_count"] or 0) < 0
                or int(row["change_count"] or 0) < 0
            ):
                add(
                    "INVALID_SCAN_COUNTERS",
                    "ERROR",
                    "Scan có counter/complete_ratio ngoài miền hợp lệ.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )
            expected_ratio = (complete_count / mapping_count) if mapping_count else 0.0
            if abs(complete_ratio - expected_ratio) > 1e-9:
                add(
                    "SCAN_COMPLETE_RATIO_MISMATCH",
                    "ERROR",
                    f"complete_ratio={complete_ratio} không khớp complete_count/mapping_count={expected_ratio}.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )
            if status in {"SUCCESS", "PARTIAL", "REJECTED"}:
                snapshot_count = int(conn.execute(
                    "SELECT COUNT(*) FROM console_snapshots WHERE scan_id=?", (scan_id,)
                ).fetchone()[0])
                snapshot_complete = int(conn.execute(
                    "SELECT COUNT(*) FROM console_snapshots WHERE scan_id=? AND is_complete=1", (scan_id,)
                ).fetchone()[0])
                if snapshot_count != mapping_count or snapshot_complete != complete_count:
                    add(
                        "SCAN_SNAPSHOT_COUNTER_MISMATCH",
                        "ERROR",
                        f"Scan counters ({mapping_count}/{complete_count}) không khớp snapshot ({snapshot_count}/{snapshot_complete}).",
                        oob_id=oob_id,
                        scan_id=scan_id,
                    )
            actual_change_count = int(conn.execute(
                "SELECT COUNT(*) FROM change_events WHERE scan_id=?", (scan_id,)
            ).fetchone()[0])
            if actual_change_count != int(row["change_count"] or 0):
                add(
                    "SCAN_CHANGE_COUNT_MISMATCH",
                    "ERROR",
                    f"change_count={row['change_count']} nhưng change_events thực tế={actual_change_count}.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )

            profile_obj, profile_valid = cls._json_object(row["profile_snapshot_json"])
            policy_obj, policy_valid = cls._json_object(row["scan_policy_snapshot_json"])
            if not profile_valid:
                add(
                    "INVALID_PROFILE_SNAPSHOT_JSON",
                    "ERROR",
                    "profile_snapshot_json không phải JSON object hợp lệ.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )
            elif profile_obj:
                stored = str(row["profile_fingerprint"] or "")
                calculated = profile_fingerprint(profile_obj)
                if not stored or calculated != stored:
                    add(
                        "PROFILE_SNAPSHOT_HASH_MISMATCH",
                        "ERROR",
                        "Profile snapshot không khớp profile_fingerprint đã lưu.",
                        oob_id=oob_id,
                        scan_id=scan_id,
                    )
            elif cls._version_at_least(str(row["scanner_version"] or ""), (1, 1, 3)):
                add(
                    "PROFILE_SNAPSHOT_MISSING",
                    "ERROR",
                    "Scan phiên bản 1.1.3+ thiếu profile snapshot dùng để tái dựng parser.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )

            if not policy_valid:
                add(
                    "INVALID_SCAN_POLICY_JSON",
                    "ERROR",
                    "scan_policy_snapshot_json không phải JSON object hợp lệ.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )
            elif policy_obj:
                missing = sorted(cls.REQUIRED_POLICY_KEYS - set(policy_obj))
                if missing:
                    add(
                        "SCAN_POLICY_SNAPSHOT_INCOMPLETE",
                        "ERROR",
                        "Scan policy snapshot thiếu: " + ", ".join(missing),
                        oob_id=oob_id,
                        scan_id=scan_id,
                    )
            elif cls._version_at_least(str(row["scanner_version"] or ""), (1, 1, 3)):
                add(
                    "SCAN_POLICY_SNAPSHOT_MISSING",
                    "ERROR",
                    "Scan phiên bản 1.1.3+ thiếu snapshot ngưỡng quality/timeout.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                )

    @staticmethod
    def _audit_raw_outputs(conn: sqlite3.Connection, add) -> None:
        for row in conn.execute(
            """
            SELECT r.id,r.scan_id,s.oob_id,r.raw_output,r.stored_output_length,
                   r.stored_output_sha256
            FROM raw_outputs r JOIN scan_runs s ON s.id=r.scan_id
            ORDER BY r.id
            """
        ):
            raw = str(row["raw_output"] or "")
            digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            if len(raw) != int(row["stored_output_length"] or 0) or digest != str(
                row["stored_output_sha256"] or ""
            ):
                add(
                    "RAW_OUTPUT_INTEGRITY_MISMATCH",
                    "ERROR",
                    f"raw_output_id={row['id']} không khớp SHA256/length đã lưu.",
                    oob_id=row["oob_id"],
                    scan_id=row["scan_id"],
                )

    @classmethod
    def _audit_target_rows(
        cls,
        conn: sqlite3.Connection,
        table: str,
        current: bool,
        add,
    ) -> None:
        if table not in {"console_targets", "console_snapshots"}:
            raise ValueError("Target audit table không hợp lệ.")
        id_column = "id"
        scan_column = "last_scan_id" if current else "scan_id"
        rows = conn.execute(
            f"""
            SELECT {id_column} AS row_id,oob_id,{scan_column} AS source_scan_id,
                   state,state_confident,session_user,is_complete,protocol,target_host,target_port,console_line,alias,command,
                   state_evidence,mapping_source_command,
                   mapping_text_line,mapping_text_line_no,
                   mapping_command_line,mapping_command_line_no
            FROM {table} ORDER BY id
            """
        ).fetchall()
        raw_cache: dict[tuple[int, str], sqlite3.Row | None] = {}
        for row in rows:
            target_id = int(row["row_id"]) if current else None
            scan_id = int(row["source_scan_id"])
            oob_id = int(row["oob_id"])
            state = str(row["state"] or "")
            if state not in cls.TARGET_STATES:
                add(
                    "INVALID_TARGET_STATE",
                    "ERROR",
                    f"Target state không hợp lệ: {state!r}",
                    oob_id=oob_id,
                    scan_id=scan_id,
                    target_id=target_id,
                )
            state_confident = bool(row["state_confident"])
            session_user = str(row["session_user"] or "").strip()
            if state in {"AVAILABLE", "BUSY", "BUSY_UNKNOWN_USER"} and not state_confident:
                add(
                    "UNCONFIDENT_DEFINITE_TARGET_STATE",
                    "ERROR",
                    f"State {state} phải có state_confident=1.",
                    oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                )
            if state == "BUSY" and not session_user:
                add(
                    "BUSY_STATE_WITHOUT_USER",
                    "ERROR",
                    "State BUSY nhưng session_user trống; phải dùng BUSY_UNKNOWN_USER nếu không biết user.",
                    oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                )
            if state == "AVAILABLE" and session_user:
                add(
                    "AVAILABLE_STATE_WITH_USER",
                    "ERROR",
                    "State AVAILABLE nhưng session_user vẫn có giá trị.",
                    oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                )
            if current and not bool(row["is_complete"]):
                add(
                    "INCOMPLETE_CURRENT_TARGET_SEMANTIC",
                    "ERROR",
                    "Current target không được chứa core mapping incomplete.",
                    oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                )
            protocol = str(row["protocol"] or "")
            if protocol not in cls.TARGET_PROTOCOLS:
                add(
                    "INVALID_TARGET_PROTOCOL",
                    "ERROR",
                    f"Target protocol không hợp lệ: {protocol!r}",
                    oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                )
            if protocol == "VERTIV_CLI":
                console_line = row["console_line"]
                alias = str(row["alias"] or "").strip()
                command = str(row["command"] or "").strip()
                if console_line is None or int(console_line) <= 0:
                    add(
                        "VERTIV_TARGET_WITHOUT_SERIAL_PORT",
                        "ERROR",
                        "VERTIV_CLI target phải có console_line/serial port > 0.",
                        oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                    )
                if not alias or command != f"connect {alias}":
                    add(
                        "VERTIV_TARGET_COMMAND_MISMATCH",
                        "ERROR",
                        "VERTIV_CLI target command phải khớp chính xác 'connect <alias>'.",
                        oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                    )
                if int(row["target_port"] or 0) != 0:
                    add(
                        "VERTIV_TARGET_FAKE_TCP_ENDPOINT",
                        "WARNING",
                        "VERTIV_CLI target không nên giả lập target_port TCP; access/connect dùng port-name.",
                        oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                    )

            target_host = str(row["target_host"] or "")
            if target_host and is_valid_host(target_host) and target_host != normalize_host(target_host):
                add(
                    "NON_CANONICAL_TARGET_HOST",
                    "WARNING",
                    f"Target host {target_host!r} chưa canonical; dữ liệu mới sẽ tự chuẩn hóa.",
                    oob_id=oob_id, scan_id=scan_id, target_id=target_id,
                )
            _, evidence_valid = cls._json_object(row["state_evidence"])
            if not evidence_valid:
                add(
                    "INVALID_STATE_EVIDENCE_JSON",
                    "ERROR",
                    f"state_evidence trong {table} không phải JSON object hợp lệ.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                    target_id=target_id,
                )

            source_command = str(row["mapping_source_command"] or "")
            if not source_command:
                if current:
                    add(
                        "TARGET_PROVENANCE_UNAVAILABLE",
                        "WARNING",
                        "Current target không có mapping_source_command; có thể là dữ liệu legacy.",
                        oob_id=oob_id,
                        scan_id=scan_id,
                        target_id=target_id,
                    )
                continue

            cache_key = (scan_id, source_command)
            if cache_key not in raw_cache:
                raw_cache[cache_key] = conn.execute(
                    """
                    SELECT id,raw_output FROM raw_outputs
                    WHERE scan_id=? AND command_name='menu' AND command_text=?
                      AND is_core=1 AND success=1
                    ORDER BY id LIMIT 1
                    """,
                    cache_key,
                ).fetchone()
            source = raw_cache[cache_key]
            if source is None:
                add(
                    "CURRENT_TARGET_SOURCE_RAW_MISSING" if current else "SNAPSHOT_SOURCE_RAW_MISSING",
                    "ERROR",
                    "Không tìm thấy raw menu command đã sinh mapping.",
                    oob_id=oob_id,
                    scan_id=scan_id,
                    target_id=target_id,
                )
                continue

            raw_lines = str(source["raw_output"] or "").splitlines()
            cls._verify_source_line(
                raw_lines,
                row["mapping_text_line_no"],
                row["mapping_text_line"],
                "TEXT",
                current,
                oob_id,
                scan_id,
                target_id,
                add,
            )
            cls._verify_source_line(
                raw_lines,
                row["mapping_command_line_no"],
                row["mapping_command_line"],
                "COMMAND",
                current,
                oob_id,
                scan_id,
                target_id,
                add,
            )

    @staticmethod
    def _verify_source_line(
        raw_lines: list[str],
        line_no_value: object,
        stored_line_value: object,
        kind: str,
        current: bool,
        oob_id: int,
        scan_id: int,
        target_id: int | None,
        add,
    ) -> None:
        stored = str(stored_line_value or "").strip()
        if not stored:
            return
        if line_no_value is None:
            add(
                f"{'CURRENT' if current else 'SNAPSHOT'}_{kind}_SOURCE_LINE_NUMBER_MISSING",
                "WARNING",
                f"Có mapping_{kind.casefold()}_line nhưng thiếu số dòng provenance.",
                oob_id=oob_id,
                scan_id=scan_id,
                target_id=target_id,
            )
            return
        try:
            line_no = int(line_no_value)
        except (TypeError, ValueError):
            line_no = 0
        actual = raw_lines[line_no - 1].strip() if 1 <= line_no <= len(raw_lines) else ""
        if actual != stored:
            add(
                f"{'CURRENT' if current else 'SNAPSHOT'}_{kind}_SOURCE_LINE_MISMATCH",
                "ERROR",
                f"Provenance line {line_no} không khớp raw menu output đã lưu.",
                oob_id=oob_id,
                scan_id=scan_id,
                target_id=target_id,
            )

    @classmethod
    def _audit_connection_rows(cls, conn: sqlite3.Connection, add) -> None:
        for row in conn.execute(
            """
            SELECT id,oob_id,status,started_at,ended_at,mapping_last_scan_id,
                   console_path_verified,runtime_menu_verified,
                   runtime_mapping_verified,runtime_mapping_verification_code,
                   live_state,live_state_confident,live_session_user,
                   live_state_reason_code,live_state_evidence,live_state_checked_at,
                   ssh_host_key_fingerprint,ssh_host_key_policy
            FROM connection_history ORDER BY id
            """
        ):
            status = str(row["status"] or "")
            oob_id = int(row["oob_id"])
            connection_id = int(row["id"])
            if status not in cls.CONNECTION_STATUSES:
                add(
                    "INVALID_CONNECTION_STATUS",
                    "ERROR",
                    f"Connection status không hợp lệ: {status!r}",
                    oob_id=oob_id,
                )
            if status == "RUNNING" and row["ended_at"]:
                add(
                    "RUNNING_CONNECTION_HAS_END_TIME", "ERROR",
                    f"connection_id={connection_id} RUNNING nhưng đã có ended_at.", oob_id=oob_id,
                )
            if status in {"SUCCESS", "FAILED", "ABANDONED"} and not row["ended_at"]:
                add(
                    "FINISHED_CONNECTION_MISSING_END_TIME", "ERROR",
                    f"connection_id={connection_id} đã kết thúc nhưng thiếu ended_at.", oob_id=oob_id,
                )
            mapping_scan_id = row["mapping_last_scan_id"]
            if mapping_scan_id is not None:
                source_scan = conn.execute(
                    "SELECT oob_id,mapping_quality,baseline_updated FROM scan_runs WHERE id=?",
                    (mapping_scan_id,),
                ).fetchone()
                if source_scan is None:
                    add(
                        "CONNECTION_MAPPING_SCAN_MISSING", "ERROR",
                        f"connection_id={connection_id} trỏ mapping scan {mapping_scan_id} không tồn tại.",
                        oob_id=oob_id, scan_id=int(mapping_scan_id),
                    )
                elif int(source_scan["oob_id"]) != oob_id:
                    add(
                        "CONNECTION_MAPPING_SCAN_OOB_MISMATCH", "ERROR",
                        f"connection_id={connection_id} dùng mapping scan của OOB khác.",
                        oob_id=oob_id, scan_id=int(mapping_scan_id),
                    )
                elif source_scan["mapping_quality"] != "ACCEPTED" or int(source_scan["baseline_updated"] or 0) != 1:
                    add(
                        "CONNECTION_FROM_UNACCEPTED_MAPPING", "ERROR",
                        f"connection_id={connection_id} dùng mapping không được baseline xác nhận.",
                        oob_id=oob_id, scan_id=int(mapping_scan_id),
                    )
            if int(row["console_path_verified"] or 0) and not str(row["ssh_host_key_fingerprint"] or ""):
                add(
                    "VERIFIED_PATH_WITHOUT_SSH_FINGERPRINT", "WARNING",
                    f"connection_id={connection_id} có runtime path evidence nhưng thiếu SSH host-key fingerprint.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )

            live_state = str(row["live_state"] or "UNKNOWN")
            live_confident = bool(row["live_state_confident"] or 0)
            live_user = str(row["live_session_user"] or "").strip()
            if live_state not in cls.TARGET_STATES:
                add(
                    "INVALID_CONNECTION_LIVE_STATE", "ERROR",
                    f"connection_id={connection_id} có live_state không hợp lệ: {live_state!r}.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )
            if live_state in {"AVAILABLE", "BUSY", "BUSY_UNKNOWN_USER"} and not live_confident:
                add(
                    "UNCONFIDENT_CONNECTION_LIVE_STATE", "ERROR",
                    f"connection_id={connection_id} có state {live_state} nhưng confidence=false.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )
            if live_state == "BUSY" and not live_user:
                add(
                    "BUSY_CONNECTION_LIVE_STATE_WITHOUT_USER", "ERROR",
                    f"connection_id={connection_id} BUSY nhưng thiếu live_session_user.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )
            if live_state == "AVAILABLE" and live_user:
                add(
                    "AVAILABLE_CONNECTION_LIVE_STATE_WITH_USER", "ERROR",
                    f"connection_id={connection_id} AVAILABLE nhưng lại có live_session_user.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )
            _evidence, evidence_valid = cls._json_object(row["live_state_evidence"])
            if not evidence_valid:
                add(
                    "INVALID_CONNECTION_LIVE_STATE_EVIDENCE_JSON", "ERROR",
                    f"connection_id={connection_id} có live_state_evidence không phải JSON object hợp lệ.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )
            if int(row["runtime_mapping_verified"] or 0) and not str(row["runtime_mapping_verification_code"] or "").strip():
                add(
                    "RUNTIME_MAPPING_VERIFIED_WITHOUT_CODE", "WARNING",
                    f"connection_id={connection_id} runtime_mapping_verified=1 nhưng thiếu verification code.",
                    oob_id=oob_id, scan_id=int(mapping_scan_id) if mapping_scan_id is not None else None,
                )

    @staticmethod
    def _json_object(value: object) -> tuple[dict[str, Any], bool]:
        try:
            parsed = json.loads(str(value or "{}"))
        except (TypeError, json.JSONDecodeError):
            return {}, False
        return (parsed, True) if isinstance(parsed, dict) else ({}, False)

    @staticmethod
    def _version_at_least(value: str, minimum: tuple[int, int, int]) -> bool:
        try:
            parts = value.split(".")[:3]
            parsed = tuple(int(part) for part in parts)
            if len(parsed) != 3:
                return False
            return parsed >= minimum
        except (TypeError, ValueError):
            return False
