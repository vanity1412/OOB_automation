from __future__ import annotations

import inspect

from oob_manager.config import profile_fingerprint
from oob_manager.exceptions import InteractiveSessionError, ValidationError
from oob_manager.models import (
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    PortAuthenticationCredentials,
    RawCommandOutput,
    SessionCredentials,
)
from oob_manager.utils.security import sanitize_text, sanitize_value
from oob_manager.utils.validation import is_valid_host
from oob_manager.vendors.factory import create_vendor_adapter


class DeviceIdentityService:
    """Coordinate fail-closed downstream identity discovery."""

    def __init__(
        self,
        oob_repo,
        target_repo,
        identity_repo,
        settings,
        lock_repo=None,
        adapter_factory=create_vendor_adapter,
    ) -> None:
        self.oob_repo = oob_repo
        self.target_repo = target_repo
        self.identity_repo = identity_repo
        self.settings = settings
        self.lock_repo = lock_repo
        self.adapter_factory = adapter_factory

    @staticmethod
    def _mapping_signature(target) -> tuple[object, ...]:
        return (
            target.oob_id,
            target.menu_name.casefold(),
            target.menu_item,
            target.alias.casefold(),
            target.protocol,
            target.target_host.casefold(),
            target.target_port,
            target.command.strip(),
            target.last_scan_id,
        )

    @staticmethod
    def _sanitize_outputs(
        outputs: list[RawCommandOutput],
        secrets: tuple[str, ...],
    ) -> list[RawCommandOutput]:
        sanitized: list[RawCommandOutput] = []
        for item in outputs:
            raw_before = str(item.raw_output or "")
            error_before = str(item.error_message or "")
            raw_after = sanitize_text(raw_before, secrets)
            error_after = sanitize_text(error_before, secrets)
            sanitized.append(
                RawCommandOutput(
                    command_name=sanitize_text(item.command_name, secrets),
                    command_text=sanitize_text(item.command_text, secrets),
                    raw_output=raw_after,
                    success=bool(item.success),
                    error_message=error_after,
                    is_core=bool(item.is_core),
                    redaction_applied=(
                        bool(item.redaction_applied)
                        or raw_after != raw_before
                        or error_after != error_before
                    ),
                )
            )
        return sanitized

    @classmethod
    def _sanitize_result(
        cls,
        result: DownstreamDiscoveryResult,
        secrets: tuple[str, ...],
    ) -> DownstreamDiscoveryResult:
        result.raw_outputs = cls._sanitize_outputs(result.raw_outputs, secrets)
        result.downstream_prompt = sanitize_text(result.downstream_prompt, secrets)
        result.runtime_mapping_verification_message = sanitize_text(
            result.runtime_mapping_verification_message,
            secrets,
        )
        result.live_state_evidence = sanitize_text(result.live_state_evidence, secrets)
        result.identity.source_evidence = sanitize_value(
            result.identity.source_evidence,
            secrets,
        )
        result.metadata = sanitize_value(result.metadata, secrets)
        return result

    def discover(
        self,
        target_id: int,
        oob_credentials: SessionCredentials,
        downstream_credentials: DownstreamCredentials,
        port_credentials: PortAuthenticationCredentials | None = None,
        *,
        prefer_banner_hostname: bool = False,
        clear_line_recovery_callback=None,
        quick_hostname_only: bool = False,
    ) -> DownstreamDiscoveryResult:
        port_credentials = port_credentials or PortAuthenticationCredentials()
        target = self.target_repo.get(target_id)
        if not target:
            raise ValidationError("Không tìm thấy target.")
        if not target.is_complete:
            raise ValidationError(
                "Target chưa đủ dữ liệu để downstream discovery.",
                error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
            )

        device = self.oob_repo.get(target.oob_id)
        if not device or not device.enabled:
            raise ValidationError("OOB không tồn tại hoặc đang bị vô hiệu hóa.")
        if device.vendor == "CISCO":
            if target.protocol != "TELNET":
                raise ValidationError(
                    "Cisco downstream target phải là reverse-Telnet.",
                    error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
                )
            if not is_valid_host(target.target_host) or not 1 <= int(target.target_port) <= 65535:
                raise ValidationError(
                    "Endpoint target không hợp lệ.",
                    error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
                )
        elif device.vendor == "VERTIV":
            if (
                target.protocol != "VERTIV_CLI"
                or not isinstance(target.console_line, int)
                or target.console_line <= 0
            ):
                raise ValidationError(
                    "Vertiv downstream target phải là ACS access serial port hợp lệ.",
                    error_code="DOWNSTREAM_TARGET_UNSUPPORTED",
                )
        else:
            raise ValidationError(
                f"Downstream discovery chưa hỗ trợ OOB vendor {device.vendor}.",
                error_code="DOWNSTREAM_OOB_VENDOR_UNSUPPORTED",
            )

        adapter = self.adapter_factory(device, self.settings)
        runtime_profile = getattr(adapter, "profile", None)
        if isinstance(runtime_profile, dict):
            device = self.oob_repo.sync_profile_fingerprint(
                device.id,
                profile_fingerprint(runtime_profile),
            )
        if device.mapping_stale:
            raise ValidationError(
                "Mapping OOB đang STALE; cần scan lại trước downstream discovery.",
                error_code="STALE_MAPPING",
            )

        provenance_ok, provenance_code, provenance_message = (
            self.target_repo.verify_open_provenance(target_id)
        )
        if not provenance_ok:
            raise ValidationError(
                provenance_message + " Cần scan lại trước downstream discovery.",
                error_code=provenance_code or "MAPPING_PROVENANCE_INVALID",
            )

        initial_device_revision = int(device.connection_revision)
        initial_baseline_revision = int(device.baseline_revision)
        initial_signature = self._mapping_signature(target)
        lease = (
            self.lock_repo.start_lease(device.id, "IDENTITY_DISCOVERY")
            if self.lock_repo is not None
            else None
        )
        try:
            run_id = self.identity_repo.start(
                device,
                target,
                oob_credentials.username,
                downstream_credentials.username,
            )
        except Exception:
            if lease is not None:
                lease.close(raise_on_heartbeat_error=False)
            raise

        setattr(
            adapter,
            "transport_audit_callback",
            lambda algorithm, fingerprint, policy: self.identity_repo.update_ssh_host_key(
                run_id, algorithm, fingerprint, policy
            ),
        )
        # Runtime-only controls. Không persist credential/callback xuống DB.
        # Banner-first chỉ dùng cho cable A/B; full identity mặc định vẫn login +
        # chạy whitelist read-only command như trước.
        setattr(adapter, "prefer_banner_hostname", bool(prefer_banner_hostname))
        setattr(adapter, "clear_line_recovery_callback", clear_line_recovery_callback)
        setattr(adapter, "quick_hostname_only", bool(quick_hostname_only))

        secrets = (
            oob_credentials.password,
            oob_credentials.enable_password or "",
            port_credentials.resolved_password(oob_credentials.password),
            port_credentials.resolved_direct_password(oob_credentials.password),
            downstream_credentials.password,
        )
        try:
            discover_method = getattr(adapter, "discover_downstream_identity", None)
            if not callable(discover_method):
                raise InteractiveSessionError(
                    "Adapter OOB hiện tại chưa hỗ trợ downstream identity discovery.",
                    error_code="DOWNSTREAM_DISCOVERY_UNSUPPORTED",
                )
            parameters = inspect.signature(discover_method).parameters
            if "port_credentials" in parameters:
                result = discover_method(
                    device,
                    target,
                    oob_credentials,
                    downstream_credentials,
                    port_credentials=port_credentials,
                )
            else:
                # Backward compatibility for third-party/fake adapters using
                # the legacy signature. Do not catch TypeError from inside the adapter,
                # because that would hide a real implementation defect.
                result = discover_method(
                    device,
                    target,
                    oob_credentials,
                    downstream_credentials,
                )
            result = self._sanitize_result(result, secrets)

            current_device = self.oob_repo.get(device.id)
            current_target = self.target_repo.get(target_id)
            if (
                not current_device
                or not current_target
                or int(current_device.connection_revision) != initial_device_revision
                or int(current_device.baseline_revision) != initial_baseline_revision
                or current_device.mapping_stale
                or self._mapping_signature(current_target) != initial_signature
            ):
                raise InteractiveSessionError(
                    "OOB/target mapping thay đổi trong lúc downstream discovery; kết quả không được commit.",
                    error_code="IDENTITY_MAPPING_CHANGED_DURING_DISCOVERY",
                )
            provenance_ok, provenance_code, provenance_message = (
                self.target_repo.verify_open_provenance(target_id)
            )
            if not provenance_ok:
                raise InteractiveSessionError(
                    provenance_message,
                    error_code=provenance_code or "MAPPING_PROVENANCE_INVALID",
                )

            if lease is not None:
                lease.ensure_owned()
            self.identity_repo.finish(run_id, current_target, result)
            return result
        except Exception as exc:
            raw_outputs = self._sanitize_outputs(
                list(getattr(exc, "raw_outputs", []) or []),
                secrets,
            )
            identity = getattr(exc, "identity", None)
            if identity is not None:
                identity.source_evidence = sanitize_value(
                    identity.source_evidence,
                    secrets,
                )
            self.identity_repo.finish_failed(
                run_id,
                getattr(exc, "error_code", "DOWNSTREAM_DISCOVERY_FAILED"),
                sanitize_text(str(exc), secrets),
                raw_outputs=raw_outputs,
                identity=identity,
                runtime_mapping_verified=bool(
                    getattr(exc, "runtime_mapping_verified", False)
                ),
                runtime_mapping_code=sanitize_text(
                    getattr(exc, "runtime_mapping_verification_code", "UNVERIFIED")
                    or "UNVERIFIED",
                    secrets,
                ),
                runtime_mapping_message=sanitize_text(
                    getattr(exc, "runtime_mapping_verification_message", "") or "",
                    secrets,
                ),
                live_state=sanitize_text(
                    getattr(exc, "live_state", "UNKNOWN") or "UNKNOWN",
                    secrets,
                ),
                live_state_confident=bool(
                    getattr(exc, "live_state_confident", False)
                ),
                live_state_reason_code=sanitize_text(
                    getattr(exc, "live_state_reason_code", "") or "",
                    secrets,
                ),
                live_state_evidence=sanitize_text(
                    getattr(exc, "live_state_evidence", "{}") or "{}",
                    secrets,
                ),
                live_state_checked_at=sanitize_text(
                    getattr(exc, "live_state_checked_at", "") or "",
                    secrets,
                ),
                login_method=sanitize_text(
                    getattr(exc, "login_method", "UNKNOWN") or "UNKNOWN",
                    secrets,
                ),
                downstream_prompt=sanitize_text(
                    getattr(exc, "downstream_prompt", "") or "",
                    secrets,
                ),
            )
            raise
        finally:
            if lease is not None:
                lease.close(raise_on_heartbeat_error=False)
