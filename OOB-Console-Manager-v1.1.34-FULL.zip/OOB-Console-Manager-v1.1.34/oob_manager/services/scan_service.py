"""Workflow scan OOB và cập nhật database có quality gate."""
from __future__ import annotations

import json
import logging

from oob_manager import __version__
from oob_manager.config import load_profile, profile_fingerprint
from oob_manager.exceptions import InputCancelledError, OOBConfigurationChangedError, ValidationError
from oob_manager.models import RawCommandOutput, ScanResult, SessionCredentials
from oob_manager.services.change_service import ChangeService
from oob_manager.services.scan_quality import ScanQualityEvaluator
from oob_manager.utils.datetime_utils import utc_now
from oob_manager.utils.security import sanitize_text
from oob_manager.vendors.factory import create_vendor_adapter


class ScanService:
    """Điều phối adapter, mapping quality, snapshot, baseline và change event."""

    def __init__(
        self,
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        settings,
        adapter_factory=create_vendor_adapter,
        change_service: ChangeService | None = None,
    ) -> None:
        self.oob_repo = oob_repo
        self.target_repo = target_repo
        self.scan_repo = scan_repo
        self.change_repo = change_repo
        self.lock_repo = lock_repo
        self.settings = settings
        self.adapter_factory = adapter_factory
        self.change_service = change_service or ChangeService(self.target_repo.matcher)
        self.quality = ScanQualityEvaluator(
            settings.minimum_complete_ratio,
            settings.maximum_drop_ratio,
        )
        self.logger = logging.getLogger(__name__)

    def scan_one(
        self,
        oob_id: int,
        credentials: SessionCredentials,
        *,
        trigger_source: str = "SERVICE",
    ) -> ScanResult:
        device = self.oob_repo.get(oob_id)
        if not device:
            raise ValidationError("Không tìm thấy OOB.")
        if not device.enabled:
            raise ValidationError("OOB đang bị vô hiệu hóa.")

        started_at = utc_now()
        scan_id: int | None = None
        operation_lease = None
        secret_values = (credentials.password, credentials.enable_password or "")
        connection_revision = device.connection_revision
        baseline_was_stale = device.mapping_stale
        controlled_reconcile_stale = bool(
            baseline_was_stale
            and (device.baseline_stale_reason or "").startswith("CONTROLLED_RECONCILIATION:")
        )
        expected_profile_fingerprint = ""
        adapter = None

        try:
            operation_lease = self.lock_repo.start_lease(oob_id, "SCAN")
            profile = load_profile(device.vendor)
            expected_profile_fingerprint = profile_fingerprint(profile)
            # Profile là một phần logic parse/line calculation. Nếu profile đổi
            # mà baseline không bị invalidate, cùng raw config có thể bị hiểu theo
            # nghĩa khác. Đồng bộ fingerprint trước scan để fail closed.
            device = self.oob_repo.sync_profile_fingerprint(
                oob_id, expected_profile_fingerprint
            )
            connection_revision = device.connection_revision
            baseline_was_stale = device.mapping_stale
            controlled_reconcile_stale = bool(
                baseline_was_stale
                and (device.baseline_stale_reason or "").startswith("CONTROLLED_RECONCILIATION:")
            )
            scan_id = self.scan_repo.start(
                device,
                __version__,
                connection_revision,
                expected_profile_fingerprint,
                ssh_username=credentials.username,
                trigger_source=trigger_source,
                profile_snapshot_json=json.dumps(
                    profile, ensure_ascii=False, sort_keys=True, separators=(",", ":")
                ),
                scan_policy_snapshot_json=json.dumps(
                    {
                        "connect_timeout": self.settings.connect_timeout,
                        "banner_timeout": self.settings.banner_timeout,
                        "auth_timeout": self.settings.auth_timeout,
                        "shell_timeout": self.settings.shell_timeout,
                        "command_timeout": self.settings.command_timeout,
                        "connection_attempts": self.settings.connection_attempts,
                        "retry_delay": self.settings.retry_delay,
                        "operation_lock_lease_seconds": self.settings.operation_lock_lease_seconds,
                        "operation_lock_heartbeat_seconds": self.settings.operation_lock_heartbeat_seconds,
                        "minimum_complete_ratio": 1.0,
                        "maximum_drop_ratio": self.settings.maximum_drop_ratio,
                        "baseline_policy": "ALL_CORE_TARGETS_COMPLETE",
                    },
                    ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                ),
            )

            adapter = self.adapter_factory(device, self.settings)
            # Adapter records host-key evidence immediately after SSH authentication,
            # before long-running collection. If the process dies mid-scan, the
            # RUNNING/FAILED audit row still says which SSH server identity was reached.
            setattr(
                adapter,
                "transport_audit_callback",
                lambda algorithm, fingerprint, policy: self.scan_repo.update_ssh_host_key(
                    scan_id, algorithm, fingerprint, policy
                ),
            )
            vendor_data = adapter.collect(device, credentials)
            self._normalize_vendor_target_states(vendor_data)
            ssh_wrapper = getattr(adapter, "ssh", None)
            if scan_id is not None and ssh_wrapper is not None:
                self.scan_repo.update_ssh_host_key(
                    scan_id,
                    str(getattr(ssh_wrapper, "last_host_key_algorithm", "") or ""),
                    str(getattr(ssh_wrapper, "last_host_key_fingerprint", "") or ""),
                    str(getattr(ssh_wrapper, "host_key_policy", "") or ""),
                )
            # Usernames/session owners are audit identities, not secrets. Only
            # credential values are removed from persisted evidence.
            persistence_secrets = secret_values
            vendor_data.raw_outputs = self._sanitize_raw_outputs(
                vendor_data.raw_outputs,
                persistence_secrets,
            )
            self.scan_repo.save_raw_outputs(scan_id, vendor_data.raw_outputs)

            previous_targets = self.target_repo.list_current(oob_id)
            # Khi identity/connectivity đã đổi, baseline cũ không còn comparable.
            effective_generation_stale = baseline_was_stale and not controlled_reconcile_stale
            quality_reference = [] if effective_generation_stale else previous_targets
            quality = self.quality.evaluate(
                quality_reference,
                vendor_data.targets,
                vendor_data.raw_outputs,
                vendor_data,
            )
            for target in vendor_data.targets:
                target.oob_id = oob_id
                target.last_scan_id = scan_id

            events = []
            if quality.mapping_accepted and not effective_generation_stale:
                events = self.change_service.compare(
                    previous_targets,
                    vendor_data.targets,
                    oob_id=oob_id,
                    scan_id=scan_id,
                )

            warning_messages = list(
                dict.fromkeys([*quality.warnings, *quality.reasons])
            )
            findings = self._build_findings(vendor_data, quality)

            # Profile file có thể bị sửa giữa lúc scan. Không commit kết quả parse
            # theo profile cũ vào baseline mới.
            live_profile_fingerprint = profile_fingerprint(load_profile(device.vendor))
            if live_profile_fingerprint != expected_profile_fingerprint:
                self.oob_repo.sync_profile_fingerprint(oob_id, live_profile_fingerprint)
                raise OOBConfigurationChangedError(
                    "Vendor profile thay đổi trong lúc scan; từ chối cập nhật mapping."
                )

            operation_lease.ensure_owned()
            baseline_updated = self._persist_completed_scan(
                scan_id=scan_id,
                oob_id=oob_id,
                connection_revision=connection_revision,
                expected_profile_fingerprint=expected_profile_fingerprint,
                baseline_was_stale=effective_generation_stale,
                status=quality.status,
                mapping_quality=quality.mapping_quality,
                mapping_accepted=quality.mapping_accepted,
                targets=vendor_data.targets,
                previous_targets=previous_targets,
                events=events,
                warning_count=len(warning_messages),
                complete_ratio=quality.complete_ratio,
                error_code="SCAN_REJECTED" if quality.status == "REJECTED" else "",
                error_message="; ".join(quality.reasons),
                findings=findings,
            )

            return ScanResult(
                scan_id=scan_id,
                oob_id=oob_id,
                status=quality.status,
                mapping_count=len(vendor_data.targets),
                warning_count=len(warning_messages),
                mapping_quality=quality.mapping_quality,
                baseline_updated=baseline_updated,
                error_code="SCAN_REJECTED" if quality.status == "REJECTED" else "",
                error_message="; ".join(quality.reasons),
                started_at=started_at,
                finished_at=utc_now(),
            )
        except Exception as exc:
            error_code = getattr(exc, "error_code", "SCAN_FAILED")
            error_message = sanitize_text(str(exc), secret_values)
            if scan_id is not None and adapter is not None:
                ssh_wrapper = getattr(adapter, "ssh", None)
                if ssh_wrapper is not None:
                    try:
                        self.scan_repo.update_ssh_host_key(
                            scan_id,
                            str(getattr(ssh_wrapper, "last_host_key_algorithm", "") or ""),
                            str(getattr(ssh_wrapper, "last_host_key_fingerprint", "") or ""),
                            str(getattr(ssh_wrapper, "host_key_policy", "") or ""),
                        )
                    except Exception:
                        self.logger.error(
                            "Không thể lưu SSH host-key audit cho scan lỗi scan_id=%s",
                            scan_id,
                            extra={"operation": "scan_host_key_audit"},
                        )
            attached_raw_outputs = self._sanitize_raw_outputs(
                list(getattr(exc, "raw_outputs", []) or []),
                secret_values,
            )
            if scan_id is not None and attached_raw_outputs:
                try:
                    self.scan_repo.save_raw_outputs(scan_id, attached_raw_outputs)
                except Exception:
                    self.logger.error(
                        "Không thể lưu raw output của scan lỗi scan_id=%s",
                        scan_id,
                        extra={"operation": "scan_raw_failure"},
                    )
            self.logger.error(
                "Scan thất bại oob_id=%s scan_id=%s exception_type=%s code=%s",
                oob_id,
                scan_id,
                type(exc).__name__,
                error_code,
                extra={"operation": "scan"},
            )
            self.logger.debug(
                "Scan failure summary exception_type=%s code=%s",
                type(exc).__name__,
                error_code,
                extra={"operation": "scan_debug"},
            )
            if scan_id is not None:
                try:
                    with self.target_repo.db.transaction() as conn:
                        self.scan_repo.save_findings(
                            scan_id,
                            [{
                                "finding_type": "ERROR",
                                "severity": "ERROR",
                                "code": error_code,
                                "source": "scan_exception",
                                "message": error_message,
                            }],
                            conn=conn,
                        )
                        self.scan_repo.finish(
                            scan_id,
                            "FAILED",
                            error_code=error_code,
                            error_message=error_message,
                            mapping_quality="REJECTED",
                            baseline_updated=False,
                            conn=conn,
                        )
                        self.oob_repo.update_last_scan(oob_id, utc_now(), conn=conn)
                except Exception:
                    self.logger.error(
                        "Không thể ghi trạng thái FAILED cho scan_id=%s",
                        scan_id,
                        extra={"operation": "scan_persistence"},
                    )
            return ScanResult(
                scan_id=scan_id,
                oob_id=oob_id,
                status="FAILED",
                mapping_quality="REJECTED",
                baseline_updated=False,
                error_code=error_code,
                error_message=error_message,
                started_at=started_at,
                finished_at=utc_now(),
            )
        finally:
            if operation_lease is not None:
                try:
                    operation_lease.close(raise_on_heartbeat_error=False)
                except Exception:
                    self.logger.error(
                        "Không thể giải phóng operation lock oob_id=%s",
                        oob_id,
                        extra={"operation": "scan_lock_release"},
                    )

    def _persist_completed_scan(
        self,
        *,
        scan_id: int,
        oob_id: int,
        connection_revision: int,
        expected_profile_fingerprint: str,
        baseline_was_stale: bool,
        status: str,
        mapping_quality: str,
        mapping_accepted: bool,
        targets,
        previous_targets,
        events,
        warning_count: int,
        complete_ratio: float,
        error_code: str,
        error_message: str,
        findings: list[dict[str, str]],
    ) -> bool:
        complete_count = sum(1 for target in targets if target.is_complete)
        baseline_updated = False
        with self.target_repo.db.transaction() as conn:
            current_revision, current_profile_fingerprint = self.oob_repo.get_mapping_context(
                oob_id, conn=conn
            )
            if current_revision != connection_revision:
                raise OOBConfigurationChangedError(
                    "Cấu hình OOB thay đổi trong lúc scan; từ chối cập nhật mapping."
                )
            if current_profile_fingerprint != expected_profile_fingerprint:
                raise OOBConfigurationChangedError(
                    "Vendor profile thay đổi trong lúc scan; từ chối cập nhật mapping."
                )

            if mapping_accepted:
                if baseline_was_stale:
                    # Baseline generation mới: không nối identity với mapping của OOB cũ.
                    self.target_repo.reset_current(
                        oob_id,
                        scan_id,
                        targets,
                        conn=conn,
                    )
                else:
                    self.target_repo.replace_current(
                        oob_id,
                        scan_id,
                        targets,
                        conn=conn,
                    )
                self.target_repo.save_snapshot(
                    oob_id,
                    scan_id,
                    targets,
                    conn=conn,
                )
                if not baseline_was_stale:
                    self._refresh_event_target_ids(events, targets)
                    self.change_repo.save_all(events, conn=conn)
                self.oob_repo.mark_baseline_current(
                    oob_id,
                    connection_revision,
                    conn=conn,
                )
                baseline_updated = True
            elif status in {"PARTIAL", "REJECTED"}:
                # Dữ liệu mapping chưa đủ tin cậy: vẫn lưu snapshot để audit,
                # không thay current inventory và không sinh change event. Khi cấu hình
                # OOB đã đổi, baseline cũ không còn comparable nên tuyệt đối không gán
                # target_id lịch sử của OOB/revision cũ cho snapshot mới.
                if baseline_was_stale:
                    for target in targets:
                        target.id = None
                else:
                    match_result = self.target_repo.matcher.match(
                        previous_targets, targets
                    )
                    for old_target, new_target in match_result.pairs:
                        new_target.id = old_target.id
                self.target_repo.save_snapshot(
                    oob_id,
                    scan_id,
                    targets,
                    conn=conn,
                )

            self.scan_repo.save_findings(scan_id, findings, conn=conn)

            self.scan_repo.finish(
                scan_id,
                status,
                mapping_count=len(targets),
                warning_count=warning_count,
                complete_count=complete_count,
                complete_ratio=complete_ratio,
                change_count=len(events) if baseline_updated and not baseline_was_stale else 0,
                error_code=error_code,
                error_message=error_message,
                mapping_quality=mapping_quality,
                baseline_updated=baseline_updated,
                conn=conn,
            )
            self.oob_repo.update_last_scan(oob_id, utc_now(), conn=conn)
        return baseline_updated

    @staticmethod
    def _normalize_vendor_target_states(vendor_data) -> None:
        """Fail closed when a vendor adapter returns internally inconsistent state.

        Mapping fields are kept, but session/line telemetry is downgraded rather
        than allowing an unconfident ``AVAILABLE``/``BUSY`` value into current
        inventory. This protects generic/future adapters in addition to Cisco.
        """
        for target in vendor_data.targets:
            previous_state = target.state
            warning = ""
            if target.state in {"AVAILABLE", "BUSY", "BUSY_UNKNOWN_USER"} and not target.state_confident:
                target.state = "UNKNOWN"
                target.session_user = ""
                target.state_reason_code = "UNCONFIDENT_VENDOR_STATE_NORMALIZED"
                warning = f"{target.alias or target.menu_item}: state {previous_state} không có evidence/confidence; hạ về UNKNOWN."
            elif target.state == "BUSY" and not target.session_user.strip():
                target.state = "BUSY_UNKNOWN_USER"
                target.state_reason_code = "BUSY_WITHOUT_USER_NORMALIZED"
                warning = f"{target.alias or target.menu_item}: BUSY không có username; chuyển BUSY_UNKNOWN_USER."
            elif target.state == "AVAILABLE" and target.session_user.strip():
                target.state = "UNKNOWN"
                target.state_confident = False
                target.session_user = ""
                target.state_reason_code = "AVAILABLE_WITH_USER_NORMALIZED"
                warning = f"{target.alias or target.menu_item}: AVAILABLE nhưng có session_user; hạ về UNKNOWN."
            elif target.state == "UNKNOWN" and target.state_confident:
                target.state_confident = False
                target.state_reason_code = target.state_reason_code or "UNKNOWN_STATE_CONFIDENCE_NORMALIZED"
                warning = f"{target.alias or target.menu_item}: UNKNOWN không được đánh dấu confident; đã chuẩn hóa."

            if warning:
                try:
                    evidence = json.loads(target.state_evidence or "{}")
                    if not isinstance(evidence, dict):
                        evidence = {}
                except (TypeError, json.JSONDecodeError):
                    evidence = {}
                evidence["normalized_from_state"] = previous_state
                evidence["normalized_by"] = "ScanService"
                target.state_evidence = json.dumps(
                    evidence, ensure_ascii=False, sort_keys=True, separators=(",", ":")
                )
                vendor_data.warnings.append(warning)

    @staticmethod
    def _refresh_event_target_ids(events, targets) -> None:
        by_alias = {}
        by_endpoint = {}
        from oob_manager.utils.validation import normalize_alias

        for target in targets:
            alias_key = normalize_alias(target.alias)
            if alias_key:
                by_alias.setdefault(alias_key, []).append(target)
            if target.target_host and target.target_port:
                by_endpoint.setdefault(
                    (target.target_host.casefold(), target.target_port), []
                ).append(target)

        for event in events:
            data = event.new_data
            if not data or data.get("target_id") is not None:
                continue
            candidates = by_alias.get(normalize_alias(str(data.get("alias", ""))), [])
            if len(candidates) != 1:
                endpoint = (
                    str(data.get("target_host", "")).casefold(),
                    int(data.get("target_port", 0) or 0),
                )
                candidates = by_endpoint.get(endpoint, [])
            if len(candidates) == 1:
                data["target_id"] = candidates[0].id

    @staticmethod
    def _build_findings(vendor_data, quality) -> list[dict[str, str]]:
        findings: list[dict[str, str]] = []
        seen_messages: set[str] = set()

        def add(kind: str, severity: str, code: str, source: str, message: str) -> None:
            normalized = message.strip()
            if not normalized or normalized in seen_messages:
                return
            seen_messages.add(normalized)
            findings.append({
                "finding_type": kind,
                "severity": severity,
                "code": code,
                "source": source,
                "message": message,
            })

        for message in vendor_data.warnings:
            add("WARNING", "WARNING", "ADAPTER_WARNING", "adapter", message)
        for message in vendor_data.parser_errors:
            add("PARSER", "ERROR", "PARSER_ERROR", "parser", message)
        for message in quality.reasons:
            add("QUALITY", "WARNING", "QUALITY_REASON", "quality_gate", message)
        for message in quality.warnings:
            add("WARNING", "WARNING", "QUALITY_WARNING", "quality_gate", message)
        return findings

    @staticmethod
    def _sanitize_raw_outputs(
        outputs: list[RawCommandOutput],
        secrets: tuple[str, ...],
    ) -> list[RawCommandOutput]:
        for output in outputs:
            raw_before = output.raw_output
            error_before = output.error_message
            output.raw_output = sanitize_text(raw_before, secrets)
            output.error_message = sanitize_text(error_before, secrets)
            output.redaction_applied = (
                output.raw_output != raw_before or output.error_message != error_before
            )
        return outputs

    def scan_all(
        self,
        credential_provider,
        *,
        trigger_source: str = "SCAN_ALL",
        auth_failure_handler=None,
    ) -> list[ScanResult]:
        """Scan tuần tự tất cả OOB đang bật.

        ``InputCancelledError`` dừng toàn bộ batch. Khi có
        ``auth_failure_handler``, lỗi ``SSH_AUTHENTICATION_FAILED`` có thể được
        operator xử lý ngay theo RETRY/SKIP/CANCEL mà không thay credential chung
        của các OOB còn lại. Mỗi lần retry là một SSH attempt/scan audit thật trong DB.
        """
        results: list[ScanResult] = []
        for device in self.oob_repo.list_all(include_disabled=False):
            try:
                credentials = credential_provider(device)
                while True:
                    result = self.scan_one(
                        device.id,
                        credentials,
                        trigger_source=trigger_source,
                    )
                    credential_failure_codes = {
                        "SSH_AUTHENTICATION_FAILED",
                        "ENABLE_PASSWORD_REQUIRED",
                        "ENABLE_FAILED",
                    }
                    if (
                        result.error_code not in credential_failure_codes
                        or auth_failure_handler is None
                    ):
                        results.append(result)
                        break

                    action, replacement = auth_failure_handler(
                        device, credentials, result
                    )
                    normalized = str(action or "").strip().upper()
                    if normalized == "RETRY":
                        if replacement is None:
                            raise ValidationError(
                                "Auth retry yêu cầu credential thay thế."
                            )
                        credentials = replacement
                        continue
                    if normalized == "SKIP":
                        results.append(result)
                        break
                    if normalized == "CANCEL":
                        # Scan auth thất bại đã là một audit row thật. Trả batch-level
                        # CANCELLED gắn scan_id đó để CLI phân biệt với Ctrl+C trước khi
                        # scan_one() bắt đầu và có thể export đúng evidence lỗi.
                        results.append(
                            ScanResult(
                                scan_id=result.scan_id,
                                oob_id=device.id or 0,
                                status="CANCELLED",
                                mapping_quality="REJECTED",
                                baseline_updated=False,
                                error_code="INPUT_CANCELLED",
                                error_message=(
                                    "Operator đã hủy Scan All sau lỗi xác thực OOB; "
                                    f"attempt_error={result.error_code}."
                                ),
                                started_at=result.started_at,
                                finished_at=utc_now(),
                            )
                        )
                        return results
                    raise ValidationError(
                        "Auth failure handler phải trả RETRY, SKIP hoặc CANCEL."
                    )
            except InputCancelledError:
                results.append(
                    ScanResult(
                        scan_id=None,
                        oob_id=device.id or 0,
                        status="CANCELLED",
                        mapping_quality="REJECTED",
                        baseline_updated=False,
                        error_code="INPUT_CANCELLED",
                        error_message="Operator đã hủy Scan tất cả OOB.",
                        finished_at=utc_now(),
                    )
                )
                break
            except Exception as exc:
                results.append(
                    ScanResult(
                        scan_id=None,
                        oob_id=device.id or 0,
                        status="FAILED",
                        mapping_quality="REJECTED",
                        baseline_updated=False,
                        error_code=getattr(exc, "error_code", "CREDENTIAL_ERROR"),
                        error_message=sanitize_text(str(exc)),
                        finished_at=utc_now(),
                    )
                )
        return results
