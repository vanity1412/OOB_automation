"""Tìm target hiện tại theo nhiều trường."""
from __future__ import annotations

from dataclasses import dataclass

from oob_manager.models.console_target import ConsoleTarget


@dataclass(slots=True)
class ConsoleTargetSearchResult:
    target: ConsoleTarget
    oob_name: str
    oob_host: str
    oob_vendor: str
    mapping_stale: bool = False
    stale_reason: str = ""
    actual_hostname: str = ""
    actual_vendor: str = ""
    actual_model: str = ""
    actual_serial_number: str = ""
    identity_confidence: str = ""
    alias_comparison: str = ""


class SearchService:
    def __init__(self, repo) -> None:
        self.repo = repo
        self.last_truncated = False

    def search_targets(
        self,
        query: str,
        limit: int = 100,
    ) -> list[ConsoleTargetSearchResult]:
        normalized_query = query.strip()
        if not normalized_query:
            self.last_truncated = False
            return []

        safe_limit = min(max(limit, 1), 500)
        rows = self.repo.search(normalized_query, safe_limit + 1)
        self.last_truncated = len(rows) > safe_limit
        rows = rows[:safe_limit]
        return [
            ConsoleTargetSearchResult(
                target=self.repo._map(row),
                oob_name=row["oob_name"],
                oob_host=row["oob_host"],
                oob_vendor=row["oob_vendor"],
                mapping_stale=(
                    row["connection_revision"] != row["baseline_revision"]
                    or bool(
                        row["baseline_profile_fingerprint"]
                        and row["current_profile_fingerprint"]
                        != row["baseline_profile_fingerprint"]
                    )
                ),
                stale_reason=row["baseline_stale_reason"],
                actual_hostname=row["actual_hostname"] or "",
                actual_vendor=row["actual_vendor"] or "",
                actual_model=row["actual_model"] or "",
                actual_serial_number=row["actual_serial_number"] or "",
                identity_confidence=row["identity_confidence"] or "",
                alias_comparison=row["alias_comparison"] or "",
            )
            for row in rows
        ]
