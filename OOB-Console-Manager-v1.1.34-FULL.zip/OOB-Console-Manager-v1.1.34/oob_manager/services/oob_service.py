"""Business logic quản lý inventory OOB."""
from __future__ import annotations

from oob_manager.constants import CONNECTION_MODES, VENDORS
from oob_manager.exceptions import ValidationError
from oob_manager.models.oob_device import OOBDevice
from oob_manager.utils.datetime_utils import utc_now
from oob_manager.utils.validation import validate_host, validate_nonempty, validate_port


class OOBService:
    def __init__(self, repo) -> None:
        self.repo = repo

    def create(self, device: OOBDevice) -> OOBDevice:
        self._validate(device)
        device.created_at = utc_now()
        device.updated_at = device.created_at
        return self.repo.create(device)

    def update(self, device: OOBDevice) -> OOBDevice:
        return self.create_update_validation(device)

    def create_update_validation(self, device: OOBDevice) -> OOBDevice:
        self._validate(device)
        return self.repo.update(device)

    @staticmethod
    def _validate(device: OOBDevice) -> None:
        device.name = validate_nonempty(device.name, "Tên OOB")
        device.host = validate_host(device.host)
        device.ssh_port = validate_port(device.ssh_port)
        device.vendor = device.vendor.strip().upper()
        device.connection_mode = device.connection_mode.strip().upper()
        # Username mặc định là metadata vận hành, không phải secret. Password/enable
        # password vẫn tuyệt đối memory-only và không đi qua OOBDevice.
        device.default_username = str(device.default_username or "").strip()
        if any(ch in device.default_username for ch in ("\r", "\n", "\x00")):
            raise ValidationError("Username mặc định chứa ký tự điều khiển không hợp lệ.")
        if len(device.default_username) > 128:
            raise ValidationError("Username mặc định dài quá 128 ký tự.")
        device.notes = device.notes.strip()
        if device.vendor not in VENDORS:
            raise ValidationError("Nhà sản xuất không hợp lệ.")
        if device.connection_mode not in CONNECTION_MODES:
            raise ValidationError("Kiểu kết nối không hợp lệ.")
        if device.vendor == "CISCO" and not device.device_type:
            device.device_type = "cisco_ios"
        elif device.vendor == "VERTIV" and not device.device_type:
            device.device_type = "vertiv"

    def list_all(self, include_disabled: bool = True):
        return self.repo.list_all(include_disabled=include_disabled)

    def get(self, oob_id: int):
        return self.repo.get(oob_id)

    def disable(self, oob_id: int) -> None:
        self.repo.disable(oob_id)
