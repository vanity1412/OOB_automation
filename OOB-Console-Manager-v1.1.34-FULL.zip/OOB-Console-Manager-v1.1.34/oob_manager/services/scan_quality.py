"""Đánh giá độ tin cậy của dữ liệu scan trước khi cập nhật baseline."""
from __future__ import annotations

from collections import Counter

from oob_manager.models.console_target import ConsoleTarget
from oob_manager.models.scan_result import RawCommandOutput, ScanQualityResult, VendorScanData
from oob_manager.utils.validation import contains_dangerous_control


class ScanQualityEvaluator:
    """Tách độ hoàn chỉnh toàn scan khỏi chất lượng core mapping."""

    CLI_ERRORS = (
        "% invalid input",
        "% incomplete command",
        "% ambiguous command",
        "authorization failed",
        "unknown command",
    )

    def __init__(
        self,
        minimum_complete_ratio: float = 1.0,
        maximum_drop_ratio: float = 0.5,
    ) -> None:
        self.minimum_complete_ratio = minimum_complete_ratio
        self.maximum_drop_ratio = maximum_drop_ratio

    def evaluate(
        self,
        previous_targets: list[ConsoleTarget],
        current_targets: list[ConsoleTarget],
        raw_outputs: list[RawCommandOutput],
        vendor_data: VendorScanData,
    ) -> ScanQualityResult:
        warnings = list(vendor_data.warnings)

        if not vendor_data.connection_success:
            return ScanQualityResult(
                status="FAILED",
                mapping_quality="REJECTED",
                mapping_accepted=False,
                warnings=warnings,
                reasons=["Kết nối không thành công."],
                complete_ratio=0.0,
            )

        core_outputs = [output for output in raw_outputs if output.is_core]
        menu_succeeded = any(
            output.success and output.command_name == "menu" for output in core_outputs
        )
        if not core_outputs or not menu_succeeded:
            return ScanQualityResult(
                status="FAILED",
                mapping_quality="REJECTED",
                mapping_accepted=False,
                warnings=warnings,
                reasons=["Command menu chính không thành công."],
                complete_ratio=0.0,
            )

        # Chỉ đánh giá lỗi CLI trên output menu đã được adapter xác nhận thành công.
        # Cisco profile có thể có nhiều fallback command; một command đầu tiên
        # không được hỗ trợ không được phép "đầu độc" fallback sau đã chạy đúng.
        menu_raw = "\n".join(
            output.raw_output.casefold()
            for output in core_outputs
            if output.command_name == "menu" and output.success
        )
        if any(error_marker in menu_raw for error_marker in self.CLI_ERRORS):
            return ScanQualityResult(
                status="REJECTED",
                mapping_quality="REJECTED",
                mapping_accepted=False,
                warnings=warnings,
                reasons=["Output menu chứa lỗi CLI."],
                complete_ratio=0.0,
            )

        if not current_targets:
            reason = "Không tìm thấy target nào."
            if vendor_data.parser_errors:
                reason += " Parser báo: " + "; ".join(vendor_data.parser_errors)
            return ScanQualityResult(
                status="REJECTED",
                mapping_quality="REJECTED",
                mapping_accepted=False,
                warnings=warnings,
                reasons=[reason],
                complete_ratio=0.0,
            )

        complete_count = sum(1 for target in current_targets if target.is_complete)
        complete_ratio = complete_count / len(current_targets)

        dangerous_targets = [
            target for target in current_targets if contains_dangerous_control(target.command)
        ]
        if dangerous_targets:
            return ScanQualityResult(
                status="REJECTED",
                mapping_quality="REJECTED",
                mapping_accepted=False,
                warnings=warnings,
                reasons=["Phát hiện command có ký tự nguy hiểm."],
                complete_ratio=complete_ratio,
            )

        # Chỉ so với baseline cũ khi caller xác nhận hai baseline còn comparable.
        if previous_targets:
            drop_ratio = max(0, len(previous_targets) - len(current_targets)) / len(
                previous_targets
            )
            if drop_ratio > self.maximum_drop_ratio:
                return ScanQualityResult(
                    status="REJECTED",
                    mapping_quality="REJECTED",
                    mapping_accepted=False,
                    warnings=warnings,
                    reasons=[f"Số target giảm bất thường {drop_ratio:.0%}."],
                    complete_ratio=complete_ratio,
                )

        mapping_reasons: list[str] = []
        incomplete_count = len(current_targets) - complete_count
        if incomplete_count:
            mapping_reasons.append(
                f"Có {incomplete_count} target core mapping chưa đầy đủ."
            )
        # v1.1.8 production policy is intentionally strict: accepted baseline
        # requires every discovered core target to be complete. The historical
        # ratio setting is retained only for old database snapshots.

        endpoint_counts = Counter(
            (target.target_host.casefold(), target.target_port)
            for target in current_targets
            if target.target_host and target.target_port
        )
        duplicate_endpoints = [
            f"{host}:{port}"
            for (host, port), count in endpoint_counts.items()
            if count > 1
        ]
        if duplicate_endpoints:
            message = "Duplicate endpoint cần kiểm tra: " + ", ".join(
                duplicate_endpoints
            )
            warnings.append(message)
            mapping_reasons.append(message)

        if vendor_data.parser_errors:
            mapping_reasons.append(
                "Parser có lỗi một phần: " + "; ".join(vendor_data.parser_errors)
            )

        optional_failed = sorted(
            {
                output.command_name
                for output in raw_outputs
                if not output.is_core and not output.success
            }
        )
        telemetry_reasons: list[str] = []
        if optional_failed:
            telemetry_reasons.append(
                "Command phụ thất bại: " + ", ".join(optional_failed)
            )
        metadata = vendor_data.metadata or {}
        if (
            metadata.get("show_users_success")
            and metadata.get("session_confident") is False
        ):
            telemetry_reasons.append(
                "Parser show users không đủ tin cậy để kết luận session."
            )
        if (
            metadata.get("show_line_success")
            and metadata.get("show_line_confident") is False
        ):
            telemetry_reasons.append(
                "Parser show line không đủ tin cậy để kết luận line."
            )

        if mapping_reasons:
            return ScanQualityResult(
                status="PARTIAL",
                mapping_quality="PARTIAL",
                mapping_accepted=False,
                warnings=warnings,
                reasons=[*mapping_reasons, *telemetry_reasons],
                complete_ratio=complete_ratio,
            )

        if telemetry_reasons:
            # Scan tổng thể chưa hoàn chỉnh, nhưng core mapping đủ tin cậy để cập nhật.
            return ScanQualityResult(
                status="PARTIAL",
                mapping_quality="ACCEPTED",
                mapping_accepted=True,
                warnings=warnings,
                reasons=telemetry_reasons,
                complete_ratio=complete_ratio,
            )

        return ScanQualityResult(
            status="SUCCESS",
            mapping_quality="ACCEPTED",
            mapping_accepted=True,
            warnings=warnings,
            reasons=[],
            complete_ratio=complete_ratio,
        )
