"""Đối chiếu target giữa hai snapshot mà không dùng menu item làm identity chính."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Hashable

from oob_manager.models.console_target import ConsoleTarget
from oob_manager.utils.validation import normalize_alias

TargetKey = Callable[[ConsoleTarget], Hashable | None]


@dataclass(slots=True)
class TargetMatchResult:
    """Kết quả ghép target cũ và mới."""

    pairs: list[tuple[ConsoleTarget, ConsoleTarget]] = field(default_factory=list)
    previous_unmatched: list[ConsoleTarget] = field(default_factory=list)
    current_unmatched: list[ConsoleTarget] = field(default_factory=list)


class TargetMatcher:
    """Ghép target theo nhiều tầng identity, chỉ ghép khi khóa là duy nhất hai phía."""

    def match(
        self,
        previous_targets: list[ConsoleTarget],
        current_targets: list[ConsoleTarget],
    ) -> TargetMatchResult:
        old_remaining = list(range(len(previous_targets)))
        new_remaining = list(range(len(current_targets)))
        matched_indices: list[tuple[int, int]] = []

        stages: tuple[TargetKey, ...] = (
            lambda target: ("id", target.id) if target.id is not None else None,
            lambda target: (
                "alias",
                normalize_alias(target.alias),
            )
            if normalize_alias(target.alias)
            else None,
            lambda target: (
                "endpoint",
                target.target_host.casefold(),
                target.target_port,
            )
            if target.target_host and target.target_port
            else None,
            lambda target: (
                "host_console_line",
                target.target_host.casefold(),
                target.console_line,
            )
            if target.target_host and target.console_line is not None
            else None,
        )

        for key_func in stages:
            stage_pairs = self._unique_stage(
                previous_targets,
                current_targets,
                old_remaining,
                new_remaining,
                key_func,
            )
            for old_index, new_index in stage_pairs:
                matched_indices.append((old_index, new_index))
                old_remaining.remove(old_index)
                new_remaining.remove(new_index)

        return TargetMatchResult(
            pairs=[
                (previous_targets[old_index], current_targets[new_index])
                for old_index, new_index in matched_indices
            ],
            previous_unmatched=[previous_targets[index] for index in old_remaining],
            current_unmatched=[current_targets[index] for index in new_remaining],
        )

    @staticmethod
    def _unique_stage(
        previous_targets: list[ConsoleTarget],
        current_targets: list[ConsoleTarget],
        old_remaining: list[int],
        new_remaining: list[int],
        key_func: TargetKey,
    ) -> list[tuple[int, int]]:
        old_by_key: dict[Hashable, list[int]] = {}
        new_by_key: dict[Hashable, list[int]] = {}

        for index in old_remaining:
            key = key_func(previous_targets[index])
            if key is not None:
                old_by_key.setdefault(key, []).append(index)
        for index in new_remaining:
            key = key_func(current_targets[index])
            if key is not None:
                new_by_key.setdefault(key, []).append(index)

        pairs: list[tuple[int, int]] = []
        for key, old_indices in old_by_key.items():
            new_indices = new_by_key.get(key, [])
            if len(old_indices) == 1 and len(new_indices) == 1:
                pairs.append((old_indices[0], new_indices[0]))
        return pairs
