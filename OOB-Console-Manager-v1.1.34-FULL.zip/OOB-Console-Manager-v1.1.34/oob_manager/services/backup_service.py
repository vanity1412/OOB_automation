"""Sao lưu SQLite bằng backup API và kiểm tra integrity."""
from __future__ import annotations

from pathlib import Path
import hashlib
import sqlite3

from oob_manager.exceptions import DatabaseError
from oob_manager.utils.datetime_utils import utc_now
from oob_manager.utils.paths import BACKUP_DIR


class BackupService:
    def __init__(self, db, backup_dir: Path | None = None) -> None:
        self.db = db
        self.backup_dir = backup_dir

    def create_backup(self) -> Path:
        backup_root = self.backup_dir or BACKUP_DIR
        now_local = utc_now().astimezone()
        backup_dir = Path(backup_root) / now_local.strftime("%Y-%m-%d")
        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = now_local.strftime("%H%M%S")
        destination = self._available_path(
            backup_dir / f"oob_manager_{timestamp}.db"
        )

        source = self.db.connect()
        target = sqlite3.connect(destination)
        try:
            source.backup(target)
        finally:
            target.close()
            source.close()

        if not destination.exists() or destination.stat().st_size <= 0:
            raise DatabaseError("File backup không hợp lệ.")

        check_connection = sqlite3.connect(destination)
        try:
            integrity_result = check_connection.execute(
                "PRAGMA integrity_check"
            ).fetchone()[0]
            foreign_key_errors = check_connection.execute(
                "PRAGMA foreign_key_check"
            ).fetchall()
        finally:
            check_connection.close()

        if integrity_result != "ok" or foreign_key_errors:
            destination.unlink(missing_ok=True)
            detail = integrity_result if integrity_result != "ok" else "foreign_key_check"
            raise DatabaseError(f"Backup kiểm tra toàn vẹn thất bại: {detail}")

        # Sidecar checksum giúp đối chiếu file backup sau khi copy sang máy/NAS khác.
        # Đây là integrity checksum, không phải chữ ký chống người có quyền sửa cả
        # file DB lẫn checksum.
        digest = hashlib.sha256(destination.read_bytes()).hexdigest()
        checksum_path = destination.with_suffix(destination.suffix + ".sha256")
        checksum_path.write_text(
            f"{digest}  {destination.name}\n",
            encoding="ascii",
        )
        return destination

    @staticmethod
    def _available_path(path: Path) -> Path:
        if not path.exists():
            return path
        counter = 1
        while True:
            candidate = path.with_name(f"{path.stem}_{counter:02d}{path.suffix}")
            if not candidate.exists():
                return candidate
            counter += 1
