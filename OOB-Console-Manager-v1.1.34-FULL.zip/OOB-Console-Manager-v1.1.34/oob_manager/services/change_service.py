"""Phát hiện thay đổi giữa hai snapshot console target."""
from __future__ import annotations

from oob_manager.models.change_event import ChangeEvent
from oob_manager.models.console_target import ConsoleTarget
from oob_manager.services.target_matching import TargetMatcher
from oob_manager.utils.validation import normalize_alias
from oob_manager.utils.security import redact_username
import re

TELNET_COMMAND_RE = re.compile(r"^telnet\s+\S+\s+\d+(?P<suffix>\s+/stream)?$", re.I)


class ChangeService:
    """So sánh target cũ/mới và sinh event có cấu trúc."""

    def __init__(self, matcher: TargetMatcher | None = None) -> None:
        self.matcher = matcher or TargetMatcher()

    def compare(
        self,
        previous_targets: list[ConsoleTarget],
        current_targets: list[ConsoleTarget],
        *,
        oob_id: int = 0,
        scan_id: int = 0,
    ) -> list[ChangeEvent]:
        match_result = self.matcher.match(previous_targets, current_targets)
        events: list[ChangeEvent] = []

        def compact(target: ConsoleTarget) -> dict[str, object]:
            return {
                "target_id": target.id,
                "menu_name": target.menu_name,
                "menu_item": target.menu_item,
                "alias": target.alias,
                "command": target.command,
                "protocol": target.protocol,
                "target_host": target.target_host,
                "target_port": target.target_port,
                "console_line": target.console_line,
                "console_line_source": target.console_line_source,
                "state": target.state,
                "state_confident": target.state_confident,
                "state_reason_code": target.state_reason_code,
                "session_user": redact_username(target.session_user),
                "mapping_source_command": target.mapping_source_command,
                "is_complete": target.is_complete,
            }

        def emit(
            code: str,
            old_target: ConsoleTarget | None = None,
            new_target: ConsoleTarget | None = None,
        ) -> None:
            identity_target = new_target or old_target
            assert identity_target is not None
            identity = normalize_alias(identity_target.alias)
            if not identity:
                identity = f"{identity_target.target_host}:{identity_target.target_port}"
            events.append(
                ChangeEvent(
                    oob_id=oob_id,
                    scan_id=scan_id,
                    event_code=code,
                    target_identity=identity,
                    old_data=compact(old_target) if old_target else None,
                    new_data=compact(new_target) if new_target else None,
                )
            )

        for old_target, new_target in match_result.pairs:
            # Giữ stable identity cho event và bước persistence tiếp theo.
            new_target.id = old_target.id
            location_change_count = sum(
                (
                    old_target.menu_name != new_target.menu_name,
                    old_target.menu_item != new_target.menu_item,
                    old_target.target_host != new_target.target_host,
                    old_target.target_port != new_target.target_port,
                )
            )
            same_alias = (
                normalize_alias(old_target.alias) != ""
                and normalize_alias(old_target.alias) == normalize_alias(new_target.alias)
            )
            moved = same_alias and location_change_count >= 2

            if moved:
                emit("CONSOLE_TARGET_MOVED", old_target, new_target)
            else:
                if old_target.target_host != new_target.target_host:
                    emit("CONSOLE_TARGET_HOST_CHANGED", old_target, new_target)
                if old_target.target_port != new_target.target_port:
                    emit("CONSOLE_TARGET_PORT_CHANGED", old_target, new_target)
                if old_target.menu_item != new_target.menu_item:
                    emit("CONSOLE_MENU_ITEM_CHANGED", old_target, new_target)
                if old_target.menu_name != new_target.menu_name:
                    emit("CONSOLE_MENU_CHANGED", old_target, new_target)

            if normalize_alias(old_target.alias) != normalize_alias(new_target.alias):
                emit("CONSOLE_ALIAS_CHANGED", old_target, new_target)
            if old_target.command != new_target.command and not self._command_change_explained_by_endpoint(
                old_target, new_target
            ):
                emit("CONSOLE_COMMAND_CHANGED", old_target, new_target)
            if old_target.console_line != new_target.console_line:
                emit("CONSOLE_LINE_CHANGED", old_target, new_target)
            if (
                old_target.state_confident
                and new_target.state_confident
                and old_target.state != new_target.state
            ):
                emit("CONSOLE_STATE_CHANGED", old_target, new_target)

        for old_target in match_result.previous_unmatched:
            emit("CONSOLE_TARGET_MISSING", old_target, None)
        for new_target in match_result.current_unmatched:
            emit("NEW_CONSOLE_TARGET", None, new_target)

        return events

    @staticmethod
    def _command_change_explained_by_endpoint(
        old_target: ConsoleTarget,
        new_target: ConsoleTarget,
    ) -> bool:
        """Không tạo event command riêng nếu telnet command chỉ đổi host/port tương ứng."""
        if old_target.protocol != "TELNET" or new_target.protocol != "TELNET":
            return False
        old_match = TELNET_COMMAND_RE.fullmatch(old_target.command.strip())
        new_match = TELNET_COMMAND_RE.fullmatch(new_target.command.strip())
        if not old_match or not new_match:
            return False
        endpoint_changed = (
            old_target.target_host != new_target.target_host
            or old_target.target_port != new_target.target_port
        )
        return endpoint_changed and (old_match.group("suffix") or "").casefold() == (
            new_match.group("suffix") or ""
        ).casefold()
