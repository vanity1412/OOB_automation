"""Helper nhập liệu và hiển thị dùng chung cho CLI."""
from __future__ import annotations

from datetime import datetime


def clear_screen() -> None:
    """Tương thích ngược: v1.1.26 không xóa màn hình terminal.

    Giữ helper này để code/plugin cũ import không lỗi, nhưng cố tình không chạy
    ``cls``, ``clear`` hay ANSI clear. Operator có thể scroll lên xem toàn bộ
    output SSH/scan/error trước đó.
    """
    return


def pause() -> None:
    """Dừng để người dùng đọc kết quả."""
    input("\nNhấn Enter để tiếp tục...")


def confirm(message: str, default: bool = False) -> bool:
    """Đọc xác nhận có/không bằng tiếng Việt hoặc tiếng Anh."""
    suffix = "[C/k]" if default else "[c/K]"
    value = input(f"{message} {suffix}: ").strip().casefold()
    return default if not value else value in {"c", "co", "có", "y", "yes"}


def read_choice(
    prompt: str = "Nhập lựa chọn: ",
    minimum: int = 0,
    maximum: int | None = None,
) -> int:
    """Đọc lựa chọn số và lặp lại khi dữ liệu không hợp lệ."""
    while True:
        value = input(prompt).strip()
        try:
            number = int(value)
        except ValueError:
            print("[CẢNH BÁO] Vui lòng nhập số.")
            continue
        if number < minimum or (maximum is not None and number > maximum):
            print("[CẢNH BÁO] Lựa chọn ngoài phạm vi.")
            continue
        return number


def truncate_text(value: str, width: int) -> str:
    """Rút gọn chuỗi nhưng không vượt quá chiều rộng yêu cầu."""
    return value if len(value) <= width else value[: max(0, width - 1)] + "…"


def format_datetime(value: datetime | str | None) -> str:
    """Định dạng thời gian về múi giờ local của máy chạy tool."""
    if not value:
        return "Chưa có"
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value)
        except ValueError:
            return value
    return value.astimezone().strftime("%Y-%m-%d %H:%M")
