from __future__ import annotations

from oob_manager.cli.theme import bad, ok, warn, accent


def success(message: str) -> None:
    print(f"{ok('[OK]')} {message}")


def error(message: str) -> None:
    print(f"{bad('[LỖI]')} {message}")


def warning(message: str) -> None:
    print(f"{warn('[CẢNH BÁO]')} {message}")


def info(message: str) -> None:
    print(f"{accent('[THÔNG TIN]')} {message}")
