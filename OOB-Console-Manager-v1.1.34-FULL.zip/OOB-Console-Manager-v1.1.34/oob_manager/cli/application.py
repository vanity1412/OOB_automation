"""Ứng dụng CLI tiếng Việt cho OOB Console Manager."""
from __future__ import annotations

import getpass
import logging
from datetime import date, datetime
from pathlib import Path

from oob_manager.cli import messages, tables
from oob_manager.cli.menus import render_main_menu, render_submenu, render_title
from oob_manager.cli.help_text import get_help_text
from oob_manager.cli.session_credentials import SessionCredentialStore
from oob_manager.cli.prompts import format_datetime
from oob_manager.config import ApplicationSettings, validate_all_profiles
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
from oob_manager.database.repositories.reconciliation_repository import ReconciliationRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.settings_repository import SettingsRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import InputCancelledError, ValidationError, friendly_error
from oob_manager.models import (
    OOBDevice,
    SessionCredentials,
    DownstreamCredentials,
    PortAuthenticationCredentials,
)
from oob_manager.services.backup_service import BackupService
from oob_manager.services.console_service import ConsoleService
from oob_manager.services.cable_verification_service import CableVerificationService
from oob_manager.services.device_identity_service import DeviceIdentityService
from oob_manager.services.database_audit_service import DatabaseAuditService
from oob_manager.services.export_service import (
    CONNECTION_STATUS_LABELS_VI,
    EVENT_LABELS_VI,
    STATUS_LABELS_VI,
    ExportService,
)
from oob_manager.services.oob_service import OOBService
from oob_manager.services.reconciliation_service import ReconciliationService
from oob_manager.services.scan_service import ScanService
from oob_manager.services.search_service import SearchService
from oob_manager.utils.paths import DB_PATH, ensure_directories
from oob_manager.utils.validation import normalize_alias, validate_host, validate_nonempty, validate_port


class CLIApplication:
    """Điều phối menu; business logic nằm trong service/repository."""

    def __init__(
        self,
        debug: bool = False,
        *,
        db_path: Path | str = DB_PATH,
        input_func=input,
        getpass_func=getpass.getpass,
        pause_enabled: bool = True,
    ) -> None:
        ensure_directories()
        validate_all_profiles()
        self.debug = debug
        self._input_func = input_func
        self._getpass_func = getpass_func
        self.input = self._safe_input
        self.getpass = self._safe_getpass
        self.pause_enabled = pause_enabled
        # Password/enable password chỉ nằm trong RAM của tiến trình CLI.
        self.session_credentials = SessionCredentialStore()

        self.db = DatabaseConnection(db_path)
        MigrationManager(self.db).migrate()
        self.oob_repo = OOBRepository(self.db)
        self.target_repo = TargetRepository(self.db)
        self.scan_repo = ScanRepository(self.db)
        self.change_repo = ChangeRepository(self.db)
        self.connection_repo = ConnectionRepository(self.db)
        self.identity_repo = DeviceIdentityRepository(self.db)
        self.reconciliation_repo = ReconciliationRepository(self.db)
        self.scan_repo.recover_abandoned_same_host()
        self.connection_repo.recover_abandoned_same_host()
        self.identity_repo.recover_abandoned_same_host()
        self.settings_repo = SettingsRepository(self.db)
        self.settings = ApplicationSettings.from_mapping(
            self.settings_repo.get_all(),
            debug=debug,
        )
        self.lock_repo = ScanLockRepository(
            self.db,
            lease_seconds=self.settings.operation_lock_lease_seconds,
            heartbeat_seconds=self.settings.operation_lock_heartbeat_seconds,
        )
        self.lock_repo.recover_stale_same_host()
        self.oob_service = OOBService(self.oob_repo)
        self.search_service = SearchService(self.target_repo)
        self.scan_service = ScanService(
            self.oob_repo,
            self.target_repo,
            self.scan_repo,
            self.change_repo,
            self.lock_repo,
            self.settings,
        )
        self.console_service = ConsoleService(
            self.oob_repo,
            self.target_repo,
            self.connection_repo,
            self.settings,
            self.lock_repo,
        )
        self.identity_service = DeviceIdentityService(
            self.oob_repo,
            self.target_repo,
            self.identity_repo,
            self.settings,
            self.lock_repo,
        )
        self.cable_verification_service = CableVerificationService(
            self.oob_repo,
            self.target_repo,
            self.settings,
            self.lock_repo,
        )
        self.reconciliation_service = ReconciliationService(
            self.oob_repo,
            self.target_repo,
            self.identity_repo,
            self.reconciliation_repo,
            self.settings,
            self.lock_repo,
        )
        self.backup_service = BackupService(self.db)
        self.export_service = ExportService(self.db, self.settings)
        self.logger = logging.getLogger(__name__)

    def run(self) -> None:
        """Main loop tối giản cho operator; credential phiên luôn bị bỏ reference khi thoát."""
        try:
            self._run_main_loop()
        finally:
            self.session_credentials.clear()

    def _run_main_loop(self) -> None:
        """Main loop không xóa lịch sử terminal."""
        while True:
            print("\n" + render_title())
            self._show_pending_alerts()
            print(render_main_menu())
            try:
                choice = self._read_menu_token(
                    {"0", "1", "2", "3", "4", "5", "a", "c", "h", "help", "?"},
                    "Chọn: ",
                )
            except (EOFError, StopIteration, InputCancelledError):
                return

            if choice in {"h", "help", "?"}:
                self._show_help("quick")
                continue
            if choice == "0":
                print("Tạm biệt!")
                return
            if choice == "c":
                self._credential_session_menu()
                continue

            workflow = {
                "1": self._workflow_oob_scan,
                "2": self._workflow_search_connect,
                "3": self._workflow_device_check,
                "4": self._workflow_inventory_history,
                "5": self._workflow_update_oob,
                "a": self._workflow_advanced,
            }[choice]
            workflow()

    def _read_menu_token(self, valid: set[str], prompt: str = "Chọn: ") -> str:
        while True:
            raw = self.input(prompt).strip().casefold()
            if raw in valid:
                return raw
            messages.warning("Lựa chọn không hợp lệ. Nhập H để xem hướng dẫn.")

    def _execute_action(self, action, *, help_topic: str = "quick") -> None:
        """Chạy một chức năng cũ nhưng giữ nguyên history terminal."""
        print("\n" + "=" * 80)
        try:
            action()
        except InputCancelledError:
            messages.info("Thao tác đã được hủy an toàn.")
        except Exception as exc:
            self.logger.error(
                "CLI action failed exception_type=%s code=%s",
                type(exc).__name__,
                getattr(exc, "error_code", "UNHANDLED_ERROR"),
                extra={"operation": "cli_action"},
            )
            messages.error(friendly_error(exc))
            if self.debug:
                messages.warning(
                    f"Debug an toàn: {type(exc).__name__} / "
                    f"{getattr(exc, 'error_code', 'UNHANDLED_ERROR')}"
                )
        self._pause(help_topic=help_topic)

    def _submenu_loop(self, title_text: str, actions: dict[str, tuple[str, object, str]]) -> None:
        valid = {"0", "h", "help", "?", *actions.keys()}
        while True:
            print(render_submenu(title_text, [(key, value[0]) for key, value in actions.items()]))
            choice = self._read_menu_token(valid, "Chọn: ")
            if choice == "0":
                return
            if choice in {"h", "help", "?"}:
                self._show_help("quick")
                continue
            _label, action, topic = actions[choice]
            self._execute_action(action, help_topic=topic)

    def _workflow_oob_scan(self) -> None:
        self._submenu_loop(
            "OOB & SCAN",
            {
                "1": ("Thêm OOB", self.add_oob, "quick"),
                "2": ("Danh sách OOB", self.list_oobs, "quick"),
                "3": ("Scan + so sánh Device A/B", self.scan_and_verify_cabling, "identity"),
                "4": ("Scan mapping only", self.scan_one, "scan"),
                "5": ("Scan tất cả OOB (mapping only)", self.scan_all, "scan"),
                "6": ("Cập nhật / xóa OOB", self._oob_maintenance_menu, "quick"),
            },
        )

    def _oob_maintenance_menu(self) -> None:
        self._submenu_loop(
            "CẬP NHẬT / XÓA OOB",
            {
                "1": ("Cập nhật thông tin kết nối OOB", self.update_oob, "quick"),
                "2": ("Xóa / vô hiệu hóa OOB", self.delete_oob, "quick"),
            },
        )

    def _workflow_search_connect(self) -> None:
        self._submenu_loop(
            "TÌM & KẾT NỐI THIẾT BỊ",
            {
                "1": ("Xem thiết bị phía sau một OOB", self.list_targets, "targets"),
                "2": ("Tìm target / mở manual console", self.search_and_connect, "targets"),
            },
        )

    def _workflow_device_check(self) -> None:
        self._submenu_loop(
            "IDENTITY NÂNG CAO",
            {
                "1": ("Full identity read-only (hostname/model/serial/version)", self.discover_downstream_identity, "identity"),
                "2": ("Xem identity đã xác minh", self.show_device_identities, "identity"),
                "3": ("Xem bất thường / thay đổi identity", self.show_identity_events, "identity"),
            },
        )

    def _workflow_inventory_history(self) -> None:
        self._submenu_loop(
            "INVENTORY & LỊCH SỬ",
            {
                "1": ("Inventory hiện tại", self.current_inventory_review, "daily"),
                "2": ("Tìm lịch sử một thiết bị", self.target_history_review, "daily"),
                "3": ("Inventory hôm nay", self.daily_inventory_today, "daily"),
                "4": ("Xem inventory theo ngày / xuất CSV", self.daily_inventory_review, "daily"),
                "5": ("Xem thay đổi console mapping", self.show_changes, "changes"),
                "6": ("Lịch sử scan", self.show_scans, "scan"),
                "7": ("Xem snapshot theo Scan ID", self.scan_snapshot_review, "scan"),
                "8": ("Lịch sử kết nối console", self.show_connections, "connections"),
                "9": ("Xuất 1 CSV inventory hiện tại", self.export_simple_current_inventory, "daily"),
            },
        )

    def _workflow_update_oob(self) -> None:
        self._submenu_loop(
            "CẬP NHẬT OOB",
            {
                "1": ("Xem mapping thay đổi", self.show_changes, "changes"),
                "2": ("Xem identity mismatch / device change", self.show_identity_events, "identity"),
                "3": ("Đồng bộ alias/name OOB có kiểm soát", self.reconcile_oob_alias, "reconciliation"),
            },
        )

    def _workflow_advanced(self) -> None:
        self._submenu_loop(
            "NÂNG CAO",
            {
                "1": ("Backup database", self.backup_db, "settings"),
                "2": ("Settings / Export đầy đủ / Locks / Database Health", self.settings_menu, "settings"),
            },
        )


    def _show_pending_alerts(self) -> None:
        """Surface unseen local anomalies without requiring a webhook service."""
        try:
            identity_count = self.identity_repo.count_unviewed_critical_events()
            change_count = self.change_repo.count_unviewed()
        except Exception:
            # Main menu must remain usable even if the reminder query encounters a
            # legacy/corrupt database. Database Audit can diagnose that separately.
            return
        if identity_count:
            messages.error(
                f"⚠ Có {identity_count} bất thường identity mức cao chưa xem "
                "(SERIAL_CHANGED/DEVICE_CHANGE_SUSPECTED) — vào [3] IDENTITY NÂNG CAO."
            )
        if change_count:
            messages.warning(
                f"⚠ Có {change_count} thay đổi console mapping chưa xem — vào [4] INVENTORY & LỊCH SỬ."
            )

    def _safe_input(self, prompt: str = "") -> str:
        try:
            return self._input_func(prompt)
        except (EOFError, KeyboardInterrupt, StopIteration) as exc:
            raise InputCancelledError("User cancelled input") from exc

    def _safe_getpass(self, prompt: str = "Password: ") -> str:
        try:
            return self._getpass_func(prompt)
        except (EOFError, KeyboardInterrupt, StopIteration) as exc:
            raise InputCancelledError("User cancelled credential input") from exc

    def _pause(self, *, help_topic: str | None = None) -> None:
        if not self.pause_enabled:
            return
        while True:
            value = self.input("\nEnter: quay lại | H: hướng dẫn màn hình: ").strip().casefold()
            if value in {"h", "help", "?"}:
                # Không clear: giữ nguyên evidence/output phía trên để operator đối chiếu.
                self._show_help(help_topic or "quick")
                continue
            return

    def _show_help(self, topic: str = "quick") -> None:
        print(get_help_text(topic))

    def _read_main_choice(self) -> int | None:
        """Compatibility helper cho test/plugin cũ; main loop mới dùng _read_menu_token."""
        raw_value = self.input("Nhập lựa chọn (H=Help): ").strip().casefold()
        if raw_value in {"h", "help", "?"}:
            return None
        try:
            return int(raw_value)
        except ValueError:
            messages.warning("Vui lòng nhập số hoặc H/HELP/?.")
            return -1

    def _read_choice(self, minimum: int, maximum: int) -> int:
        while True:
            raw_value = self.input("Nhập lựa chọn: ").strip()
            try:
                value = int(raw_value)
            except ValueError:
                messages.warning("Vui lòng nhập số.")
                continue
            if minimum <= value <= maximum:
                return value
            messages.warning("Lựa chọn ngoài phạm vi.")


    def _read_nonempty(self, prompt: str, field_name: str, default: str = "") -> str:
        while True:
            raw_value = self.input(prompt).strip()
            try:
                return validate_nonempty(raw_value or default, field_name)
            except ValidationError as exc:
                messages.warning(str(exc))

    def _read_host(self, prompt: str, default: str = "") -> str:
        while True:
            raw_value = self.input(prompt).strip()
            try:
                return validate_host(raw_value or default)
            except ValidationError as exc:
                messages.warning(str(exc))

    def _read_port(self, prompt: str, default: int = 22) -> int:
        while True:
            raw_value = self.input(prompt).strip()
            try:
                return validate_port(raw_value or default)
            except ValidationError as exc:
                messages.warning(str(exc))

    def _read_vendor_choice(self, current: str | None = None) -> str:
        """Đọc vendor theo menu 1/2; Enter chỉ hợp lệ khi có giá trị hiện tại."""
        while True:
            current_value = str(current or "").strip().upper()
            suffix = " hoặc Enter giữ nguyên" if current_value else ""
            raw_value = self.input(
                f"Vendor: 1.CISCO 2.VERTIV{suffix}: "
            ).strip()
            if not raw_value and current_value in {"CISCO", "VERTIV"}:
                return current_value
            if raw_value == "1":
                return "CISCO"
            if raw_value == "2":
                return "VERTIV"
            messages.warning("Lựa chọn vendor không hợp lệ. Chỉ nhập 1, 2 hoặc Enter để giữ nguyên.")

    def _read_optional_enabled(self, current: bool) -> bool:
        """Đọc Enabled với retry tại chỗ để không làm mất form update."""
        yes_values = {"y", "yes", "c", "co", "có"}
        no_values = {"n", "no", "k", "không", "khong"}
        while True:
            raw_value = self.input(
                f"Enabled [{'Y' if current else 'N'}] (Y/N, Enter giữ nguyên): "
            ).strip().casefold()
            if not raw_value:
                return current
            if raw_value in yes_values:
                return True
            if raw_value in no_values:
                return False
            messages.warning("Giá trị Enabled không hợp lệ. Chỉ nhập Y/N hoặc Enter để giữ nguyên.")

    def _edit_oob_connection_fields(self, device: OOBDevice) -> bool:
        """Sửa riêng Host/SSH Port/Vendor; trả True nếu vendor thay đổi."""
        old_vendor = str(device.vendor or "").strip().upper()
        device.host = self._read_host(f"Host [{device.host}]: ", device.host)
        device.ssh_port = self._read_port(
            f"SSH port [{device.ssh_port}]: ", device.ssh_port
        )
        device.vendor = self._read_vendor_choice(old_vendor)
        device.device_type = "cisco_ios" if device.vendor == "CISCO" else "vertiv"
        return device.vendor != old_vendor

    def _prompt_credentials(
        self,
        device: OOBDevice,
        *,
        suggested_username: str | None = None,
    ) -> SessionCredentials:
        """Nhập credential mới; password không bao giờ persistence."""
        default_username = (
            str(suggested_username).strip()
            if suggested_username is not None
            else str(device.default_username or "").strip()
        )
        while True:
            prompt = (
                f"Username SSH [{default_username}]: "
                if default_username
                else "Username SSH: "
            )
            entered = self.input(prompt).strip()
            username = entered or default_username
            if username:
                break
            messages.warning("Username không được để trống khi kết nối SSH.")
        password = self.getpass("Password: ")
        enable_password = None
        if str(device.vendor or "").strip().upper() == "CISCO":
            enable_value = self.getpass(
                "Cisco Enable Password [Enter nếu không cần]: "
            )
            enable_password = enable_value or None
        return SessionCredentials(username, password, enable_password)

    def _credentials_with_source(
        self,
        device: OOBDevice,
        *,
        force_prompt: bool = False,
        announce: bool = True,
        suggested_username: str | None = None,
    ) -> tuple[SessionCredentials, str]:
        if not force_prompt:
            credentials, source = self.session_credentials.resolve(device)
            if credentials is not None:
                if announce:
                    messages.info(f"Credential OOB: {source} (RAM only).")
                return credentials, source
        return (
            self._prompt_credentials(device, suggested_username=suggested_username),
            "PROMPT",
        )

    def _credentials(self, device: OOBDevice) -> SessionCredentials:
        credentials, _source = self._credentials_with_source(device)
        return credentials

    def _prompt_shared_session_credentials(self) -> SessionCredentials:
        """Credential chung: enable chỉ được dùng khi target vendor là Cisco."""
        if self.session_credentials.default is not None:
            default_username = self.session_credentials.default.username
        else:
            usernames = {
                str(device.default_username or "").strip()
                for device in self.oob_service.list_all(include_disabled=False)
                if str(device.default_username or "").strip()
            }
            default_username = next(iter(usernames)) if len(usernames) == 1 else ""
        pseudo = OOBDevice(vendor="CISCO", default_username=default_username)
        return self._prompt_credentials(pseudo)

    def _set_vendor_session_credentials(self) -> None:
        devices = self.oob_service.list_all(include_disabled=False)
        active_vendors = {str(device.vendor or "").upper() for device in devices}
        vendors = [vendor for vendor in ("CISCO", "VERTIV") if not active_vendors or vendor in active_vendors]
        for vendor in vendors:
            current = self.session_credentials.by_vendor.get(vendor)
            suggested = current.username if current else next(
                (device.default_username for device in devices if device.vendor == vendor and device.default_username),
                "",
            )
            print(f"\n---------------- {vendor} ----------------")
            credentials = self._prompt_credentials(
                OOBDevice(vendor=vendor, default_username=suggested)
            )
            self.session_credentials.set_vendor(vendor, credentials)
        messages.success("Đã nạp credential theo vendor vào RAM cho phiên hiện tại.")

    def _show_session_credential_status(self) -> None:
        rows = self.session_credentials.status_rows()
        if not rows:
            messages.info("Chưa có credential phiên nào trong RAM.")
            return
        tables.show_rows(
            ["PHẠM VI", "USERNAME", "CISCO ENABLE"],
            rows,
            [22, 32, 14],
        )
        messages.info("Password/enable password không được hiển thị, ghi DB, log hoặc CSV.")

    def _credential_session_menu(self) -> None:
        while True:
            print(
                "\n" + "=" * 80 +
                "\nCREDENTIAL PHIÊN LÀM VIỆC (RAM ONLY)\n" +
                "=" * 80 +
                "\n[1] Nạp một credential chung cho tất cả OOB"
                "\n[2] Nạp credential riêng theo vendor Cisco / Vertiv"
                "\n[3] Xem trạng thái credential đang nạp"
                "\n[4] Xóa toàn bộ credential phiên khỏi RAM"
                "\n[0] Quay lại"
            )
            choice = self._read_menu_token({"0", "1", "2", "3", "4"}, "Chọn: ")
            if choice == "0":
                return
            if choice == "1":
                credentials = self._prompt_shared_session_credentials()
                self.session_credentials.set_default(credentials)
                messages.success(
                    "Credential chung đã nạp vào RAM. Không lưu DB/log/CSV và tự mất khi thoát tool."
                )
            elif choice == "2":
                self._set_vendor_session_credentials()
            elif choice == "3":
                self._show_session_credential_status()
            else:
                self.session_credentials.clear()
                messages.success("Đã xóa toàn bộ credential phiên khỏi RAM.")

    def _downstream_credentials(
        self,
        *,
        target_label: str = "",
        suggested_username: str = "",
    ) -> DownstreamCredentials:
        """Nhập credential của thiết bị PHÍA SAU OOB, không phải credential SSH OOB.

        target_label chỉ dùng để làm rõ port/device đang được retry. suggested_username
        cho phép giữ lại username batch khi chỉ cần sửa password cho một target.
        """
        if target_label:
            print(f"\n--- Login thiết bị phía sau OOB: {target_label} ---")
        suffix = f" [{suggested_username}]" if suggested_username else ""
        username = self.input(
            f"Username THIẾT BỊ phía sau OOB{suffix} "
            "(Enter giữ username gợi ý / bỏ trống nếu console đã login): "
        ).strip()
        if not username:
            username = suggested_username.strip()
        password = self.getpass(
            "Password THIẾT BỊ phía sau OOB (bỏ trống nếu không cần): "
        )
        return DownstreamCredentials(username=username, password=password)

    @staticmethod
    def _is_retryable_downstream_login_error(error_code: str) -> bool:
        """Chỉ retry các lỗi thuộc tầng login/prompt downstream.

        BUSY/UNKNOWN/mapping safety và identity rejected không được biến thành login
        retry, vì đó là các lớp bảo vệ/độ tin cậy khác nhau.
        """
        code = str(error_code or "").strip().upper()
        if not code.startswith("DOWNSTREAM_"):
            return False
        if code in {
            "DOWNSTREAM_IDENTITY_REJECTED",
            "DOWNSTREAM_DISCOVERY_FAILED",
        }:
            return False
        return any(
            token in code
            for token in (
                "USERNAME",
                "PASSWORD",
                "CREDENTIAL",
                "AUTH",
                "LOGIN",
                "PROMPT_UNVERIFIED",
            )
        )

    def _port_auth_credentials(self) -> PortAuthenticationCredentials:
        print(
            "\n--- Phương thức truy cập serial Vertiv ---\n"
            "1. SSH quản trị ACS -> cd access -> connect <port-name> (khuyến nghị)\n"
            "2. Direct SSH qua username:port_name (chỉ dùng khi ACS đã bật direct SSH)"
        )
        access_choice = self._read_choice(1, 2)
        if access_choice == 2:
            messages.info(
                "Tool vẫn mở một phiên SSH quản trị trước để đọc lại access/show và "
                "xác minh port Idle; chỉ sau đó mới mở direct SSH user:port_name."
            )
            print(
                "Credential direct SSH có thể dùng cùng account quản trị hoặc account riêng.\n"
                "1. Dùng lại username/password OOB\n"
                "2. Nhập account direct-serial riêng"
            )
            direct_choice = self._read_choice(1, 2)
            if direct_choice == 1:
                return PortAuthenticationCredentials(
                    access_method="DIRECT_SSH_PORT_NAME",
                    use_oob_credentials_for_direct=True,
                )
            while True:
                direct_username = self.input(
                    "Base username direct SSH (tool tự ghép :port_name): "
                ).strip()
                if direct_username and ":" not in direct_username:
                    break
                messages.warning(
                    "Base username direct SSH phải khác rỗng và không chứa ':'."
                )
            direct_password = self.getpass("Password direct SSH: ")
            return PortAuthenticationCredentials(
                access_method="DIRECT_SSH_PORT_NAME",
                direct_username=direct_username,
                direct_password=direct_password,
                use_oob_credentials_for_direct=False,
            )

        print(
            "\n--- Xác thực serial port Vertiv (khác credential OOB/downstream) ---\n"
            "1. Port không yêu cầu password\n"
            "2. Nhập password serial-port riêng\n"
            "3. Dùng lại OOB password (phải chọn rõ ràng)"
        )
        choice = self._read_choice(1, 3)
        if choice == 1:
            return PortAuthenticationCredentials(access_method="CLI_CONNECT")
        if choice == 2:
            return PortAuthenticationCredentials(
                password=self.getpass("Serial-port authentication password: "),
                access_method="CLI_CONNECT",
            )
        return PortAuthenticationCredentials(
            use_oob_password=True, access_method="CLI_CONNECT"
        )

    def add_oob(self) -> None:
        print("\nTHÊM THIẾT BỊ OOB")
        name = self._read_nonempty("Tên OOB: ", "Tên OOB")
        host = self._read_host("IP hoặc hostname: ")
        port = self._read_port("Cổng SSH quản trị OOB [22] (Vertiv: KHÔNG phải serial alias 7001): ")
        print("1. Cisco\n2. Vertiv/Vertix")
        vendor = "CISCO" if self._read_choice(1, 2) == 1 else "VERTIV"
        mode = "SSH"
        messages.info(
            "Management/control-plane chỉ sử dụng SSH; API/SSH_AND_API chưa bật cho production."
        )
        username = self.input(
            "Username SSH mặc định (được lưu; bỏ trống nếu chưa biết): "
        ).strip()
        messages.info(
            "Chỉ username mặc định được lưu. Password/Enable password chỉ tồn tại trong RAM và không ghi DB/export."
        )
        notes = self.input("Ghi chú: ").strip()
        device = OOBDevice(
            name=name,
            host=host,
            ssh_port=port,
            vendor=vendor,
            device_type="cisco_ios" if vendor == "CISCO" else "vertiv",
            default_username=username,
            connection_mode=mode,
            notes=notes,
        )

        print(
            "\n1. Kiểm tra kết nối rồi lưu\n"
            "2. Lưu nhưng chưa kiểm tra\n"
            "0. Hủy"
        )
        choice = self._read_choice(0, 2)
        if choice == 0:
            return

        tested_credentials: SessionCredentials | None = None
        tested_source = ""
        connection_verified = False

        if choice == 1:
            # Username khai báo rõ ràng cho OOB mới không được âm thầm bị thay bằng
            # một session credential có username khác.
            resolved_credentials, resolved_source = self.session_credentials.resolve(device)
            if (
                resolved_credentials is not None
                and device.default_username
                and resolved_credentials.username != device.default_username
            ):
                messages.warning(
                    "Username OOB mới khác username của credential phiên. Cần nhập credential đúng cho OOB này trước khi Test Connection."
                )
                tested_credentials = self._prompt_credentials(
                    device, suggested_username=device.default_username
                )
                tested_source = "PROMPT"
            elif resolved_credentials is not None:
                tested_credentials = resolved_credentials
                tested_source = resolved_source
                messages.info(f"Credential OOB: {tested_source} (RAM only).")
            else:
                tested_credentials, tested_source = self._credentials_with_source(device)

            if not device.default_username:
                device.default_username = tested_credentials.username

            from oob_manager.vendors.factory import create_vendor_adapter

            while True:
                try:
                    result = create_vendor_adapter(device, self.settings).test_connection(
                        device,
                        tested_credentials,
                    )
                    if result.success:
                        connection_verified = True
                        # Metadata username phải phản ánh đúng account vừa được test thành công.
                        device.default_username = tested_credentials.username
                        messages.success(result.message or "Kiểm tra kết nối thành công.")
                        if not self._confirm("Kết nối đã được xác minh. Tiếp tục lưu OOB?"):
                            return
                        break
                    error_text = result.message or "Kiểm tra kết nối thất bại."
                except InputCancelledError:
                    raise
                except Exception as exc:
                    error_text = friendly_error(exc)

                messages.error(
                    "Kiểm tra kết nối thất bại. Form OOB hiện tại được giữ nguyên.\n"
                    f"OOB={device.name} | Host={device.host}:{device.ssh_port} | "
                    f"Vendor={device.vendor} | Username={tested_credentials.username}\n"
                    f"Lỗi: {error_text}"
                )
                print(
                    "\n[1] Thử lại cùng credential\n"
                    "[2] Nhập credential khác\n"
                    "[3] Sửa Host / SSH Port / Vendor\n"
                    "[4] Lưu OOB nhưng đánh dấu CHƯA KIỂM TRA\n"
                    "[0] Hủy"
                )
                recovery_choice = self._read_choice(0, 4)
                if recovery_choice == 0:
                    return
                if recovery_choice == 1:
                    continue
                if recovery_choice == 2:
                    tested_credentials = self._prompt_credentials(
                        device, suggested_username=device.default_username
                    )
                    tested_source = "PROMPT"
                    continue
                if recovery_choice == 3:
                    vendor_changed = self._edit_oob_connection_fields(device)
                    if vendor_changed:
                        messages.info(
                            "Vendor đã thay đổi; credential sẽ được nhập lại để tránh dùng sai loại xác thực."
                        )
                        tested_credentials = self._prompt_credentials(
                            device, suggested_username=device.default_username
                        )
                        tested_source = "PROMPT"
                    continue

                # Lưu chưa kiểm tra: không quảng bá credential thất bại vào session store.
                tested_credentials = None
                tested_source = ""
                messages.warning(
                    "OOB sẽ được lưu ở trạng thái chưa xác minh kết nối. Cần Scan thành công trước khi có mapping dùng cho console."
                )
                break

        saved = self.oob_service.create(device)
        messages.success(f"Đã lưu OOB ID {saved.id}.")

        if connection_verified and tested_credentials is not None and tested_source == "PROMPT":
            answer = self.input(
                "Dùng credential vừa test làm SESSION DEFAULT cho phiên hiện tại? [Y/n]: "
            ).strip().casefold()
            if answer not in {"n", "no", "k", "không", "khong"}:
                self.session_credentials.set_default(tested_credentials)
                messages.success(
                    "Credential vừa test đã nạp vào RAM cho phiên hiện tại; password không được lưu persistent."
                )

    def list_oobs(self) -> None:
        devices = self.oob_service.list_all()
        if devices:
            tables.show_oobs(devices)
        else:
            messages.info("Chưa có OOB nào.")

    def _select_oob(self, include_disabled: bool = False) -> OOBDevice | None:
        devices = self.oob_service.list_all(include_disabled=include_disabled)
        if not devices:
            messages.info("Chưa có OOB phù hợp.")
            return None
        tables.show_oobs(devices)
        print("0. Quay lại")
        index = self._read_choice(0, len(devices))
        return None if index == 0 else devices[index - 1]

    def scan_one(self) -> None:
        device = self._select_oob(False)
        if not device:
            return
        credentials = self._credentials(device)
        result = self.scan_service.scan_one(
            device.id,
            credentials,
            trigger_source="CLI_MANUAL",
        )
        messages.info(
            f"Kết quả scan: {result.status}; mapping={result.mapping_quality}; "
            f"target={result.mapping_count}; cảnh báo={result.warning_count}; "
            f"baseline={'đã cập nhật' if result.baseline_updated else 'giữ nguyên'}"
        )
        if result.error_message:
            messages.warning(result.error_message)
        if result.scan_id is not None:
            self._export_scan_artifacts_safe(result.scan_id)

    def scan_and_verify_cabling(self) -> None:
        """Scan một OOB rồi batch-verify identity trên các port an toàn.

        Đây là workflow đúng thứ tự vận hành: scan mapping (device A) -> lấy các
        target AVAILABLE đã có evidence -> mở từng console tuần tự -> chỉ đọc hostname
        banner/prompt (device B) -> export mismatch A/B. BUSY/UNKNOWN/INCOMPLETE không
        bao giờ bị auto-connect.
        """
        device = self._select_oob(False)
        if not device:
            return
        credentials = self._credentials(device)
        result = self.scan_service.scan_one(
            device.id,
            credentials,
            trigger_source="CLI_SCAN_CABLE_VERIFY",
        )
        messages.info(
            f"Kết quả scan: {result.status}; mapping={result.mapping_quality}; "
            f"target={result.mapping_count}; cảnh báo={result.warning_count}; "
            f"baseline={'đã cập nhật' if result.baseline_updated else 'giữ nguyên'}"
        )
        if result.error_message:
            messages.warning(result.error_message)
        if result.scan_id is not None:
            self._export_scan_artifacts_safe(result.scan_id)

        if result.mapping_quality != "ACCEPTED" or not result.baseline_updated:
            messages.warning(
                "Không chạy dò A/B vì scan mới chưa tạo baseline mapping ACCEPTED. "
                "Tool giữ fail-closed để tránh nối vào mapping chưa đủ tin cậy."
            )
            return
        self._run_batch_cable_verification(device, credentials)

    @staticmethod
    def _cable_port_value(target) -> str:
        if target.protocol == "VERTIV_CLI":
            value = target.console_line if target.console_line is not None else target.menu_item
            return str(value) if value is not None else "-"
        if target.target_port is not None:
            return str(target.target_port)
        if target.console_line is not None:
            return str(target.console_line)
        return str(target.menu_item or "-")

    @staticmethod
    def _cable_console_path(target) -> str:
        if target.protocol == "VERTIV_CLI":
            port = target.console_line if target.console_line is not None else target.menu_item
            return f"serial/{port if port is not None else '-'}"
        if target.target_host:
            endpoint = f"{target.target_host}:{target.target_port}" if target.target_port else target.target_host
        else:
            endpoint = "-"
        return f"{endpoint} / line {target.console_line if target.console_line is not None else '-'}"

    def verify_available_ports_identity(self) -> None:
        """Fresh scan + quick A/B; never verify an old current mapping blindly."""
        self.scan_and_verify_cabling()

    def _run_batch_cable_verification(
        self,
        device: OOBDevice,
        oob_credentials: SessionCredentials,
    ) -> None:
        """Quick A/B cable check: banner/prompt hostname only, no downstream login.

        Device A comes from the accepted OOB mapping. Device B is read only from
        the serial banner or an already-present CLI prompt. The probe never sends
        downstream username/password and never executes commands on the downstream
        router/switch. Cisco/Vertiv live state safety checks remain enforced by the
        vendor adapters immediately before opening each console path.
        """
        if device.vendor not in {"CISCO", "VERTIV"}:
            messages.error(f"Quick A/B chưa hỗ trợ OOB vendor {device.vendor}.")
            return
        if device.mapping_stale:
            messages.error("Mapping đang STALE. Cần scan lại OOB trước khi dò A/B.")
            return

        targets = self.target_repo.list_current(device.id)
        if not targets:
            messages.info("OOB chưa có target hiện tại. Cần scan trước.")
            return
        # Stable report order = exact order returned by the accepted fresh scan.
        # Initial BUSY/UNKNOWN rows are created before probes, so sort once before
        # export to avoid a confusing 1,3,2 style CSV.
        target_order = {target.id: index for index, target in enumerate(targets)}

        def sort_rows_in_scan_order() -> None:
            rows.sort(key=lambda row: target_order.get(row.get("target_id"), len(target_order)))

        def supported(target) -> bool:
            return (
                target.protocol == "TELNET"
                if device.vendor == "CISCO"
                else target.protocol == "VERTIV_CLI"
            )

        candidates = [
            target for target in targets
            if target.is_complete
            and target.state_confident
            and target.state == "AVAILABLE"
            and supported(target)
        ]
        candidate_ids = {target.id for target in candidates}
        skipped_initial = len(targets) - len(candidates)

        # Keep one result row for every mapping from the fresh scan. Ports that
        # cannot be opened safely are explicit SKIP/ERROR rows instead of silently
        # disappearing from the A/B CSV. This makes "scan count" and "A/B result
        # count" reconcilable without weakening the BUSY/UNKNOWN fail-closed gate.
        rows: list[dict[str, object]] = []
        matches = mismatches = no_hostname = 0
        skipped_errors = 0
        for target in targets:
            if target.id in candidate_ids:
                continue
            if not target.is_complete or not supported(target):
                code = "DOWNSTREAM_TARGET_UNSUPPORTED"
                reason = "Target incomplete hoặc protocol không hỗ trợ Quick A/B."
            elif target.state in {"BUSY", "BUSY_UNKNOWN_USER"} and target.state_confident:
                code = "CONSOLE_LINE_BUSY"
                reason = "Port/line đang BUSY; không mở console."
            else:
                code = "DOWNSTREAM_LINE_NOT_CONFIRMED_AVAILABLE"
                reason = "Port/line không được chứng minh AVAILABLE/confident; không mở console."
            rows.append({
                "detected_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "oob": device.name,
                "vendor": device.vendor,
                "port": self._cable_port_value(target),
                "device_a": (target.alias or "").strip(),
                "device_b": "",
                "status": "SKIP/ERROR",
                "evidence_source": "",
                "target_id": target.id,
                "console_path": self._cable_console_path(target),
                "error_code": code,
                "message": reason,
            })
            skipped_errors += 1

        if candidates:
            tables.show_rows(
                ["#", "PORT", "DEVICE A (OOB)", "STATE", "CONSOLE PATH"],
                [
                    (
                        index,
                        self._cable_port_value(target),
                        target.alias or "-",
                        target.state,
                        self._cable_console_path(target),
                    )
                    for index, target in enumerate(candidates, 1)
                ],
                [5, 9, 30, 12, 34],
            )
        print(
            "\nQUICK OOB CABLE CHECK - READ ONLY\n"
            f"  OOB                 : {device.name}\n"
            f"  Vendor              : {device.vendor}\n"
            f"  Mapping fresh scan  : {len(targets)}\n"
            f"  Target sẽ mở console: {len(candidates)}\n"
            f"  Target SKIP sẵn     : {skipped_initial}\n"
            "  Device A            : alias/name từ mapping OOB.\n"
            "  Device B            : chỉ đọc hostname từ banner/prompt console.\n"
            "  Downstream login    : KHÔNG dùng username/password.\n"
            "  Downstream command  : KHÔNG chạy show/version/inventory.\n"
            "  Safety              : live-check AVAILABLE trước mỗi connect; BUSY/UNKNOWN = SKIP/ERROR.\n"
            "  Troubleshooting     : KHÔNG clear-line/kill session trong quick batch.\n"
            "  Mapping             : KHÔNG tự sửa khi A khác B."
        )
        if not candidates:
            messages.warning(
                "Không có target COMPLETE + AVAILABLE/confident để mở console. "
                "Các mapping vẫn được ghi CSV dưới trạng thái SKIP/ERROR."
            )
            sort_rows_in_scan_order()
            paths = self.export_service.export_cable_verification(device.name, rows)
            print("\n" + "=" * 80)
            print(
                "KẾT QUẢ QUICK OOB CABLE CHECK\n"
                f"  Mapping scan  : {len(targets)}\n"
                "  Đã mở console : 0\n"
                "  MATCH         : 0\n"
                "  MISMATCH      : 0\n"
                "  NO_HOSTNAME   : 0\n"
                f"  SKIP/ERROR    : {skipped_errors}\n"
                f"  CSV toàn bộ   : {paths['all']}\n"
                f"  CSV mismatch  : {paths['mismatch']}"
            )
            print("=" * 80)
            return

        if not self._confirm("Bắt đầu quick check các port AVAILABLE ở trên?"):
            messages.info(
                "Đã hủy mở console. Các port không AVAILABLE vẫn chưa được export vì batch chưa chạy."
            )
            return

        skip_codes = {
            "CONSOLE_LINE_BUSY",
            "DOWNSTREAM_LINE_NOT_CONFIRMED_AVAILABLE",
            "CONSOLE_STATE_UNVERIFIED",
        }

        for index, target in enumerate(candidates, 1):
            device_a = (target.alias or "").strip()
            port = self._cable_port_value(target)
            console_path = self._cable_console_path(target)
            print(f"\n[{index}/{len(candidates)}] port={port}  A={device_a or '-'}")
            try:
                result = self.cable_verification_service.probe(
                    int(target.id),
                    oob_credentials,
                )
                device_b = (result.identity.actual_hostname or "").strip()
                source = str(
                    result.metadata.get("cable_identity_source", "") or ""
                ).strip().upper()

                if not device_b:
                    status = "NO_HOSTNAME"
                    no_hostname += 1
                    messages.warning(
                        f"NO_HOSTNAME: port {port}: đã mở console nhưng banner/prompt "
                        "không cho biết hostname; tool không login sâu hơn."
                    )
                elif device_a and normalize_alias(device_a) == normalize_alias(device_b):
                    status = "MATCH"
                    matches += 1
                    messages.success(f"MATCH: port {port}: {device_b}")
                else:
                    status = "MISMATCH"
                    mismatches += 1
                    messages.warning(
                        f"CẮM NHẦM/MAPPING CŨ: port {port}: "
                        f"A={device_a or '-'} | B={device_b}"
                    )

                rows.append({
                    "detected_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                    "oob": device.name,
                    "vendor": device.vendor,
                    "port": port,
                    "device_a": device_a,
                    "device_b": device_b,
                    "status": status,
                    "evidence_source": source or "NO_HOSTNAME",
                    "target_id": target.id,
                    "console_path": console_path,
                    "error_code": "",
                    "message": (
                        "Hostname read from console banner/prompt; no downstream login/commands."
                        if device_b
                        else "Console opened but hostname was not visible; probe stopped without downstream login."
                    ),
                })
            except Exception as exc:
                code = str(
                    getattr(exc, "error_code", "QUICK_HOSTNAME_PROBE_FAILED")
                    or "QUICK_HOSTNAME_PROBE_FAILED"
                )
                message = friendly_error(exc)
                status = "SKIP/ERROR"
                skipped_errors += 1
                if code in skip_codes:
                    messages.warning(f"SKIP/ERROR port {port}: {code} - {message}")
                else:
                    messages.error(f"SKIP/ERROR port {port}: {code} - {message}")
                rows.append({
                    "detected_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                    "oob": device.name,
                    "vendor": device.vendor,
                    "port": port,
                    "device_a": device_a,
                    "device_b": "",
                    "status": status,
                    "evidence_source": "",
                    "target_id": target.id,
                    "console_path": console_path,
                    "error_code": code,
                    "message": message,
                })

        sort_rows_in_scan_order()
        paths = self.export_service.export_cable_verification(device.name, rows)
        print("\n" + "=" * 80)
        print(
            "KẾT QUẢ QUICK OOB CABLE CHECK\n"
            f"  Mapping scan  : {len(targets)}\n"
            f"  Đã mở console : {len(candidates)}\n"
            f"  MATCH         : {matches}\n"
            f"  MISMATCH      : {mismatches}\n"
            f"  NO_HOSTNAME   : {no_hostname}\n"
            f"  SKIP/ERROR    : {skipped_errors}\n"
            f"  CSV toàn bộ   : {paths['all']}\n"
            f"  CSV mismatch  : {paths['mismatch']}"
        )
        if mismatches:
            messages.warning(
                "Có A/B mismatch: kiểm tra mapping cũ hoặc dây console cắm nhầm. "
                "Tool KHÔNG tự cập nhật alias/mapping."
            )
        elif skipped_errors:
            messages.warning("Không thấy mismatch trong các port kết luận được, nhưng vẫn có port SKIP/ERROR.")
        else:
            messages.success("Quick check hoàn tất; không phát hiện A/B mismatch trong các port có hostname.")
        print("=" * 80)

    def scan_all(self) -> None:
        devices = self.oob_service.list_all(include_disabled=False)
        if not devices:
            messages.info("Chưa có OOB đang bật để scan.")
            return
        device_names = {device.id: device.name for device in devices}
        total = len(devices)

        # Nếu credential phiên đã phủ toàn bộ OOB thì Scan All chạy ngay, không hỏi lại.
        session_coverage = all(
            self.session_credentials.resolve(device)[0] is not None for device in devices
        )
        per_device_mode = False
        batch_common: SessionCredentials | None = None

        if session_coverage:
            messages.info("Credential: dùng credential phiên đã nạp trong RAM cho toàn bộ batch.")
        else:
            print(
                "\nCREDENTIAL CHO SCAN ALL\n"
                "[1] Dùng một credential chung cho tất cả OOB (RAM only)\n"
                "[2] Nạp credential riêng theo vendor Cisco / Vertiv (RAM only)\n"
                "[3] Nhập riêng credential cho từng OOB\n"
                "[0] Hủy"
            )
            mode = self._read_menu_token({"0", "1", "2", "3"}, "Chọn: ")
            if mode == "0":
                return
            if mode == "1":
                batch_common = self._prompt_shared_session_credentials()
                self.session_credentials.set_default(batch_common)
                messages.success("Đã nạp SESSION DEFAULT vào RAM cho batch và các operation tiếp theo.")
            elif mode == "2":
                self._set_vendor_session_credentials()
            else:
                per_device_mode = True

        credential_sources: dict[int, str] = {}
        pending_oob_overrides: dict[int, SessionCredentials] = {}

        def provider(device: OOBDevice) -> SessionCredentials:
            if per_device_mode:
                print(f"\nNhập credential riêng cho {device.name}")
                credentials, source = self._credentials_with_source(
                    device, force_prompt=True, announce=False
                )
            elif batch_common is not None:
                credentials = SessionCredentials(
                    batch_common.username,
                    batch_common.password,
                    batch_common.enable_password if device.vendor == "CISCO" else None,
                )
                source = "SESSION_DEFAULT"
            else:
                credentials, source = self._credentials_with_source(
                    device, announce=False
                )
            if device.id is not None:
                credential_sources[int(device.id)] = source
            print(f"\n[{device.name}] Credential: {source}")
            return credentials

        def auth_failure_handler(device, current_credentials, result):
            source = credential_sources.get(int(device.id or 0), "UNKNOWN")
            messages.warning(
                f"{device.name}: xác thực OOB thất bại ({result.error_code}) với credential {source}."
            )
            print(
                "[1] Nhập credential riêng cho OOB này và retry\n"
                "[2] Bỏ qua OOB này\n"
                "[3] Hủy toàn bộ Scan All"
            )
            action = self._read_menu_token({"1", "2", "3"}, "Chọn: ")
            if action == "2":
                return "SKIP", None
            if action == "3":
                return "CANCEL", None

            retry_credentials = self._prompt_credentials(
                device, suggested_username=current_credentials.username
            )
            if device.id is not None:
                pending_oob_overrides[int(device.id)] = retry_credentials
                credential_sources[int(device.id)] = "OOB_OVERRIDE_RETRY"
            return "RETRY", retry_credentials

        results = self.scan_service.scan_all(
            provider,
            trigger_source="CLI_SCAN_ALL",
            auth_failure_handler=auth_failure_handler,
        )

        # Chỉ promote credential riêng khi scan đã đi qua được tầng credential.
        # FAILED/CANCELLED không chứng minh credential hợp lệ: retry có thể vẫn sai
        # enable hoặc có thể gặp TCP/SSH failure trước khi authenticate xong.
        verified_credential_statuses = {"SUCCESS", "PARTIAL", "REJECTED"}
        for result in results:
            override = pending_oob_overrides.get(int(result.oob_id))
            if override is not None and result.status in verified_credential_statuses:
                device = next((item for item in devices if item.id == result.oob_id), None)
                if device is not None:
                    self.session_credentials.set_oob(result.oob_id, device.vendor, override)

        for result in results:
            name = device_names.get(result.oob_id, f"OOB ID {result.oob_id}")
            print(
                f"{name}: {result.status} - {result.mapping_count} target"
                + (f" - {result.error_message}" if result.error_message else "")
            )
            if result.scan_id is not None:
                self._export_scan_artifacts_safe(result.scan_id)

        cancelled = next((result for result in results if result.status == "CANCELLED"), None)
        completed = [result for result in results if result.status != "CANCELLED"]
        success_count = sum(result.status == "SUCCESS" for result in completed)
        partial_count = sum(result.status == "PARTIAL" for result in completed)
        failed_count = sum(result.status in {"FAILED", "REJECTED"} for result in completed)
        cancelled_count = 1 if cancelled else 0
        cancelled_was_attempted = bool(cancelled and cancelled.scan_id is not None)
        processed_count = len(completed) + (1 if cancelled_was_attempted else 0)
        not_scanned = (
            max(total - processed_count, 0)
            if cancelled
            else max(total - len(results), 0)
        )

        print("\n" + "=" * 80)
        if cancelled:
            cancelled_name = device_names.get(cancelled.oob_id, f"OOB ID {cancelled.oob_id}")
            messages.warning(f"SCAN ALL ĐÃ HỦY tại {cancelled_name}.")
        else:
            messages.info("SCAN ALL ĐÃ HOÀN TẤT.")
        print(
            f"Tổng OOB      : {total}\n"
            f"Đã xử lý      : {processed_count}\n"
            f"SUCCESS       : {success_count}\n"
            f"PARTIAL       : {partial_count}\n"
            f"FAILED/REJECT : {failed_count}\n"
            f"CANCELLED     : {cancelled_count}\n"
            f"Chưa scan     : {not_scanned}"
        )
        if cancelled:
            print(
                "Các scan hoàn thành trước khi hủy vẫn được lưu bình thường.\n"
                "Các OOB phía sau không được gọi credential_provider hay tạo scan giả."
            )
        print("=" * 80)

    def _export_scan_artifacts_safe(self, scan_id: int) -> None:
        """Best-effort operator artifacts; export failure không được biến scan thành fail."""
        try:
            paths = self.export_service.export_after_scan(scan_id)
            messages.info(
                "Đã lưu output theo thời gian: "
                f"run={paths['run_dir']} | daily={paths['daily']} | latest={paths['latest']}"
            )
        except Exception as exc:
            self.logger.warning(
                "post-scan artifact export failed scan_id=%s error=%s",
                scan_id,
                type(exc).__name__,
            )
            messages.warning(
                "Scan đã lưu trong database nhưng không tạo được file output tự động. "
                "Có thể export lại từ Inventory & Lịch sử / Nâng cao."
            )

    def list_targets(self) -> None:
        device = self._select_oob(True)
        if not device:
            return
        targets = self.target_repo.list_current(device.id)
        if device.mapping_stale:
            messages.warning(
                "Mapping hiện tại đã cũ do cấu hình kết nối OOB/profile thay đổi. "
                "Dữ liệu chỉ dùng để đối chiếu; cần scan lại trước khi mở console."
            )
        if targets:
            tables.show_targets(targets, {device.id: device.name})
        else:
            messages.info("OOB chưa có target hiện tại.")

    def search_and_connect(self) -> None:
        query = self.input("Nhập từ khóa: ").strip()
        results = self.search_service.search_targets(query)
        if not results:
            messages.info("Không tìm thấy target.")
            return
        if self.search_service.last_truncated:
            messages.warning(
                "Có nhiều kết quả hơn giới hạn hiển thị. "
                "Cần nhập từ khóa cụ thể hơn."
            )
        tables.show_search(results)
        print("0. Quay lại")
        index = self._read_choice(0, len(results))
        if index == 0:
            return

        selected = results[index - 1]
        target = selected.target
        if selected.mapping_stale:
            messages.error(
                "Mapping console này đã cũ do cấu hình OOB/profile thay đổi. "
                "Cần scan lại OOB với mapping đủ tin cậy trước khi kết nối."
            )
            return
        if not target.is_complete:
            messages.error(
                "Không thể mở console tự động vì dữ liệu target chưa đầy đủ."
            )
            return
        if selected.oob_vendor == "CISCO" and target.protocol != "TELNET":
            messages.error("Cisco target này không phải reverse-Telnet được hỗ trợ.")
            return
        if selected.oob_vendor == "VERTIV" and target.protocol != "VERTIV_CLI":
            messages.error("Vertiv target này không phải ACS access serial port được hỗ trợ.")
            return

        endpoint = (
            f"{target.target_host}:{target.target_port}"
            if selected.oob_vendor == "CISCO"
            else f"ACS access / serial port {target.console_line or target.menu_item or '-'}"
        )
        live_check = (
            "Cisco NORMAL_CLI: đọc lại core mapping + show line/show users ngay trước reverse Telnet."
            if selected.oob_vendor == "CISCO"
            else "Vertiv ACS8000: chạy read-only 'cd access' + 'show' ngay trước 'connect <port_name>'."
        )
        from oob_manager.cli.theme import accent, bad, muted, title, warn
        print(title("┌" + "─" * 86 + "┐"))
        print(title("│" + " MANUAL CONSOLE - KIỂM TRA TRƯỚC KHI KẾT NỐI ".center(86) + "│"))
        print(title("├" + "─" * 86 + "┤"))
        print(f"│ Target         : {accent(target.alias or '(không alias)')}")
        print(f"│ OOB            : {selected.oob_name} ({selected.oob_vendor})")
        print(f"│ Console path   : {endpoint}")
        print(f"│ Scan state     : {target.state if target.state_confident else 'UNKNOWN'}")
        print(f"│ Live check     : {live_check}")
        print(title("├" + "─" * 86 + "┤"))
        print(f"│ {warn('CẢNH BÁO:')} Khi bridge mở, mọi phím nhập được gửi TRỰC TIẾP tới thiết bị thật.")
        print(f"│ {bad('Tool không tự rollback cấu hình downstream do operator nhập.')}")
        print(f"│ {muted('Thoát phiên tool: Ctrl+] rồi chọn quit.')}")
        print(title("└" + "─" * 86 + "┘"))
        if not self._confirm("Xác nhận mở console trực tiếp tới thiết bị thật?"):
            return
        device = self.oob_repo.get(target.oob_id)
        if not device:
            raise ValidationError("OOB của target không còn tồn tại.")
        allow_unverified_state = False
        override_reason = ""
        if selected.oob_vendor == "CISCO" or not target.state_confident or target.state != "AVAILABLE":
            messages.warning(
                "Nếu account vào AUTO_MENU hoặc live state không xác minh được, mặc định tool sẽ chặn. "
                "BUSY luôn bị chặn kể cả khi override."
            )
            allow_unverified_state = self._confirm(
                "Cho phép override thủ công CHỈ cho trạng thái UNKNOWN sau khi mapping/menu đã được kiểm tra?"
            )
            if allow_unverified_state:
                while not override_reason:
                    override_reason = self.input(
                        "Lý do override (BẮT BUỘC, sẽ lưu vào connection_history): "
                    ).strip()
                    if not override_reason:
                        messages.warning("Không được để trống lý do override UNKNOWN.")
                if len(override_reason) > 1000:
                    raise ValidationError("Lý do override tối đa 1000 ký tự.")
        credentials = self._credentials(device)
        port_credentials = (
            self._port_auth_credentials()
            if device.vendor == "VERTIV"
            else PortAuthenticationCredentials()
        )
        try:
            self.console_service.open(
                target.id,
                credentials,
                port_credentials=port_credentials,
                allow_unverified_state=allow_unverified_state,
                override_reason=override_reason,
                clear_line_recovery_callback=self._prompt_clear_line_recovery,
            )
        except Exception as exc:
            if (
                device.vendor == "VERTIV"
                and getattr(exc, "error_code", "") == "CONSOLE_LINE_BUSY"
            ):
                messages.error(friendly_error(exc))
                self._show_vertiv_session_recovery_guide(target.alias)
                return
            raise

    def _show_vertiv_session_recovery_guide(self, port_name: str = "") -> None:
        """Chỉ HIỂN THỊ hướng dẫn; tool tuyệt đối không kill session Vertiv tự động."""
        print("\n" + "=" * 80)
        print("        VERTIV ACS800/8000 - HƯỚNG DẪN XỬ LÝ PORT ĐANG IN-USE")
        print("=" * 80)
        if port_name:
            print(f"Target/Port Name : {port_name}")
        print(
            "\nTool KHÔNG tự đóng session. Chỉ thực hiện thủ công khi đã xác nhận không có "
            "người đang xử lý sự cố trên port đó.\n"
            "\nCác lệnh đã đối chiếu theo Vertiv ACS800/8000 Command Reference:\n"
            "  1) SSH vào management CLI của ACS.\n"
            "  2) cd active_sessions\n"
            "  3) show\n"
            "     -> tìm đúng target_name và ghi lại session ID.\n"
            "  4) Nếu được phân quyền và CHẮC CHẮN session cần đóng:\n"
            "       kill_session <session_id>\n"
            "  5) cd /\n"
            "     cd access\n"
            "     show\n"
            "     -> xác nhận port đã trở về Idle.\n"
            "  6) connect <port_name>\n"
            "\nLƯU Ý: 'show sessions', 'show ports status' và 'disconnect port5' không được "
            "tool đưa vào hướng dẫn vì chưa khớp command set ACS800/8000 chính thức đã "
            "đối chiếu.\n"
        )
        print("=" * 80)

    def _prompt_clear_line_recovery(self, context: dict) -> tuple[bool, str]:
        """Ask for explicit approval before disruptive Cisco ``clear line``.

        This callback is reached only after the adapter has re-checked the exact
        reverse-Telnet line and still proved it AVAILABLE. BUSY/UNKNOWN states
        are blocked inside the adapter and never get an approval prompt.
        """
        line = context.get("line")
        alias = context.get("alias") or "-"
        host = context.get("host") or "-"
        port = context.get("port") or "-"
        print(
            "\n" + "=" * 80 + "\n"
            "          REVERSE TELNET BỊ CONNECTION REFUSED - CLEAR LINE RECOVERY\n"
            + "=" * 80
        )
        print(
            f"\n Target       : {alias}\n"
            f" Endpoint     : {host}:{port}\n"
            f" Console line : {line}\n"
            " Live state   : AVAILABLE (đã kiểm tra lại show line/show users)\n\n"
            "Cisco trả '% Connection refused by remote host'. Trường hợp này có thể do\n"
            "async line/session cũ chưa được giải phóng. Lệnh 'clear line <N>' sẽ NGẮT\n"
            "bất kỳ session nào còn tồn tại trên line đó. Tool KHÔNG tự chạy lệnh này.\n"
        )
        messages.warning(
            f"Nếu đồng ý, tool sẽ chạy 'clear line {line}', xử lý [confirm], "
            "hậu kiểm line rồi chỉ retry Telnet đúng 1 lần."
        )
        if not self._confirm(f"Xác nhận thực thi clear line {line}?"):
            messages.info("Đã hủy clear line; không retry reverse Telnet.")
            return False, ""
        reason = ""
        while not reason:
            reason = self.input(
                "Lý do clear line (BẮT BUỘC, lưu audit): "
            ).strip()
            if not reason:
                messages.warning("Không được để trống lý do clear line.")
        if len(reason) > 1000:
            raise ValidationError("Lý do clear line tối đa 1000 ký tự.")
        return True, reason

    def discover_downstream_identity(self) -> None:
        query = self.input("Nhập alias/hostname/IP/serial để tìm target: ").strip()
        results = self.search_service.search_targets(query)
        if not results:
            messages.info("Không tìm thấy target.")
            return
        tables.show_search(results)
        print("0. Quay lại")
        index = self._read_choice(0, len(results))
        if index == 0:
            return
        selected = results[index - 1]
        target = selected.target
        if selected.mapping_stale:
            messages.error("Mapping đang STALE. Cần scan lại OOB trước khi discovery.")
            return
        device = self.oob_repo.get(target.oob_id)
        if not device:
            raise ValidationError("OOB của target không còn tồn tại.")
        if device.vendor not in {"CISCO", "VERTIV"}:
            messages.error(f"Downstream discovery chưa hỗ trợ OOB vendor {device.vendor}.")
            return

        console_path = (
            f"{target.target_host}:{target.target_port}"
            if device.vendor == "CISCO"
            else f"ACS access / serial port {target.console_line or target.menu_item or '-'} / {target.alias}"
        )
        safety_rule = (
            "Cisco: chỉ tiếp tục khi NORMAL_CLI và show line/show users xác nhận AVAILABLE."
            if device.vendor == "CISCO"
            else "Vertiv: đọc lại 'cd access' + 'show' và chỉ tiếp tục khi port được xác nhận Idle/AVAILABLE."
        )
        print(
            "\n================================================================\n"
            "       XÁC MINH DANH TÍNH THIẾT BỊ PHÍA SAU - READ ONLY\n"
            "================================================================\n"
            f"Alias cấu hình : {target.alias}\n"
            f"OOB             : {device.name} ({device.vendor} {device.host}:{device.ssh_port})\n"
            f"Đường console   : {console_path}\n\n"
            "Tool chỉ chạy whitelist command nhận dạng downstream: show/display version, inventory/chassis hardware/ESN.\n"
            "Không vào config mode, không clear/kick session, không reboot.\n"
            f"{safety_rule}\n"
            "UNKNOWN/BUSY sẽ bị fail-closed."
        )
        if not self._confirm("Tiếp tục read-only downstream discovery?"):
            return
        print("\n--- Credential OOB ---")
        oob_credentials = self._credentials(device)
        port_credentials = (
            self._port_auth_credentials()
            if device.vendor == "VERTIV"
            else PortAuthenticationCredentials()
        )
        print("\n--- Credential thiết bị phía sau ---")
        downstream_credentials = self._downstream_credentials()
        result = self.identity_service.discover(
            target.id,
            oob_credentials,
            downstream_credentials,
            port_credentials,
            clear_line_recovery_callback=self._prompt_clear_line_recovery,
        )
        identity = result.identity
        print("\nKẾT QUẢ DANH TÍNH DOWNSTREAM")
        tables.show_rows(
            ["TRƯỜNG", "GIÁ TRỊ"],
            [
                ("Alias cấu hình", target.alias or "-"),
                ("Hostname thực tế", identity.actual_hostname or "-"),
                ("Vendor", identity.vendor),
                ("Platform", identity.platform_family or "-"),
                ("Model", identity.model or "-"),
                ("Serial", identity.serial_number or "-"),
                ("Version", identity.software_version or "-"),
                ("Quality", identity.quality),
                ("Confidence", identity.confidence),
                ("So sánh alias", identity.alias_comparison),
                ("Verification", result.verification.status),
                ("Severity", result.verification.severity),
                ("Hardware continuity", result.verification.hardware_continuity),
                ("Changed fields", ", ".join(result.verification.changed_fields) or "-"),
                ("Verification reason", ", ".join(result.verification.reason_codes) or "-"),
                ("Tóm tắt", result.verification.summary or "-"),
                ("Live line", result.live_state if result.live_state_confident else "UNKNOWN"),
            ],
            [24, 70],
        )
        verification = result.verification
        if verification.status == "DEVICE_CHANGE_SUSPECTED":
            messages.warning(
                "CẢNH BÁO CAO: hardware serial khác identity ACCEPTED trước đó. "
                "Tool chỉ đánh dấu DEVICE_CHANGE_SUSPECTED; chưa tự kết luận cắm nhầm line. "
                "Cần đối chiếu RMA/change ticket và mapping OOB trước khi thao tác."
            )
        elif verification.status == "VERIFIED_MISMATCH":
            messages.warning(
                "Hostname thực tế khác alias cấu hình OOB. Đã ghi ALIAS_MISMATCH để audit; "
                "tool không tự sửa alias/mapping."
            )
        elif verification.status == "VERIFIED_MATCH":
            messages.success("Identity đã xác minh và hostname khớp alias OOB.")
        elif verification.status == "VERIFIED_IDENTITY":
            messages.info("Identity đã xác minh nhưng chưa đủ alias để kết luận MATCH/MISMATCH.")

        if identity.quality == "ACCEPTED":
            messages.success(
                "Identity đạt ACCEPTED; current identity + verification + raw evidence + snapshot "
                "đã được lưu để dò lại."
            )
            if verification.events:
                messages.info(f"Đã ghi {len(verification.events)} identity event cho run này.")
        else:
            messages.warning(
                "Identity chỉ đạt PARTIAL nên KHÔNG ghi đè current verified identity. "
                "Run/raw evidence/snapshot vẫn được giữ để điều tra. ACCEPTED yêu cầu "
                "hostname + hardware serial đáng tin."
            )

    def reconcile_oob_alias(self) -> None:
        """Human-approved alias-only reconciliation back to the OOB appliance."""
        rows = [
            row for row in self.identity_repo.list_current()
            if str(row["mapping_validity"] or "") == "VALID"
            and str(row["identity_quality"] or "") == "ACCEPTED"
            and (row["actual_hostname"] or "").strip()
            and (row["configured_alias"] or "").strip().casefold()
                != (row["actual_hostname"] or "").strip().casefold()
        ]
        if not rows:
            messages.info(
                "Không có target nào vừa có identity ACCEPTED/VALID vừa khác alias OOB. "
                "Cần chạy xác minh identity khi nghi ngờ thiết bị đã thay đổi."
            )
            return

        tables.show_rows(
            ["#", "OOB", "ALIAS OOB", "HOSTNAME THẬT", "VENDOR", "SERIAL", "VERIFY"],
            [
                (
                    idx, row["oob_name"], row["configured_alias"], row["actual_hostname"],
                    row["device_vendor"], row["serial_number"] or "-",
                    row["verification_status"],
                )
                for idx, row in enumerate(rows, 1)
            ],
            [5, 20, 22, 22, 10, 18, 24],
        )
        print("0. Quay lại")
        choice = self._read_choice(0, len(rows))
        if choice == 0:
            return
        row = rows[choice - 1]
        target_id = int(row["target_id"])
        plan = self.reconciliation_service.build_plan(target_id)
        device = self.oob_repo.get(plan.oob_id)
        if not device:
            raise ValidationError("OOB không còn tồn tại.")

        print(
            "\n================================================================\n"
            "        CONTROLLED OOB ALIAS RECONCILIATION - WRITE OPERATION\n"
            "================================================================\n"
            f"OOB             : {device.name} ({device.vendor} {device.host}:{device.ssh_port})\n"
            f"Physical path   : {plan.physical_path}\n"
            f"Alias hiện tại  : {plan.old_alias}\n"
            f"Identity thực tế: {plan.new_alias}\n\n"
            "PHẠM VI ĐƯỢC PHÉP:\n"
            "  - Chỉ đổi label/Port Name trên ĐÚNG physical console path đã xác minh.\n"
            "  - Cisco: KHÔNG đổi menu command, target host/port hay console line.\n"
            "  - Vertiv: KHÔNG đổi serial port number, SSH/Telnet alias hay CAS protocol.\n"
            "  - Không bao giờ tự push chỉ vì phát hiện mismatch.\n"
            "  - BUSY/UNKNOWN bị chặn tuyệt đối cho reconciliation.\n"
        )
        print("COMMAND DIFF DỰ KIẾN:")
        for command in plan.proposed_commands:
            print(f"  {command}")
        messages.warning(
            "Chỉ tiếp tục khi thay đổi đã được xác nhận hợp lệ (RMA/change ticket), "
            "không phải cắm nhầm dây hoặc hostname downstream bị đổi sai."
        )
        ticket_id = self._read_nonempty("Change/Ticket ID: ", "Change/Ticket ID")
        reason = self._read_nonempty("Lý do thay đổi: ", "Lý do thay đổi")
        confirmation = self.input(
            f"Gõ chính xác alias mới '{plan.new_alias}' để xác nhận WRITE: "
        ).strip()
        if confirmation != plan.new_alias:
            messages.info("Alias xác nhận không khớp; đã hủy mà không ghi cấu hình.")
            return

        print("\n--- Credential OOB có quyền cấu hình alias ---")
        credentials = self._credentials(device)
        try:
            reconciliation_id, result = self.reconciliation_service.apply(
                plan, credentials, ticket_id=ticket_id, reason=reason
            )
        except Exception:
            current = self.oob_repo.get(plan.oob_id)
            if (
                current
                and current.mapping_stale
                and (current.baseline_stale_reason or "").startswith("CONTROLLED_RECONCILIATION:")
            ):
                messages.error(
                    "Reconciliation không hoàn tất sạch nhưng baseline đã được khóa STALE trước write. "
                    "Không mở console; cần kiểm tra OOB và chạy scan ACCEPTED trước khi tiếp tục."
                )
            raise
        messages.success(result.verification_message)
        messages.warning(
            "Sau write, baseline được đánh dấu STALE có chủ đích. Tool sẽ scan lại ngay; "
            "nếu scan không ACCEPTED thì mọi console vẫn bị block cho tới khi scan thành công."
        )
        try:
            scan_result = self.scan_service.scan_one(
                plan.oob_id, credentials, trigger_source="CLI_RECONCILE"
            )
        except Exception:
            self.reconciliation_service.update_baseline_refresh(
                reconciliation_id, "RESCAN_FAILED"
            )
            raise
        if scan_result.baseline_updated:
            self.reconciliation_service.update_baseline_refresh(
                reconciliation_id, "RESCAN_BASELINE_UPDATED"
            )
            messages.success(
                f"Rescan #{scan_result.scan_id} đã ACCEPT mapping mới và cập nhật baseline."
            )
            messages.info(
                "Alias mapping đã đổi nên current downstream identity cũ được invalidated có chủ đích. "
                "Cần xác minh identity lại trên baseline mới."
            )
        else:
            self.reconciliation_service.update_baseline_refresh(
                reconciliation_id, "RESCAN_NOT_ACCEPTED"
            )
            messages.error(
                f"Rescan #{scan_result.scan_id} chưa cập nhật baseline. Mapping vẫn STALE/fail-closed; "
                "không mở console cho tới khi scan ACCEPTED."
            )

    def show_device_identities(self) -> None:
        rows = self.identity_repo.list_current()
        if not rows:
            messages.info("Chưa có downstream identity nào đạt quality=ACCEPTED.")
            return
        tables.show_rows(
            ["TARGET", "HOSTNAME THẬT", "VENDOR", "MODEL", "SERIAL", "VERIFY", "HW", "SEV", "CHANGED", "MAP", "XÁC MINH LÚC"],
            [
                (
                    row["configured_alias"] or "-",
                    row["actual_hostname"] or "-",
                    row["device_vendor"],
                    row["model"] or "-",
                    row["serial_number"] or "-",
                    row["verification_status"],
                    row["hardware_continuity"],
                    row["verification_severity"],
                    row["changed_fields"] or "-",
                    row["mapping_validity"],
                    format_datetime(row["verified_at"]),
                )
                for row in rows
            ],
            [20, 20, 8, 16, 17, 23, 10, 8, 18, 7, 18],
        )

    def show_identity_events(self) -> None:
        rows = self.identity_repo.list_recent_events()
        if not rows:
            messages.info("Chưa có identity event/bất thường được ghi nhận.")
            return
        tables.show_rows(
            ["ID", "THỜI GIAN", "OOB", "TARGET", "MỨC", "SỰ KIỆN", "FIELD", "OLD", "NEW"],
            [
                (
                    row["identity_event_id"],
                    format_datetime(row["detected_at"]),
                    row["oob_name"],
                    row["configured_alias"] or row["actual_hostname"] or "-",
                    row["severity"],
                    row["event_code"],
                    row["field_name"] or "-",
                    row["old_value"] or "-",
                    row["new_value"] or "-",
                )
                for row in rows
            ],
            [6, 18, 20, 20, 8, 28, 20, 22, 22],
        )
        self.identity_repo.mark_events_viewed(
            [int(row["identity_event_id"]) for row in rows]
        )

    def show_changes(self) -> None:
        rows = self.change_repo.list_recent()
        if not rows:
            messages.info("Chưa có thay đổi.")
            return
        tables.show_rows(
            ["ID", "OOB", "THỜI GIAN", "SỰ KIỆN", "TARGET"],
            [
                (
                    row["id"],
                    row["oob_name"],
                    format_datetime(row["detected_at"]),
                    EVENT_LABELS_VI.get(row["event_code"], row["event_code"]),
                    row["target_identity"],
                )
                for row in rows
            ],
            [6, 28, 18, 34, 30],
        )
        self.change_repo.mark_viewed([int(row["id"]) for row in rows])

    def show_scans(self) -> None:
        rows = self.scan_repo.list_recent()
        if not rows:
            messages.info("Chưa có lịch sử scan.")
            return
        tables.show_rows(
            ["ID", "OOB", "BẮT ĐẦU", "SCAN", "MAPPING", "BASELINE", "TARGET", "WARN"],
            [
                (
                    row["id"],
                    row["oob_name"],
                    format_datetime(row["started_at"]),
                    STATUS_LABELS_VI.get(row["status"], row["status"]),
                    row["mapping_quality"],
                    "CẬP NHẬT" if row["baseline_updated"] else "GIỮ",
                    row["mapping_count"],
                    row["warning_count"],
                )
                for row in rows
            ],
            [6, 24, 18, 24, 12, 10, 8, 8],
        )

    def current_inventory_review(self) -> None:
        rows = self.export_service.current_inventory_rows()
        if not rows:
            messages.info("Chưa có inventory hiện tại. Cần scan OOB trước.")
            return
        print("INVENTORY HIỆN TẠI")
        tables.show_rows(
            ["OOB", "TARGET", "CONSOLE", "STATE", "HOSTNAME THẬT", "MODEL", "SERIAL", "KẾT QUẢ", "LAST SCAN"],
            [
                (
                    row["oob"],
                    row["target_alias"],
                    row["console_path"],
                    row["state"],
                    row["actual_hostname"] or "CHƯA XÁC MINH",
                    row["model"] or "-",
                    row["serial"] or "-",
                    row["overall"],
                    row["last_scan_at"] or "-",
                )
                for row in rows
            ],
            [18, 24, 25, 12, 24, 16, 18, 18, 18],
        )
        print(
            f"\nTổng: {len(rows)} target | "
            f"NORMAL={sum(1 for row in rows if row['overall'] == 'NORMAL')} | "
            f"MISMATCH={sum(1 for row in rows if row['overall'] == 'MISMATCH')} | "
            f"CHƯA XÁC MINH={sum(1 for row in rows if row['overall'] == 'CHƯA_XÁC_MINH')}"
        )

    def target_history_review(self) -> None:
        query = self.input("Tìm target để xem lịch sử: ").strip()
        candidates = self.export_service.search_history_targets(query)
        if not candidates:
            messages.info("Không tìm thấy target trong snapshot lịch sử.")
            return
        tables.show_rows(
            ["STT", "TARGET", "OOB", "CONSOLE GẦN NHẤT", "LAST SEEN"],
            [
                (index, row["alias"], row["oob"], row["console_path"], row["last_seen"])
                for index, row in enumerate(candidates, 1)
            ],
            [6, 26, 22, 28, 19],
        )
        print("0. Quay lại")
        index = self._read_choice(0, len(candidates))
        if index == 0:
            return
        target_id = int(candidates[index - 1]["target_id"])
        history = self.export_service.target_history_rows(target_id)
        if not history:
            messages.info("Chưa có snapshot lịch sử cho target này.")
            return
        print("\nLỊCH SỬ THIẾT BỊ")
        tables.show_rows(
            ["TIME", "SCAN", "OOB", "TARGET", "CONSOLE", "STATE", "HOSTNAME THẬT", "SERIAL", "MAPPING"],
            [
                (
                    row["time"], row["scan_id"], row["oob"], row["target_alias"],
                    row["console_path"], row["state"], row["actual_hostname"] or "-",
                    row["serial"] or "-", row["mapping_quality"],
                )
                for row in history
            ],
            [19, 7, 20, 24, 25, 12, 24, 18, 12],
        )
        messages.info(
            "Dữ liệu lấy từ console_snapshots theo từng scan; target đã mất khỏi current inventory vẫn tìm được theo lịch sử."
        )

    def scan_snapshot_review(self) -> None:
        raw = self.input("Nhập Scan ID cần xem: ").strip()
        try:
            scan_id = int(raw)
        except ValueError as exc:
            raise ValidationError("Scan ID phải là số nguyên dương.") from exc
        if scan_id <= 0:
            raise ValidationError("Scan ID phải là số nguyên dương.")
        summary = self.export_service.get_scan_summary(scan_id)
        if not summary:
            messages.info(f"Không tìm thấy Scan ID {scan_id}.")
            return
        print("\nCHI TIẾT SCAN")
        tables.show_rows(
            ["SCAN", "OOB", "TIME", "STATUS", "MAPPING", "TARGET", "CHANGE", "WARN"],
            [(
                summary["scan_id"], summary["oob_name"], summary["started_at_local"],
                summary["status"], summary["mapping_quality"], summary["mapping_count"],
                summary["change_count"], summary["warning_count"],
            )],
            [7, 24, 19, 14, 12, 8, 8, 8],
        )
        rows = self.export_service.scan_snapshot_rows(scan_id)
        if not rows:
            messages.warning("Scan tồn tại nhưng không có console snapshot để hiển thị.")
            return
        tables.show_rows(
            ["TARGET", "CONSOLE", "STATE", "HOSTNAME THẬT", "MODEL", "SERIAL", "KẾT QUẢ"],
            [
                (
                    row["target_alias"], row["console_path"], row["state"],
                    row["actual_hostname"] or "CHƯA XÁC MINH", row["model"] or "-",
                    row["serial"] or "-", row["overall"],
                )
                for row in rows
            ],
            [24, 26, 12, 24, 16, 18, 18],
        )

    def export_simple_current_inventory(self) -> None:
        path = self.export_service.export_current_inventory()
        messages.success(f"Đã xuất CSV inventory đơn giản:\n{path}")

    def daily_inventory_today(self) -> None:
        self._show_daily_inventory(date.today())

    def daily_inventory_review(self) -> None:
        day = self._read_review_date()
        self._show_daily_inventory(day)

    def _show_daily_inventory(self, day: date) -> None:
        print("=" * 80)
        print(f"                INVENTORY NGÀY {day.strftime('%d/%m/%Y')}")
        print("=" * 80)
        scans = self.export_service.list_daily_scans(day)
        if not scans:
            messages.info(f"Không có scan nào trong ngày {day.strftime('%d/%m/%Y')}.")
            return

        tables.show_rows(
            ["SCAN", "OOB", "BẮT ĐẦU", "STATUS", "MAPPING", "TARGET", "CHANGE"],
            [
                (
                    row["scan_id"],
                    row["oob_name"],
                    format_datetime(row["started_at"]),
                    STATUS_LABELS_VI.get(row["status"], row["status"]),
                    row["mapping_quality"],
                    row["mapping_count"],
                    row["change_count"],
                )
                for row in scans
            ],
            [7, 24, 18, 18, 12, 8, 8],
        )

        inventory = self.export_service.daily_inventory_rows(day)
        if not inventory:
            messages.warning(
                "Có scan trong ngày nhưng chưa có mapping ACCEPTED để dựng daily inventory. "
                "Xem lịch sử scan để kiểm tra scan PARTIAL/REJECTED."
            )
            return

        print("\nSnapshot đại diện: scan mapping ACCEPTED mới nhất của từng OOB trong ngày.")
        tables.show_rows(
            ["OOB", "TARGET", "CONSOLE", "STATE", "HOSTNAME THẬT", "MODEL", "SERIAL", "KẾT QUẢ"],
            [
                (
                    row["oob"],
                    row["target_alias"],
                    row["console_path"],
                    row["state"],
                    row["actual_hostname"] or "CHƯA XÁC MINH",
                    row["model"] or "-",
                    row["serial"] or "-",
                    row["overall"],
                )
                for row in inventory
            ],
            [20, 25, 25, 12, 25, 16, 18, 18],
        )
        print(
            f"\nTổng: {len(inventory)} target | "
            f"NORMAL={sum(1 for row in inventory if row['overall'] == 'NORMAL')} | "
            f"MISMATCH={sum(1 for row in inventory if row['overall'] == 'MISMATCH')} | "
            f"CHƯA XÁC MINH={sum(1 for row in inventory if row['overall'] == 'CHƯA_XÁC_MINH')}"
        )
        if self._confirm("Xuất 1 file CSV đơn giản cho ngày này?"):
            path = self.export_service.export_daily_inventory(day)
            messages.success(f"Đã xuất:\n{path}")


    def _read_review_date(self) -> date:
        while True:
            raw = self.input(
                f"Ngày cần xem [DD/MM/YYYY hoặc YYYY-MM-DD, Enter={date.today().strftime('%d/%m/%Y')}]: "
            ).strip()
            if not raw:
                return date.today()
            for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
                try:
                    return datetime.strptime(raw, fmt).date()
                except ValueError:
                    pass
            messages.warning("Ngày không hợp lệ. Ví dụ: 27/07/2026 hoặc 2026-07-27.")

    def show_connections(self) -> None:
        rows = self.connection_repo.list_recent()
        if not rows:
            messages.info("Chưa có lịch sử kết nối.")
            return
        tables.show_rows(
            ["ID", "OOB", "TARGET", "OPERATOR", "BẮT ĐẦU", "PHIÊN", "MAP", "LINE", "OVERRIDE", "CLEAR", "LÝ DO"],
            [
                (
                    row["id"],
                    row["oob_name"],
                    row["target_alias_display"] or "-",
                    row["username"] or "-",
                    format_datetime(row["started_at"]),
                    CONNECTION_STATUS_LABELS_VI.get(row["status"], row["status"]),
                    "OK" if row["runtime_mapping_verified"] else "CHƯA",
                    row["live_state"] if row["live_state_confident"] else "UNKNOWN",
                    "DÙNG" if row["safety_override_used"] else ("YÊU CẦU" if row["safety_override_requested"] else "-"),
                    (f"LINE {row['clear_line_number']}" if row["clear_line_recovery_used"] else ("ĐỀ XUẤT" if row["clear_line_recovery_requested"] else "-")),
                    (row["clear_line_reason"] or row["safety_override_reason"] or "-"),
                )
                for row in rows
            ],
            [6, 18, 20, 16, 16, 14, 7, 12, 8, 10, 30],
        )

    def update_oob(self) -> None:
        device = self._select_oob(True)
        if not device:
            return
        old_identity = (
            device.host,
            device.ssh_port,
            device.vendor,
            device.connection_mode,
        )

        device.name = self._read_nonempty(
            f"Tên [{device.name}]: ", "Tên OOB", device.name
        )
        device.host = self._read_host(f"Host [{device.host}]: ", device.host)
        device.ssh_port = self._read_port(
            f"SSH port quản trị OOB [{device.ssh_port}] (Vertiv: không phải serial alias): ",
            device.ssh_port,
        )

        print(f"Vendor hiện tại: {device.vendor}")
        device.vendor = self._read_vendor_choice(device.vendor)
        device.device_type = "cisco_ios" if device.vendor == "CISCO" else "vertiv"

        if device.connection_mode != "SSH":
            messages.warning(
                f"Mode legacy {device.connection_mode} không còn được hỗ trợ; chuyển về SSH."
            )
        device.connection_mode = "SSH"

        username_value = self.input(
            f"Username SSH mặc định [{device.default_username or '-'}] "
            "(Enter giữ nguyên, '-' để xóa): "
        ).strip()
        if username_value:
            device.default_username = "" if username_value == "-" else username_value
        messages.info("Username mặc định được lưu; password/enable password vẫn chỉ ở RAM.")
        notes = self.input(f"Ghi chú [{device.notes}] (nhập - để xóa): ").strip()
        if notes:
            device.notes = "" if notes == "-" else notes

        device.enabled = self._read_optional_enabled(device.enabled)

        new_identity = (
            device.host,
            device.ssh_port,
            device.vendor,
            device.connection_mode,
        )
        if new_identity != old_identity:
            messages.warning(
                "Host/port/vendor/connection mode đã thay đổi. Mapping hiện tại sẽ "
                "được đánh dấu cần scan lại và không thể dùng để mở console."
            )
        saved = self.oob_service.create_update_validation(device)
        messages.success("Đã cập nhật OOB.")
        if saved.mapping_stale:
            messages.warning("Mapping đang STALE/CẦN SCAN LẠI trước khi mở console.")

    def delete_oob(self) -> None:
        device = self._select_oob(True)
        if not device:
            return
        print(
            "1. Vô hiệu hóa OOB\n"
            "2. Xóa hoàn toàn OOB khỏi DB active (lịch sử chỉ còn trong backup)\n"
            "0. Hủy"
        )
        choice = self._read_choice(0, 2)
        if choice == 1:
            self.oob_repo.disable(device.id)
            messages.success("Đã vô hiệu hóa OOB.")
            return
        if choice != 2:
            return

        counts = self.oob_repo.related_counts(device.id)
        messages.warning(
            "XÓA CỨNG sẽ xóa inventory + scan/raw/snapshot/change/connection history của OOB "
            "khỏi database đang dùng. Chỉ file backup tạo ngay trước khi xóa còn giữ lịch sử đó. "
            "Nếu cần audit lâu dài, nên chọn Vô hiệu hóa thay vì Xóa hoàn toàn.\n"
            "Dữ liệu liên quan trong DB active sẽ bị xóa:\n"
            + "\n".join(f"- {name}: {count}" for name, count in counts.items())
        )
        typed_name = self.input(
            f"Nhập lại tên OOB '{device.name}' để xác nhận: "
        ).strip()
        if typed_name != device.name:
            messages.warning("Tên xác nhận không khớp.")
            return
        backup_path = self.backup_service.create_backup()
        self.oob_repo.hard_delete(device.id)
        messages.success(f"Đã xóa. Backup trước xóa: {backup_path}")

    def backup_db(self) -> None:
        print("Đang sao lưu cơ sở dữ liệu...")
        path = self.backup_service.create_backup()
        messages.success(f"Đã tạo:\n{path}")

    def settings_menu(self) -> None:
        while True:
            print(
                "\n1. TCP connect timeout\n"
                "2. SSH banner/auth/shell timeout và retry\n"
                "3. Command timeout\n"
                "4. Maximum drop ratio\n"
                "5. Thư mục export\n"
                "6. Xuất báo cáo CSV\n"
                "7. Xem operation lock\n"
                "8. Kiểm tra database / audit views\n"
                "0. Quay lại"
            )
            choice = self._read_choice(0, 8)
            if choice == 0:
                return
            if choice == 1:
                self._save_settings(
                    {"connect_timeout": self.input("Giây: ").strip()}
                )
            elif choice == 2:
                self._save_settings(
                    {
                        "banner_timeout": self.input("Banner timeout giây: ").strip(),
                        "auth_timeout": self.input("Authentication timeout giây: ").strip(),
                        "shell_timeout": self.input("Open shell timeout giây: ").strip(),
                        "connection_attempts": self.input("Số lần thử SSH (1-3): ").strip(),
                        "retry_delay": self.input("Delay giữa các lần thử: ").strip(),
                        "operation_lock_lease_seconds": self.input("Operation lock lease giây (>=60): ").strip(),
                        "operation_lock_heartbeat_seconds": self.input("Lock heartbeat giây (>=5): ").strip(),
                    }
                )
            elif choice == 3:
                self._save_settings(
                    {"command_timeout": self.input("Giây: ").strip()}
                )
            elif choice == 4:
                self._save_settings(
                    {
                        "maximum_drop_ratio": self.input(
                            "Maximum drop ratio (0-1): "
                        ).strip()
                    }
                )
            elif choice == 5:
                self._save_settings(
                    {"export_dir": self.input("Thư mục export: ").strip()}
                )
            elif choice == 6:
                messages.success(
                    f"Đã xuất dữ liệu tại {self.export_service.export_all()}"
                )
            elif choice == 7:
                locks = self.lock_repo.list_all()
                if locks:
                    tables.show_rows(
                        ["OOB ID", "OPERATION", "PID", "MÁY", "BẮT ĐẦU", "HEARTBEAT", "LEASE ĐẾN"],
                        [
                            (
                                row["oob_id"],
                                row["operation"],
                                row["pid"],
                                row["hostname"],
                                format_datetime(row["started_at"]),
                                format_datetime(row["heartbeat_at"]),
                                format_datetime(row["expires_at"]),
                            )
                            for row in locks
                        ],
                        [8, 20, 10, 24, 18, 18, 18],
                    )
                else:
                    messages.info("Không có operation lock đang hoạt động.")
            elif choice == 8:
                self._show_database_health()

    def _show_database_health(self) -> None:
        """Kiểm tra read-only để operator biết DB có toàn vẹn và audit được không."""
        raw_integrity_errors = 0
        invalid_state_evidence = 0
        with self.db.read() as conn:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            fk_errors = conn.execute("PRAGMA foreign_key_check").fetchall()
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            counts = {
                "OOB": conn.execute("SELECT COUNT(*) FROM oob_devices").fetchone()[0],
                "Current targets": conn.execute("SELECT COUNT(*) FROM console_targets").fetchone()[0],
                "Scans": conn.execute("SELECT COUNT(*) FROM scan_runs").fetchone()[0],
                "Raw outputs": conn.execute("SELECT COUNT(*) FROM raw_outputs").fetchone()[0],
                "Findings": conn.execute("SELECT COUNT(*) FROM scan_findings").fetchone()[0],
                "Snapshots": conn.execute("SELECT COUNT(*) FROM console_snapshots").fetchone()[0],
                "Changes": conn.execute("SELECT COUNT(*) FROM change_events").fetchone()[0],
                "Connections": conn.execute("SELECT COUNT(*) FROM connection_history").fetchone()[0],
                "OOB config changes": conn.execute("SELECT COUNT(*) FROM oob_change_history").fetchone()[0],
                "Identity runs": conn.execute("SELECT COUNT(*) FROM device_identity_runs").fetchone()[0],
                "Current identities": conn.execute("SELECT COUNT(*) FROM device_identities").fetchone()[0],
                "Identity raw outputs": conn.execute("SELECT COUNT(*) FROM device_identity_raw_outputs").fetchone()[0],
                "Identity events": conn.execute("SELECT COUNT(*) FROM device_identity_events").fetchone()[0],
            }
            views = {row["name"] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='view'"
            ).fetchall()}
            quality_issues = DatabaseAuditService.collect_issues(conn)
            raw_integrity_errors = sum(
                1 for row in quality_issues
                if row["issue_code"] == "RAW_OUTPUT_INTEGRITY_MISMATCH"
            )
            invalid_state_evidence = sum(
                1 for row in quality_issues
                if row["issue_code"] == "INVALID_STATE_EVIDENCE_JSON"
            )
        print(f"Schema version: {version}")
        print(f"SQLite integrity_check: {integrity}")
        print(f"Foreign key errors: {len(fk_errors)}")
        print(f"Raw output hash/length errors: {raw_integrity_errors}")
        print(f"Invalid current state_evidence JSON: {invalid_state_evidence}")
        print(f"Data quality issues: {len(quality_issues)}")
        print("Audit views: " + ", ".join(sorted(views)))
        tables.show_rows(
            ["NHÓM DỮ LIỆU", "SỐ DÒNG"],
            [(name, value) for name, value in counts.items()],
            [28, 12],
        )
        if quality_issues:
            tables.show_rows(
                ["MỨC", "MÃ", "OOB", "SCAN", "TARGET", "MÔ TẢ"],
                [
                    (
                        row["severity"],
                        row["issue_code"],
                        row["oob_id"] or "-",
                        row["scan_id"] or "-",
                        row["target_id"] or "-",
                        row["message"],
                    )
                    for row in quality_issues[:20]
                ],
                [9, 38, 7, 7, 8, 55],
            )
            if len(quality_issues) > 20:
                messages.warning(
                    f"Còn {len(quality_issues) - 20} issue khác; xem v_data_quality_issues hoặc CSV export."
                )
        fatal_quality_issues = [row for row in quality_issues if row["severity"] == "ERROR"]
        if (
            integrity == "ok"
            and not fk_errors
            and raw_integrity_errors == 0
            and invalid_state_evidence == 0
            and not fatal_quality_issues
        ):
            messages.success("Database hiện toàn vẹn và có thể truy vết qua audit views/CSV.")
        else:
            messages.error(
                "Database/audit có lỗi cần kiểm tra. Cần backup và xử lý các issue ERROR trước khi sử dụng dữ liệu."
            )

    def _save_settings(self, updates: dict[str, str]) -> None:
        current_values = self.settings_repo.get_all()
        candidate_values = {**current_values, **updates}
        candidate = ApplicationSettings.from_mapping(
            candidate_values,
            debug=self.debug,
        )
        self.settings_repo.set_many(updates)
        self._apply_settings(candidate)
        messages.success("Đã cập nhật cấu hình.")

    def _apply_settings(self, settings: ApplicationSettings) -> None:
        self.settings = settings
        self.scan_service.settings = settings
        self.scan_service.quality.minimum_complete_ratio = 1.0
        self.scan_service.quality.maximum_drop_ratio = settings.maximum_drop_ratio
        self.lock_repo.lease_seconds = settings.operation_lock_lease_seconds
        self.lock_repo.heartbeat_seconds = settings.operation_lock_heartbeat_seconds
        self.console_service.settings = settings
        self.identity_service.settings = settings
        self.export_service.settings = settings

    def _confirm(self, message: str) -> bool:
        value = self.input(f"{message} [c/K]: ").strip().casefold()
        return value in {"c", "co", "có", "y", "yes"}
