from __future__ import annotations

from oob_manager.cli.prompts import format_datetime, truncate_text
from oob_manager.cli.theme import accent, muted, style_value


def _table(headers, rows, widths):
    inner = sum(widths) + 3 * (len(widths) - 1) + 2
    print(muted("┌" + "─" * inner + "┐"))
    header_cells = [truncate_text(str(h), w).ljust(w) for h, w in zip(headers, widths)]
    print("│ " + " │ ".join(accent(cell) for cell in header_cells) + " │")
    print(muted("├" + "─" * inner + "┤"))
    for row in rows:
        cells = []
        for value, width in zip(row, widths):
            raw = truncate_text(str(value), width)
            cells.append(style_value(value, raw.ljust(width)))
        print("│ " + " │ ".join(cells) + " │")
    print(muted("└" + "─" * inner + "┘"))


def _target_endpoint(target, vendor: str = "") -> str:
    if (vendor or "").upper() == "VERTIV" or target.protocol == "VERTIV_CLI":
        port = target.console_line if target.console_line is not None else target.menu_item
        return f"ACS access / port {port if port is not None else '-'}"
    return f"{target.target_host}:{target.target_port}" if target.target_host else "-"


def show_oobs(devices):
    _table(
        ["STT", "TÊN OOB", "ĐỊA CHỈ", "VENDOR", "TRẠNG THÁI", "MAPPING", "LẦN QUÉT CUỐI"],
        [
            (
                i,
                d.name,
                f"{d.host}:{d.ssh_port}",
                d.vendor,
                "ĐANG BẬT" if d.enabled else "ĐÃ TẮT",
                "CẦN SCAN LẠI" if d.mapping_stale else "VALID",
                format_datetime(d.last_scan_at),
            )
            for i, d in enumerate(devices, 1)
        ],
        [4, 28, 21, 8, 11, 14, 17],
    )


def show_targets(targets, oob_names=None):
    oob_names = oob_names or {}
    _table(
        ["STT", "ALIAS OOB", "OOB", "MENU", "ITEM", "ENDPOINT CONSOLE", "TRẠNG THÁI"],
        [
            (
                i,
                t.alias or "(không alias)",
                oob_names.get(t.oob_id, str(t.oob_id)),
                t.menu_name,
                t.menu_item if t.menu_item is not None else "-",
                _target_endpoint(t),
                t.state if t.state_confident or t.state == "INCOMPLETE" else "UNKNOWN",
            )
            for i, t in enumerate(targets, 1)
        ],
        [4, 26, 23, 11, 6, 23, 14],
    )


def show_search(results):
    _table(
        ["STT", "ALIAS OOB", "HOSTNAME THẬT", "OOB", "ITEM", "ENDPOINT CONSOLE", "MAPPING"],
        [
            (
                i,
                r.target.alias or "(không alias)",
                r.actual_hostname or "CHƯA XÁC MINH",
                r.oob_name,
                r.target.menu_item if r.target.menu_item is not None else "-",
                _target_endpoint(r.target, r.oob_vendor),
                "STALE" if r.mapping_stale else "VALID",
            )
            for i, r in enumerate(results, 1)
        ],
        [4, 25, 23, 21, 6, 23, 8],
    )


def show_rows(headers, rows, widths):
    _table(headers, rows, widths)
