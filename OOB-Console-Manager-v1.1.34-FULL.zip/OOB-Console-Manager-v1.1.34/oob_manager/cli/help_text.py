"""HELP ngắn gọn theo 5 workflow operator của v1.1.34."""
from __future__ import annotations

HELP_TEXTS: dict[str, str] = {
    "quick": r"""
================================================================================
                           HƯỚNG DẪN NHANH
================================================================================
QUY TRÌNH LẦN ĐẦU / CÔNG VIỆC HẰNG NGÀY
  [1] OOB & SCAN
      Workflow chính: fresh scan rồi so Device A (mapping OOB) với Device B
      (hostname thật từ banner/prompt). Mapping-only nằm riêng khi cần.

  [2] TÌM & KẾT NỐI THIẾT BỊ
      Tìm target rồi mở manual console. Search không phụ thuộc thứ tự token:
      bras-HCM / HCM-BRAS / hcm bras đều có thể tìm cùng nhóm target.

  [3] IDENTITY NÂNG CAO
      Full Identity read-only là chức năng nâng cao: hostname, vendor, model,
      serial, version. Quick A/B KHÔNG chạy qua workflow này.

  [4] INVENTORY & LỊCH SỬ
      Inventory hiện tại/hôm nay/theo ngày, lịch sử từng target, xem đúng một
      Scan ID, mapping changes, connection history và CSV đơn giản.

  [5] CẬP NHẬT OOB
      Xem mismatch rồi đồng bộ alias/name OOB có kiểm soát khi change hợp lệ.

  [C] CREDENTIAL PHIÊN LÀM VIỆC
      Nạp username/password một lần vào RAM cho cả phiên; có thể dùng chung hoặc
      riêng Cisco/Vertiv. Password không lưu DB/log/CSV và mất khi thoát tool.

  [A] NÂNG CAO
      Backup DB, timeout/retry, export audit đầy đủ, locks, DB Health.

KHÔNG CLEAR SCREEN
  Tool không chạy cls/clear. Toàn bộ output trước đó được giữ để scroll lên dò lại.

MANUAL CONSOLE
  Khi bridge mở, mọi lệnh operator gõ được gửi trực tiếp tới thiết bị thật.
  Identity Discovery ở [3] vẫn chỉ chạy whitelist read-only.
  Ctrl+] mở menu local của terminal bridge.

MÀU
  Xanh: OK/AVAILABLE/NORMAL   Vàng: PARTIAL/UNKNOWN   Đỏ: BUSY/ERROR/MISMATCH
================================================================================
""",
    "scan": r"""
================================================================================
                         HELP - SCAN / MAPPING
================================================================================
SUCCESS  : scan hoàn tất.
PARTIAL  : telemetry phụ chưa đầy đủ; cần xem mapping_quality.
REJECTED : mapping không đủ tin cậy; baseline cũ được giữ.
ACCEPTED : core mapping đủ bằng chứng để dùng làm baseline.
AVAILABLE: line/port được chứng minh rảnh.
BUSY     : đang có session; bị chặn.
UNKNOWN  : chưa đủ bằng chứng; mặc định fail-closed.
================================================================================
""",
    "targets": r"""
================================================================================
                       HELP - TARGET / CONSOLE
================================================================================
ALIAS OOB      : tên cấu hình trên OOB, chưa chắc là hostname vật lý thật.
ENDPOINT/LINE  : console path do OOB cấu hình.
STATE          : state ở scan gần nhất; trước connect tool sẽ live-verify lại.

Search v1.1.31 là token search: bras-HCM và HCM-BRAS đều tìm các target có cả
BRAS và HCM, không bắt buộc đúng thứ tự.

BUSY luôn bị chặn. UNKNOWN chỉ override ở đường đã thiết kế và phải lưu lý do.
================================================================================
""",
    "connections": r"""
================================================================================
                      HELP - LỊCH SỬ KẾT NỐI
================================================================================
SUCCESS : phiên kết thúc không ghi nhận lỗi tool.
FAILED  : không mở được hoặc bị safety gate chặn.
MAP OK  : runtime mapping đã được xác minh lúc mở.
OVERRIDE: operator đã dùng/yêu cầu override UNKNOWN; lý do được audit.
CLEAR   : Cisco clear-line recovery; BUSY/UNKNOWN không được clear line.
SESSION LOG: session_logs/YYYY-MM-DD/conn_<ID>_<TARGET>.log nếu terminal bridge đã mở.
================================================================================
""",
    "identity": r"""
================================================================================
                        HELP - DEVICE IDENTITY
================================================================================
Identity Discovery đi qua console và chỉ chạy command read-only để lấy:
hostname, vendor, model, serial, software version.

EXACT_MATCH    : hostname thật khớp alias OOB.
MISMATCH       : alias/hostname hoặc hardware có khác biệt cần kiểm tra.
SERIAL_CHANGED : có dấu hiệu thay thiết bị/RMA/cable change; không tự kết luận.

QUICK A/B (nằm ở [1] OOB & SCAN, tách khỏi Full Identity):
  Device A = alias/name từ mapping OOB của fresh scan ACCEPTED.
  Device B = hostname nhìn thấy thật từ pre-login banner hoặc device prompt.
  Chỉ đọc hostname; KHÔNG gửi username/password downstream.
  KHÔNG chạy show/version/inventory xuống thiết bị.
  Console im lặng chỉ được wake bằng đúng 1 Enter; vẫn không thấy hostname => NO_HOSTNAME.
  Chỉ COMPLETE + AVAILABLE/confident được auto-connect; BUSY/UNKNOWN/STALE => SKIP/ERROR.
  Cisco Connection Refused trong Quick A/B => SKIP/ERROR; KHÔNG hỏi/không chạy clear line.
  Vertiv port-auth password trong Quick A/B => SKIP/ERROR; KHÔNG hỏi credential phụ.
  A != B => MISMATCH và ghi cable_mismatch.csv; tool KHÔNG tự sửa alias/mapping.
  Chỉ có 4 trạng thái operator: MATCH / MISMATCH / NO_HOSTNAME / SKIP/ERROR.

Controlled clear-line và Full Identity chỉ tồn tại ở workflow manual/nâng cao riêng,
không được gọi ngầm từ Quick A/B.
================================================================================
""",
    "changes": r"""
================================================================================
                     HELP - CHANGE / DRIFT EVENTS
================================================================================
Mapping changes: alias/host/port/line/menu item/command thay đổi giữa baseline.
Identity events: hostname/serial/device identity thay đổi phía sau console.
Đối chiếu cả hai nguồn trước khi sửa OOB hoặc kết luận cắm sai dây.
================================================================================
""",
    "reconciliation": r"""
================================================================================
                      HELP - CẬP NHẬT OOB
================================================================================
Đây là WRITE có kiểm soát (chức năng cũ: Menu 17): chỉ đồng bộ alias/name trên đúng physical console
path đã xác minh. Không tự đổi reverse-Telnet host/port, console line hay serial
port number. Có ticket/lý do, live verification, read-back và rescan.
================================================================================
""",
    "daily": r"""
================================================================================
                     HELP - INVENTORY / LỊCH SỬ
================================================================================
Inventory hiện tại : trạng thái current target + identity gần nhất.
Lịch sử target      : tìm một thiết bị rồi xem mapping/state của từng scan trước.
Inventory hôm nay  : snapshot từ scan ACCEPTED mới nhất của từng OOB hôm nay.
Theo ngày           : chọn DD/MM/YYYY hoặc YYYY-MM-DD rồi có thể xuất CSV.
Scan ID             : xem đúng snapshot của một lần scan cụ thể.

Cấu trúc output v1.1.34:
  exports/YYYY-MM-DD/latest/current_inventory.csv
  exports/YYYY-MM-DD/daily/daily_inventory_YYYY-MM-DD.csv
  exports/YYYY-MM-DD/runs/HHMMSS_scan-ID_OOB/
  exports/YYYY-MM-DD/advanced/full_HHMMSS/
  session_logs/YYYY-MM-DD/
  backups/YYYY-MM-DD/

latest/daily là view tiện dụng; runs/advanced không ghi đè artifact cũ.
================================================================================
""",
    "vertiv_session": r"""
================================================================================
                 HELP - VERTIV PORT IN-USE / ACTIVE SESSION
================================================================================
Tool không tự kill session Vertiv. Khi live-check xác minh port In-Use:
  cd active_sessions
  show
  -> xác định đúng target_name + session ID
  kill_session <session_id>      (chỉ khi được phân quyền và đã xác nhận an toàn)
  cd /
  cd access
  show                           (xác nhận port trở lại Idle)
  connect <port_name>

Không dùng hướng dẫn "disconnect port5" hoặc "show ports status" vì các lệnh đó
không khớp command set ACS800/8000 chính thức đã đối chiếu cho workflow này.
================================================================================
""",
    "settings": r"""
================================================================================
                         HELP - NÂNG CAO
================================================================================
Khu vực này không cần dùng hằng ngày: backup DB, timeout/retry, full audit CSV,
operation locks, database health và scan-quality settings.
================================================================================
""",
}


def get_help_text(topic: str | None) -> str:
    return HELP_TEXTS.get(topic or "quick", HELP_TEXTS["quick"])
