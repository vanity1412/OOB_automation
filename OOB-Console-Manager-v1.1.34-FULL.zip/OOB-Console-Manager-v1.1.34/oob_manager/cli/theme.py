"""Màu sắc và khung hiển thị dùng chung cho CLI.

Không đưa ANSI escape vào output khi stdout không phải terminal để test/export/log vẫn sạch.
"""
from __future__ import annotations

import os
import sys

try:
    from colorama import Fore, Style, just_fix_windows_console

    just_fix_windows_console()
except ImportError:  # pragma: no cover - dependency bootstrap normally installs colorama
    class _Empty:
        BLACK = RED = GREEN = YELLOW = BLUE = MAGENTA = CYAN = WHITE = ""
        BRIGHT = DIM = NORMAL = RESET_ALL = ""

    Fore = Style = _Empty()


def color_enabled() -> bool:
    if os.getenv("NO_COLOR") is not None:
        return False
    if os.getenv("OOB_FORCE_COLOR", "").strip().casefold() in {"1", "true", "yes", "on"}:
        return True
    try:
        return bool(sys.stdout.isatty())
    except Exception:
        return False


def paint(text: object, color: str = "", *, bold: bool = False, dim: bool = False) -> str:
    value = str(text)
    if not color_enabled():
        return value
    prefix = color
    if bold:
        prefix = Style.BRIGHT + prefix
    elif dim:
        prefix = Style.DIM + prefix
    return f"{prefix}{value}{Style.RESET_ALL}"


def title(text: object) -> str:
    return paint(text, Fore.CYAN, bold=True)


def section(text: object) -> str:
    return paint(text, Fore.MAGENTA, bold=True)


def accent(text: object) -> str:
    return paint(text, Fore.CYAN, bold=True)


def ok(text: object) -> str:
    return paint(text, Fore.GREEN, bold=True)


def warn(text: object) -> str:
    return paint(text, Fore.YELLOW, bold=True)


def bad(text: object) -> str:
    return paint(text, Fore.RED, bold=True)


def muted(text: object) -> str:
    return paint(text, Fore.WHITE, dim=True)


_GREEN = {
    "SUCCESS", "AVAILABLE", "ACCEPTED", "NORMAL", "VALID", "READY", "PASS",
    "EXACT_MATCH", "HEALTHY", "ENABLED", "ĐANG BẬT", "THÀNH CÔNG",
}
_YELLOW = {
    "PARTIAL", "UNKNOWN", "BUSY_UNKNOWN_USER", "STALE", "INCOMPLETE", "CANCELLED",
    "CHƯA XÁC MINH", "WARNING", "CẢNH BÁO", "CẦN SCAN LẠI", "DEGRADED",
}
_RED = {
    "FAILED", "FAIL", "ERROR", "REJECTED", "BUSY", "MISMATCH", "DIFFERENT",
    "SERIAL_CHANGED", "DEVICE_CHANGE_SUSPECTED", "AUTH_FAILED", "UNREACHABLE",
    "LỖI", "ĐÃ TẮT",
}


def style_value(value: object, padded_text: str | None = None) -> str:
    """Tô màu cell theo status mà không làm sai độ rộng bảng."""
    raw = str(value or "").strip()
    upper = raw.upper()
    rendered = padded_text if padded_text is not None else str(value)
    if upper in _GREEN or upper.endswith("_SUCCESS"):
        return ok(rendered)
    if upper in _YELLOW or "UNKNOWN" in upper or "PARTIAL" in upper or "STALE" in upper:
        return warn(rendered)
    if upper in _RED or "FAILED" in upper or "BUSY" == upper or "MISMATCH" in upper or "REJECTED" in upper:
        return bad(rendered)
    return rendered
