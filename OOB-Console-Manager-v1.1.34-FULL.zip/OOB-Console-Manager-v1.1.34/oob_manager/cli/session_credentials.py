"""Credential phiên làm việc chỉ tồn tại trong RAM của tiến trình CLI.

Không module nào trong file này ghi password/enable password xuống DB, log hay export.
Default username của OOB là metadata không bí mật và được persistence riêng trong
``oob_devices.default_username``.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from oob_manager.models import OOBDevice, SessionCredentials


@dataclass(slots=True)
class SessionCredentialStore:
    """Resolve credential theo thứ tự: OOB override -> vendor -> default."""

    default: SessionCredentials | None = None
    by_vendor: dict[str, SessionCredentials] = field(default_factory=dict)
    by_oob: dict[int, SessionCredentials] = field(default_factory=dict)

    @staticmethod
    def _copy_for_vendor(credentials: SessionCredentials, vendor: str) -> SessionCredentials:
        vendor_key = str(vendor or "").strip().upper()
        return SessionCredentials(
            username=credentials.username,
            password=credentials.password,
            enable_password=(credentials.enable_password if vendor_key == "CISCO" else None),
        )

    def set_default(self, credentials: SessionCredentials) -> None:
        self.default = SessionCredentials(
            credentials.username, credentials.password, credentials.enable_password
        )

    def set_vendor(self, vendor: str, credentials: SessionCredentials) -> None:
        key = str(vendor or "").strip().upper()
        if key not in {"CISCO", "VERTIV"}:
            raise ValueError("Vendor credential phải là CISCO hoặc VERTIV.")
        self.by_vendor[key] = self._copy_for_vendor(credentials, key)

    def set_oob(self, oob_id: int, vendor: str, credentials: SessionCredentials) -> None:
        self.by_oob[int(oob_id)] = self._copy_for_vendor(credentials, vendor)

    def resolve(self, device: OOBDevice) -> tuple[SessionCredentials | None, str]:
        if device.id is not None and int(device.id) in self.by_oob:
            return self._copy_for_vendor(self.by_oob[int(device.id)], device.vendor), "OOB_OVERRIDE"
        vendor = str(device.vendor or "").strip().upper()
        if vendor in self.by_vendor:
            return self._copy_for_vendor(self.by_vendor[vendor], vendor), f"VENDOR_{vendor}"
        if self.default is not None:
            return self._copy_for_vendor(self.default, vendor), "SESSION_DEFAULT"
        return None, "PROMPT"

    def has_any(self) -> bool:
        return self.default is not None or bool(self.by_vendor) or bool(self.by_oob)

    def clear(self) -> None:
        # Python không bảo đảm secure memory wipe cho string immutable. Việc clear
        # chỉ xóa reference của application để credential không được persistence.
        self.default = None
        self.by_vendor.clear()
        self.by_oob.clear()

    def status_rows(self) -> list[tuple[str, str, str]]:
        rows: list[tuple[str, str, str]] = []
        if self.default is not None:
            rows.append(("DEFAULT", self.default.username, "CÓ" if self.default.enable_password else "KHÔNG"))
        for vendor in sorted(self.by_vendor):
            cred = self.by_vendor[vendor]
            rows.append((vendor, cred.username, "CÓ" if cred.enable_password else "KHÔNG"))
        for oob_id in sorted(self.by_oob):
            cred = self.by_oob[oob_id]
            rows.append((f"OOB#{oob_id}", cred.username, "CÓ" if cred.enable_password else "KHÔNG"))
        return rows
