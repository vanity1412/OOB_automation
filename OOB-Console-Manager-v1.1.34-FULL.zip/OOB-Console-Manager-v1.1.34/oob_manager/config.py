"""Cấu hình ứng dụng và profile vendor."""
from __future__ import annotations

from dataclasses import dataclass
import json
import hashlib
import re
from pathlib import Path
from typing import Any

from oob_manager.exceptions import ProfileError, ValidationError
from oob_manager.utils.paths import EXPORT_DIR, PROFILE_DIR


@dataclass(slots=True)
class ApplicationSettings:
    """Runtime policy for production-safe OOB operations.

    v1.1.8 separates SSH phases so a slow banner/authentication exchange does
    not consume the same budget as a device command.  ``minimum_complete_ratio``
    is retained only for database/settings backward compatibility; the baseline
    policy is now intentionally strict and always requires 100% complete core
    mappings.
    """

    connect_timeout: int = 10
    banner_timeout: int = 20
    auth_timeout: int = 15
    shell_timeout: int = 15
    command_timeout: int = 20
    connection_attempts: int = 2
    retry_delay: float = 1.0
    operation_lock_lease_seconds: int = 180
    operation_lock_heartbeat_seconds: int = 15
    minimum_complete_ratio: float = 1.0
    maximum_drop_ratio: float = 0.5
    debug: bool = False
    export_encoding: str = "utf-8-sig"
    export_dir: str = str(EXPORT_DIR)
    # Kept only so legacy settings/databases continue to load. API modes are
    # hidden/unsupported in v1.1.8, therefore this value has no execution path.
    vertiv_verify_tls: bool = True

    def validated(self) -> "ApplicationSettings":
        for name, value, maximum in (
            ("connect_timeout", self.connect_timeout, 300),
            ("banner_timeout", self.banner_timeout, 600),
            ("auth_timeout", self.auth_timeout, 300),
            ("shell_timeout", self.shell_timeout, 300),
            ("command_timeout", self.command_timeout, 600),
        ):
            if not 1 <= int(value) <= maximum:
                raise ValidationError(f"{name} phải từ 1 đến {maximum} giây.")
        if not 1 <= int(self.connection_attempts) <= 3:
            raise ValidationError("Số lần thử SSH phải từ 1 đến 3.")
        if not 0 <= float(self.retry_delay) <= 30:
            raise ValidationError("Thời gian chờ retry phải từ 0 đến 30 giây.")
        if not 60 <= int(self.operation_lock_lease_seconds) <= 86400:
            raise ValidationError("Operation lock lease phải từ 60 đến 86400 giây.")
        if not 5 <= int(self.operation_lock_heartbeat_seconds) < int(self.operation_lock_lease_seconds):
            raise ValidationError("Heartbeat lock phải từ 5 giây và nhỏ hơn lease.")
        # Production policy: one incomplete core target can represent a wrong
        # console path, therefore accepted baseline must be 100% complete.
        self.minimum_complete_ratio = 1.0
        if not 0 <= self.maximum_drop_ratio < 1:
            raise ValidationError("Ngưỡng giảm dữ liệu phải từ 0 đến dưới 1.")
        if self.export_encoding not in {"utf-8-sig", "utf-8"}:
            raise ValidationError("Encoding export chỉ hỗ trợ utf-8-sig hoặc utf-8.")
        if not str(self.export_dir).strip():
            raise ValidationError("Thư mục export không được để trống.")
        return self

    @classmethod
    def from_mapping(
        cls,
        values: dict[str, str],
        *,
        debug: bool = False,
    ) -> "ApplicationSettings":
        def parse_bool(key: str, default: bool) -> bool:
            raw_value = str(values.get(key, str(default))).strip().casefold()
            true_values = {"1", "true", "yes", "on"}
            false_values = {"0", "false", "no", "off"}
            if raw_value in true_values:
                return True
            if raw_value in false_values:
                return False
            raise ValidationError(
                f"Cấu hình {key} phải là true/false, 1/0, yes/no hoặc on/off."
            )

        try:
            settings = cls(
                connect_timeout=int(values.get("connect_timeout", 10)),
                banner_timeout=int(values.get("banner_timeout", 20)),
                auth_timeout=int(values.get("auth_timeout", 15)),
                shell_timeout=int(values.get("shell_timeout", 15)),
                command_timeout=int(values.get("command_timeout", 20)),
                connection_attempts=int(values.get("connection_attempts", 2)),
                retry_delay=float(values.get("retry_delay", 1.0)),
                operation_lock_lease_seconds=int(values.get("operation_lock_lease_seconds", 180)),
                operation_lock_heartbeat_seconds=int(values.get("operation_lock_heartbeat_seconds", 15)),
                minimum_complete_ratio=1.0,
                maximum_drop_ratio=float(values.get("maximum_drop_ratio", 0.5)),
                debug=debug,
                export_encoding=values.get("export_encoding", "utf-8-sig"),
                export_dir=values.get("export_dir", str(EXPORT_DIR)).strip(),
                vertiv_verify_tls=parse_bool("vertiv_verify_tls", True),
            )
        except (TypeError, ValueError) as exc:
            raise ValidationError("Cấu hình đang chứa giá trị số không hợp lệ.") from exc
        return settings.validated()




def _validate_cisco_read_only_command(command: str, *, prepare: bool = False) -> None:
    """Fail closed nếu profile có command có thể thay đổi thiết bị.

    Scan profile chỉ được phép chạy ``show ...`` và terminal-local paging/width
    preparation. Cisco output modifier pipe chỉ cho phép các bộ lọc read-only.
    """
    value = command.strip()
    forbidden = ("\n", "\r", ";", "&&", "||", "`", "$(", ">", "<")
    if any(token in value for token in forbidden):
        raise ProfileError(f"Profile CISCO chứa command không an toàn: {command}")
    if prepare:
        if not re.fullmatch(r"(?i)terminal\s+(?:length|width)\s+\d+", value):
            raise ProfileError(
                f"Profile CISCO prepare command không thuộc allowlist terminal-local: {command}"
            )
        return
    pieces = value.split("|")
    if len(pieces) > 2 or not re.match(r"(?i)^show\s+", pieces[0].strip()):
        raise ProfileError(f"Profile CISCO chỉ cho phép command đọc 'show': {command}")
    if len(pieces) == 2:
        modifier = pieces[1].strip()
        # IOS cho phép viết tắt các output filter. Chỉ allowlist những prefix
        # không có side effect; tuyệt đối không cho redirect/append/tee.
        readonly_modifiers = (
            r"(?:i|in|inc|incl|inclu|includ|include|"
            r"e|ex|exc|excl|exclu|exclud|exclude|"
            r"b|be|beg|begi|begin|"
            r"s|se|sec|sect|secti|sectio|section)"
        )
        if not re.match(rf"(?i)^{readonly_modifiers}\s+.+$", modifier):
            raise ProfileError(f"Profile CISCO có output modifier không được phép: {command}")


def load_profile(vendor: str, profile_dir: Path = PROFILE_DIR) -> dict[str, Any]:
    path = profile_dir / f"{vendor.casefold()}.json"
    if not path.exists():
        raise ProfileError(f"Không tìm thấy profile: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProfileError(f"Profile {vendor} không hợp lệ: {exc}") from exc
    normalized_vendor = vendor.upper()
    if data.get("vendor") != normalized_vendor:
        raise ProfileError(f"Profile {vendor} thiếu hoặc sai trường vendor.")
    for key in ("connect_timeout", "command_timeout"):
        if key in data and (not isinstance(data[key], int) or data[key] <= 0):
            raise ProfileError(f"Profile {vendor}: {key} phải là số nguyên dương.")

    if normalized_vendor == "CISCO":
        menu_commands = data.get("menu_commands")
        if not isinstance(menu_commands, list) or not menu_commands or not all(
            isinstance(command, str) and command.strip() for command in menu_commands
        ):
            raise ProfileError(
                "Profile CISCO phải có menu_commands là danh sách command không rỗng."
            )
        optional_commands = data.get("optional_commands")
        if not isinstance(optional_commands, dict) or not all(
            isinstance(name, str)
            and name.strip()
            and isinstance(command, str)
            and command.strip()
            for name, command in optional_commands.items()
        ):
            raise ProfileError(
                "Profile CISCO phải có optional_commands là object command hợp lệ."
            )
        prepare_commands = data.get("prepare_commands", [])
        if not isinstance(prepare_commands, list) or not all(
            isinstance(command, str) and command.strip() for command in prepare_commands
        ):
            raise ProfileError("Profile CISCO: prepare_commands không hợp lệ.")
        for command in menu_commands:
            _validate_cisco_read_only_command(command)
        for command in optional_commands.values():
            _validate_cisco_read_only_command(command)
        for command in prepare_commands:
            _validate_cisco_read_only_command(command, prepare=True)

        reverse_base = data.get("reverse_telnet_port_base")
        if reverse_base is not None and (
            not isinstance(reverse_base, int) or not 1 <= reverse_base <= 65535
        ):
            raise ProfileError(
                "Profile CISCO: reverse_telnet_port_base phải từ 1 đến 65535."
            )
    elif normalized_vendor == "VERTIV":
        data = dict(data)
        commands = data.get("ssh_commands")
        if (
            isinstance(commands, list)
            and not commands
            and str(data.get("status", "")).upper() in {"", "NOT_CONFIGURED"}
        ):
            # Backward-compatible migration for v1.1.7 profile files. Runtime
            # policy is CLI-only; legacy API keys are ignored and removed from
            # the fingerprinted profile returned to callers.
            commands = [
                "cd /",
                "cd access",
                "show",
                "cd /active_sessions",
                "show",
            ]
            data["ssh_commands"] = commands
            data["status"] = "ACS8000_CLI_READ_ONLY"
            for legacy_key in (
                "api_scheme", "api_port", "api_base_path", "verify_tls", "api_mapping"
            ):
                data.pop(legacy_key, None)
        if not isinstance(commands, list) or not commands or not all(
            isinstance(command, str) and command.strip() for command in commands
        ):
            raise ProfileError(
                "Profile VERTIV phải có ssh_commands cho ACS8000 Management CLI."
            )
        required = {
            "cli_family": "ACS8000",
            "access_path": "/access",
            "active_sessions_path": "/active_sessions",
            "access_show_command": "show",
            "connect_command": "connect",
            "status": "ACS8000_CLI_READ_ONLY",
        }
        for key, default in required.items():
            value = data.get(key, default)
            if not isinstance(value, str) or not value.strip():
                raise ProfileError(f"Profile VERTIV: {key} phải là chuỗi không rỗng.")
            data[key] = value.strip()
        if data["status"].upper() != "ACS8000_CLI_READ_ONLY":
            raise ProfileError(
                "Profile VERTIV v1.1.22 chỉ cho phép status ACS8000_CLI_READ_ONLY."
            )
        if data["connect_command"].casefold() != "connect":
            raise ProfileError("Profile VERTIV connect_command phải là 'connect'.")
        normalized_commands = {command.strip().casefold() for command in commands}
        required_commands = {"cd /", "cd access", "show", "cd /active_sessions"}
        if not required_commands.issubset(normalized_commands):
            raise ProfileError(
                "Profile VERTIV thiếu command read-only bắt buộc cho access/active_sessions."
            )
    return data



def profile_fingerprint(profile: dict[str, Any]) -> str:
    """SHA-256 của phần profile có ảnh hưởng hành vi scan/connect.

    Metadata chỉ dùng cho tài liệu như ``note`` không được đưa vào fingerprint;
    thay một câu mô tả không nên làm toàn bộ baseline OOB bị STALE.
    """
    behavioral = {key: value for key, value in profile.items() if key not in {"note"}}
    payload = json.dumps(behavioral, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

def validate_all_profiles(profile_dir: Path = PROFILE_DIR) -> None:
    for vendor in ("CISCO", "VERTIV"):
        load_profile(vendor, profile_dir)
