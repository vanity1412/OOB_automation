OOB Console Manager - per-scan artifact
Scan ID: 11
OOB: test
inventory.csv = mapping/state đúng tại lần scan này.
scan_summary.csv = trạng thái scan.
changes.csv = thay đổi phát hiện bởi scan này.
Raw evidence đầy đủ vẫn nằm trong SQLite/full audit export.
