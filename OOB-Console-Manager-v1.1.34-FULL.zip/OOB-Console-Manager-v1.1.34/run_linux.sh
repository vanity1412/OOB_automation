#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================================"
echo "  OOB Console Manager v1.1.34 - Linux Launcher"
echo "============================================================"

if command -v python3 >/dev/null 2>&1; then
    BOOT_PY=python3
elif command -v python >/dev/null 2>&1; then
    BOOT_PY=python
else
    echo "[LỖI] Không tìm thấy Python 3.10 trở lên."
    exit 1
fi

"$BOOT_PY" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' || {
    echo "[LỖI] Cần Python 3.10 trở lên."
    exit 1
}

recreate=0
if [[ ! -x .venv/bin/python ]]; then
    recreate=1
elif ! .venv/bin/python -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then
    recreate=1
fi

if [[ "$recreate" == "1" ]]; then
    echo "[1/4] Tạo lại virtual environment .venv ..."
    rm -rf .venv
    "$BOOT_PY" -m venv .venv || {
        echo "[LỖI] Không tạo được .venv. Trên Debian/Ubuntu có thể cần cài python3-venv."
        exit 1
    }
else
    echo "[1/4] .venv hợp lệ."
fi

VENV_PY="$(pwd)/.venv/bin/python"

if ! "$VENV_PY" -c "import importlib.metadata as m,sys; sys.exit(0 if m.version('paramiko')=='3.5.1' and m.version('colorama')=='0.4.6' else 1)" >/dev/null 2>&1; then
    echo "[2/4] Đồng bộ runtime dependencies đúng phiên bản ..."
    "$VENV_PY" -m pip install --upgrade --disable-pip-version-check -r requirements.txt
else
    echo "[2/4] Runtime dependencies đúng phiên bản."
fi

"$VENV_PY" -c "import paramiko,colorama; print('[OK] paramiko=' + paramiko.__version__ + ' | colorama=' + colorama.__version__)"

echo "[3/4] Kiểm tra môi trường ..."
"$VENV_PY" main.py --check

echo "[4/4] Khởi động OOB Console Manager..."
exec "$VENV_PY" main.py
