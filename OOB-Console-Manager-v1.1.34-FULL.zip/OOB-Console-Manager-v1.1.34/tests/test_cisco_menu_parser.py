from pathlib import Path
from oob_manager.vendors.cisco.parsers import parse_menu_config,parse_show_line,parse_show_users
FIX=Path(__file__).parent/"fixtures"
def test_basic():
 r=parse_menu_config((FIX/"cisco_menu_basic.txt").read_text());t=r.targets[0];assert (t.menu_name,t.menu_item,t.alias,t.protocol,t.target_host,t.target_port,t.is_complete)==("OOB",1,"Router-A","TELNET","172.28.200.11",2003,True)
def test_order_multiple_and_special_alias():
 r=parse_menu_config((FIX/"cisco_menu_multiple.txt").read_text());assert len(r.targets)==3
 assert {(t.menu_name,t.menu_item) for t in r.targets}=={("OOB",1),("OOB",2),("OOB-MP04-New",1)}
 assert next(t for t in r.targets if t.menu_item==2).alias=="HCM-CDNBDL-Quan9-QF5130-02_RE0"
def test_incomplete_no_crash():
 r=parse_menu_config((FIX/"cisco_menu_incomplete.txt").read_text());assert len(r.targets)==4;assert any(not t.is_complete for t in r.targets)
def test_malicious_command_rejected():
 r=parse_menu_config("menu OOB text [1] Router\nmenu OOB command 1 telnet 172.28.200.11 2003 ; reload");assert r.targets[0].is_complete is False;assert r.targets[0].protocol=="UNKNOWN"
def test_ssh_not_telnet():
 t=parse_menu_config("menu OOB command 1 ssh -l admin 172.28.200.12").targets[0];assert t.protocol=="SSH";assert t.target_port==22
def test_show_line():
 r=parse_show_line((FIX/"cisco_show_line.txt").read_text());assert [(x.async_port,x.line_no) for x in r.entries]==[("0/0/0",3),("0/0/1",4),("0/1/0",19)]
def test_show_users_variants():
 raw="""Line User Host(s) Idle Location\n*  2 vty 0 oobbackup idle 00:00:00 210.245.31.140\n132 vty 0 operator1 idle 23:30:31 10.10.10.10"""
 r=parse_show_users(raw);assert len(r.sessions)==2;assert r.sessions[0].username=="oobbackup";assert r.sessions[0].current;assert r.session_confident
def test_show_users_low_confidence():
 r=parse_show_users("Line User Host(s) Idle Location\nformat strange vty user");assert not r.session_confident
