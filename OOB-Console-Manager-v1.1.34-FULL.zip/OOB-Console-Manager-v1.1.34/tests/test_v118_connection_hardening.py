from __future__ import annotations

from datetime import timedelta
import logging
from pathlib import Path
import socket
import sys
import types

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.exceptions import (
    InteractiveSessionError,
    SSHAuthenticationError,
    ScanLockError,
)
from oob_manager.models import (
    ConsoleOpenResult,
    ConsoleTarget,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    OOBDevice,
    PortAuthenticationCredentials,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.networking.ssh_client import SSHClientWrapper
from oob_manager.networking.terminal_bridge import TerminalBridge
from oob_manager.services.console_service import ConsoleService
from oob_manager.services.device_identity_service import DeviceIdentityService
from oob_manager.services.scan_quality import ScanQualityEvaluator
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


def _cisco_target(*, complete: bool = True) -> ConsoleTarget:
    return ConsoleTarget(
        id=10,
        oob_id=1,
        menu_name="OOB",
        menu_item=4,
        alias="R4",
        command="telnet 10.0.0.4 2004",
        protocol="TELNET",
        target_host="10.0.0.4",
        target_port=2004,
        console_line=4,
        state="AVAILABLE",
        state_confident=True,
        is_complete=complete,
        last_scan_id=9,
    )


def test_logger_exception_suppresses_secret_in_traceback(tmp_path, monkeypatch):
    import oob_manager.logging_config as module

    monkeypatch.setattr(module, "LOG_DIR", tmp_path)
    module.configure_logging(debug=True)
    sentinel = "TRACEBACK-SENTINEL-SECRET"
    logger = logging.getLogger("v118-redaction")
    try:
        raise RuntimeError(sentinel)
    except RuntimeError:
        logger.exception("controlled failure")
    for handler in logging.getLogger().handlers:
        handler.flush()
    combined = "\n".join(
        path.read_text(encoding="utf-8") for path in tmp_path.glob("*.log")
    )
    assert sentinel not in combined
    assert "exception_type=RuntimeError" in combined


def test_console_failure_sanitizes_all_audit_messages():
    secret = "CONSOLE-SECRET-123"
    target = _cisco_target()
    device = OOBDevice(id=1, name="OOB", host="127.0.0.1", vendor="CISCO")

    class OOBRepo:
        def get(self, _):
            return device

        def sync_profile_fingerprint(self, *_):
            return device

    class TargetRepo:
        def get(self, _):
            return target

        def verify_open_provenance(self, _):
            return True, "", ""

    class ConnectionRepo:
        def __init__(self):
            self.finish_kwargs = None

        def start(self, *args, **kwargs):
            return 77

        def update_ssh_host_key(self, *args, **kwargs):
            return None

        def finish(self, *args, **kwargs):
            self.finish_kwargs = kwargs

    class Adapter:
        profile = None
        ssh = None

        def open_console(self, *args, **kwargs):
            error = InteractiveSessionError(
                f"password={secret}", error_code="INTERACTIVE_SESSION_ERROR"
            )
            error.runtime_mapping_verification_message = f"raw {secret}"
            error.live_state_evidence = f'{{"password":"{secret}"}}'
            raise error

    connection_repo = ConnectionRepo()
    service = ConsoleService(
        OOBRepo(),
        TargetRepo(),
        connection_repo,
        ApplicationSettings(),
        adapter_factory=lambda *_: Adapter(),
    )
    with pytest.raises(InteractiveSessionError):
        service.open(10, SessionCredentials("admin", secret))

    persisted = repr(connection_repo.finish_kwargs)
    assert secret not in persisted
    assert "ĐÃ_CHE" in persisted


def test_identity_raw_output_sanitizer_removes_runtime_credentials():
    secret = "IDENTITY-RAW-SECRET"
    outputs = [
        RawCommandOutput(
            "show_version",
            "show version",
            f"debug password={secret}\n{secret}",
            False,
            f"failed {secret}",
        )
    ]
    sanitized = DeviceIdentityService._sanitize_outputs(outputs, (secret,))
    assert secret not in repr(sanitized)
    assert sanitized[0].redaction_applied


def test_foreign_host_expired_lock_is_recovered_and_active_lock_blocks(tmp_path):
    db = DatabaseConnection(tmp_path / "locks.db")
    MigrationManager(db).migrate()
    device = OOBRepository(db).create(OOBDevice(name="OOB", host="127.0.0.1"))
    now = utc_now()
    with db.transaction() as conn:
        conn.execute(
            """
            INSERT INTO scan_locks(
                oob_id,pid,hostname,started_at,operation,heartbeat_at,expires_at
            ) VALUES(?,?,?,?,?,?,?)
            """,
            (
                device.id,
                999999,
                "OLD-FOREIGN-HOST",
                to_db(now - timedelta(hours=1)),
                "SCAN",
                to_db(now - timedelta(hours=1)),
                to_db(now - timedelta(minutes=30)),
            ),
        )
    repo = ScanLockRepository(db)
    assert repo.recover_stale_same_host() == 1

    repo.acquire(device.id, "SCAN")
    try:
        with pytest.raises(ScanLockError):
            ScanLockRepository(db).acquire(device.id, "CONSOLE")
    finally:
        repo.release(device.id, "SCAN")


def test_auto_menu_is_fail_closed_without_explicit_override(monkeypatch):
    class Channel:
        def __init__(self):
            self.sent = []

        def send(self, value):
            self.sent.append(value)
            return len(value)

    class Client:
        def close(self):
            pass

    class SSH:
        def __init__(self):
            self.channel = Channel()

        def connect(self, *args, **kwargs):
            return Client()

        def open_shell(self, client):
            return self.channel

        def read_until_quiet(self, *args, **kwargs):
            return "=== OOB MENU ===\n4. R4\nSelect:"

    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    with pytest.raises(InteractiveSessionError) as caught:
        adapter.open_console(
            OOBDevice(id=1, name="OOB", host="127.0.0.1"),
            _cisco_target(),
            SessionCredentials("u", "p"),
        )
    assert caught.value.error_code == "CONSOLE_STATE_UNVERIFIED"
    assert adapter.ssh.channel.sent == []
    assert not caught.value.runtime_mapping_verified


def test_strict_baseline_rejects_four_of_five_complete_targets():
    targets = [_cisco_target() for _ in range(4)] + [_cisco_target(complete=False)]
    for index, target in enumerate(targets, 1):
        target.alias = f"R{index}"
        target.target_host = f"10.0.0.{index}"
        target.target_port = 2000 + index
        target.command = f"telnet 10.0.0.{index} {2000 + index}"
    raw = [RawCommandOutput("menu", "show run", "menu output", True, is_core=True)]
    data = VendorScanData(True, "NORMAL_CLI", targets, raw)
    result = ScanQualityEvaluator(minimum_complete_ratio=0.8).evaluate([], targets, raw, data)
    assert result.complete_ratio == 0.8
    assert result.status == "PARTIAL"
    assert not result.mapping_accepted


def _fake_paramiko(connect_behaviors):
    module = types.ModuleType("paramiko")

    class SSHException(Exception):
        pass

    class AuthenticationException(SSHException):
        pass

    class BadHostKeyException(SSHException):
        pass

    class AutoAddPolicy:
        pass

    class Key:
        def asbytes(self):
            return b"key"

        def get_name(self):
            return "ssh-ed25519"

    class Transport:
        def is_active(self):
            return True

        def get_remote_server_key(self):
            return Key()

    module.instances = []

    class SSHClient:
        def __init__(self):
            self.closed = False
            module.instances.append(self)

        def load_system_host_keys(self):
            pass

        def load_host_keys(self, path):
            pass

        def set_missing_host_key_policy(self, policy):
            pass

        def connect(self, **kwargs):
            behavior = connect_behaviors.pop(0)
            if behavior == "banner":
                raise SSHException("Error reading SSH protocol banner")
            if behavior == "auth":
                raise AuthenticationException("denied")
            if isinstance(behavior, BaseException):
                raise behavior

        def get_transport(self):
            return Transport()

        def close(self):
            self.closed = True

    module.SSHException = SSHException
    module.AuthenticationException = AuthenticationException
    module.BadHostKeyException = BadHostKeyException
    module.AutoAddPolicy = AutoAddPolicy
    module.SSHClient = SSHClient
    return module


def test_ssh_retries_transient_banner_failure_once(tmp_path, monkeypatch):
    fake = _fake_paramiko(["banner", None])
    monkeypatch.setitem(sys.modules, "paramiko", fake)
    wrapper = SSHClientWrapper(
        known_hosts_path=tmp_path / "known_hosts",
        max_attempts=2,
        retry_delay=0,
    )
    client = wrapper.connect("127.0.0.1", 22, "u", "p")
    assert client is fake.instances[1]
    assert wrapper.last_connect_attempts == 2
    assert fake.instances[0].closed


def test_ssh_authentication_failure_is_not_retried(tmp_path, monkeypatch):
    fake = _fake_paramiko(["auth"])
    monkeypatch.setitem(sys.modules, "paramiko", fake)
    wrapper = SSHClientWrapper(
        known_hosts_path=tmp_path / "known_hosts",
        max_attempts=3,
        retry_delay=0,
    )
    with pytest.raises(SSHAuthenticationError):
        wrapper.connect("127.0.0.1", 22, "u", "bad")
    assert len(fake.instances) == 1
    assert wrapper.last_connect_attempts == 1


def test_terminal_send_all_handles_partial_channel_writes():
    class Channel:
        def __init__(self):
            self.received = bytearray()

        def send(self, data):
            accepted = min(2, len(data))
            self.received.extend(data[:accepted])
            return accepted

    channel = Channel()
    TerminalBridge._send_all(channel, b"abcdef")
    assert bytes(channel.received) == b"abcdef"


def test_vertiv_port_auth_requires_explicit_credential_and_uses_separate_secret(monkeypatch):
    target = ConsoleTarget(
        id=9,
        oob_id=7,
        menu_name="ACCESS",
        menu_item=1,
        alias="R1",
        command="connect R1",
        protocol="VERTIV_CLI",
        console_line=1,
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="VERTIV_ACCESS_IDLE",
        is_complete=True,
    )
    device = OOBDevice(
        id=7,
        name="ACS",
        host="127.0.0.1",
        vendor="VERTIV",
        connection_mode="SSH",
    )

    class Channel:
        def __init__(self):
            self.sent = []

        def send(self, value):
            self.sent.append(value.decode() if isinstance(value, bytes) else value)
            return len(value)

    class Client:
        def close(self):
            pass

    class SSH:
        def __init__(self, reads):
            self.reads = list(reads)
            self.channel = Channel()
            self.last_host_key_algorithm = ""
            self.last_host_key_fingerprint = ""
            self.host_key_policy = "TOFU_PERSISTENT"

        def connect(self, *args, **kwargs):
            return Client()

        def open_shell(self, *args, **kwargs):
            return self.channel

        def read_until_quiet(self, *args, **kwargs):
            return self.reads.pop(0)

        def drain_channel(self, *args, **kwargs):
            return ""

    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)

    def prepare(adapter, reads):
        adapter.ssh = SSH(reads)
        monkeypatch.setattr(adapter, "_ensure_cli", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
        monkeypatch.setattr(adapter, "_runtime_verify", lambda *a: (target, "access"))
        monkeypatch.setattr(adapter, "_goto_access", lambda *a: "--:- access cli->")

    missing = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    prepare(missing, ["initial", "Password:"])
    with pytest.raises(InteractiveSessionError) as caught:
        missing.discover_downstream_identity(
            device,
            target,
            SessionCredentials("admin", "OOB-MANAGEMENT-SECRET"),
            DownstreamCredentials("down", "down-secret"),
        )
    assert caught.value.error_code == "VERTIV_PORT_AUTH_PASSWORD_REQUIRED"
    assert "OOB-MANAGEMENT-SECRET\n" not in missing.ssh.channel.sent

    explicit = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    prepare(explicit, ["initial", "Password:", "Type the hot key <CTRL>Z>\nlogin:"])
    monkeypatch.setattr(
        "oob_manager.vendors.vertiv.adapter.DownstreamIdentityCollector.collect",
        lambda *a, **k: DownstreamDiscoveryResult(),
    )
    explicit.discover_downstream_identity(
        device,
        target,
        SessionCredentials("admin", "OOB-MANAGEMENT-SECRET"),
        DownstreamCredentials("down", "down-secret"),
        PortAuthenticationCredentials(password="PORT-AUTH-SECRET"),
    )
    assert "PORT-AUTH-SECRET\n" in explicit.ssh.channel.sent
    assert "OOB-MANAGEMENT-SECRET\n" not in explicit.ssh.channel.sent


def test_v14_preserves_account_identifiers_for_internal_audit(tmp_path):
    from oob_manager.database.repositories.connection_repository import ConnectionRepository
    from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
    from oob_manager.database.repositories.scan_repository import ScanRepository

    db = DatabaseConnection(tmp_path / "privacy.db")
    MigrationManager(db).migrate()
    device = OOBRepository(db).create(
        OOBDevice(
            name="OOB-PRIVACY",
            host="127.0.0.1",
            default_username="operator01",
        )
    )
    target = _cisco_target()
    target.oob_id = device.id
    target.id = None

    scan_id = ScanRepository(db).start(device, "1.1.8", ssh_username="operator01")
    connection_id = ConnectionRepository(db).start(
        device.id, target, "operator01", device=device
    )
    with db.transaction() as conn:
        # Simulate an older row/audit payload before rerunning the idempotent migration.
        conn.execute(
            "UPDATE scan_runs SET error_message=? WHERE id=?",
            ("login operator01 failed", scan_id),
        )
        conn.execute(
            "UPDATE connection_history SET live_session_user=?, live_state_evidence=? WHERE id=?",
            ("operator01", '{"active_session_user":"operator01"}', connection_id),
        )
    MigrationManager(db).migrate()

    with db.read() as conn:
        oob = conn.execute("SELECT * FROM oob_devices WHERE id=?", (device.id,)).fetchone()
        scan = conn.execute("SELECT * FROM scan_runs WHERE id=?", (scan_id,)).fetchone()
        history = conn.execute(
            "SELECT * FROM connection_history WHERE id=?", (connection_id,)
        ).fetchone()
    assert oob["default_username"] == "operator01"
    assert scan["ssh_username_at_scan"] == "operator01"
    assert "operator01" in scan["error_message"]
    assert history["username"] == "operator01"
    assert history["live_session_user"] == "operator01"
    assert "operator01" in history["live_state_evidence"]


def test_vertiv_identity_rejects_repeated_port_password_prompt(monkeypatch):
    target = ConsoleTarget(
        id=9,
        oob_id=7,
        menu_name="ACCESS",
        menu_item=1,
        alias="R1",
        command="connect R1",
        protocol="VERTIV_CLI",
        console_line=1,
        state="AVAILABLE",
        state_confident=True,
        is_complete=True,
    )
    device = OOBDevice(
        id=7,
        name="ACS",
        host="127.0.0.1",
        vendor="VERTIV",
        connection_mode="SSH",
    )

    class Channel:
        def __init__(self):
            self.sent = []

        def send(self, value):
            self.sent.append(value)
            return len(value)

    class Client:
        def close(self):
            pass

    class SSH:
        last_host_key_algorithm = ""
        last_host_key_fingerprint = ""
        host_key_policy = "TOFU_PERSISTENT"

        def __init__(self):
            self.channel = Channel()
            self.reads = ["initial", "Password:", "Authentication failed\nPassword:"]

        def connect(self, *args, **kwargs):
            return Client()

        def open_shell(self, *args, **kwargs):
            return self.channel

        def read_until_quiet(self, *args, **kwargs):
            return self.reads.pop(0)

        def drain_channel(self, *args, **kwargs):
            return ""

    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_ensure_cli", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda *a: (target, "access"))
    monkeypatch.setattr(adapter, "_goto_access", lambda *a: "--:- access cli->")

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.discover_downstream_identity(
            device,
            target,
            SessionCredentials("admin", "oob-secret"),
            DownstreamCredentials("down", "down-secret"),
            PortAuthenticationCredentials(password="wrong-port-secret"),
        )
    assert caught.value.error_code == "VERTIV_PORT_AUTHENTICATION_FAILED"


def test_vertiv_manual_console_uses_separate_port_password(monkeypatch):
    target = ConsoleTarget(
        id=9,
        oob_id=7,
        menu_name="ACCESS",
        menu_item=1,
        alias="R1",
        command="connect R1",
        protocol="VERTIV_CLI",
        console_line=1,
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="VERTIV_ACCESS_IDLE",
        state_evidence="{}",
        is_complete=True,
    )
    device = OOBDevice(
        id=7,
        name="ACS",
        host="127.0.0.1",
        vendor="VERTIV",
        connection_mode="SSH",
    )

    class Channel:
        def __init__(self):
            self.sent = []

        def send(self, value):
            self.sent.append(value)
            return len(value)

    class Client:
        def close(self):
            pass

    class SSH:
        last_host_key_algorithm = ""
        last_host_key_fingerprint = ""
        host_key_policy = "TOFU_PERSISTENT"

        def __init__(self):
            self.channel = Channel()
            self.reads = ["initial", "Password:", "Type the hot key to suspend the connection\nlogin:"]

        def connect(self, *args, **kwargs):
            return Client()

        def open_shell(self, *args, **kwargs):
            return self.channel

        def read_until_quiet(self, *args, **kwargs):
            return self.reads.pop(0)

        def drain_channel(self, *args, **kwargs):
            return ""

    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_ensure_cli", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda *a: (target, "access"))
    monkeypatch.setattr(adapter, "_goto_access", lambda *a: "--:- access cli->")
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.TerminalBridge.bridge", lambda *a, **k: None)

    result = adapter.open_console(
        device,
        target,
        SessionCredentials("admin", "oob-management-secret"),
        port_credentials=PortAuthenticationCredentials(password="port-auth-secret"),
    )
    assert result.console_path_verified
    assert "port-auth-secret\n" in adapter.ssh.channel.sent
    assert "oob-management-secret\n" not in adapter.ssh.channel.sent
