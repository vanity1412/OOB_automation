import sqlite3

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import ValidationError
from oob_manager.models import (
    ConsoleTarget,
    OOBDevice,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.console_service import ConsoleService
from oob_manager.services.oob_service import OOBService
from oob_manager.services.scan_service import ScanService
from oob_manager.services.search_service import SearchService
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.cisco.parsers import parse_menu_config, parse_show_line, parse_show_users
from oob_manager.vendors.cisco.state_resolver import resolve_console_states


def make_target(alias="R1", item=1, port=2001, *, line=None, state="UNKNOWN", confident=False):
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=item,
        alias=alias,
        command=f"telnet 10.0.0.1 {port}",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=port,
        console_line=line,
        state=state,
        state_confident=confident,
        is_complete=True,
    )


def setup_repos(tmp_path):
    db = DatabaseConnection(tmp_path / "v112.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    device = oob_repo.create(OOBDevice(name="OOB-1", host="10.0.0.1", device_type="cisco_ios"))
    return db, oob_repo, target_repo, scan_repo, change_repo, lock_repo, device


class DataAdapter:
    def __init__(self, targets, *, failed_optional=(), parser_errors=()):
        self.targets = targets
        self.failed_optional = set(failed_optional)
        self.parser_errors = list(parser_errors)

    def collect(self, device, credentials):
        outputs = [
            RawCommandOutput(
                "menu",
                "show run | i ^menu",
                "menu OOB text [1] R1\nmenu OOB command 1 telnet 10.0.0.1 2001",
                True,
                is_core=True,
            )
        ]
        for name in ("show_users", "show_line", "show_version"):
            outputs.append(
                RawCommandOutput(
                    name,
                    name.replace("_", " "),
                    "" if name in self.failed_optional else "ok",
                    name not in self.failed_optional,
                    "authorization failed" if name in self.failed_optional else "",
                    is_core=False,
                )
            )
        return VendorScanData(
            True,
            "NORMAL_CLI",
            self.targets,
            outputs,
            parser_errors=self.parser_errors,
        )


def service(repos, adapter):
    return ScanService(
        repos[1], repos[2], repos[3], repos[4], repos[5],
        ApplicationSettings(), adapter_factory=lambda d, s: adapter,
    )


def test_first_partial_supporting_failure_still_creates_inventory(tmp_path):
    repos = setup_repos(tmp_path)
    target = make_target(state="UNKNOWN", confident=False)
    result = service(repos, DataAdapter([target], failed_optional={"show_users"})).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "PARTIAL"
    assert result.mapping_quality == "ACCEPTED"
    assert result.baseline_updated is True
    current = repos[2].list_current(repos[6].id)
    assert len(current) == 1
    assert current[0].state == "UNKNOWN"
    assert current[0].state_confident is False


def test_core_partial_does_not_replace_baseline(tmp_path):
    repos = setup_repos(tmp_path)
    assert service(repos, DataAdapter([make_target()])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    old = repos[2].list_current(repos[6].id)[0]
    incomplete = ConsoleTarget(
        menu_name="OOB", menu_item=1, alias="R1", command="",
        protocol="UNKNOWN", state="INCOMPLETE", state_confident=True,
        is_complete=False,
    )
    result = service(repos, DataAdapter([incomplete])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "PARTIAL"
    assert result.mapping_quality == "PARTIAL"
    assert not result.baseline_updated
    current = repos[2].list_current(repos[6].id)[0]
    assert current.id == old.id and current.target_port == old.target_port


def test_drop_rejected_does_not_generate_mass_missing(tmp_path):
    repos = setup_repos(tmp_path)
    many = [make_target(alias=f"R{i}", item=i, port=2000+i) for i in range(1, 11)]
    assert service(repos, DataAdapter(many)).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    result = service(repos, DataAdapter([make_target()])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "REJECTED"
    assert len(repos[2].list_current(repos[6].id)) == 10
    with repos[0].read() as conn:
        assert conn.execute(
            "SELECT COUNT(*) FROM change_events WHERE scan_id=?", (result.scan_id,)
        ).fetchone()[0] == 0


def test_state_resolver_maps_only_tty_session_to_console_line():
    target = make_target(line=6)
    lines = parse_show_line("0/0/0 6 TTY - - - - - 0 0 0/0")
    users = parse_show_users(
        "Line User Host(s) Idle Location\n"
        "* 2 vty 0 admin idle 00:00:00 10.1.1.1\n"
        "6 tty 6 operator01 idle 00:01:00 10.2.2.2"
    )
    resolve_console_states(
        [target], lines, users, show_line_success=True, show_users_success=True
    )
    assert target.state == "BUSY"
    assert target.session_user == "operator01"
    assert target.state_confident


def test_oob_admin_vty_is_not_console_user_and_line_can_be_available():
    target = make_target(line=6)
    lines = parse_show_line("0/0/0 6 TTY - - - - - 0 0 0/0")
    users = parse_show_users(
        "Line User Host(s) Idle Location\n"
        "* 2 vty 0 admin01 idle 00:00:00 10.1.1.1"
    )
    resolve_console_states(
        [target], lines, users, show_line_success=True, show_users_success=True
    )
    assert target.state == "AVAILABLE"
    assert target.session_user == ""
    assert target.state_confident


def test_show_line_current_marker_is_busy_without_guessing_user():
    target = make_target(line=6)
    lines = parse_show_line("* 0/0/0 6 TTY - - - - - 0 0 0/0")
    users = parse_show_users("")
    resolve_console_states(
        [target], lines, users, show_line_success=True, show_users_success=False
    )
    # Cisco terminal-server show line dùng '*' để đánh dấu line đang in-use.
    # Không có show-users đáng tin thì chỉ được kết luận BUSY_UNKNOWN_USER.
    assert target.state == "BUSY_UNKNOWN_USER"
    assert target.session_user == ""
    assert target.state_confident
    assert target.state_reason_code == "SHOW_LINE_TTY_IN_USE_USER_UNAVAILABLE"

def test_show_users_failure_results_unknown_not_available():
    target = make_target(line=6)
    lines = parse_show_line("0/0/0 6 TTY - - - - - 0 0 0/0")
    users = parse_show_users("")
    resolve_console_states(
        [target], lines, users, show_line_success=True, show_users_success=False
    )
    assert target.state == "UNKNOWN"
    assert target.session_user == ""
    assert not target.state_confident


def test_ambiguous_show_users_is_unknown():
    target = make_target(line=6)
    lines = parse_show_line("0/0/0 6 TTY - - - - - 0 0 0/0")
    users = parse_show_users("Line User Host(s) Idle Location\nweird tty user format")
    assert not users.session_confident
    resolve_console_states(
        [target], lines, users, show_line_success=True, show_users_success=True
    )
    assert target.state == "UNKNOWN"
    assert not target.state_confident


def test_state_change_event_suppressed_when_new_telemetry_untrusted(tmp_path):
    repos = setup_repos(tmp_path)
    old = make_target(state="AVAILABLE", confident=True)
    assert service(repos, DataAdapter([old])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    new = make_target(state="UNKNOWN", confident=False)
    result = service(repos, DataAdapter([new], failed_optional={"show_users"})).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    )
    with repos[0].read() as conn:
        assert conn.execute(
            "SELECT COUNT(*) FROM change_events WHERE scan_id=? AND event_code='CONSOLE_STATE_CHANGED'",
            (result.scan_id,),
        ).fetchone()[0] == 0


@pytest.mark.parametrize("field,value", [
    ("host", "10.0.0.99"),
    ("ssh_port", 2222),
    ("vendor", "VERTIV"),
    ("connection_mode", "SSH_AND_API"),
])
def test_identity_change_marks_mapping_stale(tmp_path, field, value):
    repos = setup_repos(tmp_path)
    assert service(repos, DataAdapter([make_target()])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    device = repos[1].get(repos[6].id)
    setattr(device, field, value)
    if field == "vendor":
        device.device_type = "vertiv"
    OOBService(repos[1]).update(device)
    updated = repos[1].get(device.id)
    assert updated.mapping_stale
    assert updated.connection_revision > updated.baseline_revision


def test_notes_change_does_not_stale_mapping(tmp_path):
    repos = setup_repos(tmp_path)
    device = repos[1].get(repos[6].id)
    device.notes = "new note"
    OOBService(repos[1]).update(device)
    assert not repos[1].get(device.id).mapping_stale


def test_stale_mapping_visible_in_search_and_blocked_in_service(tmp_path):
    repos = setup_repos(tmp_path)
    assert service(repos, DataAdapter([make_target()])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    target_id = repos[2].list_current(repos[6].id)[0].id
    device = repos[1].get(repos[6].id)
    device.host = "10.0.0.99"
    OOBService(repos[1]).update(device)
    results = SearchService(repos[2]).search_targets("R1")
    assert results and results[0].mapping_stale

    called = False
    class Adapter:
        def open_console(self, *args):
            nonlocal called
            called = True

    console = ConsoleService(
        repos[1], repos[2], ConnectionRepository(repos[0]), ApplicationSettings(),
        adapter_factory=lambda d, s: Adapter(),
    )
    with pytest.raises(ValidationError) as exc:
        console.open(target_id, SessionCredentials("u", "p"))
    assert getattr(exc.value, "error_code", "") == "STALE_MAPPING"
    assert called is False


def test_stale_failed_scan_remains_stale(tmp_path):
    repos = setup_repos(tmp_path)
    assert service(repos, DataAdapter([make_target()])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    device = repos[1].get(repos[6].id)
    device.host = "10.0.0.99"
    OOBService(repos[1]).update(device)

    class FailAdapter:
        def collect(self, device, credentials):
            raise RuntimeError("timeout")

    result = service(repos, FailAdapter()).scan_one(device.id, SessionCredentials("u", "p"))
    assert result.status == "FAILED"
    assert repos[1].get(device.id).mapping_stale


def test_stale_accepted_partial_starts_new_baseline_without_mass_events(tmp_path):
    repos = setup_repos(tmp_path)
    assert service(repos, DataAdapter([make_target(alias="OLD")])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    old_id = repos[2].list_current(repos[6].id)[0].id
    device = repos[1].get(repos[6].id)
    device.host = "10.0.0.99"
    OOBService(repos[1]).update(device)
    result = service(
        repos,
        DataAdapter([make_target(alias="NEW", item=9, port=2099)], failed_optional={"show_users"}),
    ).scan_one(device.id, SessionCredentials("u", "p"))
    assert result.status == "PARTIAL"
    assert result.mapping_quality == "ACCEPTED"
    assert result.baseline_updated
    assert not repos[1].get(device.id).mapping_stale
    new = repos[2].list_current(device.id)[0]
    assert new.alias == "NEW"
    assert new.id != old_id
    with repos[0].read() as conn:
        assert conn.execute(
            "SELECT COUNT(*) FROM change_events WHERE scan_id=?", (result.scan_id,)
        ).fetchone()[0] == 0


def test_stream_suffix_preserved_for_normal_cli(monkeypatch):
    target = parse_menu_config(
        "menu OOB text [1] R1\nmenu OOB command 1 telnet 10.0.0.1 2001 /stream"
    ).targets[0]
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})

    class Channel:
        def __init__(self): self.sent = []
        def send(self, value): self.sent.append(value)
    class Client:
        def close(self): pass
    class SSH:
        def __init__(self): self.channel = Channel()
        def connect(self, *args, **kwargs): return Client()
        def open_shell(self, client): return self.channel
        def read_until_quiet(self, channel, timeout=None, quiet=None): return "OOB#"
    fake = SSH()
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.TerminalBridge.bridge", lambda *a, **kw: None)
    adapter.open_console(OOBDevice(id=1, name="OOB", host="127.0.0.1"), target, SessionCredentials("u", "p"))
    assert fake.channel.sent == ["telnet 10.0.0.1 2001 /stream\n"]


def test_migration_v3_has_new_columns_and_integrity(tmp_path):
    db = DatabaseConnection(tmp_path / "migrate.db")
    MigrationManager(db).migrate()
    MigrationManager(db).migrate()
    with db.read() as conn:
        oob_cols = {row["name"] for row in conn.execute("PRAGMA table_info(oob_devices)")}
        scan_cols = {row["name"] for row in conn.execute("PRAGMA table_info(scan_runs)")}
        target_cols = {row["name"] for row in conn.execute("PRAGMA table_info(console_targets)")}
        assert {"connection_revision", "baseline_revision", "baseline_stale_reason", "baseline_stale_at"} <= oob_cols
        assert {"connection_revision", "mapping_quality", "baseline_updated"} <= scan_cols
        assert "state_confident" in target_cols
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("PRAGMA foreign_key_check").fetchall() == []
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16


def test_stale_rejected_scan_remains_stale_and_keeps_old_current(tmp_path):
    repos = setup_repos(tmp_path)
    original = [make_target(alias=f"R{i}", item=i, port=2000+i) for i in range(1, 5)]
    assert service(repos, DataAdapter(original)).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    old_ids = [t.id for t in repos[2].list_current(repos[6].id)]

    device = repos[1].get(repos[6].id)
    device.host = "10.0.0.99"
    OOBService(repos[1]).update(device)

    # Core mapping không đủ complete ratio => PARTIAL mapping, không accepted.
    incomplete = ConsoleTarget(
        menu_name="OOB", menu_item=1, alias="X", command="",
        protocol="UNKNOWN", state="INCOMPLETE", state_confident=True,
        is_complete=False,
    )
    result = service(repos, DataAdapter([incomplete])).scan_one(
        device.id, SessionCredentials("u", "p")
    )
    assert result.status == "PARTIAL"
    assert result.mapping_quality == "PARTIAL"
    assert not result.baseline_updated
    assert repos[1].get(device.id).mapping_stale
    assert [t.id for t in repos[2].list_current(device.id)] == old_ids
    with repos[0].read() as conn:
        snapshot = conn.execute(
            "SELECT target_id FROM console_snapshots WHERE scan_id=?", (result.scan_id,)
        ).fetchone()
        assert snapshot["target_id"] is None


def test_config_change_during_scan_cannot_commit_old_revision(tmp_path):
    repos = setup_repos(tmp_path)
    assert service(repos, DataAdapter([make_target(alias="BASE")])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    old = repos[2].list_current(repos[6].id)[0]

    class MutatingAdapter(DataAdapter):
        def collect(self, device, credentials):
            current = repos[1].get(device.id)
            current.host = "10.0.0.99"
            OOBService(repos[1]).update(current)
            return super().collect(device, credentials)

    result = service(repos, MutatingAdapter([make_target(alias="NEW")])).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "FAILED"
    assert result.error_code == "OOB_CONFIGURATION_CHANGED"
    current = repos[2].list_current(repos[6].id)[0]
    assert current.id == old.id
    assert current.alias == "BASE"
    assert repos[1].get(repos[6].id).mapping_stale
    with repos[0].read() as conn:
        assert conn.execute("SELECT COUNT(*) FROM scan_locks").fetchone()[0] == 0


def test_v2_scan_history_backfills_mapping_quality_without_overwriting_v3(tmp_path):
    path = tmp_path / "legacy_v2.db"
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE schema_versions(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
        INSERT INTO schema_versions VALUES(2, '2026-07-24T00:00:00+00:00');
        CREATE TABLE oob_devices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE, host TEXT NOT NULL, ssh_port INTEGER NOT NULL,
            vendor TEXT NOT NULL, device_type TEXT NOT NULL DEFAULT '',
            default_username TEXT NOT NULL DEFAULT '', connection_mode TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1, notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_scan_at TEXT,
            UNIQUE(host, ssh_port)
        );
        INSERT INTO oob_devices(name,host,ssh_port,vendor,device_type,default_username,
          connection_mode,enabled,notes,created_at,updated_at)
        VALUES('OOB','10.0.0.1',22,'CISCO','cisco_ios','','SSH',1,'','now','now');
        CREATE TABLE scan_runs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, oob_id INTEGER NOT NULL,
            started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
            mapping_count INTEGER NOT NULL DEFAULT 0, complete_count INTEGER NOT NULL DEFAULT 0,
            complete_ratio REAL NOT NULL DEFAULT 0, change_count INTEGER NOT NULL DEFAULT 0,
            warning_count INTEGER NOT NULL DEFAULT 0, error_code TEXT NOT NULL DEFAULT '',
            error_message TEXT NOT NULL DEFAULT '', scanner_version TEXT NOT NULL
        );
        INSERT INTO scan_runs(oob_id,started_at,status,scanner_version) VALUES(1,'now','SUCCESS','1.1.1');
        INSERT INTO scan_runs(oob_id,started_at,status,scanner_version) VALUES(1,'now','PARTIAL','1.1.1');
        INSERT INTO scan_runs(oob_id,started_at,status,scanner_version) VALUES(1,'now','FAILED','1.1.1');
        """
    )
    conn.commit()
    conn.close()

    db = DatabaseConnection(path)
    MigrationManager(db).migrate()
    with db.read() as migrated:
        rows = migrated.execute(
            "SELECT status,mapping_quality,baseline_updated FROM scan_runs ORDER BY id"
        ).fetchall()
        assert [(r["status"], r["mapping_quality"], r["baseline_updated"]) for r in rows] == [
            ("SUCCESS", "ACCEPTED", 1),
            ("PARTIAL", "PARTIAL", 0),
            ("FAILED", "REJECTED", 0),
        ]
        # Mô phỏng v3 PARTIAL+ACCEPTED; migrate lại không được backfill đè mất semantics mới.
        migrated.execute(
            "UPDATE scan_runs SET mapping_quality='ACCEPTED', baseline_updated=1 WHERE status='PARTIAL'"
        )

    MigrationManager(db).migrate()
    with db.read() as migrated:
        row = migrated.execute(
            "SELECT mapping_quality,baseline_updated FROM scan_runs WHERE status='PARTIAL'"
        ).fetchone()
        assert row["mapping_quality"] == "ACCEPTED"
        assert row["baseline_updated"] == 1


def test_hostname_case_only_change_does_not_stale_mapping(tmp_path):
    db = DatabaseConnection(tmp_path / "hostname-case.db")
    MigrationManager(db).migrate()
    repo = OOBRepository(db)
    device = OOBService(repo).create(
        OOBDevice(name="OOB-case", host="OOB.Example.Local")
    )
    device.host = "oob.example.local"
    OOBService(repo).update(device)
    updated = repo.get(device.id)
    assert not updated.mapping_stale
    assert updated.connection_revision == 1


def test_any_incomplete_core_target_makes_mapping_not_accepted(tmp_path):
    repos = setup_repos(tmp_path)
    targets = [make_target(alias="GOOD", item=1, port=2001)]
    targets.append(ConsoleTarget(
        menu_name="OOB", menu_item=2, alias="BROKEN", command="",
        protocol="UNKNOWN", state="INCOMPLETE", state_confident=True,
        is_complete=False,
    ))
    result = service(repos, DataAdapter(targets)).scan_one(
        repos[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "PARTIAL"
    assert result.mapping_quality == "PARTIAL"
    assert not result.baseline_updated
    assert repos[2].list_current(repos[6].id) == []


def test_unconfident_supporting_parser_makes_overall_partial_but_mapping_accepted():
    targets = [make_target()]
    raw = [
        RawCommandOutput("menu", "show run | i ^menu", "menu data", True, is_core=True),
        RawCommandOutput("show_users", "show users", "malformed tty row", True, is_core=False),
    ]
    from oob_manager.services.scan_quality import ScanQualityEvaluator
    quality = ScanQualityEvaluator().evaluate(
        [], targets, raw,
        VendorScanData(
            True, "NORMAL_CLI", targets, raw,
            metadata={"show_users_success": True, "session_confident": False},
        ),
    )
    assert quality.status == "PARTIAL"
    assert quality.mapping_quality == "ACCEPTED"
    assert quality.mapping_accepted


def test_cisco_test_connection_rejects_unknown_prompt(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})

    class Client:
        def close(self):
            pass

    class SSH:
        def connect(self, *args, **kwargs):
            return Client()
        def open_shell(self, client):
            return object()
        def read_until_quiet(self, channel, timeout=None):
            return "Welcome to console server\n"

    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *args, **kwargs: 0.1)
    result = adapter.test_connection(
        OOBDevice(id=1, name="OOB", host="127.0.0.1"),
        SessionCredentials("u", "p"),
    )
    assert not result.success
    assert result.login_mode == "UNKNOWN"
    assert result.error_code == "UNKNOWN_LOGIN_MODE"
