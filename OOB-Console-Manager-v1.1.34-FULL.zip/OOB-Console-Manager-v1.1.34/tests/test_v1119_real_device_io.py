from __future__ import annotations

import time

from oob_manager.config import ApplicationSettings
from oob_manager.models import ConsoleTarget, OOBDevice, PortAuthenticationCredentials, SessionCredentials
from oob_manager.networking.ssh_client import SSHClientWrapper, extract_prompt
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


class _TimedChannel:
    """Tiny channel double that releases chunks at monotonic-time offsets."""

    def __init__(self, events):
        self.started = time.monotonic()
        self.events = list(events)
        self.closed = False
        self.eof_received = False

    def recv_ready(self):
        return bool(self.events and time.monotonic() - self.started >= self.events[0][0])

    def recv(self, _size):
        if not self.events:
            return b""
        _delay, payload = self.events.pop(0)
        return payload


def test_state_reader_waits_through_banner_gap_until_real_prompt():
    wrapper = SSHClientWrapper(command_timeout=2)
    channel = _TimedChannel(
        [
            (0.0, b"Authorized access only\r\n"),
            # Deliberately greater than the old 0.5 s quiet threshold.
            (0.65, b"HCM-OOB-01#"),
        ]
    )

    output, state = wrapper.read_until_state(
        channel,
        lambda text: "PROMPT" if extract_prompt(text) else None,
        timeout=1.5,
        settle=0.05,
    )

    assert state == "PROMPT"
    assert "Authorized access only" in output
    assert extract_prompt(output) == "HCM-OOB-01#"
    assert time.monotonic() - channel.started >= 0.60


def test_cisco_login_reader_does_not_finish_on_banner_quiet_gap():
    adapter = CiscoOOBAdapter(ApplicationSettings(command_timeout=2), {"vendor": "CISCO"})
    channel = _TimedChannel(
        [
            (0.0, b"NOTICE\r\n"),
            (0.60, b"OOB-RTR#"),
        ]
    )
    output, mode = adapter._read_login_state(channel)
    assert mode == "NORMAL_CLI"
    assert extract_prompt(output) == "OOB-RTR#"


def test_cisco_enable_uses_auth_command_deadline_not_3_5_second_quiet_windows():
    settings = ApplicationSettings(command_timeout=23, auth_timeout=31)
    adapter = CiscoOOBAdapter(settings, {"vendor": "CISCO"})

    class Channel:
        def __init__(self):
            self.sent = []

        def send(self, value):
            self.sent.append(value)
            return len(value)

    class SSH:
        def __init__(self):
            self.timeouts = []
            self.responses = ["Password:", "OOB#"]

        def drain_channel(self, *args, **kwargs):
            return ""

        def read_until_state(self, channel, detector, timeout=None, settle=0.2, **kwargs):
            self.timeouts.append(timeout)
            output = self.responses.pop(0)
            return output, detector(output)

    adapter.ssh = SSH()
    channel = Channel()
    output = adapter._ensure_enable(
        channel,
        "OOB>",
        SessionCredentials("operator", "login-secret", "enable-secret"),
    )

    assert output.endswith("OOB#")
    assert channel.sent == ["enable\n", "enable-secret\n"]
    assert adapter.ssh.timeouts == [31.0, 31.0]


def test_vertiv_connect_transition_uses_full_command_timeout_and_classifies_password_safely():
    settings = ApplicationSettings(command_timeout=27)
    adapter = VertivOOBAdapter(settings, {"vendor": "VERTIV"})

    class SSH:
        def __init__(self):
            self.calls = []

        def read_until_state(self, channel, detector, timeout=None, settle=0.2, **kwargs):
            self.calls.append(timeout)
            text = "Password:"
            return text, detector(text)

    adapter.ssh = SSH()
    _output, normal_state = adapter._read_connect_transition(object(), direct_ssh=False)
    _output, direct_state = adapter._read_connect_transition(object(), direct_ssh=True)

    assert adapter.ssh.calls == [27, 27]
    assert normal_state == "PORT_PASSWORD"
    assert direct_state == "TARGET_EVIDENCE"


def test_vertiv_access_method_is_explicit_and_fail_closed():
    assert PortAuthenticationCredentials().normalized_access_method() == "CLI_CONNECT"
    assert (
        PortAuthenticationCredentials(access_method="direct_ssh_port_name").normalized_access_method()
        == "DIRECT_SSH_PORT_NAME"
    )
    assert PortAuthenticationCredentials(access_method="surprise").normalized_access_method() == "INVALID"


def test_vertiv_direct_ssh_uses_username_colon_port_name(monkeypatch):
    settings = ApplicationSettings(command_timeout=10)
    adapter = VertivOOBAdapter(settings, {"vendor": "VERTIV"})
    target = ConsoleTarget(
        alias="R-PE-01",
        protocol="VERTIV_CLI",
        command="connect R-PE-01",
        console_line=1,
        is_complete=True,
    )
    device = OOBDevice(id=1, name="ACS", host="192.0.2.10", vendor="VERTIV")

    class Channel:
        pass

    class Client:
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    class SSH:
        last_host_key_algorithm = "ssh-ed25519"
        last_host_key_fingerprint = "SHA256:test"
        host_key_policy = "TOFU_PERSISTENT"

        def __init__(self):
            self.connect_args = None
            self.client = Client()

        def connect(self, host, port, username, password):
            self.connect_args = (host, port, username, password)
            return self.client

        def open_shell(self, client, width=160, height=48):
            return Channel()

        def read_until_state(self, channel, detector, timeout=None, settle=0.2, **kwargs):
            text = "Type the hot key to suspend the connection: <CTRL>z\n"
            return text, detector(text)

    fake = SSH()
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)

    client, _channel, preflight, state = adapter._open_direct_serial_ssh(
        device,
        target,
        SessionCredentials("admin", "oob-secret"),
    )

    assert client is fake.client
    assert fake.connect_args == ("192.0.2.10", 22, "admin:R-PE-01", "oob-secret")
    assert state == "TARGET_EVIDENCE"
    assert "hot key" in preflight
    client.close()


def _vertiv_available_target() -> ConsoleTarget:
    return ConsoleTarget(
        id=9,
        oob_id=7,
        menu_name="ACCESS",
        menu_item=1,
        alias="R1",
        command="connect R1",
        protocol="VERTIV_CLI",
        target_host="192.0.2.10",
        console_line=1,
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="VERTIV_ACCESS_IDLE",
        state_evidence='{"status":"Idle"}',
        is_complete=True,
    )


def test_vertiv_open_console_direct_ssh_still_requires_management_safety_check(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    target = _vertiv_available_target()
    device = OOBDevice(id=7, name="ACS", host="192.0.2.10", vendor="VERTIV")

    class Client:
        def __init__(self): self.closed = False
        def close(self): self.closed = True

    class SSH:
        last_host_key_algorithm = ""
        last_host_key_fingerprint = ""
        host_key_policy = "TOFU_PERSISTENT"
        def __init__(self): self.mgmt = Client()
        def connect(self, *a, **k): return self.mgmt
        def open_shell(self, *a, **k): return object()

    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
    verified = {"called": 0}
    def runtime_verify(*args):
        verified["called"] += 1
        return target, "access/show"
    monkeypatch.setattr(adapter, "_runtime_verify", runtime_verify)

    direct_client = Client()
    direct_channel = object()
    direct_called = {"called": 0}
    def direct_open(*args):
        direct_called["called"] += 1
        return direct_client, direct_channel, "hotkey", "TARGET_EVIDENCE"
    monkeypatch.setattr(adapter, "_open_direct_serial_ssh", direct_open)
    bridged = {}
    monkeypatch.setattr(
        "oob_manager.vendors.vertiv.adapter.TerminalBridge.bridge",
        lambda _self, channel, initial_output="": bridged.update(
            channel=channel, initial_output=initial_output
        ),
    )

    result = adapter.open_console(
        device,
        target,
        SessionCredentials("admin", "secret"),
        PortAuthenticationCredentials(access_method="DIRECT_SSH_PORT_NAME"),
    )

    assert verified["called"] == 1
    assert direct_called["called"] == 1
    assert result.runtime_mapping_verified
    assert result.console_path_verified
    assert result.path_verification_code == "VERTIV_DIRECT_SSH_SELECTOR_AUTHENTICATED"
    assert bridged["channel"] is direct_channel
    assert direct_client.closed
    assert adapter.ssh.mgmt.closed


def test_vertiv_direct_identity_records_access_method(monkeypatch):
    from oob_manager.models import DownstreamCredentials, DownstreamDiscoveryResult

    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    target = _vertiv_available_target()
    device = OOBDevice(id=7, name="ACS", host="192.0.2.10", vendor="VERTIV")

    class Client:
        def __init__(self): self.closed = False
        def close(self): self.closed = True

    class SSH:
        last_host_key_algorithm = "ssh-ed25519"
        last_host_key_fingerprint = "SHA256:test"
        host_key_policy = "TOFU_PERSISTENT"
        def __init__(self): self.mgmt = Client()
        def connect(self, *a, **k): return self.mgmt
        def open_shell(self, *a, **k): return object()

    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_ensure_cli", lambda *a: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda *a: (target, "access/show"))
    direct_client = Client()
    monkeypatch.setattr(
        adapter,
        "_open_direct_serial_ssh",
        lambda *a: (direct_client, object(), "hotkey", "TARGET_EVIDENCE"),
    )
    monkeypatch.setattr(
        "oob_manager.vendors.vertiv.adapter.DownstreamIdentityCollector.collect",
        lambda *a, **k: DownstreamDiscoveryResult(),
    )

    result = adapter.discover_downstream_identity(
        device,
        target,
        SessionCredentials("admin", "secret"),
        DownstreamCredentials("down", "down-secret"),
        PortAuthenticationCredentials(access_method="DIRECT_SSH_PORT_NAME"),
    )

    assert result.metadata["vertiv_access_method"] == "DIRECT_SSH_PORT_NAME"
    assert result.runtime_mapping_verified
    assert direct_client.closed
    assert adapter.ssh.mgmt.closed


def test_vertiv_direct_ssh_can_use_separate_runtime_only_account(monkeypatch):
    settings = ApplicationSettings(command_timeout=10)
    adapter = VertivOOBAdapter(settings, {"vendor": "VERTIV"})
    target = ConsoleTarget(
        alias="R-PE-02",
        protocol="VERTIV_CLI",
        command="connect R-PE-02",
        console_line=2,
        is_complete=True,
    )
    device = OOBDevice(id=1, name="ACS", host="192.0.2.11", vendor="VERTIV")

    class Client:
        def close(self):
            pass

    class SSH:
        last_host_key_algorithm = "ssh-ed25519"
        last_host_key_fingerprint = "SHA256:test"
        host_key_policy = "TOFU_PERSISTENT"

        def __init__(self):
            self.connect_args = None

        def connect(self, host, port, username, password):
            self.connect_args = (host, port, username, password)
            return Client()

        def open_shell(self, client, width=160, height=48):
            return object()

        def read_until_state(self, channel, detector, timeout=None, settle=0.2, **kwargs):
            text = "Type the hot key to suspend the connection: <CTRL>z\n"
            return text, detector(text)

    fake = SSH()
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    port_credentials = PortAuthenticationCredentials(
        access_method="DIRECT_SSH_PORT_NAME",
        direct_username="serial-op",
        direct_password="serial-secret",
        use_oob_credentials_for_direct=False,
    )

    client, _channel, _preflight, state = adapter._open_direct_serial_ssh(
        device,
        target,
        SessionCredentials("mgmt-op", "mgmt-secret"),
        port_credentials,
    )

    assert fake.connect_args == (
        "192.0.2.11",
        22,
        "serial-op:R-PE-02",
        "serial-secret",
    )
    assert state == "TARGET_EVIDENCE"
    client.close()


def test_downstream_auth_waits_through_slow_banner_gaps():
    from oob_manager.downstream.collector import DownstreamIdentityCollector
    from oob_manager.models import DownstreamCredentials

    wrapper = SSHClientWrapper(command_timeout=2)
    collector = DownstreamIdentityCollector(wrapper, command_timeout=2)

    class LoginChannel(_TimedChannel):
        def __init__(self):
            super().__init__([
                (0.0, b"Authorized users only\r\n"),
                (0.60, b"login: "),
            ])
            self.sent = []
            self.phase = 0

        def send(self, value):
            self.sent.append(value)
            now = time.monotonic() - self.started
            if value == "operator\n":
                self.events = [(now + 0.55, b"Password: ")]
            elif value == "down-secret\n":
                self.events = [(now + 0.55, b"R-PE-01#")]
            return len(value)

    channel = LoginChannel()
    # Initial serial preflight can contain only a hotkey/banner and no login state.
    prompt, method = collector._authenticate(
        channel,
        "Type the hot key to suspend the connection: <CTRL>z\n",
        DownstreamCredentials("operator", "down-secret"),
    )

    assert prompt == "R-PE-01#"
    assert method == "USERNAME_PASSWORD"
    assert "operator\n" in channel.sent
    assert "down-secret\n" in channel.sent
