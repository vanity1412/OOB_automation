from __future__ import annotations

from oob_manager.config import ApplicationSettings
from oob_manager.models import OOBDevice, SessionCredentials
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter, _clean_terminal_text


ACCESS_SHOW_WITH_BEL_PROMPT = (
    "show\r\n"
    "  name               port  type    status\r\r\n"
    "  =================  ====  ======  ======\r\r\n"
    "  HPG-Vertiv-OOB-02                      \r\r\n"
    "  HPG-MP-02-01-N     1     serial  idle  \r\r\n"
    "  HPG-SW-02-01-mem0  5     serial  idle  \r\r\n"
    "\r\r\nType ls to see available sub-nodes.\r\r\n"
    "--:- access cli-> \x07"
)


class DummyClient:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class ScriptChannel:
    def __init__(self, initial: str = ""):
        self.sent: list[str] = []
        self.buffer = bytearray(initial.encode())
        self.location = "root"

    def settimeout(self, value):
        pass

    def send(self, value):
        text = value.decode() if isinstance(value, bytes) else value
        self.sent.append(text)
        command = text.strip()
        if command == "cd access":
            self.location = "access"
            response = "\r\n--:- access cli-> \x07"
        elif command == "show" and self.location == "access":
            response = ACCESS_SHOW_WITH_BEL_PROMPT
        else:
            response = ""
        self.buffer.extend(response.encode())
        return len(value)

    def recv_ready(self):
        return bool(self.buffer)

    def recv(self, size):
        data = bytes(self.buffer[:size])
        del self.buffer[:size]
        return data


class ScriptSSH:
    def __init__(self, initial: str):
        self.client = DummyClient()
        self.channel = ScriptChannel()
        self.initial = initial
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:test"
        self.host_key_policy = "TOFU_PERSISTENT"

    def connect(self, *args, **kwargs):
        return self.client

    def open_shell(self, client, *args, **kwargs):
        return self.channel

    def read_until_quiet(self, *args, **kwargs):
        value, self.initial = self.initial, ""
        return value

    def drain_channel(self, *args, **kwargs):
        return ""


def _device() -> OOBDevice:
    return OOBDevice(
        id=4,
        name="HPG-Vertiv-OOB-02",
        host="172.29.13.116",
        ssh_port=22,
        vendor="VERTIV",
        connection_mode="SSH",
        enabled=True,
    )


def test_real_acs_bel_after_prompt_is_ignored():
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=1), {"vendor": "VERTIV"})
    assert _clean_terminal_text("--:- access cli-> \x07").strip() == "--:- access cli->"
    assert adapter._extract_cli_prompt("--:- access cli-> \x07") == "--:- access cli->"


def test_show_with_bel_prompt_completes_without_enter_recovery(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=1), {"vendor": "VERTIV"})
    adapter.ssh = ScriptSSH("--:- / cli-> \x07")
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)

    data = adapter.collect(_device(), SessionCredentials("admin", "secret"))

    assert data.connection_success is True
    assert [target.alias for target in data.targets] == ["HPG-MP-02-01-N", "HPG-SW-02-01-mem0"]
    # No bare Enter is required to force a second prompt redraw anymore.
    assert adapter.ssh.channel.sent[:2] == ["cd access\n", "show\n"]
    assert "\n" not in adapter.ssh.channel.sent[2:]


def test_connection_test_does_not_run_access_inventory(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=1), {"vendor": "VERTIV"})
    adapter.ssh = ScriptSSH("--:- / cli-> \x07")
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)

    result = adapter.test_connection(_device(), SessionCredentials("admin", "secret"))

    assert result.success is True
    assert result.login_mode == "VERTIV_CLI"
    assert adapter.ssh.channel.sent == []
    assert adapter.ssh.client.closed is True
