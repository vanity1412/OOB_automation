import sqlite3

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.models import (
    ConsoleTarget,
    OOBDevice,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.scan_quality import ScanQualityEvaluator
from oob_manager.services.scan_service import ScanService


class FakeAdapter:
    def __init__(self, targets):
        self.targets = targets

    def collect(self, device, credentials):
        return VendorScanData(
            True,
            "NORMAL_CLI",
            self.targets,
            [
                RawCommandOutput(
                    "menu",
                    "show run | i menu",
                    "menu OOB text [1] R1\nmenu OOB command 1 telnet 10.0.0.1 2001",
                    True,
                    is_core=True,
                )
            ],
        )


def make_target(alias="R1", item=1, port=2001):
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=item,
        alias=alias,
        command=f"telnet 10.0.0.1 {port}",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=port,
        state="AVAILABLE",
        is_complete=True,
    )


def setup_repositories(tmp_path):
    db = DatabaseConnection(tmp_path / "review.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    device = oob_repo.create(OOBDevice(name="OOB-1", host="127.0.0.1"))
    return db, oob_repo, target_repo, scan_repo, change_repo, lock_repo, device


def build_service(repositories, targets, change_repo=None, scan_repo=None):
    db, oob_repo, target_repo, real_scan_repo, real_change_repo, lock_repo, _ = repositories
    return ScanService(
        oob_repo,
        target_repo,
        scan_repo or real_scan_repo,
        change_repo or real_change_repo,
        lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda device, settings: FakeAdapter(targets),
    )


def test_target_id_and_connection_link_survive_successful_rescan(tmp_path):
    repos = setup_repositories(tmp_path)
    db, _, target_repo, _, _, _, device = repos
    first_service = build_service(repos, [make_target()])
    assert first_service.scan_one(device.id, SessionCredentials("u", "p")).status == "SUCCESS"
    first = target_repo.list_current(device.id)[0]
    first_id = first.id
    first_seen = first.first_seen_at

    connection_repo = ConnectionRepository(db)
    connection_id = connection_repo.start(device.id, first, "operator")
    connection_repo.finish(connection_id, "SUCCESS")

    second_service = build_service(repos, [make_target(item=4, port=2006)])
    assert second_service.scan_one(device.id, SessionCredentials("u", "p")).status == "SUCCESS"
    second = target_repo.list_current(device.id)[0]

    assert second.id == first_id
    assert second.first_seen_at == first_seen
    with db.read() as conn:
        history = conn.execute(
            "SELECT target_id, target_alias, target_port FROM connection_history WHERE id=?",
            (connection_id,),
        ).fetchone()
    assert history["target_id"] == first_id
    assert history["target_alias"] == "R1"
    assert history["target_port"] == 2001


def test_success_persistence_rolls_back_when_change_save_fails(tmp_path):
    repos = setup_repositories(tmp_path)
    _, _, target_repo, _, _, _, device = repos
    assert build_service(repos, [make_target()]).scan_one(
        device.id, SessionCredentials("u", "p")
    ).status == "SUCCESS"

    class FailingChangeRepository(ChangeRepository):
        def save_all(self, events, *, conn=None):
            raise RuntimeError("forced change persistence failure")

    failing_repo = FailingChangeRepository(repos[0])
    result = build_service(
        repos,
        [make_target(item=4, port=2006)],
        change_repo=failing_repo,
    ).scan_one(device.id, SessionCredentials("u", "p"))

    assert result.status == "FAILED"
    current = target_repo.list_current(device.id)[0]
    assert current.menu_item == 1
    assert current.target_port == 2001


def test_scan_lock_released_when_scan_start_fails(tmp_path):
    repos = setup_repositories(tmp_path)
    db, _, _, _, _, lock_repo, device = repos

    class BrokenScanRepository:
        def start(self, oob_id, scanner_version):
            raise RuntimeError("cannot create scan")

    result = build_service(
        repos,
        [make_target()],
        scan_repo=BrokenScanRepository(),
    ).scan_one(device.id, SessionCredentials("u", "p"))

    assert result.status == "FAILED"
    with db.read() as conn:
        assert conn.execute("SELECT COUNT(*) FROM scan_locks").fetchone()[0] == 0


def test_duplicate_endpoint_is_partial_warning_not_baseline_success():
    targets = [make_target(alias="R1", item=1), make_target(alias="R2", item=2)]
    raw = [RawCommandOutput("menu", "show", "menu data", True, is_core=True)]
    quality = ScanQualityEvaluator().evaluate(
        [],
        targets,
        raw,
        VendorScanData(True, "NORMAL_CLI", targets, raw),
    )
    assert quality.status == "PARTIAL"
    assert any("Duplicate endpoint" in message for message in quality.warnings)


def test_migration_upgrades_v1_columns_before_new_indexes(tmp_path):
    path = tmp_path / "legacy.db"
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE schema_versions(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
        INSERT INTO schema_versions VALUES(1, '2026-01-01T00:00:00+00:00');
        CREATE TABLE oob_devices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE, host TEXT NOT NULL, ssh_port INTEGER NOT NULL,
            vendor TEXT NOT NULL, device_type TEXT NOT NULL DEFAULT '',
            default_username TEXT NOT NULL DEFAULT '', connection_mode TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1, notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_scan_at TEXT,
            UNIQUE(host, ssh_port)
        );
        CREATE TABLE scan_runs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, oob_id INTEGER NOT NULL,
            started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
            mapping_count INTEGER NOT NULL DEFAULT 0,
            warning_count INTEGER NOT NULL DEFAULT 0,
            error_code TEXT NOT NULL DEFAULT '', error_message TEXT NOT NULL DEFAULT '',
            scanner_version TEXT NOT NULL
        );
        CREATE TABLE console_targets(
            id INTEGER PRIMARY KEY AUTOINCREMENT, oob_id INTEGER NOT NULL,
            menu_name TEXT NOT NULL, menu_item INTEGER, alias TEXT NOT NULL DEFAULT '',
            command TEXT NOT NULL DEFAULT '', protocol TEXT NOT NULL,
            target_host TEXT NOT NULL DEFAULT '', target_port INTEGER NOT NULL DEFAULT 0,
            console_line INTEGER, state TEXT NOT NULL, session_user TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL, is_complete INTEGER NOT NULL,
            first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, last_scan_id INTEGER NOT NULL
        );
        CREATE TABLE console_snapshots(
            id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id INTEGER NOT NULL,
            oob_id INTEGER NOT NULL, menu_name TEXT NOT NULL, menu_item INTEGER,
            alias TEXT NOT NULL DEFAULT '', command TEXT NOT NULL DEFAULT '',
            protocol TEXT NOT NULL, target_host TEXT NOT NULL DEFAULT '',
            target_port INTEGER NOT NULL DEFAULT 0, console_line INTEGER,
            state TEXT NOT NULL, session_user TEXT NOT NULL DEFAULT '', source TEXT NOT NULL,
            is_complete INTEGER NOT NULL, captured_at TEXT NOT NULL
        );
        CREATE TABLE connection_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT, oob_id INTEGER NOT NULL,
            target_id INTEGER, username TEXT NOT NULL, started_at TEXT NOT NULL,
            ended_at TEXT, status TEXT NOT NULL, error_code TEXT NOT NULL DEFAULT '',
            error_message TEXT NOT NULL DEFAULT ''
        );
        """
    )
    conn.close()

    db = DatabaseConnection(path)
    MigrationManager(db).migrate()
    MigrationManager(db).migrate()
    with db.read() as migrated:
        scan_columns = {
            row["name"] for row in migrated.execute("PRAGMA table_info(scan_runs)")
        }
        snapshot_columns = {
            row["name"]
            for row in migrated.execute("PRAGMA table_info(console_snapshots)")
        }
        connection_columns = {
            row["name"]
            for row in migrated.execute("PRAGMA table_info(connection_history)")
        }
        assert {"complete_count", "complete_ratio", "change_count"} <= scan_columns
        assert "target_id" in snapshot_columns
        assert {"target_alias", "target_host", "target_port", "menu_name", "menu_item"} <= connection_columns
        assert migrated.execute("PRAGMA user_version").fetchone()[0] == 16


def test_failed_scan_persists_attached_raw_output(tmp_path):
    repos = setup_repositories(tmp_path)
    db, _, _, _, _, _, device = repos

    class RawFailureAdapter:
        def collect(self, device, credentials):
            from oob_manager.exceptions import CommandExecutionError

            error = CommandExecutionError(
                "auto menu cannot scan",
                error_code="AUTO_MENU_SCAN_UNAVAILABLE",
            )
            error.raw_outputs = [
                RawCommandOutput(
                    "initial",
                    "SSH login",
                    "=== OOB MENU ===\n1. Router-A\nSelect:",
                    True,
                    is_core=True,
                )
            ]
            raise error

    service = ScanService(
        repos[1],
        repos[2],
        repos[3],
        repos[4],
        repos[5],
        ApplicationSettings(),
        adapter_factory=lambda device, settings: RawFailureAdapter(),
    )
    result = service.scan_one(device.id, SessionCredentials("u", "p"))
    assert result.status == "FAILED"
    assert result.error_code == "AUTO_MENU_SCAN_UNAVAILABLE"
    with db.read() as conn:
        row = conn.execute(
            "SELECT command_name, raw_output FROM raw_outputs WHERE scan_id=?",
            (result.scan_id,),
        ).fetchone()
    assert row["command_name"] == "initial"
    assert "OOB MENU" in row["raw_output"]


def test_new_target_event_receives_persisted_target_id(tmp_path):
    repos = setup_repositories(tmp_path)
    db, _, target_repo, _, _, _, device = repos
    result = build_service(repos, [make_target()]).scan_one(
        device.id, SessionCredentials("u", "p")
    )
    target_id = target_repo.list_current(device.id)[0].id
    with db.read() as conn:
        event = conn.execute(
            "SELECT new_data FROM change_events WHERE scan_id=? AND event_code='NEW_CONSOLE_TARGET'",
            (result.scan_id,),
        ).fetchone()
    import json

    assert json.loads(event["new_data"])["target_id"] == target_id


def test_partial_scan_saves_snapshot_but_keeps_current_baseline(tmp_path):
    repos = setup_repositories(tmp_path)
    db, oob_repo, target_repo, _, _, _, device = repos
    assert build_service(repos, [make_target()]).scan_one(
        device.id, SessionCredentials("u", "p")
    ).status == "SUCCESS"

    class PartialAdapter:
        def collect(self, device, credentials):
            changed = make_target(item=4, port=2006)
            return VendorScanData(
                True,
                "NORMAL_CLI",
                [changed],
                [
                    RawCommandOutput("menu", "show", "menu data", True, is_core=True),
                    RawCommandOutput("show_users", "show users", "", False),
                ],
            )

    service = ScanService(
        oob_repo,
        target_repo,
        repos[3],
        repos[4],
        repos[5],
        ApplicationSettings(),
        adapter_factory=lambda device, settings: PartialAdapter(),
    )
    result = service.scan_one(device.id, SessionCredentials("u", "p"))
    assert result.status == "PARTIAL"
    assert result.mapping_quality == "ACCEPTED"
    assert result.baseline_updated
    current = target_repo.list_current(device.id)[0]
    assert current.menu_item == 4 and current.target_port == 2006
    with db.read() as conn:
        assert conn.execute(
            "SELECT COUNT(*) FROM console_snapshots WHERE scan_id=?",
            (result.scan_id,),
        ).fetchone()[0] == 1
        assert conn.execute(
            "SELECT COUNT(*) FROM change_events WHERE scan_id=?",
            (result.scan_id,),
        ).fetchone()[0] >= 1


def test_failed_scan_updates_last_scan_timestamp(tmp_path):
    repos = setup_repositories(tmp_path)
    _, oob_repo, _, _, _, _, device = repos

    class FailureAdapter:
        def collect(self, device, credentials):
            raise RuntimeError("failure")

    service = ScanService(
        repos[1], repos[2], repos[3], repos[4], repos[5], ApplicationSettings(),
        adapter_factory=lambda device, settings: FailureAdapter(),
    )
    assert service.scan_one(device.id, SessionCredentials("u", "p")).status == "FAILED"
    assert oob_repo.get(device.id).last_scan_at is not None
