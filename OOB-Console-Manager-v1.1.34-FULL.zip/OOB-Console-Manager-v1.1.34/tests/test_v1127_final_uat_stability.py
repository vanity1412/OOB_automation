from __future__ import annotations

from pathlib import Path

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings
from oob_manager.models import OOBDevice, SessionCredentials
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter


class _Client:
    def close(self):
        pass


class _Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value):
        self.sent.append(value)
        return len(value)


class _CiscoSSH:
    def __init__(self, initial: str, transitions: list[tuple[str, str | None]]):
        self.initial = initial
        self.transitions = list(transitions)
        self.expected_prompt = None
        self.last_host_key_algorithm = "ssh-rsa"
        self.last_host_key_fingerprint = "SHA256:test"
        self.host_key_policy = "TOFU_PERSISTENT"
        self.channel = _Channel()

    def connect(self, *args, **kwargs):
        return _Client()

    def open_shell(self, client):
        return self.channel

    def read_until_state(self, channel, detector, timeout=None, settle=0.2, initial=""):
        if not initial and self.initial:
            value = self.initial
            self.initial = ""
            return value, detector(value)
        if self.transitions:
            return self.transitions.pop(0)
        return "", None

    def drain_channel(self, channel, *args, **kwargs):
        return ""


def _cisco_device() -> OOBDevice:
    return OOBDevice(id=1, name="OOB", host="192.0.2.10", vendor="CISCO")


def test_v1127_enable_can_promote_without_enable_password():
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    ssh = _CiscoSSH("", [("OOB#\n", "PRIVILEGED")])
    adapter.ssh = ssh

    output = adapter._ensure_enable(
        ssh.channel,
        "OOB>\n",
        SessionCredentials("noc", "login-password", None),
    )

    assert ssh.channel.sent == ["enable\n"]
    assert output.endswith("OOB#\n")


def test_v1127_enable_password_is_required_only_if_device_asks_for_it():
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    ssh = _CiscoSSH("", [("Password:\n", "PASSWORD")])
    adapter.ssh = ssh

    try:
        adapter._ensure_enable(
            ssh.channel,
            "OOB>\n",
            SessionCredentials("noc", "login-password", None),
        )
    except Exception as exc:
        assert getattr(exc, "error_code", "") == "ENABLE_PASSWORD_REQUIRED"
    else:  # pragma: no cover
        raise AssertionError("expected ENABLE_PASSWORD_REQUIRED")

    assert ssh.channel.sent == ["enable\n"]


def test_v1127_cisco_connection_test_verifies_privileged_exec(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    ssh = _CiscoSSH("OOB>\n", [("OOB#\n", "PRIVILEGED")])
    adapter.ssh = ssh
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *args, **kwargs: 0.1)

    result = adapter.test_connection(
        _cisco_device(), SessionCredentials("noc", "login-password", None)
    )

    assert result.success
    assert result.login_mode == "NORMAL_CLI"
    assert "privileged EXEC" in result.message
    assert ssh.expected_prompt == "OOB#"


def test_v1127_vertiv_credentials_do_not_prompt_for_enable_password(tmp_path: Path):
    answers = iter(["admin"])
    secrets = iter(["management-password"])
    app = CLIApplication(
        db_path=tmp_path / "cli.db",
        input_func=lambda _prompt="": next(answers),
        getpass_func=lambda _prompt="": next(secrets),
        pause_enabled=False,
    )

    credentials = app._credentials(
        OOBDevice(id=1, name="ACS", host="192.0.2.20", vendor="VERTIV")
    )

    assert credentials.username == "admin"
    assert credentials.password == "management-password"
    assert credentials.enable_password is None


def test_v1127_dependency_check_reports_wrong_pinned_version(monkeypatch):
    from oob_manager.utils import dependency_check

    monkeypatch.setattr(dependency_check.importlib.util, "find_spec", lambda _name: object())

    def fake_version(name: str) -> str:
        return {"paramiko": "4.0.0", "colorama": "0.4.6"}[name]

    monkeypatch.setattr(dependency_check.importlib_metadata, "version", fake_version)
    issues = dependency_check.dependency_issues()
    assert any("paramiko==4.0.0" in item and "3.5.1" in item for item in issues)
    assert not any("colorama" in item for item in issues)
