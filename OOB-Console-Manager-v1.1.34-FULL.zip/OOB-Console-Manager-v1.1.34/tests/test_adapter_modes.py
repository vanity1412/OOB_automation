from oob_manager.config import ApplicationSettings
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter

def adapter():
    return CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})

def test_detect_normal_cli():
    assert adapter().detect_login_mode("\r\nHCM-OOB-01#") == "NORMAL_CLI"
    assert adapter().detect_login_mode("\r\nHCM-OOB-01>") == "NORMAL_CLI"

def test_detect_auto_menu():
    output = "=== OOB MENU ===\n1. Router-A\n2. Router-B\nSelect:"
    assert adapter().detect_login_mode(output) == "AUTO_MENU"

def test_unknown_mode():
    assert adapter().detect_login_mode("Welcome only") == "UNKNOWN"
