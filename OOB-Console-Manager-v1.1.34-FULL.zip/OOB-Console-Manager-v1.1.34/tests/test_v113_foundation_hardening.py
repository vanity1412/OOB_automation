import csv
import hashlib
import json
import sqlite3
import socket
from pathlib import Path

import pytest

from oob_manager.config import ApplicationSettings, load_profile
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import CommandExecutionError, InteractiveSessionError, ProfileError
from oob_manager.models import ConsoleTarget, OOBDevice, RawCommandOutput, SessionCredentials, VendorScanData
from oob_manager.networking.ssh_client import SSHClientWrapper, _ends_with_prompt, extract_prompt
from oob_manager.services.export_service import ExportService
from oob_manager.services.oob_service import OOBService
from oob_manager.services.scan_quality import ScanQualityEvaluator
from oob_manager.services.scan_service import ScanService
from oob_manager.services.target_matching import TargetMatcher
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.cisco.parsers import parse_menu_config, parse_show_line, parse_show_users
from oob_manager.vendors.cisco.state_resolver import resolve_console_states


def make_target(alias="R1", item=1, port=2001, line=1):
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=item,
        alias=alias,
        command=f"telnet 10.0.0.1 {port}",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=port,
        console_line=line,
        console_line_source="REVERSE_TELNET_PORT_CONFIRMED",
        state="UNKNOWN",
        state_confident=False,
        state_reason_code="TEST",
        state_evidence="{}",
        source="CISCO_MENU",
        mapping_source_command="show run | i ^menu",
        mapping_text_line=f"menu OOB text [{item}] {alias}",
        mapping_command_line=f"menu OOB command {item} telnet 10.0.0.1 {port}",
        is_complete=True,
    )


def setup_stack(tmp_path):
    db = DatabaseConnection(tmp_path / "foundation.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    device = oob_repo.create(OOBDevice(name="OOB-A", host="10.10.10.1", device_type="cisco_ios"))
    return db, oob_repo, target_repo, scan_repo, change_repo, lock_repo, device


class Adapter:
    def __init__(self, targets, *, supporting_fail=False):
        self.targets = targets
        self.supporting_fail = supporting_fail

    def collect(self, device, credentials):
        raw = [
            RawCommandOutput(
                "menu", "show run | i ^menu",
                "menu OOB text [1] R1\nmenu OOB command 1 telnet 10.0.0.1 2001",
                True, is_core=True,
            ),
            RawCommandOutput(
                "show_users", "show users", "", not self.supporting_fail,
                "authorization failed" if self.supporting_fail else "", is_core=False,
            ),
        ]
        return VendorScanData(
            True,
            "NORMAL_CLI",
            self.targets,
            raw,
            warnings=["show users chưa đủ dữ liệu"] if self.supporting_fail else [],
            metadata={"show_users_success": not self.supporting_fail, "session_confident": not self.supporting_fail},
        )


def make_scan_service(stack, adapter):
    return ScanService(
        stack[1], stack[2], stack[3], stack[4], stack[5],
        ApplicationSettings(), adapter_factory=lambda device, settings: adapter,
    )


def test_missing_alias_is_not_complete_core_mapping():
    parsed = parse_menu_config("menu OOB text [1]\nmenu OOB command 1 telnet 10.0.0.1 2001")
    assert len(parsed.targets) == 1
    assert parsed.targets[0].is_complete is False
    quality = ScanQualityEvaluator().evaluate(
        [],
        parsed.targets,
        [RawCommandOutput("menu", "show run | i ^menu", "menu data", True, is_core=True)],
        VendorScanData(True, "NORMAL_CLI", parsed.targets),
    )
    assert quality.mapping_accepted is False
    assert quality.mapping_quality == "PARTIAL"


def test_parser_persists_exact_menu_source_lines():
    raw = "menu OOB text [4] ----> R4\nmenu OOB command 4 telnet 172.28.200.11 2006 /stream"
    target = parse_menu_config(raw).targets[0]
    assert target.mapping_text_line == "menu OOB text [4] ----> R4"
    assert target.mapping_command_line == "menu OOB command 4 telnet 172.28.200.11 2006 /stream"


def test_async_show_users_maps_session_by_async_port():
    target = make_target(line=3, port=2003)
    lines = parse_show_line("0/0/0 3 TTY - - - - - 0 0 0/0")
    users = parse_show_users(
        "Line User Host(s) Idle Location\n"
        "tty 0/0/0 operator01 00:01:00 10.20.30.40"
    )
    assert users.session_confident
    resolve_console_states([target], lines, users, show_line_success=True, show_users_success=True)
    assert target.state == "BUSY"
    assert target.session_user == "operator01"
    assert target.state_reason_code == "ACTIVE_TTY_SESSION_WITH_USER"
    evidence = json.loads(target.state_evidence)
    assert evidence["show_line_async_port"] == "0/0/0"


def test_available_requires_confirmed_show_line_not_only_no_tty_match():
    target = make_target(line=6, port=2006)
    users = parse_show_users(
        "Line User Host(s) Idle Location\n"
        "* 2 vty 0 admin01 00:00:00 10.1.1.1"
    )
    resolve_console_states(
        [target], parse_show_line(""), users,
        show_line_success=False, show_users_success=True,
    )
    assert target.state == "UNKNOWN"
    assert not target.state_confident
    assert target.state_reason_code == "LINE_NOT_CONFIRMED_FOR_AVAILABILITY"


def test_same_menu_item_alone_does_not_reuse_target_identity():
    old = make_target(alias="Router-A", item=4, port=2004, line=4)
    old.id = 11
    new = ConsoleTarget(
        menu_name="OOB", menu_item=4, alias="Switch-X",
        command="telnet 10.0.0.99 2099", protocol="TELNET",
        target_host="10.0.0.99", target_port=2099, console_line=99,
        is_complete=True,
    )
    result = TargetMatcher().match([old], [new])
    assert result.pairs == []
    assert result.previous_unmatched == [old]
    assert result.current_unmatched == [new]


def test_scan_history_snapshots_oob_identity_at_scan_time(tmp_path):
    stack = setup_stack(tmp_path)
    result = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    assert result.baseline_updated
    device = stack[1].get(stack[6].id)
    device.host = "10.10.10.99"
    OOBService(stack[1]).update(device)
    with stack[0].read() as conn:
        row = conn.execute("SELECT * FROM scan_runs WHERE id=?", (result.scan_id,)).fetchone()
    assert row["oob_host_at_scan"] == "10.10.10.1"
    assert row["config_snapshot_source"] == "LIVE_CAPTURE"
    assert len(row["profile_fingerprint"]) == 64


def test_raw_output_records_core_role_hash_and_length(tmp_path):
    stack = setup_stack(tmp_path)
    result = make_scan_service(stack, Adapter([make_target()], supporting_fail=True)).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with stack[0].read() as conn:
        rows = conn.execute("SELECT * FROM raw_outputs WHERE scan_id=? ORDER BY id", (result.scan_id,)).fetchall()
    assert [row["is_core"] for row in rows] == [1, 0]
    for row in rows:
        raw = row["raw_output"]
        assert row["stored_output_length"] == len(raw)
        assert row["stored_output_sha256"] == hashlib.sha256(raw.encode()).hexdigest()


def test_scan_findings_keep_human_readable_reason(tmp_path):
    stack = setup_stack(tmp_path)
    result = make_scan_service(stack, Adapter([make_target()], supporting_fail=True)).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "PARTIAL"
    with stack[0].read() as conn:
        findings = conn.execute(
            "SELECT source, message FROM scan_findings WHERE scan_id=? ORDER BY id",
            (result.scan_id,),
        ).fetchall()
    messages = "\n".join(row["message"] for row in findings)
    assert "show users" in messages.casefold()
    assert any(row["source"] in {"adapter", "quality_gate"} for row in findings)


def test_rejected_scan_keeps_snapshot_for_forensics(tmp_path):
    stack = setup_stack(tmp_path)
    baseline = [make_target(alias=f"R{i}", item=i, port=2000+i, line=i) for i in range(1, 11)]
    assert make_scan_service(stack, Adapter(baseline)).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    ).baseline_updated
    rejected = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    assert rejected.status == "REJECTED"
    with stack[0].read() as conn:
        assert conn.execute("SELECT COUNT(*) FROM console_snapshots WHERE scan_id=?", (rejected.scan_id,)).fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM change_events WHERE scan_id=?", (rejected.scan_id,)).fetchone()[0] == 0


def test_connection_history_keeps_oob_and_target_snapshot_after_edits(tmp_path):
    stack = setup_stack(tmp_path)
    scan = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    target = stack[2].list_current(stack[6].id)[0]
    repo = ConnectionRepository(stack[0])
    connection_id = repo.start(stack[6].id, target, "operator", device=stack[1].get(stack[6].id))
    repo.finish(connection_id, "SUCCESS", console_path_verified=True, path_verification_code="TEST_PATH_VERIFIED")

    device = stack[1].get(stack[6].id)
    device.host = "10.10.10.99"
    device.name = "OOB-RENAMED"
    OOBService(stack[1]).update(device)

    with stack[0].read() as conn:
        row = conn.execute("SELECT * FROM connection_history WHERE id=?", (connection_id,)).fetchone()
    assert row["oob_name_at_connection"] == "OOB-A"
    assert row["oob_host_at_connection"] == "10.10.10.1"
    assert row["target_alias"] == "R1"
    assert row["mapping_last_scan_id"] == scan.scan_id
    assert row["console_path_verified"] == 1


def test_audit_views_make_trace_easy(tmp_path):
    stack = setup_stack(tmp_path)
    result = make_scan_service(stack, Adapter([make_target()], supporting_fail=True)).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with stack[0].read() as conn:
        target = conn.execute("SELECT * FROM v_current_console_inventory").fetchone()
        scan = conn.execute("SELECT * FROM v_scan_audit WHERE id=?", (result.scan_id,)).fetchone()
        trace = conn.execute("SELECT * FROM v_target_trace").fetchone()
        command = conn.execute("SELECT * FROM v_scan_command_audit WHERE scan_id=? ORDER BY raw_output_id LIMIT 1", (result.scan_id,)).fetchone()
    assert target["mapping_validity"] == "VALID"
    assert target["state_reason_code"]
    assert scan["raw_output_count"] == 2
    assert scan["finding_count"] >= 1
    assert scan["snapshot_count"] == 1
    assert trace["last_scan_id"] == result.scan_id
    assert trace["mapping_source_command"]
    assert command["command_name"] == "menu"


def test_v3_migration_marks_backfilled_history_as_not_exact(tmp_path):
    # Tạo DB từ schema v3 tối giản có dữ liệu lịch sử rồi migrate v4.
    db_path = tmp_path / "v3.db"
    conn = sqlite3.connect(db_path)
    conn.executescript(
        """
        PRAGMA user_version=3;
        CREATE TABLE schema_versions(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
        INSERT INTO schema_versions VALUES(3,'2026-01-01T00:00:00+00:00');
        CREATE TABLE oob_devices(id INTEGER PRIMARY KEY, name TEXT, host TEXT, ssh_port INTEGER, vendor TEXT, device_type TEXT,
          default_username TEXT, connection_mode TEXT, enabled INTEGER, notes TEXT, created_at TEXT, updated_at TEXT, last_scan_at TEXT,
          connection_revision INTEGER, baseline_revision INTEGER, baseline_stale_reason TEXT, baseline_stale_at TEXT);
        INSERT INTO oob_devices VALUES(1,'OOB-OLD','192.0.2.10',22,'CISCO','cisco_ios','','SSH',1,'','2026-01-01','2026-01-01',NULL,1,1,'',NULL);
        CREATE TABLE scan_runs(id INTEGER PRIMARY KEY,oob_id INTEGER,started_at TEXT,finished_at TEXT,status TEXT,mapping_count INTEGER,
          complete_count INTEGER,complete_ratio REAL,change_count INTEGER,warning_count INTEGER,error_code TEXT,error_message TEXT,
          scanner_version TEXT,connection_revision INTEGER,mapping_quality TEXT,baseline_updated INTEGER);
        INSERT INTO scan_runs VALUES(1,1,'2026-01-01','2026-01-01','PARTIAL',1,1,1,0,1,'','','1.1.2',1,'ACCEPTED',1);
        CREATE TABLE raw_outputs(id INTEGER PRIMARY KEY,scan_id INTEGER,command_name TEXT,command_text TEXT,raw_output TEXT,success INTEGER,error_message TEXT,created_at TEXT);
        INSERT INTO raw_outputs VALUES(1,1,'menu','show menu','abc',1,'','2026-01-01');
        CREATE TABLE console_targets(id INTEGER PRIMARY KEY,oob_id INTEGER,menu_name TEXT,menu_item INTEGER,alias TEXT,command TEXT,protocol TEXT,
          target_host TEXT,target_port INTEGER,console_line INTEGER,state TEXT,session_user TEXT,state_confident INTEGER,source TEXT,is_complete INTEGER,
          first_seen_at TEXT,last_seen_at TEXT,last_scan_id INTEGER);
        CREATE TABLE console_snapshots(id INTEGER PRIMARY KEY,target_id INTEGER,scan_id INTEGER,oob_id INTEGER,menu_name TEXT,menu_item INTEGER,alias TEXT,
          command TEXT,protocol TEXT,target_host TEXT,target_port INTEGER,console_line INTEGER,state TEXT,session_user TEXT,state_confident INTEGER,source TEXT,
          is_complete INTEGER,captured_at TEXT);
        CREATE TABLE change_events(id INTEGER PRIMARY KEY,oob_id INTEGER,scan_id INTEGER,event_code TEXT,target_identity TEXT,old_data TEXT,new_data TEXT,detected_at TEXT);
        CREATE TABLE connection_history(id INTEGER PRIMARY KEY,oob_id INTEGER,target_id INTEGER,target_alias TEXT,target_host TEXT,target_port INTEGER,
          menu_name TEXT,menu_item INTEGER,username TEXT,started_at TEXT,ended_at TEXT,status TEXT,error_code TEXT,error_message TEXT);
        CREATE TABLE application_settings(key TEXT PRIMARY KEY,value TEXT,updated_at TEXT);
        CREATE TABLE scan_locks(oob_id INTEGER PRIMARY KEY,pid INTEGER,hostname TEXT,started_at TEXT);
        """
    )
    conn.close()
    db = DatabaseConnection(db_path)
    MigrationManager(db).migrate()
    with db.read() as migrated:
        scan = migrated.execute("SELECT * FROM scan_runs WHERE id=1").fetchone()
        finding = migrated.execute("SELECT * FROM scan_findings WHERE scan_id=1").fetchone()
        raw = migrated.execute("SELECT * FROM raw_outputs WHERE id=1").fetchone()
    assert scan["config_snapshot_source"] == "BACKFILLED_CURRENT"
    assert scan["oob_host_at_scan"] == "192.0.2.10"
    assert finding["code"] == "LEGACY_FINDINGS_UNAVAILABLE"
    assert raw["stored_output_length"] == 3
    assert len(raw["stored_output_sha256"]) == 64


class FakeChannel:
    def __init__(self):
        self.sent = []
    def send(self, value):
        self.sent.append(value)


class FakeClient:
    def close(self):
        pass


def test_auto_menu_refuses_blind_selection_when_runtime_items_unparseable(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    channel = FakeChannel()
    class SSH:
        def connect(self, *args, **kwargs): return FakeClient()
        def open_shell(self, client): return channel
        def read_until_quiet(self, channel, timeout=None, quiet=None): return "=== OOB MENU ===\nSelect:"
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    with pytest.raises(InteractiveSessionError) as exc:
        adapter.open_console(OOBDevice(id=1, name="OOB", host="127.0.0.1"), make_target(item=4, port=2004, line=4), SessionCredentials("u", "p"))
    assert exc.value.error_code == "RUNTIME_MENU_UNVERIFIED"
    assert channel.sent == []


def test_console_preflight_detects_explicit_connection_failure(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    channel = FakeChannel()
    outputs = iter(["OOB#", "% Connection timed out; remote host not responding"])
    class SSH:
        def connect(self, *args, **kwargs): return FakeClient()
        def open_shell(self, client): return channel
        def read_until_quiet(self, channel, timeout=None, quiet=None): return next(outputs)
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.TerminalBridge.bridge", lambda *a, **kw: pytest.fail("must not bridge after explicit failure"))
    with pytest.raises(InteractiveSessionError) as exc:
        adapter.open_console(OOBDevice(id=1, name="OOB", host="127.0.0.1"), make_target(), SessionCredentials("u", "p"))
    assert exc.value.error_code == "TARGET_CONNECT_FAILED"


def test_ssh_pager_detection_preserves_partial_raw_output():
    class Channel:
        def __init__(self):
            self.phase = "stale"
            self.sent = []
            self.queue = [b"old prompt#"]
        def recv_ready(self):
            if self.phase == "stale":
                return bool(self.queue)
            return bool(self.queue)
        def recv(self, _):
            return self.queue.pop(0)
        def send(self, value):
            self.sent.append(value)
            self.phase = "command"
            self.queue = [b"show run\r\nline1\r\n--More--"]
    wrapper = SSHClientWrapper(command_timeout=1)
    channel = Channel()
    with pytest.raises(CommandExecutionError) as exc:
        wrapper.run_shell_command(channel, "show run", timeout=1)
    assert exc.value.error_code == "COMMAND_PAGING_DETECTED"
    assert "--More--" in exc.value.raw_output
    assert channel.sent == ["show run\n"]


def test_export_manifest_contains_real_file_hashes_and_scan_findings(tmp_path):
    stack = setup_stack(tmp_path)
    make_scan_service(stack, Adapter([make_target()], supporting_fail=True)).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    settings = ApplicationSettings(export_dir=str(tmp_path / "exports"))
    export_dir = ExportService(stack[0], settings).export_all()
    assert (export_dir / "scan_findings.csv").exists()
    with (export_dir / "export_manifest.csv").open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    by_name = {row["file_name"]: row for row in rows}
    target_file = export_dir / "scan_history.csv"
    expected = hashlib.sha256(target_file.read_bytes()).hexdigest()
    assert by_name["scan_history.csv"]["file_sha256"] == expected
    assert int(by_name["scan_history.csv"]["file_size_bytes"]) == target_file.stat().st_size


def test_auto_menu_blocks_same_item_when_runtime_alias_is_different(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    channel = FakeChannel()
    class SSH:
        def connect(self, *args, **kwargs): return FakeClient()
        def open_shell(self, client): return channel
        def read_until_quiet(self, channel, timeout=None, quiet=None):
            return "=== OOB MENU ===\n4. ----> DIFFERENT-ROUTER\nSelect:"
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    with pytest.raises(InteractiveSessionError) as exc:
        adapter.open_console(
            OOBDevice(id=1, name="OOB", host="127.0.0.1"),
            make_target(alias="R1", item=4, port=2004, line=4),
            SessionCredentials("u", "p"),
        )
    assert exc.value.error_code == "RUNTIME_MENU_ALIAS_MISMATCH"
    assert channel.sent == []


def _write_cisco_profile(path: Path, *, menu_command: str = "show run | i ^menu") -> None:
    path.mkdir(parents=True, exist_ok=True)
    (path / "cisco.json").write_text(
        json.dumps(
            {
                "vendor": "CISCO",
                "menu_commands": [menu_command],
                "optional_commands": {
                    "show_line": "show line",
                    "show_users": "show users",
                },
                "prepare_commands": ["terminal length 0"],
                "reverse_telnet_port_base": 2000,
            }
        ),
        encoding="utf-8",
    )


def test_profile_validator_accepts_shipped_read_only_abbreviation():
    profile = load_profile("CISCO")
    assert "show run | i ^menu" in profile["menu_commands"]


@pytest.mark.parametrize(
    "command",
    [
        "configure terminal",
        "show run | redirect flash:dump.txt",
        "show run ; reload",
        "show run\nreload",
        "show run | tee flash:dump.txt",
    ],
)
def test_profile_validator_blocks_write_or_injection_commands(tmp_path, command):
    profile_dir = tmp_path / "profiles"
    _write_cisco_profile(profile_dir, menu_command=command)
    with pytest.raises(ProfileError):
        load_profile("CISCO", profile_dir)


def test_prompt_capture_requires_last_nonempty_line_to_be_exact_prompt():
    assert extract_prompt("banner\nOOB#\n") == "OOB#"
    assert extract_prompt("OOB#\nlate banner") is None
    assert not _ends_with_prompt("show x\nOUTPUT-LIKE#\nmore", "OOB#")
    assert _ends_with_prompt("show x\nOUTPUT-LIKE#\nOOB#", "OOB#")


def test_menu_navigation_entry_is_not_counted_as_console_target():
    parsed = parse_menu_config(
        "menu OOB text [1] ----> R1\n"
        "menu OOB command 1 telnet 10.0.0.1 2001\n"
        "menu OOB text [9] Exit\n"
        "menu OOB command 9 exit\n"
    )
    assert [target.alias for target in parsed.targets] == ["R1"]
    assert len(parsed.ignored_entries) == 1
    assert "Exit" in parsed.ignored_entries[0]


def test_duplicate_menu_definition_is_explicitly_ambiguous_and_not_baseline_eligible():
    parsed = parse_menu_config(
        "menu OOB text [1] ----> R1\n"
        "menu OOB command 1 telnet 10.0.0.1 2001\n"
        "menu OOB command 1 telnet 10.0.0.1 2002\n"
    )
    assert parsed.duplicate_definitions
    vendor_data = VendorScanData(
        True,
        "NORMAL_CLI",
        parsed.targets,
        [RawCommandOutput("menu", "show run | i ^menu", "menu data", True, is_core=True)],
        parser_errors=[f"Duplicate menu definition: {value}" for value in parsed.duplicate_definitions],
    )
    quality = ScanQualityEvaluator().evaluate([], parsed.targets, vendor_data.raw_outputs, vendor_data)
    assert quality.mapping_accepted is False
    assert quality.mapping_quality == "PARTIAL"


def test_menu_provenance_keeps_exact_raw_line_numbers():
    parsed = parse_menu_config(
        "header\n"
        "menu OOB text [4] ----> R4\n"
        "noise\n"
        "menu OOB command 4 telnet 172.28.200.11 2006 /stream\n"
    )
    target = parsed.targets[0]
    assert target.mapping_text_line_no == 2
    assert target.mapping_command_line_no == 4


def test_scan_actor_and_oob_change_history_are_auditable(tmp_path):
    stack = setup_stack(tmp_path)
    result = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id,
        SessionCredentials("operator01", "secret"),
        trigger_source="TEST_MANUAL",
    )
    device = stack[1].get(stack[6].id)
    device.notes = "changed for audit"
    stack[1].update(device)
    with stack[0].read() as conn:
        scan = conn.execute("SELECT * FROM scan_runs WHERE id=?", (result.scan_id,)).fetchone()
        changes = conn.execute(
            "SELECT * FROM oob_change_history WHERE oob_id=? ORDER BY id", (stack[6].id,)
        ).fetchall()
    assert scan["ssh_username_at_scan"] == "operator01"
    assert scan["trigger_source"] == "TEST_MANUAL"
    assert scan["process_hostname"] == socket.gethostname()
    assert scan["process_user"]
    assert any(row["change_type"] == "OOB_CREATED" for row in changes)
    update = next(row for row in changes if row["change_type"] == "OOB_SETTINGS_CHANGED")
    assert "notes" in update["changed_fields"]
    assert json.loads(update["old_data"])["notes"] == ""
    assert json.loads(update["new_data"])["notes"] == "changed for audit"


def test_abandoned_scan_and_lock_are_recovered_on_same_host(tmp_path, monkeypatch):
    stack = setup_stack(tmp_path)
    with stack[0].transaction() as conn:
        conn.execute(
            """
            INSERT INTO scan_runs(
                oob_id, started_at, status, scanner_version, process_pid,
                process_hostname, process_user
            ) VALUES(?, '2026-01-01T00:00:00+00:00', 'RUNNING', '1.1.3', 999999, ?, 'tester')
            """,
            (stack[6].id, socket.gethostname()),
        )
        conn.execute(
            "INSERT INTO scan_locks(oob_id,pid,hostname,started_at) VALUES(?,?,?,'2026-01-01T00:00:00+00:00')",
            (stack[6].id, 999999, socket.gethostname()),
        )
    monkeypatch.setattr(ScanRepository, "_pid_alive", staticmethod(lambda pid: False))
    monkeypatch.setattr(ScanLockRepository, "_pid_alive", staticmethod(lambda pid: False))
    assert stack[3].recover_abandoned_same_host() == 1
    assert stack[5].recover_stale_same_host() == 1
    with stack[0].read() as conn:
        scan = conn.execute("SELECT * FROM scan_runs ORDER BY id DESC LIMIT 1").fetchone()
        lock_count = conn.execute("SELECT COUNT(*) FROM scan_locks").fetchone()[0]
    assert scan["status"] == "FAILED"
    assert scan["mapping_quality"] == "REJECTED"
    assert scan["error_code"] == "PROCESS_TERMINATED"
    assert scan["finished_at"]
    assert lock_count == 0


def test_connection_audit_explicitly_does_not_claim_downstream_identity(tmp_path):
    stack = setup_stack(tmp_path)
    scan = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    target = stack[2].list_current(stack[6].id)[0]
    connection_id = ConnectionRepository(stack[0]).start(
        stack[6].id, target, "operator", device=stack[1].get(stack[6].id)
    )
    ConnectionRepository(stack[0]).finish(
        connection_id,
        "SUCCESS",
        console_path_verified=True,
        path_verification_code="CONSOLE_PATH_RUNTIME_EVIDENCE",
    )
    with stack[0].read() as conn:
        row = conn.execute("SELECT * FROM connection_history WHERE id=?", (connection_id,)).fetchone()
    assert row["mapping_last_scan_id"] == scan.scan_id
    assert row["console_path_verified"] == 1
    assert row["downstream_identity_verified"] == 0
    assert row["downstream_identity_method"] == "NOT_VERIFIED"


def test_data_quality_view_detects_semantic_corruption(tmp_path):
    stack = setup_stack(tmp_path)
    result = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with stack[0].transaction() as conn:
        conn.execute(
            "UPDATE scan_runs SET complete_count=0 WHERE id=?",
            (result.scan_id,),
        )
    with stack[0].read() as conn:
        issues = {
            row["issue_code"]
            for row in conn.execute("SELECT * FROM v_data_quality_issues").fetchall()
        }
    assert "ACCEPTED_SCAN_HAS_INCOMPLETE_TARGETS" in issues


def test_quality_ignores_failed_core_fallback_when_later_menu_command_succeeds():
    target = make_target()
    raw = [
        RawCommandOutput(
            "menu", "show running-config | include ^menu",
            "% Invalid input detected at '^' marker.", False,
            "CLI error", is_core=True,
        ),
        RawCommandOutput(
            "menu", "show run | i ^menu",
            "menu OOB text [1] ----> R1\nmenu OOB command 1 telnet 10.0.0.1 2001",
            True, is_core=True,
        ),
    ]
    vendor = VendorScanData(True, "NORMAL_CLI", [target], raw)
    quality = ScanQualityEvaluator().evaluate([], [target], raw, vendor)
    assert quality.mapping_accepted is True
    assert quality.mapping_quality == "ACCEPTED"


def test_cisco_collect_wires_real_parser_and_state_resolver_with_fallback(monkeypatch):
    profile = {
        "vendor": "CISCO",
        "prepare_commands": ["terminal length 0"],
        "menu_commands": [
            "show running-config | include ^menu",
            "show run | i ^menu",
        ],
        "optional_commands": {
            "show_line": "show line",
            "show_users": "show users",
            "show_version": "show version",
            "ip_host": "show running-config | include ^ip host",
        },
        "reverse_telnet_port_base": 2000,
    }
    adapter = CiscoOOBAdapter(ApplicationSettings(), profile)
    channel = FakeChannel()

    class SSH:
        expected_prompt = None
        def connect(self, *args, **kwargs): return FakeClient()
        def open_shell(self, client): return channel
        def read_until_quiet(self, channel, timeout=None, quiet=None): return "OOB#\n"
        def run_shell_command(self, channel, command, timeout=None):
            outputs = {
                "terminal length 0": "terminal length 0\nOOB#",
                "show running-config | include ^menu": "% Invalid input detected at '^' marker.\nOOB#",
                "show run | i ^menu": (
                    "menu OOB text [1] ----> R1\n"
                    "menu OOB command 1 telnet 172.28.200.11 2001 /stream\nOOB#"
                ),
                "show line": "* 0/0/0 1 TTY - - - - - 0 0 0/0\nOOB#",
                "show users": "Line User Host(s) Idle Location\ntty 0/0/0 operator01 00:01:00 10.20.30.40\nOOB#",
                "show version": "Cisco IOS Software\nOOB#",
                "show running-config | include ^ip host": "OOB#",
            }
            return outputs[command]
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    data = adapter.collect(
        OOBDevice(id=7, name="OOB", host="127.0.0.1"),
        SessionCredentials("u", "p"),
    )
    assert len(data.targets) == 1
    target = data.targets[0]
    assert target.alias == "R1"
    assert target.target_host == "172.28.200.11"
    assert target.target_port == 2001
    assert target.console_line == 1
    assert target.state == "BUSY"
    assert target.session_user == "operator01"
    assert target.command.endswith("/stream")
    assert target.mapping_source_command == "show run | i ^menu"
    assert any("Core menu fallback" in warning for warning in data.warnings)
    quality = ScanQualityEvaluator().evaluate([], data.targets, data.raw_outputs, data)
    assert quality.mapping_accepted is True


def test_cisco_cli_error_detector_rejects_unknown_command(monkeypatch):
    adapter = CiscoOOBAdapter(
        ApplicationSettings(),
        {
            "vendor": "CISCO",
            "prepare_commands": [],
            "menu_commands": ["show run | i ^menu"],
            "optional_commands": {"show_users": "show users"},
            "reverse_telnet_port_base": 2000,
        },
    )
    channel = FakeChannel()
    class SSH:
        expected_prompt = None
        def connect(self, *args, **kwargs): return FakeClient()
        def open_shell(self, client): return channel
        def read_until_quiet(self, channel, timeout=None, quiet=None): return "OOB#\n"
        def run_shell_command(self, channel, command, timeout=None):
            if command.startswith("show run"):
                return "menu OOB text [1] ----> R1\nmenu OOB command 1 telnet 10.0.0.1 2001\nOOB#"
            return "% Unknown command\nOOB#"
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    data = adapter.collect(OOBDevice(id=1, name="OOB", host="127.0.0.1"), SessionCredentials("u", "p"))
    assert data.metadata["show_users_success"] is False
    assert data.targets[0].state == "UNKNOWN"
    quality = ScanQualityEvaluator().evaluate([], data.targets, data.raw_outputs, data)
    assert quality.status == "PARTIAL"
    assert quality.mapping_accepted is True


def test_login_mode_uses_final_prompt_not_prompt_like_banner_line():
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    value = "Welcome\nOOB>\n1. Router-A\n2. Router-B\nSelect:"
    assert adapter.detect_login_mode(value) == "AUTO_MENU"
    assert adapter.detect_login_mode("Welcome\nOOB#\n") == "NORMAL_CLI"


def test_scan_persists_ssh_host_key_identity(tmp_path):
    stack = setup_stack(tmp_path)
    adapter = Adapter([make_target()])
    class SSHAudit:
        last_host_key_algorithm = "ssh-ed25519"
        last_host_key_fingerprint = "SHA256:exampleFingerprint"
        host_key_policy = "TOFU_PERSISTENT"
    adapter.ssh = SSHAudit()
    result = make_scan_service(stack, adapter).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with stack[0].read() as conn:
        row = conn.execute("SELECT * FROM scan_runs WHERE id=?", (result.scan_id,)).fetchone()
    assert row["ssh_host_key_algorithm"] == "ssh-ed25519"
    assert row["ssh_host_key_fingerprint"] == "SHA256:exampleFingerprint"
    assert row["ssh_host_key_policy"] == "TOFU_PERSISTENT"


def test_ssh_wrapper_persistent_tofu_records_sha256_fingerprint(tmp_path, monkeypatch):
    import sys
    import types

    class SSHException(Exception): pass
    class AuthenticationException(SSHException): pass
    class BadHostKeyException(SSHException): pass
    class AutoAddPolicy: pass
    class Key:
        def asbytes(self): return b"host-key-bytes"
        def get_name(self): return "ssh-ed25519"
    class Transport:
        def get_remote_server_key(self): return Key()
    class Client:
        def __init__(self): self.loaded = []; self.policy = None; self.closed = False
        def load_system_host_keys(self): self.loaded.append("system")
        def load_host_keys(self, path): self.loaded.append(path)
        def set_missing_host_key_policy(self, policy): self.policy = policy
        def connect(self, **kwargs): self.kwargs = kwargs
        def get_transport(self): return Transport()
        def close(self): self.closed = True
    holder = {}
    def factory():
        holder["client"] = Client()
        return holder["client"]
    fake = types.SimpleNamespace(
        SSHClient=factory,
        AutoAddPolicy=AutoAddPolicy,
        SSHException=SSHException,
        AuthenticationException=AuthenticationException,
        BadHostKeyException=BadHostKeyException,
    )
    monkeypatch.setitem(sys.modules, "paramiko", fake)
    known_hosts = tmp_path / "known_hosts"
    wrapper = SSHClientWrapper(known_hosts_path=known_hosts)
    client = wrapper.connect("192.0.2.1", 22, "u", "p")
    assert client is holder["client"]
    assert known_hosts.exists()
    assert str(known_hosts) in holder["client"].loaded
    assert isinstance(holder["client"].policy, AutoAddPolicy)
    assert wrapper.host_key_policy == "TOFU_PERSISTENT"
    assert wrapper.last_host_key_algorithm == "ssh-ed25519"
    assert wrapper.last_host_key_fingerprint.startswith("SHA256:")


def test_ssh_wrapper_blocks_changed_host_key(tmp_path, monkeypatch):
    import sys
    import types
    from oob_manager.exceptions import SSHNegotiationError

    class SSHException(Exception): pass
    class AuthenticationException(SSHException): pass
    class BadHostKeyException(SSHException): pass
    class AutoAddPolicy: pass
    class Client:
        def load_system_host_keys(self): pass
        def load_host_keys(self, path): pass
        def set_missing_host_key_policy(self, policy): pass
        def connect(self, **kwargs): raise BadHostKeyException("changed")
        def close(self): pass
    fake = types.SimpleNamespace(
        SSHClient=Client,
        AutoAddPolicy=AutoAddPolicy,
        SSHException=SSHException,
        AuthenticationException=AuthenticationException,
        BadHostKeyException=BadHostKeyException,
    )
    monkeypatch.setitem(sys.modules, "paramiko", fake)
    wrapper = SSHClientWrapper(known_hosts_path=tmp_path / "known_hosts")
    with pytest.raises(SSHNegotiationError) as exc:
        wrapper.connect("192.0.2.1", 22, "u", "p")
    assert exc.value.error_code == "SSH_HOST_KEY_MISMATCH"


def test_windows_extended_keys_are_translated_to_vt100_not_raw_scan_codes():
    from oob_manager.networking.terminal_bridge import TerminalBridge
    assert TerminalBridge._windows_extended_sequence("H") == b"\x1b[A"
    assert TerminalBridge._windows_extended_sequence("P") == b"\x1b[B"
    assert TerminalBridge._windows_extended_sequence("K") == b"\x1b[D"
    assert TerminalBridge._windows_extended_sequence("M") == b"\x1b[C"
    assert TerminalBridge._windows_extended_sequence("?") == b""


def test_classic_show_users_matches_absolute_line_not_relative_tty_number():
    """Relative ``tty N`` must never be compared to show-line absolute ``Line``."""
    target_line3 = make_target(alias="R3", item=3, port=2003, line=3)
    target_line4 = make_target(alias="R4", item=4, port=2004, line=4)
    lines = parse_show_line(
        "0/0/0 3 TTY 9600/9600 - - - - - 0 0 0/0\n"
        "* 0/0/1 4 TTY 9600/9600 - - - - - 1 0 0/0"
    )
    # Absolute line=4, relative tty=3. A buggy resolver that compares tty index
    # to target line would mark R3 BUSY even though the session belongs to line 4.
    users = parse_show_users(
        "Line User Host(s) Idle Location\n"
        "4 tty 3 operator04 idle 00:00:10 10.20.30.40"
    )
    assert users.session_confident
    resolve_console_states(
        [target_line3, target_line4],
        lines,
        users,
        show_line_success=True,
        show_users_success=True,
    )
    assert target_line3.state == "AVAILABLE"
    assert target_line3.session_user == ""
    assert target_line4.state == "BUSY"
    assert target_line4.session_user == "operator04"


def test_scan_snapshots_exact_profile_and_policy_for_reproducibility(tmp_path):
    stack = setup_stack(tmp_path)
    target = make_target()
    target.mapping_text_line_no = 1
    target.mapping_command_line_no = 2
    result = make_scan_service(stack, Adapter([target])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with stack[0].read() as conn:
        row = conn.execute("SELECT * FROM scan_runs WHERE id=?", (result.scan_id,)).fetchone()
    profile = json.loads(row["profile_snapshot_json"])
    policy = json.loads(row["scan_policy_snapshot_json"])
    assert profile["vendor"] == "CISCO"
    assert profile["menu_commands"]
    assert policy == {
        "auth_timeout": 15,
        "banner_timeout": 20,
        "baseline_policy": "ALL_CORE_TARGETS_COMPLETE",
        "command_timeout": 20,
        "connect_timeout": 10,
        "connection_attempts": 2,
        "maximum_drop_ratio": 0.5,
        "minimum_complete_ratio": 1.0,
        "operation_lock_heartbeat_seconds": 15,
        "operation_lock_lease_seconds": 180,
        "retry_delay": 1.0,
        "shell_timeout": 15,
    }
    from oob_manager.config import profile_fingerprint
    assert row["profile_fingerprint"] == profile_fingerprint(profile)


def test_trace_views_link_target_and_snapshot_to_exact_raw_menu_source(tmp_path):
    stack = setup_stack(tmp_path)
    target = make_target()
    target.mapping_text_line_no = 1
    target.mapping_command_line_no = 2
    result = make_scan_service(stack, Adapter([target])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with stack[0].read() as conn:
        current = conn.execute("SELECT * FROM v_current_target_source_trace").fetchone()
        snapshot = conn.execute(
            "SELECT * FROM v_snapshot_source_trace WHERE scan_id=?", (result.scan_id,)
        ).fetchone()
    assert current["source_raw_output_id"] is not None
    assert current["source_command_text"] == target.mapping_source_command
    assert current["mapping_text_line_no"] == 1
    assert current["mapping_command_line_no"] == 2
    assert json.loads(current["profile_snapshot_json"])["vendor"] == "CISCO"
    assert snapshot["source_raw_output_id"] is not None
    assert json.loads(snapshot["profile_snapshot_json"])["vendor"] == "CISCO"
    assert "minimum_complete_ratio" in json.loads(snapshot["scan_policy_snapshot_json"])


def test_export_contains_trace_files_and_reproducibility_metadata(tmp_path):
    stack = setup_stack(tmp_path)
    target = make_target()
    target.mapping_text_line_no = 1
    target.mapping_command_line_no = 2
    make_scan_service(stack, Adapter([target])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    export_dir = ExportService(
        stack[0], ApplicationSettings(export_dir=str(tmp_path / "exports"))
    ).export_all()
    for filename in (
        "current_target_trace.csv",
        "snapshot_trace.csv",
        "scan_command_audit.csv",
        "data_quality_issues.csv",
    ):
        assert (export_dir / filename).exists()

    with (export_dir / "scan_history.csv").open(encoding="utf-8-sig", newline="") as handle:
        scan_row = next(csv.DictReader(handle))
    assert json.loads(scan_row["profile_snapshot_json"])["vendor"] == "CISCO"
    assert "minimum_complete_ratio" in json.loads(scan_row["scan_policy_snapshot_json"])

    with (export_dir / "current_target_trace.csv").open(encoding="utf-8-sig", newline="") as handle:
        trace_row = next(csv.DictReader(handle))
    assert trace_row["source_raw_output_id"]
    assert trace_row["source_raw_sha256"]

    with (export_dir / "data_quality_issues.csv").open(encoding="utf-8-sig", newline="") as handle:
        issues = list(csv.DictReader(handle))
    assert not [row for row in issues if row["severity"] == "ERROR"]


def test_data_audit_detects_raw_and_exact_source_line_corruption(tmp_path):
    from oob_manager.services.database_audit_service import DatabaseAuditService

    stack = setup_stack(tmp_path)
    target = make_target()
    target.mapping_text_line_no = 1
    target.mapping_command_line_no = 2
    result = make_scan_service(stack, Adapter([target])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    # Corrupt source text but recompute hash/length to prove provenance checking is
    # stronger than a plain integrity hash stored next to the same row.
    tampered = "menu OOB text [1] DIFFERENT\nmenu OOB command 1 telnet 10.0.0.1 2001"
    with stack[0].transaction() as conn:
        conn.execute(
            """
            UPDATE raw_outputs
            SET raw_output=?, stored_output_length=?, stored_output_sha256=?
            WHERE scan_id=? AND command_name='menu'
            """,
            (
                tampered,
                len(tampered),
                hashlib.sha256(tampered.encode()).hexdigest(),
                result.scan_id,
            ),
        )
    with stack[0].read() as conn:
        codes = {row["issue_code"] for row in DatabaseAuditService.collect_issues(conn)}
    assert "CURRENT_TEXT_SOURCE_LINE_MISMATCH" in codes
    assert "SNAPSHOT_TEXT_SOURCE_LINE_MISMATCH" in codes
    assert "RAW_OUTPUT_INTEGRITY_MISMATCH" not in codes


def test_schema_v7_triggers_reject_invalid_semantic_states(tmp_path):
    stack = setup_stack(tmp_path)
    with stack[0].read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16
        triggers = {
            row["name"]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='trigger'"
            ).fetchall()
        }
    assert "trg_scan_runs_validate_update" in triggers
    assert "trg_console_targets_validate_insert" in triggers

    result = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    with pytest.raises(sqlite3.IntegrityError):
        with stack[0].transaction() as conn:
            conn.execute(
                "UPDATE scan_runs SET baseline_updated=1,mapping_quality='REJECTED' WHERE id=?",
                (result.scan_id,),
            )
    current = stack[2].list_current(stack[6].id)[0]
    with pytest.raises(sqlite3.IntegrityError):
        with stack[0].transaction() as conn:
            conn.execute(
                "UPDATE console_targets SET state='MAGIC' WHERE id=?",
                (current.id,),
            )


def test_host_normalization_is_canonical_for_oob_and_console_targets(tmp_path):
    from oob_manager.utils.validation import validate_host
    from oob_manager.vendors.cisco.parsers import validated_telnet_command

    assert validate_host("Router.EXAMPLE.COM.") == "router.example.com"
    assert validate_host("[2001:0db8::1]") == "2001:db8::1"

    db = DatabaseConnection(tmp_path / "canonical.db")
    MigrationManager(db).migrate()
    repo = OOBRepository(db)
    device = OOBService(repo).create(
        OOBDevice(name="OOB-Canonical", host="OOB.EXAMPLE.COM.")
    )
    assert device.host == "oob.example.com"
    assert repo.get(device.id).host == "oob.example.com"

    parsed = parse_menu_config(
        "menu OOB text [1] R1\n"
        "menu OOB command 1 telnet ROUTER.EXAMPLE.COM. 2001 /stream"
    )
    target = parsed.targets[0]
    assert target.target_host == "router.example.com"
    assert validated_telnet_command(target) == "telnet router.example.com 2001 /stream"


def test_autocommand_menu_ending_with_greater_than_is_not_misclassified_as_cli():
    settings = ApplicationSettings()
    adapter = CiscoOOBAdapter(settings, load_profile("CISCO"))
    output = "[1] Router-A\n[2] Router-B\nEnter selection >"
    assert extract_prompt(output) is None
    assert adapter.detect_login_mode(output) == "AUTO_MENU"


def test_scan_service_fails_closed_on_unconfident_definite_vendor_state(tmp_path):
    stack = setup_stack(tmp_path)
    target = make_target()
    target.state = "AVAILABLE"
    target.state_confident = False
    result = make_scan_service(stack, Adapter([target])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    assert result.status == "SUCCESS"
    current = stack[2].list_current(stack[6].id)[0]
    assert current.state == "UNKNOWN"
    assert not current.state_confident
    assert current.state_reason_code == "UNCONFIDENT_VENDOR_STATE_NORMALIZED"
    with stack[0].read() as conn:
        findings = [
            row["message"]
            for row in conn.execute(
                "SELECT message FROM scan_findings WHERE scan_id=?", (result.scan_id,)
            )
        ]
    assert any("hạ về UNKNOWN" in message for message in findings)


def test_database_audit_detects_duplicate_canonical_oob_endpoints(tmp_path):
    from oob_manager.services.database_audit_service import DatabaseAuditService

    db = DatabaseConnection(tmp_path / "duplicates.db")
    MigrationManager(db).migrate()
    repo = OOBRepository(db)
    # Bypass OOBService intentionally to simulate legacy/non-normalized data.
    repo.create(OOBDevice(name="OOB-1", host="Example.COM.", ssh_port=22))
    repo.create(OOBDevice(name="OOB-2", host="example.com", ssh_port=22))
    with db.read() as conn:
        issues = DatabaseAuditService.collect_issues(conn)
    codes = [item["issue_code"] for item in issues]
    assert "NON_CANONICAL_OOB_HOST" in codes
    assert codes.count("DUPLICATE_CANONICAL_OOB_ENDPOINT") == 2


def test_console_transport_host_key_is_persisted_before_interactive_returns(tmp_path):
    from oob_manager.models import ConsoleOpenResult
    from oob_manager.services.console_service import ConsoleService

    stack = setup_stack(tmp_path)
    scan_result = make_scan_service(stack, Adapter([make_target()])).scan_one(
        stack[6].id, SessionCredentials("u", "p")
    )
    assert scan_result.baseline_updated
    connection_repo = ConnectionRepository(stack[0])

    class AuditAwareAdapter:
        profile = load_profile("CISCO")

        def open_console(self, device, target, credentials):
            self.transport_audit_callback(
                "ssh-ed25519", "SHA256:EARLY-AUDIT", "TOFU_PERSISTENT"
            )
            # Evidence must already be committed while connection is RUNNING.
            with stack[0].read() as conn:
                row = conn.execute(
                    "SELECT * FROM connection_history ORDER BY id DESC LIMIT 1"
                ).fetchone()
            assert row["status"] == "RUNNING"
            assert row["ssh_host_key_fingerprint"] == "SHA256:EARLY-AUDIT"
            return ConsoleOpenResult(
                console_path_verified=True,
                path_verification_code="TEST_PATH",
                path_verification_message="test",
            )

    service = ConsoleService(
        stack[1], stack[2], connection_repo, ApplicationSettings(),
        adapter_factory=lambda device, settings: AuditAwareAdapter(),
    )
    service.open(stack[2].list_current(stack[6].id)[0].id, SessionCredentials("u", "p"))
    with stack[0].read() as conn:
        row = conn.execute("SELECT * FROM connection_history ORDER BY id DESC LIMIT 1").fetchone()
        trace = conn.execute("SELECT * FROM v_connection_trace WHERE connection_id=?", (row["id"],)).fetchone()
    assert row["status"] == "SUCCESS"
    assert row["ssh_host_key_fingerprint"] == "SHA256:EARLY-AUDIT"
    assert trace["trace_status"] == "TRACE_OK"
    assert trace["mapping_last_scan_id"] == scan_result.scan_id


def test_export_includes_connection_trace_csv(tmp_path):
    stack = setup_stack(tmp_path)
    export_dir = ExportService(
        stack[0], ApplicationSettings(export_dir=str(tmp_path / "exports"))
    ).export_all()
    path = export_dir / "connection_trace.csv"
    assert path.exists()
    with path.open(encoding="utf-8-sig", newline="") as handle:
        headers = next(csv.reader(handle))
    assert "connection_id" in headers
    assert "trace_status" in headers


def test_backup_writes_sha256_sidecar(tmp_path):
    from oob_manager.services.backup_service import BackupService

    db = DatabaseConnection(tmp_path / "source.db")
    MigrationManager(db).migrate()
    backup = BackupService(db, backup_dir=tmp_path / "backups").create_backup()
    checksum = backup.with_suffix(backup.suffix + ".sha256")
    assert checksum.exists()
    expected = hashlib.sha256(backup.read_bytes()).hexdigest()
    assert checksum.read_text(encoding="ascii").strip() == f"{expected}  {backup.name}"


def test_canonical_only_host_edit_does_not_invalidate_baseline(tmp_path):
    db = DatabaseConnection(tmp_path / "legacy-host.db")
    MigrationManager(db).migrate()
    repo = OOBRepository(db)
    # Simulate a pre-normalization row.
    device = repo.create(OOBDevice(name="OOB-Legacy", host="Example.COM."))
    before_revision = device.connection_revision
    # OOBService canonicalizes the same semantic DNS endpoint.
    device.host = "example.com"
    updated = OOBService(repo).update(device)
    assert updated.host == "example.com"
    assert updated.connection_revision == before_revision
    assert not updated.mapping_stale
