from __future__ import annotations

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.downstream.collector import DownstreamIdentityCollector
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    DeviceIdentity,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    OOBDevice,
    SessionCredentials,
)
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.cisco.parsers import parse_menu_config, parse_show_line, parse_show_users
from oob_manager.vendors.cisco.state_resolver import resolve_console_states


BANNER = "\r\nHCM-AggSW-MNGT-FNX02L03H1-01 (ttyd0)\r\n\r\nlogin: "


class _Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value: str):
        self.sent.append(value)
        return len(value)


class _ProbeSSH:
    def __init__(self, after_enter: str):
        self.after_enter = after_enter

    def read_until_state(self, _channel, detector, timeout=None, settle=0.2, initial=""):
        text = initial + self.after_enter
        return text, detector(text)

    def read_until_quiet(self, _channel, timeout=None, quiet=None):
        return self.after_enter

    def drain_channel(self, _channel):
        return ""


def test_prelogin_tty_banner_is_device_b_without_sending_credentials():
    channel = _Channel()
    collector = DownstreamIdentityCollector(_ProbeSSH(""), command_timeout=1)

    result = collector.collect(
        channel,
        BANNER,
        DownstreamCredentials("root", "must-not-be-sent"),
        "HCM-AggSW-MNGT-FNX02L03H1-01",
        prefer_banner_hostname=True,
    )

    assert result.identity.actual_hostname == "HCM-AggSW-MNGT-FNX02L03H1-01"
    assert result.identity.quality == "PARTIAL"
    assert result.login_method == "BANNER_ONLY"
    assert result.metadata["cable_identity_source"] == "CONSOLE_BANNER_TTY"
    assert channel.sent == []
    assert "must-not-be-sent" not in result.raw_outputs[0].raw_output


def test_banner_probe_after_telnet_open_sends_only_wakeup_enter_not_credentials():
    channel = _Channel()
    collector = DownstreamIdentityCollector(_ProbeSSH(BANNER), command_timeout=1)

    result = collector.collect(
        channel,
        "Trying 172.28.200.11, 2008 ... Open\r\n",
        DownstreamCredentials("root", "must-not-be-sent"),
        "HCM-AggSW-MNGT-FNX02L03H1-01",
        prefer_banner_hostname=True,
    )

    assert result.identity.actual_hostname == "HCM-AggSW-MNGT-FNX02L03H1-01"
    assert channel.sent == ["\n"]
    assert "root\n" not in channel.sent
    assert "must-not-be-sent\n" not in channel.sent


def test_full_identity_mode_does_not_shortcut_on_banner():
    channel = _Channel()
    collector = DownstreamIdentityCollector(_ProbeSSH(""), command_timeout=1)

    with pytest.raises(InteractiveSessionError) as caught:
        collector.collect(
            channel,
            BANNER,
            DownstreamCredentials(),
            "HCM-AggSW-MNGT-FNX02L03H1-01",
            prefer_banner_hostname=False,
        )
    assert caught.value.error_code == "DOWNSTREAM_USERNAME_REQUIRED"


def test_oob_vty_sessions_do_not_make_reverse_telnet_tty_busy():
    menu = (
        "menu OOB text [8] ----> HCM-AggSW-MNGT-FNX02L03H1-01\n"
        "menu OOB command 8 telnet 172.28.200.11 2008"
    )
    target = parse_menu_config(menu).targets[0]
    target.console_line = 8
    target.console_line_source = "REVERSE_TELNET_PORT_CONFIRMED"

    line = parse_show_line(
        "Tty Line Typ Tx/Rx A Modem Roty AccO AccI Uses Noise Overruns Int\n"
        "0/0/0 8 TTY 9600/9600 - - - - - 0 0 0/0 -\n"
    )
    users = parse_show_users(
        "Line User Host(s) Idle Location\n"
        "132 vty 0 admin idle 14w4d 210.245.31.140\n"
        "133 vty 1 admin idle 12w5d 210.245.0.140\n"
        "*139 vty 0/0/4 oobbackup idle 00:00:00 210.245.31.140\n"
        "Interface User Mode Idle Peer Address\n"
    )

    resolve_console_states(
        [target],
        line,
        users,
        show_line_success=True,
        show_users_success=True,
    )
    assert target.state == "AVAILABLE"
    assert target.state_confident is True
    assert target.session_user == ""


PROFILE = {
    "vendor": "CISCO",
    "menu_commands": ["show run | i ^menu"],
    "prepare_commands": ["terminal length 0", "terminal width 512"],
    "optional_commands": {"show_line": "show line", "show_users": "show users"},
    "reverse_telnet_port_base": 2000,
}
MENU = (
    "menu OOB text [8] ----> HCM-AggSW-MNGT-FNX02L03H1-01\n"
    "menu OOB command 8 telnet 172.28.200.11 2008"
)


class _RefusedSSH:
    def __init__(self):
        self.channel = _Channel()
        self.expected_prompt = None
        self.host_key_policy = "TOFU_PERSISTENT"
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:TEST"
        self.reads = iter([
            "HCM-OOB-FNX02L03H1-01#",
            "% Connection refused by remote host\nHCM-OOB-FNX02L03H1-01#",
            "[confirm]",
            "[OK]\nHCM-OOB-FNX02L03H1-01#",
            "Trying 172.28.200.11, 2008 ... Open\n",
        ])

    class Client:
        def close(self):
            pass

    def connect(self, *args, **kwargs):
        return self.Client()

    def open_shell(self, _client):
        return self.channel

    def read_until_quiet(self, _channel, timeout=None, quiet=None):
        return next(self.reads)

    def drain_channel(self, _channel):
        return ""

    def run_shell_command(self, _channel, command, timeout=None):
        if command.startswith("terminal "):
            return f"{command}\nHCM-OOB-FNX02L03H1-01#"
        if command == "show run | i ^menu":
            return MENU + "\nHCM-OOB-FNX02L03H1-01#"
        if command == "show line":
            return (
                "Tty Line Typ Tx/Rx A Modem Roty AccO AccI Uses Noise Overruns Int\n"
                "0/0/0 8 TTY 9600/9600 - - - - - 0 0 0/0 -\n"
                "HCM-OOB-FNX02L03H1-01#"
            )
        if command == "show users":
            return (
                "Line User Host(s) Idle Location\n"
                "132 vty 0 admin idle 14w4d 210.245.31.140\n"
                "*139 vty 0/0/4 oobbackup idle 00:00:00 210.245.31.140\n"
                "HCM-OOB-FNX02L03H1-01#"
            )
        raise AssertionError(command)


def test_identity_discovery_connection_refused_clear_line_then_retry(monkeypatch):
    target = parse_menu_config(MENU).targets[0]
    target.mapping_source_command = "show run | i ^menu"
    adapter = CiscoOOBAdapter(ApplicationSettings(command_timeout=1, retry_delay=0), PROFILE)
    fake = _RefusedSSH()
    adapter.ssh = fake
    adapter.clear_line_recovery_callback = lambda context: (True, "stale line after verified AVAILABLE")
    adapter.prefer_banner_hostname = True

    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(
        "oob_manager.vendors.cisco.adapter.DownstreamIdentityCollector.collect",
        lambda self, channel, initial, credentials, alias, **kwargs: DownstreamDiscoveryResult(
            identity=DeviceIdentity(
                actual_hostname="HCM-AggSW-MNGT-FNX02L03H1-01",
                vendor="UNKNOWN",
                quality="PARTIAL",
                confidence="MEDIUM",
                source_evidence={"actual_hostname": "console_banner_tty"},
            ),
            login_method="BANNER_ONLY",
            metadata={"cable_identity_source": "CONSOLE_BANNER_TTY"},
        ),
    )

    result = adapter.discover_downstream_identity(
        OOBDevice(id=1, name="HCM-OOB-FNX02L03H1-01", host="127.0.0.1"),
        target,
        SessionCredentials("admin", "secret"),
        DownstreamCredentials(),
    )

    assert result.metadata["clear_line_recovery_used"] is True
    assert result.metadata["clear_line_number"] == 8
    assert result.metadata["clear_line_result"] == "CLEAR_SUCCEEDED_TELNET_RETRY"
    assert fake.channel.sent == [
        "telnet 172.28.200.11 2008\n",
        "clear line 8\n",
        "\n",
        "telnet 172.28.200.11 2008\n",
    ]
