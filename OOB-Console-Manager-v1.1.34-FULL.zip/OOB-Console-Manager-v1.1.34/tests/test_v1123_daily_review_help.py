from __future__ import annotations

from datetime import date
from pathlib import Path

from oob_manager.cli.application import CLIApplication
from oob_manager.cli.help_text import get_help_text
from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.services.export_service import ExportService


def _seed_daily_data(db: DatabaseConnection) -> None:
    with db.transaction() as conn:
        conn.execute(
            """
            INSERT INTO oob_devices(
                id,name,host,ssh_port,vendor,device_type,default_username,connection_mode,
                enabled,notes,created_at,updated_at,connection_revision,baseline_revision
            ) VALUES(1,'CTO-OOB-02','192.0.2.10',22,'CISCO','cisco_ios','','SSH',1,'',
                     '2026-07-27T00:00:00+00:00','2026-07-27T00:00:00+00:00',1,1)
            """
        )
        conn.execute(
            """
            INSERT INTO scan_runs(
                id,oob_id,started_at,finished_at,status,mapping_count,complete_count,
                complete_ratio,change_count,warning_count,scanner_version,connection_revision,
                mapping_quality,baseline_updated,oob_name_at_scan,oob_host_at_scan,
                oob_ssh_port_at_scan,vendor_at_scan,connection_mode_at_scan,device_type_at_scan
            ) VALUES(10,1,'2026-07-27T06:00:00+00:00','2026-07-27T06:00:05+00:00',
                     'SUCCESS',1,1,1.0,0,0,'1.1.23',1,'ACCEPTED',1,
                     'CTO-OOB-02','192.0.2.10',22,'CISCO','SSH','cisco_ios')
            """
        )
        conn.execute(
            """
            INSERT INTO console_targets(
                id,oob_id,menu_name,menu_item,alias,command,protocol,target_host,target_port,
                console_line,console_line_source,state,state_confident,state_reason_code,
                state_evidence,source,is_complete,first_seen_at,last_seen_at,last_scan_id
            ) VALUES(100,1,'OOB-CTO-02',8,'CTO-BRAS-CTR-02-08',
                     'telnet 172.29.10.36 2010','TELNET','172.29.10.36',2010,10,
                     'REVERSE_TELNET_PORT_CONFIRMED','AVAILABLE',1,'LINE_AVAILABLE','{}',
                     'CISCO_MENU',1,'2026-07-27T06:00:05+00:00','2026-07-27T06:00:05+00:00',10)
            """
        )
        conn.execute(
            """
            INSERT INTO console_snapshots(
                target_id,scan_id,oob_id,menu_name,menu_item,alias,command,protocol,
                target_host,target_port,console_line,console_line_source,state,state_confident,
                state_reason_code,state_evidence,source,is_complete,captured_at
            ) VALUES(100,10,1,'OOB-CTO-02',8,'CTO-BRAS-CTR-02-08',
                     'telnet 172.29.10.36 2010','TELNET','172.29.10.36',2010,10,
                     'REVERSE_TELNET_PORT_CONFIRMED','AVAILABLE',1,'LINE_AVAILABLE','{}',
                     'CISCO_MENU',1,'2026-07-27T06:00:05+00:00')
            """
        )
        conn.execute(
            """
            INSERT INTO device_identity_runs(
                id,oob_id,target_id,mapping_scan_id,collector_version,started_at,finished_at,status,
                identity_quality,identity_confidence,alias_comparison,verification_status,
                verification_severity,hardware_continuity,runtime_mapping_verified,live_state,
                live_state_confident,actual_hostname,detected_vendor,model,serial_number,software_version
            ) VALUES(20,1,100,10,'1.1.23','2026-07-27T06:05:00+00:00',
                     '2026-07-27T06:05:05+00:00','SUCCESS','ACCEPTED','HIGH','EXACT_MATCH',
                     'VERIFIED_MATCH','INFO','UNCHANGED',1,'AVAILABLE',1,'CTO-BRAS-CTR-02-08',
                     'JUNIPER','MX480','JN12345','23.4R2')
            """
        )
        conn.execute(
            """
            INSERT INTO device_identity_snapshots(
                identity_run_id,target_id,oob_id,configured_alias,actual_hostname,vendor,
                platform_family,model,serial_number,software_version,identity_quality,
                identity_confidence,alias_comparison,verification_status,verification_severity,
                hardware_continuity,identity_fingerprint,captured_at
            ) VALUES(20,100,1,'CTO-BRAS-CTR-02-08','CTO-BRAS-CTR-02-08','JUNIPER',
                     'JUNOS','MX480','JN12345','23.4R2','ACCEPTED','HIGH','EXACT_MATCH',
                     'VERIFIED_MATCH','INFO','UNCHANGED','fp','2026-07-27T06:05:05+00:00')
            """
        )
        conn.execute(
            """
            INSERT INTO device_identities(
                target_id,oob_id,configured_alias,actual_hostname,vendor,platform_family,model,
                serial_number,software_version,identity_quality,identity_confidence,alias_comparison,
                verification_status,verification_severity,hardware_continuity,identity_fingerprint,
                last_identity_run_id,verified_at
            ) VALUES(100,1,'CTO-BRAS-CTR-02-08','CTO-BRAS-CTR-02-08','JUNIPER','JUNOS','MX480',
                     'JN12345','23.4R2','ACCEPTED','HIGH','EXACT_MATCH','VERIFIED_MATCH','INFO',
                     'UNCHANGED','fp',20,'2026-07-27T06:05:05+00:00')
            """
        )


def test_daily_inventory_and_simple_export(tmp_path: Path):
    db = DatabaseConnection(tmp_path / 'data.db')
    MigrationManager(db).migrate()
    _seed_daily_data(db)
    settings = ApplicationSettings(export_dir=str(tmp_path / 'exports'))
    service = ExportService(db, settings)

    scans = service.list_daily_scans(date(2026, 7, 27))
    assert len(scans) == 1
    assert scans[0]['oob_name'] == 'CTO-OOB-02'

    rows = service.daily_inventory_rows(date(2026, 7, 27))
    assert len(rows) == 1
    row = rows[0]
    assert row['target_alias'] == 'CTO-BRAS-CTR-02-08'
    assert row['console_path'] == '172.29.10.36:2010 / line 10'
    assert row['actual_hostname'] == 'CTO-BRAS-CTR-02-08'
    assert row['serial'] == 'JN12345'
    assert row['overall'] == 'NORMAL'

    path = service.export_daily_inventory(date(2026, 7, 27))
    text = path.read_text(encoding='utf-8-sig')
    assert 'CTO-BRAS-CTR-02-08' in text
    assert 'JN12345' in text

    full_dir = service.export_all()
    simple = (full_dir / 'inventory_summary.csv').read_text(encoding='utf-8-sig')
    assert 'CTO-BRAS-CTR-02-08' in simple
    assert 'JN12345' in simple


def test_help_commands_and_context_help(tmp_path: Path, capsys):
    answers = iter(['help'])
    app = CLIApplication(
        db_path=tmp_path / 'cli.db',
        input_func=lambda _prompt='': next(answers),
        getpass_func=lambda _prompt='': '',
        pause_enabled=False,
    )
    assert app._read_main_choice() is None
    assert 'QUY TRÌNH LẦN ĐẦU' in get_help_text('quick')
    assert 'SUCCESS' in get_help_text('scan')
    assert 'Menu 17' in get_help_text('reconciliation')
    assert 'daily_inventory_' in get_help_text('daily')
