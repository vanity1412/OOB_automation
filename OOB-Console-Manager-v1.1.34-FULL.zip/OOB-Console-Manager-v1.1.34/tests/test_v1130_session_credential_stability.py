from __future__ import annotations

from oob_manager.cli.application import CLIApplication
from oob_manager.cli.session_credentials import SessionCredentialStore
from oob_manager.models import OOBDevice, SessionCredentials, ScanResult
from oob_manager.utils.datetime_utils import utc_now

def test_v1130_failed_retry_is_not_promoted_to_oob_override(tmp_path, monkeypatch):
    """Credential retry chỉ được cache khi scan chứng minh đã qua tầng auth/enable."""
    app = CLIApplication(
        db_path=tmp_path / "retry-cache.db",
        input_func=lambda _p="": "",
        getpass_func=lambda _p="": "still-wrong",
        pause_enabled=False,
    )
    device = OOBDevice(id=7, name="CISCO-X", host="192.0.2.7", vendor="CISCO")
    monkeypatch.setattr(app.oob_service, "list_all", lambda include_disabled=False: [device])
    app.session_credentials.set_default(
        SessionCredentials("shared", "shared-pw", "wrong-enable")
    )

    def fake_scan_all(provider, *, trigger_source, auth_failure_handler=None):
        current = provider(device)
        action, _replacement = auth_failure_handler(
            device,
            current,
            ScanResult(1, 7, "FAILED", error_code="ENABLE_FAILED"),
        )
        assert action == "RETRY"
        # Giả lập retry vẫn không chứng minh credential hợp lệ.
        return [
            ScanResult(
                2,
                7,
                "FAILED",
                error_code="ENABLE_FAILED",
                finished_at=utc_now(),
            )
        ]

    monkeypatch.setattr(app.scan_service, "scan_all", fake_scan_all)
    monkeypatch.setattr(app, "_read_menu_token", lambda *a, **k: "1")
    monkeypatch.setattr(app, "_export_scan_artifacts_safe", lambda *_a, **_k: None)

    app.scan_all()
    _cred, source = app.session_credentials.resolve(device)
    assert source == "SESSION_DEFAULT"


def test_v1130_non_auth_failure_after_retry_is_not_cached_as_verified_override(tmp_path, monkeypatch):
    """TCP/SSH failure sau khi nhập retry không đủ bằng chứng để cache password mới."""
    app = CLIApplication(
        db_path=tmp_path / "network-failure-cache.db",
        input_func=lambda _p="": "",
        getpass_func=lambda _p="": "new-secret",
        pause_enabled=False,
    )
    device = OOBDevice(id=8, name="CISCO-Y", host="192.0.2.8", vendor="CISCO")
    monkeypatch.setattr(app.oob_service, "list_all", lambda include_disabled=False: [device])
    app.session_credentials.set_default(SessionCredentials("shared", "old-secret", "enable"))

    def fake_scan_all(provider, *, trigger_source, auth_failure_handler=None):
        current = provider(device)
        action, _replacement = auth_failure_handler(
            device,
            current,
            ScanResult(10, 8, "FAILED", error_code="SSH_AUTHENTICATION_FAILED"),
        )
        assert action == "RETRY"
        return [
            ScanResult(
                11,
                8,
                "FAILED",
                error_code="TCP_CONNECTION_TIMEOUT",
                finished_at=utc_now(),
            )
        ]

    monkeypatch.setattr(app.scan_service, "scan_all", fake_scan_all)
    monkeypatch.setattr(app, "_read_menu_token", lambda *a, **k: "1")
    monkeypatch.setattr(app, "_export_scan_artifacts_safe", lambda *_a, **_k: None)

    app.scan_all()
    _cred, source = app.session_credentials.resolve(device)
    assert source == "SESSION_DEFAULT"


def test_v1130_successful_retry_is_promoted_to_oob_override(tmp_path, monkeypatch):
    app = CLIApplication(
        db_path=tmp_path / "success-cache.db",
        input_func=lambda _p="": "",
        getpass_func=lambda _p="": "new-secret",
        pause_enabled=False,
    )
    device = OOBDevice(id=9, name="LAB-OOB", host="192.0.2.9", vendor="CISCO")
    monkeypatch.setattr(app.oob_service, "list_all", lambda include_disabled=False: [device])
    app.session_credentials.set_default(SessionCredentials("shared", "old-secret", "enable"))

    def fake_scan_all(provider, *, trigger_source, auth_failure_handler=None):
        current = provider(device)
        action, replacement = auth_failure_handler(
            device,
            current,
            ScanResult(20, 9, "FAILED", error_code="SSH_AUTHENTICATION_FAILED"),
        )
        assert action == "RETRY"
        assert replacement is not None
        return [ScanResult(21, 9, "SUCCESS", finished_at=utc_now())]

    monkeypatch.setattr(app.scan_service, "scan_all", fake_scan_all)
    monkeypatch.setattr(app, "_read_menu_token", lambda *a, **k: "1")
    monkeypatch.setattr(app, "_export_scan_artifacts_safe", lambda *_a, **_k: None)

    app.scan_all()
    cred, source = app.session_credentials.resolve(device)
    assert source == "OOB_OVERRIDE"
    assert cred.password == "new-secret"


def test_v1130_add_oob_explicit_username_does_not_silently_use_other_session_username(tmp_path, monkeypatch):
    from oob_manager.models import ConnectionTestResult
    import oob_manager.vendors.factory as factory

    answers = iter([
        "LAB-OOB",
        "192.0.2.55",
        "",
        "1",          # Cisco
        "lab-admin",  # explicit default username
        "",
        "1",          # test then save
        "",           # prompt username -> keep lab-admin
        "c",          # confirm save
        "n",          # do not replace session default
    ])
    passwords = iter(["lab-pass", "lab-enable"])
    app = CLIApplication(
        db_path=tmp_path / "add-user.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    app.session_credentials.set_default(
        SessionCredentials("noc-net", "shared-pass", "shared-enable")
    )
    seen = {}

    class Adapter:
        def test_connection(self, device, credentials):
            seen["username"] = credentials.username
            seen["password"] = credentials.password
            return ConnectionTestResult(True, "NORMAL_CLI", "ok")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _device, _settings: Adapter())
    app.add_oob()

    assert seen == {"username": "lab-admin", "password": "lab-pass"}
    saved = app.oob_service.list_all()[0]
    assert saved.default_username == "lab-admin"
    default, source = app.session_credentials.resolve(saved)
    assert source == "SESSION_DEFAULT"
    assert default.username == "noc-net"


def test_v1130_run_finally_clears_session_credentials(tmp_path, monkeypatch):
    app = CLIApplication(db_path=tmp_path / "clear-finally.db", pause_enabled=False)
    app.session_credentials.set_default(SessionCredentials("noc", "secret", "enable"))
    monkeypatch.setattr(app, "_run_main_loop", lambda: None)
    app.run()
    assert not app.session_credentials.has_any()


def test_v1130_status_rows_never_include_password_text():
    store = SessionCredentialStore()
    store.set_default(SessionCredentials("noc", "TOP-SECRET", "ENABLE-SECRET"))
    serialized = repr(store.status_rows())
    assert "TOP-SECRET" not in serialized
    assert "ENABLE-SECRET" not in serialized
