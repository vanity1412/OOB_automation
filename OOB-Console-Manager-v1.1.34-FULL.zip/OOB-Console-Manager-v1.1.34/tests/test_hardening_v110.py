import json
from pathlib import Path

import pytest

from oob_manager.config import ApplicationSettings, load_profile
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.exceptions import ProfileError, ValidationError
from oob_manager.models import ConsoleTarget, OOBDevice
from oob_manager.services.export_service import ExportService
from oob_manager.services.target_matching import TargetMatcher


def make_target(alias: str, *, host: str, port: int, menu: str, item: int):
    return ConsoleTarget(
        menu_name=menu,
        menu_item=item,
        alias=alias,
        command=f"telnet {host} {port}",
        protocol="TELNET",
        target_host=host,
        target_port=port,
        state="AVAILABLE",
        is_complete=True,
    )


def test_invalid_boolean_setting_is_rejected():
    with pytest.raises(ValidationError):
        ApplicationSettings.from_mapping({"vertiv_verify_tls": "unexpected"})


def test_cisco_profile_missing_menu_commands_is_rejected(tmp_path):
    profile = {
        "vendor": "CISCO",
        "connect_timeout": 10,
        "command_timeout": 20,
        "optional_commands": {"show_line": "show line"},
    }
    (tmp_path / "cisco.json").write_text(json.dumps(profile), encoding="utf-8")
    with pytest.raises(ProfileError):
        load_profile("CISCO", tmp_path)


def test_matcher_does_not_match_only_by_shared_host_and_protocol():
    old_target = make_target(
        "Router-A", host="10.0.0.1", port=2001, menu="OOB", item=1
    )
    new_target = make_target(
        "Router-X", host="10.0.0.1", port=2099, menu="OOB", item=9
    )
    result = TargetMatcher().match([old_target], [new_target])
    assert result.pairs == []
    assert result.previous_unmatched == [old_target]
    assert result.current_unmatched == [new_target]


def test_export_uses_one_consistent_database_snapshot(tmp_path):
    db = DatabaseConnection(tmp_path / "snapshot.db")
    MigrationManager(db).migrate()
    repo = OOBRepository(db)
    repo.create(OOBDevice(name="OOB-1", host="10.0.0.1"))
    settings = ApplicationSettings(export_dir=str(tmp_path / "exports"))

    class ConcurrentWriteExport(ExportService):
        def _oob_analysis_summary(self, conn):
            rows = super()._oob_analysis_summary(conn)
            # Commit một OOB mới sau SELECT đầu tiên. Các SELECT còn lại của
            # export vẫn phải nhìn snapshot cũ.
            OOBRepository(db).create(OOBDevice(name="OOB-2", host="10.0.0.2"))
            return rows

    export_dir = ConcurrentWriteExport(db, settings).export_all()
    content = (export_dir / "oob_devices.csv").read_text(encoding="utf-8-sig")
    assert "OOB-1" in content
    assert "OOB-2" not in content


def test_raw_output_export_is_bounded_and_hashable(tmp_path):
    db = DatabaseConnection(tmp_path / "raw.db")
    MigrationManager(db).migrate()
    repo = OOBRepository(db)
    device = repo.create(OOBDevice(name="OOB-Raw", host="10.0.0.3"))
    large_output = "A" * 35_000
    with db.transaction() as conn:
        scan_id = conn.execute(
            "INSERT INTO scan_runs(oob_id, started_at, status, scanner_version) VALUES(?,?,?,?)",
            (device.id, "2026-07-25T00:00:00+00:00", "SUCCESS", "test"),
        ).lastrowid
        conn.execute(
            """
            INSERT INTO raw_outputs(
                scan_id, command_name, command_text, raw_output,
                success, error_message, created_at
            ) VALUES(?,?,?,?,?,?,?)
            """,
            (
                scan_id,
                "menu",
                "show run | i menu",
                large_output,
                1,
                "",
                "2026-07-25T00:00:01+00:00",
            ),
        )
    export_dir = ExportService(
        db, ApplicationSettings(export_dir=str(tmp_path / "exports"))
    ).export_all()
    import csv

    with (export_dir / "raw_outputs.csv").open(
        encoding="utf-8-sig", newline=""
    ) as handle:
        row = next(csv.DictReader(handle))
    assert row["raw_output_length"] == "35000"
    assert row["raw_output_truncated"] == "1"
    assert len(row["raw_output_preview"]) == 30_000
    assert len(row["raw_output_sha256"]) == 64


def test_failed_export_has_no_manifest_and_keeps_in_progress_marker(tmp_path):
    db = DatabaseConnection(tmp_path / "failed-export.db")
    MigrationManager(db).migrate()
    settings = ApplicationSettings(export_dir=str(tmp_path / "exports"))

    class FailingExport(ExportService):
        calls = 0

        def _write_dict_rows(self, path, rows):
            self.calls += 1
            if self.calls == 2:
                raise OSError("disk full")
            return super()._write_dict_rows(path, rows)

    with pytest.raises(OSError):
        FailingExport(db, settings).export_all()

    export_root = Path(settings.export_dir)
    date_dirs = list(export_root.iterdir())
    assert len(date_dirs) == 1
    export_dir = date_dirs[0]
    assert not (export_dir / "export_manifest.csv").exists()
    assert (export_dir / ".export_in_progress").exists()
