from __future__ import annotations

from pathlib import Path

import pytest

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings, profile_fingerprint
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.exceptions import ValidationError
from oob_manager.models import ConsoleTarget, OOBDevice, SessionCredentials
from oob_manager.networking.terminal_bridge import _SessionRecorder
from oob_manager.services.console_service import ConsoleService
from oob_manager.utils.datetime_utils import to_db, utc_now
from oob_manager.utils.security import REDACTED, sanitize_text


def _device_and_target(db: DatabaseConnection):
    device = OOBRepository(db).create(
        OOBDevice(name="OOB-AUDIT", host="127.0.0.1", vendor="CISCO")
    )
    target = ConsoleTarget(
        oob_id=device.id,
        menu_name="OOB",
        menu_item=1,
        alias="PE01",
        command="telnet 10.0.0.1 2001",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=2001,
        console_line=1,
        state="AVAILABLE",
        state_confident=True,
        is_complete=True,
    )
    return device, target


def test_schema_v14_adds_override_alert_and_session_audit_fields(tmp_path):
    db = DatabaseConnection(tmp_path / "v14.db")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16
        connection_cols = {
            row["name"] for row in conn.execute("PRAGMA table_info(connection_history)")
        }
        assert {
            "safety_override_requested",
            "safety_override_used",
            "safety_override_reason",
            "session_log_path",
        } <= connection_cols
        assert "viewed_at" in {
            row["name"] for row in conn.execute("PRAGMA table_info(change_events)")
        }
        assert "viewed_at" in {
            row["name"]
            for row in conn.execute("PRAGMA table_info(device_identity_events)")
        }


def test_v14_upgrade_marks_preexisting_events_as_already_viewed(tmp_path):
    """Old v13 history must not become a false "new alert" storm after upgrade."""
    db = DatabaseConnection(tmp_path / "legacy-v13.db")
    manager = MigrationManager(db)
    with db.transaction() as conn:
        conn.execute("CREATE TABLE connection_history(id INTEGER PRIMARY KEY)")
        conn.execute("CREATE TABLE change_events(id INTEGER PRIMARY KEY)")
        conn.execute("CREATE TABLE device_identity_events(id INTEGER PRIMARY KEY)")
        conn.execute("INSERT INTO change_events DEFAULT VALUES")
        conn.execute("INSERT INTO device_identity_events DEFAULT VALUES")
        manager._migrate_v14(conn)
        change_viewed = conn.execute(
            "SELECT viewed_at FROM change_events WHERE id=1"
        ).fetchone()[0]
        identity_viewed = conn.execute(
            "SELECT viewed_at FROM device_identity_events WHERE id=1"
        ).fetchone()[0]
    assert change_viewed
    assert identity_viewed


def test_internal_audit_keeps_username_but_still_redacts_credentials(tmp_path):
    db = DatabaseConnection(tmp_path / "audit.db")
    MigrationManager(db).migrate()
    device, target = _device_and_target(db)

    scan_id = ScanRepository(db).start(device, "1.1.20", ssh_username="operator01")
    connection_id = ConnectionRepository(db).start(
        device.id,
        target,
        "operator01",
        device=device,
    )
    with db.read() as conn:
        scan = conn.execute("SELECT * FROM scan_runs WHERE id=?", (scan_id,)).fetchone()
        history = conn.execute(
            "SELECT * FROM connection_history WHERE id=?", (connection_id,)
        ).fetchone()
    assert scan["ssh_username_at_scan"] == "operator01"
    assert history["username"] == "operator01"

    secret = "S3cr3t-Value"
    safe = sanitize_text(
        f"operator=operator01 password={secret} token={secret}", (secret,)
    )
    assert "operator01" in safe
    assert secret not in safe
    assert REDACTED in safe


def test_unknown_override_requires_reason_and_reason_is_audited(tmp_path):
    class Dummy:
        pass

    service = ConsoleService(Dummy(), Dummy(), Dummy(), ApplicationSettings())
    with pytest.raises(ValidationError) as caught:
        service.open(
            1,
            SessionCredentials("operator01", "secret"),
            allow_unverified_state=True,
            override_reason="",
        )
    assert caught.value.error_code == "UNKNOWN_OVERRIDE_REASON_REQUIRED"

    db = DatabaseConnection(tmp_path / "override.db")
    MigrationManager(db).migrate()
    device, target = _device_and_target(db)
    repo = ConnectionRepository(db)
    connection_id = repo.start(
        device.id,
        target,
        "operator01",
        device=device,
        safety_override_requested=True,
        safety_override_reason="AUTO_MENU không đọc được show users; kiểm tra theo ticket INC-123",
    )
    repo.finish(connection_id, "SUCCESS", safety_override_used=True)
    with db.read() as conn:
        row = conn.execute(
            "SELECT * FROM connection_history WHERE id=?", (connection_id,)
        ).fetchone()
    assert row["username"] == "operator01"
    assert row["safety_override_requested"] == 1
    assert row["safety_override_used"] == 1
    assert "INC-123" in row["safety_override_reason"]


def test_main_menu_alert_counts_unviewed_events_and_viewing_clears_them(tmp_path, capsys):
    app = CLIApplication(db_path=tmp_path / "alerts.db", pause_enabled=False)
    device = app.oob_repo.create(OOBDevice(name="OOB-ALERT", host="127.0.0.1"))
    now = to_db(utc_now())
    with app.db.transaction() as conn:
        scan_id = conn.execute(
            "INSERT INTO scan_runs(oob_id,started_at,status,scanner_version) VALUES(?,?,?,?)",
            (device.id, now, "SUCCESS", "1.1.20"),
        ).lastrowid
        conn.execute(
            """
            INSERT INTO change_events(oob_id,scan_id,event_code,target_identity,detected_at)
            VALUES(?,?,?,?,?)
            """,
            (device.id, scan_id, "CONSOLE_TARGET_PORT_CHANGED", "PE01", now),
        )
        identity_run_id = conn.execute(
            "INSERT INTO device_identity_runs(oob_id,started_at,status) VALUES(?,?,?)",
            (device.id, now, "RUNNING"),
        ).lastrowid
        conn.execute(
            """
            INSERT INTO device_identity_events(
                identity_run_id,target_id,oob_id,event_code,severity,detected_at
            ) VALUES(?,?,?,?,?,?)
            """,
            (identity_run_id, None, device.id, "SERIAL_CHANGED", "HIGH", now),
        )

    app._show_pending_alerts()
    output = capsys.readouterr().out
    assert "[3] IDENTITY NÂNG CAO" in output
    assert "[4] INVENTORY & LỊCH SỬ" in output
    assert app.change_repo.count_unviewed() == 1
    assert app.identity_repo.count_unviewed_critical_events() == 1

    changes = app.change_repo.list_recent()
    identity_events = app.identity_repo.list_recent_events()
    app.change_repo.mark_viewed([row["id"] for row in changes])
    app.identity_repo.mark_events_viewed(
        [row["identity_event_id"] for row in identity_events]
    )
    assert app.change_repo.count_unviewed() == 0
    assert app.identity_repo.count_unviewed_critical_events() == 0


def test_session_recorder_logs_commands_and_masks_password_and_echo(tmp_path):
    path = tmp_path / "session_logs" / "77.log"
    recorder = _SessionRecorder(path)
    recorder.output("Router# ")
    recorder.input(b"show version\r")
    recorder.output("show version\r\nCisco IOS XE\r\nRouter# ")
    recorder.output("Password: ")
    # Simulate a broken/echoing endpoint while the password is still being typed.
    # The recorder must suppress remote echo before it even knows the completed
    # secret value.
    recorder.input(b"Ultra")
    recorder.output("Ultra")
    recorder.input(b"Secret123\r")
    # And protect a second echo after Enter by remembering the completed secret
    # only in RAM for sanitization.
    recorder.output("UltraSecret123\r\nRouter# ")
    recorder.close()

    text = path.read_text(encoding="utf-8")
    assert "show version" in text
    assert "Cisco IOS XE" in text
    assert "UltraSecret123" not in text
    assert "SECRET_INPUT" in text
    assert "[IN]" in text
    assert "[OUT]" in text


def test_profile_fingerprint_ignores_documentation_note():
    first = {"vendor": "VERTIV", "ssh_commands": ["show"], "note": "old docs"}
    second = {"vendor": "VERTIV", "ssh_commands": ["show"], "note": "new docs"}
    assert profile_fingerprint(first) == profile_fingerprint(second)


def test_docs_and_vertiv_profile_are_synced_to_direct_ssh_support():
    root = Path(__file__).resolve().parents[1]
    readme = (root / "README.md").read_text(encoding="utf-8")
    profile = (root / "profiles" / "vertiv.json").read_text(encoding="utf-8")
    assert "v1.1.20" in readme
    assert "DIRECT_SSH_PORT_NAME" in readme
    assert "v1.1.19+" in readme
    assert "Direct SSH Port Name" in profile
    assert "v1.1.19+" in profile
