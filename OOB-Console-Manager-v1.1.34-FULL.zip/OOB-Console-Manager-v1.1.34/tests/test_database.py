import sqlite3
import pytest
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.models.oob_device import OOBDevice
from oob_manager.services.backup_service import BackupService
import oob_manager.services.backup_service as bs
def test_schema_migration_twice(tmp_path):
 db=DatabaseConnection(tmp_path/"a.db");MigrationManager(db).migrate();MigrationManager(db).migrate()
 with db.read() as c:assert c.execute("SELECT COUNT(*) FROM schema_versions").fetchone()[0]==1;assert c.execute("PRAGMA foreign_keys").fetchone()[0]==1
def test_unique_name_host_port(tmp_path):
 db=DatabaseConnection(tmp_path/"a.db");MigrationManager(db).migrate();r=OOBRepository(db);r.create(OOBDevice(name="A",host="h1"))
 with pytest.raises(Exception):r.create(OOBDevice(name="a",host="h2"))
 with pytest.raises(Exception):r.create(OOBDevice(name="B",host="h1"))
def test_transaction_rollback(tmp_path):
 db=DatabaseConnection(tmp_path/"a.db");MigrationManager(db).migrate()
 with pytest.raises(RuntimeError):
  with db.transaction() as c:c.execute("INSERT INTO application_settings(key,value,updated_at) VALUES('x','1','now')");raise RuntimeError()
 with db.read() as c:assert c.execute("SELECT COUNT(*) FROM application_settings WHERE key='x'").fetchone()[0]==0
def test_backup_integrity(tmp_path,monkeypatch):
 db=DatabaseConnection(tmp_path/"a.db");MigrationManager(db).migrate();monkeypatch.setattr(bs,"BACKUP_DIR",tmp_path/"backups");p=BackupService(db).create_backup();assert p.exists() and p.stat().st_size>0
 c=sqlite3.connect(p);assert c.execute("PRAGMA integrity_check").fetchone()[0]=="ok";c.close()
def test_parameterized_search(tmp_path):
 db=DatabaseConnection(tmp_path/"a.db");MigrationManager(db).migrate();r=OOBRepository(db);r.create(OOBDevice(name="Safe",host="host1"))
 from oob_manager.database.repositories.target_repository import TargetRepository
 assert TargetRepository(db).search("%' OR 1=1 --")==[]


def test_backup_same_second_does_not_overwrite(tmp_path, monkeypatch):
    from datetime import datetime, timezone

    db = DatabaseConnection(tmp_path / "same-second.db")
    MigrationManager(db).migrate()
    monkeypatch.setattr(bs, "BACKUP_DIR", tmp_path / "backups")
    fixed = datetime(2026, 7, 25, 22, 30, 15, tzinfo=timezone.utc)
    monkeypatch.setattr(bs, "utc_now", lambda: fixed)
    service = BackupService(db)
    first = service.create_backup()
    second = service.create_backup()
    assert first != second
    assert first.exists() and second.exists()
