from oob_manager.vendors.vertiv.parsers import parse_access_show


REAL_ACCESS_SHOW = """name               port  type    status
=================  ====  ======  ======
HPG-Vertiv-OOB-02
HPG-MP-02-01-N     1     serial  in-use
HPG-MP-02-02-N     2     serial  in-use
HPG-MP-02-03-N     3     serial  idle
HPG-MP-02-04-N     4     serial  idle
HPG-SW-02-01-mem0  5     serial  idle
HPG-SW-02-01-mem1  6     serial  idle
HPG-SW-02-02-mem0  7     serial  idle
HPG-SW-02-02-mem1  8     serial  idle
--:- access cli->
"""


def test_real_hpg_access_table_yields_all_8_serial_targets():
    result = parse_access_show(REAL_ACCESS_SHOW, 3, "172.29.13.116")
    assert len(result.targets) == 8
    assert [t.alias for t in result.targets] == [
        "HPG-MP-02-01-N", "HPG-MP-02-02-N", "HPG-MP-02-03-N", "HPG-MP-02-04-N",
        "HPG-SW-02-01-mem0", "HPG-SW-02-01-mem1", "HPG-SW-02-02-mem0", "HPG-SW-02-02-mem1",
    ]
    assert [t.state for t in result.targets[:2]] == ["BUSY_UNKNOWN_USER", "BUSY_UNKNOWN_USER"]
    assert all(t.state == "AVAILABLE" for t in result.targets[2:])


def test_access_parser_ignores_invisible_ansi_nbsp_and_backspace_artifacts():
    raw = (
        "\\x1b[32mname               port  type    status\\x1b[0m\\r"
        "=================  ====  ======  ======\\r"
        "HPG-MP-02-01-N\\xa0\\xa0\\xa01\\xa0serial\\xa0in-use\\r"
        "HPG-SW-02-01-mem0  5     seriX\\bal  idle\\r"
        "\\x1b[36m--:- access cli->\\x1b[0m\\r"
    ).encode("utf-8").decode("unicode_escape")
    result = parse_access_show(raw, 3, "172.29.13.116")
    assert len(result.targets) == 2
    assert result.targets[0].alias == "HPG-MP-02-01-N"
    assert result.targets[0].state == "BUSY_UNKNOWN_USER"
    assert result.targets[1].alias == "HPG-SW-02-01-mem0"
    assert result.targets[1].state == "AVAILABLE"
