import csv
from pathlib import Path

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.connection_repository import ConnectionRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.models import (
    ConsoleTarget,
    OOBDevice,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.export_service import ExportService
from oob_manager.services.scan_service import ScanService


class Adapter:
    def __init__(self, target):
        self.target = target

    def collect(self, device, credentials):
        return VendorScanData(
            True,
            "NORMAL_CLI",
            [self.target],
            [
                RawCommandOutput(
                    "menu",
                    "show run | i menu",
                    "menu OOB text [1] target",
                    True,
                    is_core=True,
                )
            ],
        )


def target(alias, port):
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=1,
        alias=alias,
        command=f"telnet 10.0.0.1 {port}",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=port,
        state="AVAILABLE",
        is_complete=True,
    )


def read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def test_export_is_analysis_friendly_and_excel_safe(tmp_path):
    db = DatabaseConnection(tmp_path / "export.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    device = oob_repo.create(
        OOBDevice(name="OOB-Export", host="127.0.0.1", notes="line 1\nline 2")
    )
    settings = ApplicationSettings(export_dir=str(tmp_path / "exports"))

    service = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        settings,
        adapter_factory=lambda device, settings: Adapter(target('=HYPERLINK("https://invalid")', 2001)),
    )
    assert service.scan_one(device.id, SessionCredentials("u", "p")).status == "SUCCESS"
    first_target = target_repo.list_current(device.id)[0]
    connection_repo = ConnectionRepository(db)
    connection_id = connection_repo.start(device.id, first_target, "operator")
    connection_repo.finish(connection_id, "SUCCESS")

    service.adapter_factory = lambda device, settings: Adapter(
        target('=HYPERLINK("https://invalid")', 2002)
    )
    assert service.scan_one(device.id, SessionCredentials("u", "p")).status == "SUCCESS"

    export_dir = ExportService(db, settings).export_all()
    expected_files = {
        "oob_analysis_summary.csv",
        "oob_devices.csv",
        "console_targets.csv",
        "console_snapshots.csv",
        "scan_history.csv",
        "scan_findings.csv",
        "raw_outputs.csv",
        "change_events.csv",
        "connection_history.csv",
        "export_manifest.csv",
        "README_EXPORT.txt",
    }
    assert expected_files <= {path.name for path in export_dir.iterdir()}
    assert not (export_dir / ".export_in_progress").exists()

    oob_rows = read_csv(export_dir / "oob_devices.csv")
    assert oob_rows[0]["notes"] == "line 1 line 2"
    assert oob_rows[0]["latest_scan_status_vi"] == "Thành công"

    target_rows = read_csv(export_dir / "console_targets.csv")
    assert target_rows[0]["alias"].startswith("'=")
    assert target_rows[0]["target_endpoint"] == "10.0.0.1:2002"
    assert target_rows[0]["last_scan_status_code"] == "SUCCESS"

    summary_rows = read_csv(export_dir / "oob_analysis_summary.csv")
    assert summary_rows[0]["total_scan_count"] == "2"
    assert summary_rows[0]["current_target_count"] == "1"
    assert summary_rows[0]["success_rate"] == "1.0"
    assert summary_rows[0]["success_rate_percent"] == "100.0"

    snapshot_rows = read_csv(export_dir / "console_snapshots.csv")
    assert len(snapshot_rows) == 2
    assert {row["target_port"] for row in snapshot_rows} == {"2001", "2002"}

    scan_rows = read_csv(export_dir / "scan_history.csv")
    assert {"duration_seconds", "complete_ratio", "change_count", "baseline_updated"} <= set(scan_rows[0])

    raw_rows = read_csv(export_dir / "raw_outputs.csv")
    assert len(raw_rows) == 2
    assert all(len(row["raw_output_sha256"]) == 64 for row in raw_rows)
    assert all("raw_output_preview" in row for row in raw_rows)

    change_rows = read_csv(export_dir / "change_events.csv")
    assert any(row["old_target_port"] == "2001" and row["new_target_port"] == "2002" for row in change_rows)
    assert all("old_data_json" in row and "new_data_json" in row for row in change_rows)

    connection_rows = read_csv(export_dir / "connection_history.csv")
    assert connection_rows[0]["target_alias_at_connection"].startswith("'=HYPERLINK")
    assert connection_rows[0]["target_endpoint_at_connection"] == "10.0.0.1:2001"

    manifest_rows = read_csv(export_dir / "export_manifest.csv")
    assert {row["file_name"] for row in manifest_rows} >= {
        "oob_analysis_summary.csv",
        "oob_devices.csv",
        "console_targets.csv",
        "console_snapshots.csv",
        "scan_history.csv",
        "scan_findings.csv",
        "raw_outputs.csv",
        "change_events.csv",
        "connection_history.csv",
    }


def test_empty_exports_keep_full_headers(tmp_path):
    db = DatabaseConnection(tmp_path / "empty.db")
    MigrationManager(db).migrate()
    settings = ApplicationSettings(export_dir=str(tmp_path / "exports"))
    export_dir = ExportService(db, settings).export_all()

    with (export_dir / "console_targets.csv").open(
        encoding="utf-8-sig", newline=""
    ) as handle:
        headers = next(csv.reader(handle))
    assert "target_endpoint" in headers
    assert "last_scan_status_vi" in headers
