from __future__ import annotations

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import InputCancelledError
from oob_manager.models import OOBDevice, ScanResult, SessionCredentials
from oob_manager.services.scan_service import ScanService
from oob_manager.utils.datetime_utils import utc_now


def _service(tmp_path):
    db = DatabaseConnection(tmp_path / "cancel.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    service = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        ApplicationSettings(),
    )
    return db, oob_repo, service


def _add_devices(oob_repo, count=4):
    return [
        oob_repo.create(
            OOBDevice(name=f"OOB-{index}", host=f"192.0.2.{index}", vendor="CISCO")
        )
        for index in range(1, count + 1)
    ]


def _success(device_id: int) -> ScanResult:
    return ScanResult(
        scan_id=device_id,
        oob_id=device_id,
        status="SUCCESS",
        mapping_count=1,
        mapping_quality="ACCEPTED",
        baseline_updated=True,
        finished_at=utc_now(),
    )


def test_v1128_cancel_first_device_stops_batch_before_scan_one(tmp_path, monkeypatch):
    _db, oob_repo, service = _service(tmp_path)
    _add_devices(oob_repo, 3)
    provider_calls = []
    scan_calls = []

    def provider(device):
        provider_calls.append(device.id)
        raise InputCancelledError("operator cancelled")

    monkeypatch.setattr(service, "scan_one", lambda *args, **kwargs: scan_calls.append(args[0]))
    results = service.scan_all(provider)

    assert len(provider_calls) == 1
    assert scan_calls == []
    assert len(results) == 1
    assert results[0].status == "CANCELLED"
    assert results[0].error_code == "INPUT_CANCELLED"
    assert results[0].scan_id is None


def test_v1128_cancel_mid_batch_does_not_ask_later_devices(tmp_path, monkeypatch):
    _db, oob_repo, service = _service(tmp_path)
    devices = _add_devices(oob_repo, 4)
    provider_calls = []
    scan_calls = []

    def provider(device):
        provider_calls.append(device.id)
        if device.id == devices[2].id:
            raise InputCancelledError("operator cancelled")
        return SessionCredentials("noc", "secret")

    def fake_scan_one(oob_id, _credentials, **_kwargs):
        scan_calls.append(oob_id)
        return _success(oob_id)

    monkeypatch.setattr(service, "scan_one", fake_scan_one)
    results = service.scan_all(provider)

    assert provider_calls == [devices[0].id, devices[1].id, devices[2].id]
    assert scan_calls == [devices[0].id, devices[1].id]
    assert [result.status for result in results] == ["SUCCESS", "SUCCESS", "CANCELLED"]
    assert devices[3].id not in provider_calls


def test_v1128_normal_device_error_still_continues_batch(tmp_path, monkeypatch):
    _db, oob_repo, service = _service(tmp_path)
    devices = _add_devices(oob_repo, 3)
    provider_calls = []
    scan_calls = []

    def provider(device):
        provider_calls.append(device.id)
        if device.id == devices[1].id:
            raise RuntimeError("credential backend failed")
        return SessionCredentials("noc", "secret")

    def fake_scan_one(oob_id, _credentials, **_kwargs):
        scan_calls.append(oob_id)
        return _success(oob_id)

    monkeypatch.setattr(service, "scan_one", fake_scan_one)
    results = service.scan_all(provider)

    assert provider_calls == [device.id for device in devices]
    assert scan_calls == [devices[0].id, devices[2].id]
    assert [result.status for result in results] == ["SUCCESS", "FAILED", "SUCCESS"]


def test_v1128_cancelled_credential_does_not_create_fake_scan_row(tmp_path):
    db, oob_repo, service = _service(tmp_path)
    _add_devices(oob_repo, 2)

    def provider(_device):
        raise InputCancelledError("operator cancelled")

    results = service.scan_all(provider)

    assert results[0].status == "CANCELLED"
    assert results[0].scan_id is None
    with db.read() as conn:
        assert conn.execute("SELECT COUNT(*) FROM scan_runs").fetchone()[0] == 0


def test_v1128_cli_summary_makes_cancelled_and_unscanned_explicit(tmp_path, capsys, monkeypatch):
    from oob_manager.cli.application import CLIApplication

    app = CLIApplication(db_path=tmp_path / "cli.db", pause_enabled=False)
    devices = [
        OOBDevice(id=index, name=f"OOB-{index}", host=f"192.0.2.{index}", vendor="CISCO")
        for index in range(1, 5)
    ]
    monkeypatch.setattr(app.oob_service, "list_all", lambda include_disabled=False: devices)
    app.session_credentials.set_default(SessionCredentials("operator", "secret"))
    monkeypatch.setattr(
        app.scan_service,
        "scan_all",
        lambda provider, trigger_source="CLI_SCAN_ALL", auth_failure_handler=None: [
            _success(1),
            _success(2),
            ScanResult(
                scan_id=None,
                oob_id=3,
                status="CANCELLED",
                mapping_quality="REJECTED",
                error_code="INPUT_CANCELLED",
                error_message="Operator đã hủy Scan tất cả OOB.",
                finished_at=utc_now(),
            ),
        ],
    )

    app.scan_all()
    output = capsys.readouterr().out

    assert "SCAN ALL ĐÃ HỦY tại OOB-3" in output
    assert "Tổng OOB      : 4" in output
    assert "Đã xử lý      : 2" in output
    assert "SUCCESS       : 2" in output
    assert "CANCELLED     : 1" in output
    assert "Chưa scan     : 2" in output
