import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import ConsoleTarget, OOBDevice, SessionCredentials
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter


class FakeChannel:
    def __init__(self):
        self.sent = []

    def send(self, value):
        self.sent.append(value)


class FakeClient:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class FakeSSH:
    def __init__(self, menu_output):
        self.menu_output = menu_output
        self.channel = FakeChannel()
        self.client = FakeClient()

    def connect(self, *args, **kwargs):
        return self.client

    def open_shell(self, client):
        return self.channel

    def read_until_quiet(self, channel, timeout=None, quiet=None):
        return self.menu_output


def make_target(item=4):
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=item,
        alias=f"R{item}",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=2000 + item,
        command=f"telnet 10.0.0.1 {2000 + item}",
        is_complete=True,
    )


def test_auto_menu_sends_exact_selected_item(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    fake_ssh = FakeSSH("=== OOB MENU ===\n1. R1\n4. R4\nSelect:")
    adapter.ssh = fake_ssh
    adapter.allow_unverified_state = True
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(
        "oob_manager.vendors.cisco.adapter.TerminalBridge.bridge",
        lambda self, channel, initial_output="": None,
    )

    result = adapter.open_console(
        OOBDevice(id=1, name="OOB", host="127.0.0.1"),
        make_target(4),
        SessionCredentials("u", "p"),
    )

    assert not result.runtime_mapping_verified
    assert result.runtime_mapping_verification_code == "AUTO_MENU_ITEM_ALIAS_VERIFIED_ONLY"
    assert fake_ssh.channel.sent == ["4\n"]
    assert fake_ssh.client.closed


def test_auto_menu_refuses_item_not_displayed(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), {"vendor": "CISCO"})
    fake_ssh = FakeSSH("=== OOB MENU ===\n1. R1\n2. R2\nSelect:")
    adapter.ssh = fake_ssh
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)

    with pytest.raises(InteractiveSessionError):
        adapter.open_console(
            OOBDevice(id=1, name="OOB", host="127.0.0.1"),
            make_target(4),
            SessionCredentials("u", "p"),
        )
    assert fake_ssh.channel.sent == []
