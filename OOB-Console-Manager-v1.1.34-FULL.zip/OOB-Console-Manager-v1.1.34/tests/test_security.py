import logging,sqlite3
from oob_manager.models.scan_result import SessionCredentials
from oob_manager.utils.security import redact_secrets,sanitize_text
def test_credentials_repr_redacted():
 c=SessionCredentials("user","SuperSecret","EnableSecret");r=repr(c);assert "SuperSecret" not in r and "EnableSecret" not in r
def test_redact_mapping():
 out=redact_secrets({"password":"abc","api_key":"xyz","host":"h"});assert out["password"]!="abc" and out["api_key"]!="xyz" and out["host"]=="h"
def test_sanitize_exception_text():assert "abc" not in sanitize_text("password abc failed",("abc",))

def test_password_not_written_to_database_or_export(tmp_path):
    from oob_manager.database.connection import DatabaseConnection
    from oob_manager.database.migrations import MigrationManager
    from oob_manager.database.repositories.oob_repository import OOBRepository
    from oob_manager.database.repositories.target_repository import TargetRepository
    from oob_manager.database.repositories.scan_repository import ScanRepository
    from oob_manager.database.repositories.change_repository import ChangeRepository
    from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
    from oob_manager.models import OOBDevice, ConsoleTarget, VendorScanData, RawCommandOutput
    from oob_manager.services.scan_service import ScanService
    from oob_manager.config import ApplicationSettings
    secret = "DB_EXPORT_SECRET_98412"
    db = DatabaseConnection(tmp_path / "security.db")
    MigrationManager(db).migrate()
    oob = OOBRepository(db)
    device = oob.create(OOBDevice(name="OOB", host="127.0.0.1"))
    class FailingAdapter:
        def collect(self, device, credentials):
            raise RuntimeError(f"authentication failed with {secret}")
    svc = ScanService(oob, TargetRepository(db), ScanRepository(db), ChangeRepository(db), ScanLockRepository(db), ApplicationSettings(), adapter_factory=lambda d, s: FailingAdapter())
    svc.scan_one(device.id, SessionCredentials("user", secret))
    raw = (tmp_path / "security.db").read_bytes()
    assert secret.encode() not in raw

def test_logging_filter_redacts_secret_key(tmp_path):
    import logging
    from oob_manager.logging_config import SecretRedactionFilter
    record = logging.LogRecord("x", logging.INFO, __file__, 1, "password=abc123", (), None)
    assert SecretRedactionFilter().filter(record)
    assert "abc123" not in record.getMessage()
    assert record.operation == "general"


def test_attached_raw_output_is_sanitized_before_database(tmp_path):
    from oob_manager.config import ApplicationSettings
    from oob_manager.database.connection import DatabaseConnection
    from oob_manager.database.migrations import MigrationManager
    from oob_manager.database.repositories.change_repository import ChangeRepository
    from oob_manager.database.repositories.oob_repository import OOBRepository
    from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
    from oob_manager.database.repositories.scan_repository import ScanRepository
    from oob_manager.database.repositories.target_repository import TargetRepository
    from oob_manager.exceptions import CommandExecutionError
    from oob_manager.models import OOBDevice, RawCommandOutput, SessionCredentials
    from oob_manager.services.scan_service import ScanService

    secret = "RAW_SECRET_123456"
    db = DatabaseConnection(tmp_path / "raw-secret.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    device = oob_repo.create(OOBDevice(name="OOB", host="127.0.0.1"))

    class Adapter:
        def collect(self, device, credentials):
            error = CommandExecutionError("failed", error_code="MENU_COMMAND_FAILED")
            error.raw_outputs = [
                RawCommandOutput(
                    "initial", "SSH login", f"unexpected echo {secret}", True, is_core=True
                )
            ]
            raise error

    service = ScanService(
        oob_repo,
        TargetRepository(db),
        ScanRepository(db),
        ChangeRepository(db),
        ScanLockRepository(db),
        ApplicationSettings(),
        adapter_factory=lambda device, settings: Adapter(),
    )
    service.scan_one(device.id, SessionCredentials("user", secret))
    assert secret.encode() not in (tmp_path / "raw-secret.db").read_bytes()
