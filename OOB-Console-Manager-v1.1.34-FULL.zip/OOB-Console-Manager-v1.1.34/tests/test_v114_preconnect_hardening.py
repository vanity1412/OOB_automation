from __future__ import annotations

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    OOBDevice,
    RawCommandOutput,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.scan_service import ScanService
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.cisco.parsers import parse_menu_config


PROFILE = {
    "vendor": "CISCO",
    "menu_commands": ["show run | i ^menu"],
    "optional_commands": {
        "show_line": "show line",
        "show_users": "show users",
    },
    "prepare_commands": ["terminal length 0", "terminal width 512"],
    "reverse_telnet_port_base": 2000,
}

MENU_2004 = (
    "menu OOB text [4] ----> R4\n"
    "menu OOB command 4 telnet 10.0.0.1 2004"
)


class Channel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value: str):
        self.sent.append(value)


class Client:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class LiveSSH:
    def __init__(self, *, menu: str = MENU_2004, busy: bool = False):
        self.channel = Channel()
        self.client = Client()
        self.menu = menu
        self.busy = busy
        self.reads = iter(["OOB#", "Trying 10.0.0.1 ... Open\n"])
        self.expected_prompt = None
        self.host_key_policy = "TOFU_PERSISTENT"
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:TEST"

    def connect(self, *args, **kwargs):
        return self.client

    def open_shell(self, client):
        return self.channel

    def read_until_quiet(self, channel, timeout=None, quiet=None):
        return next(self.reads)

    def run_shell_command(self, channel, command, timeout=None):
        if command.startswith("terminal "):
            return f"{command}\nOOB#"
        if command == "show run | i ^menu":
            return self.menu + "\nOOB#"
        if command == "show line":
            marker = "*" if self.busy else ""
            return (
                "Tty Line Typ Tx/Rx A Modem Roty AccO AccI Uses Noise Overruns Int\n"
                f"{marker}0/0/1   4 TTY - - - - - 0 0 0/0\nOOB#"
            )
        if command == "show users":
            extra = " 4 tty 1 operator01 00:01:00 192.0.2.44\n" if self.busy else ""
            return (
                "Line User Host(s) Idle Location\n"
                "* 0 vty 0 admin01 00:00:00 192.0.2.10\n"
                + extra
                + "OOB#"
            )
        raise AssertionError(command)


def _target():
    target = parse_menu_config(MENU_2004).targets[0]
    target.mapping_source_command = "show run | i ^menu"
    return target


def test_normal_cli_live_verifies_mapping_and_available_state(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), PROFILE)
    fake = LiveSSH()
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(
        "oob_manager.vendors.cisco.adapter.TerminalBridge.bridge",
        lambda *a, **kw: None,
    )

    result = adapter.open_console(
        OOBDevice(id=1, name="OOB", host="127.0.0.1"),
        _target(),
        SessionCredentials("u", "p"),
    )

    assert result.runtime_mapping_verified is True
    assert result.runtime_mapping_verification_code == "LIVE_MAPPING_VERIFIED"
    assert result.live_state == "AVAILABLE"
    assert result.live_state_confident is True
    assert result.live_state_reason_code == "NO_ACTIVE_TTY_SESSION_ON_CONFIRMED_LINE"
    assert fake.channel.sent == ["telnet 10.0.0.1 2004\n"]
    assert fake.client.closed


def test_normal_cli_blocks_when_runtime_endpoint_changed(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), PROFILE)
    fake = LiveSSH(
        menu=(
            "menu OOB text [4] ----> R4\n"
            "menu OOB command 4 telnet 10.0.0.1 2005"
        )
    )
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)

    with pytest.raises(InteractiveSessionError) as exc:
        adapter.open_console(
            OOBDevice(id=1, name="OOB", host="127.0.0.1"),
            _target(),
            SessionCredentials("u", "p"),
        )
    assert exc.value.error_code == "LIVE_MAPPING_ENDPOINT_MISMATCH"
    assert fake.channel.sent == []


def test_normal_cli_blocks_confirmed_busy_line_before_telnet(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), PROFILE)
    fake = LiveSSH(busy=True)
    adapter.ssh = fake
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)

    with pytest.raises(InteractiveSessionError) as exc:
        adapter.open_console(
            OOBDevice(id=1, name="OOB", host="127.0.0.1"),
            _target(),
            SessionCredentials("u", "p"),
        )
    assert exc.value.error_code == "CONSOLE_LINE_BUSY"
    assert exc.value.runtime_mapping_verified is True
    assert exc.value.live_state == "BUSY"
    assert exc.value.live_session_user == "operator01"
    assert fake.channel.sent == []


def test_provenance_detects_raw_menu_tampering(tmp_path):
    db = DatabaseConnection(tmp_path / "prov.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    lock_repo = ScanLockRepository(db)
    device = oob_repo.create(
        OOBDevice(name="OOB-1", host="192.0.2.10", device_type="cisco_ios")
    )

    target = _target()
    target.source = "CISCO_MENU"

    class Adapter:
        def collect(self, device, credentials):
            return VendorScanData(
                True,
                "NORMAL_CLI",
                [target],
                [RawCommandOutput("menu", "show run | i ^menu", MENU_2004, True, is_core=True)],
            )

    result = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda d, s: Adapter(),
    ).scan_one(device.id, SessionCredentials("u", "p"))
    assert result.baseline_updated
    current = target_repo.list_current(device.id)[0]
    ok, code, _ = target_repo.verify_open_provenance(current.id)
    assert ok and code == "MAPPING_PROVENANCE_VERIFIED"

    with db.transaction() as conn:
        conn.execute(
            "UPDATE raw_outputs SET raw_output=raw_output || ? WHERE scan_id=? AND command_name='menu'",
            ("\nTAMPERED", result.scan_id),
        )
    ok, code, _ = target_repo.verify_open_provenance(current.id)
    assert not ok
    assert code == "MAPPING_RAW_EVIDENCE_TAMPERED"


def test_schema_v8_has_live_connection_audit_columns(tmp_path):
    db = DatabaseConnection(tmp_path / "schema.db")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(connection_history)")}
    assert {
        "runtime_mapping_verified",
        "runtime_mapping_verification_code",
        "runtime_mapping_verification_message",
        "live_state",
        "live_state_confident",
        "live_session_user",
        "live_state_reason_code",
        "live_state_evidence",
        "live_state_checked_at",
    } <= columns
