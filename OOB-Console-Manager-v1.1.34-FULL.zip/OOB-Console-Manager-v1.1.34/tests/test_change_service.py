from oob_manager.models.console_target import ConsoleTarget
from oob_manager.services.change_service import ChangeService
def t(alias="R1",item=1,host="10.0.0.1",port=2001,command=None,state="AVAILABLE"):
 return ConsoleTarget(menu_name="OOB",menu_item=item,alias=alias,target_host=host,target_port=port,command=command or f"telnet {host} {port}",protocol="TELNET",is_complete=True,state=state,state_confident=True)
def codes(old,new):return [e.event_code for e in ChangeService().compare(old,new)]
def test_identical_zero():assert codes([t()],[t()])==[]
def test_new_missing():assert "NEW_CONSOLE_TARGET" in codes([], [t()]);assert "CONSOLE_TARGET_MISSING" in codes([t()],[])
def test_alias_changed_endpoint_match():assert "CONSOLE_ALIAS_CHANGED" in codes([t("Old")],[t("New")])
def test_port_changed():assert "CONSOLE_TARGET_PORT_CHANGED" in codes([t()],[t(port=2002)])
def test_item_changed():assert "CONSOLE_MENU_ITEM_CHANGED" in codes([t()],[t(item=2)])
def test_moved():
 c=codes([t(item=1,port=2001)],[t(item=4,port=2006)]);assert "CONSOLE_TARGET_MOVED" in c;assert "NEW_CONSOLE_TARGET" not in c;assert "CONSOLE_TARGET_MISSING" not in c;assert "CONSOLE_COMMAND_CHANGED" not in c
def test_command_and_state():
 c=codes([t(command="telnet 10.0.0.1 2001")],[t(command="telnet 10.0.0.1 2001 /stream",state="BUSY")]);assert "CONSOLE_COMMAND_CHANGED" in c;assert "CONSOLE_STATE_CHANGED" in c
