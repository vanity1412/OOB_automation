from oob_manager.cli.application import CLIApplication


def test_menu_invalid_then_exit(tmp_path, capsys):
    answers = iter(["abc", "0"])
    app = CLIApplication(
        db_path=tmp_path / "c.db",
        input_func=lambda p="": next(answers),
        pause_enabled=False,
    )
    app.run()
    out = capsys.readouterr().out
    assert "Lựa chọn không hợp lệ" in out
    assert "Tạm biệt" in out


def test_add_and_list_via_simplified_workflow(tmp_path, capsys):
    # main 1 -> submenu add -> save untested -> submenu list -> back -> exit
    answers = iter([
        "1", "1",
        "OOB-Test", "127.0.0.1", "22", "1", "operator", "lab", "2",
        "2", "0", "0",
    ])
    app = CLIApplication(
        db_path=tmp_path / "c.db",
        input_func=lambda p="": next(answers),
        pause_enabled=False,
    )
    app.run()
    out = capsys.readouterr().out
    assert "Đã lưu OOB" in out
    assert "OOB-Test" in out
