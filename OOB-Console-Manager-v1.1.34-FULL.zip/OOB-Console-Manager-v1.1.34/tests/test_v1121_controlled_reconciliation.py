from __future__ import annotations

import pytest

from oob_manager.config import ApplicationSettings, load_profile
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.identity_repository import DeviceIdentityRepository
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.reconciliation_repository import ReconciliationRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamDiscoveryResult,
    OOBDevice,
    RawCommandOutput,
    ReconciliationResult,
    SessionCredentials,
    VendorScanData,
)
from oob_manager.services.reconciliation_service import ReconciliationService
from oob_manager.services.scan_service import ScanService
from oob_manager.utils.datetime_utils import utc_now
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter


OLD = "HCM-PE01"
NEW = "HCM-PE05"
MENU_OLD = (
    f"menu OOB text [4] ----> {OLD}\n"
    "menu OOB command 4 telnet 10.0.0.1 2004"
)
MENU_NEW = (
    f"menu OOB text [4] ----> {NEW}\n"
    "menu OOB command 4 telnet 10.0.0.1 2004"
)


def _target(alias: str = OLD) -> ConsoleTarget:
    return ConsoleTarget(
        menu_name="OOB",
        menu_item=4,
        alias=alias,
        command="telnet 10.0.0.1 2004",
        protocol="TELNET",
        target_host="10.0.0.1",
        target_port=2004,
        console_line=4,
        console_line_source="REVERSE_TELNET_PORT_CONFIRMED",
        state="AVAILABLE",
        state_confident=True,
        state_reason_code="NO_ACTIVE_TTY_SESSION_ON_CONFIRMED_LINE",
        state_evidence='{"test":true}',
        source="CISCO_MENU",
        mapping_source_command="show run | i ^menu",
        mapping_text_line=f"menu OOB text [4] ----> {alias}",
        mapping_text_line_no=1,
        mapping_command_line="menu OOB command 4 telnet 10.0.0.1 2004",
        mapping_command_line_no=2,
        is_complete=True,
    )


def _scan_adapter(alias: str):
    class Adapter:
        def collect(self, _device, _credentials):
            raw = MENU_OLD if alias == OLD else MENU_NEW
            return VendorScanData(
                connection_success=True,
                login_mode="NORMAL_CLI",
                targets=[_target(alias)],
                raw_outputs=[
                    RawCommandOutput(
                        "menu", "show run | i ^menu", raw, True, is_core=True
                    )
                ],
            )

    return Adapter()


def _stack(tmp_path):
    db = DatabaseConnection(tmp_path / "reconcile.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    target_repo = TargetRepository(db)
    scan_repo = ScanRepository(db)
    change_repo = ChangeRepository(db)
    identity_repo = DeviceIdentityRepository(db)
    reconciliation_repo = ReconciliationRepository(db)
    lock_repo = ScanLockRepository(db, lease_seconds=60, heartbeat_seconds=5)
    device = oob_repo.create(
        OOBDevice(
            name="OOB-A",
            host="192.0.2.10",
            vendor="CISCO",
            device_type="cisco_ios",
            connection_mode="SSH",
        )
    )
    scan = ScanService(
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda _d, _s: _scan_adapter(OLD),
    ).scan_one(device.id, SessionCredentials("operator01", "secret"))
    assert scan.baseline_updated
    target = target_repo.list_current(device.id)[0]

    run_id = identity_repo.start(device, target, "operator01", "downstream")
    identity_repo.finish(
        run_id,
        target,
        DownstreamDiscoveryResult(
            identity=DeviceIdentity(
                actual_hostname=NEW,
                vendor="CISCO",
                platform_family="IOS-XE",
                model="ASR1001-X",
                serial_number="FTX1234567",
                software_version="17.9",
                quality="ACCEPTED",
                confidence="HIGH",
                alias_comparison="DIFFERENT",
                source_evidence={"actual_hostname": "prompt", "serial_number": "show inventory"},
            ),
            raw_outputs=[
                RawCommandOutput("show_version", "show version", "ok", True, is_core=True),
                RawCommandOutput("inventory", "show inventory", "ok", True, is_core=True),
            ],
            runtime_mapping_verified=True,
            runtime_mapping_verification_code="LIVE_MAPPING_VERIFIED",
            runtime_mapping_verification_message="verified",
            live_state="AVAILABLE",
            live_state_confident=True,
            live_state_reason_code="AVAILABLE",
        ),
    )
    return (
        db,
        oob_repo,
        target_repo,
        scan_repo,
        change_repo,
        identity_repo,
        reconciliation_repo,
        lock_repo,
        device,
        target,
    )


def test_schema_v15_has_reconciliation_audit_table(tmp_path):
    db = DatabaseConnection(tmp_path / "schema.db")
    MigrationManager(db).migrate()
    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16
        columns = {
            row["name"]
            for row in conn.execute("PRAGMA table_info(oob_reconciliation_history)")
        }
    assert {
        "operator_username", "ticket_id", "reason", "old_alias", "new_alias",
        "physical_path", "proposed_commands", "applied_commands", "rollback_attempted",
        "rollback_succeeded", "baseline_refresh_status",
    } <= columns


def test_service_requires_accepted_identity_and_marks_mapping_stale_after_verified_write(tmp_path):
    (
        db, oob_repo, target_repo, scan_repo, change_repo, identity_repo,
        reconciliation_repo, lock_repo, device, target,
    ) = _stack(tmp_path)

    class FakeWriteAdapter:
        profile = load_profile("CISCO")
        def reconcile_alias(self, _device, current_target, _credentials, new_alias):
            assert current_target.id == target.id
            assert new_alias == NEW
            return ReconciliationResult(
                True, current_target.alias, new_alias,
                verification_code="FAKE_READBACK_VERIFIED",
                verification_message="verified",
                applied_commands=["menu OOB text [4] ----> HCM-PE05"],
                started_at=utc_now(), finished_at=utc_now(),
            )

    service = ReconciliationService(
        oob_repo, target_repo, identity_repo, reconciliation_repo,
        ApplicationSettings(), lock_repo,
        adapter_factory=lambda _d, _s: FakeWriteAdapter(),
    )
    plan = service.build_plan(target.id)
    assert plan.old_alias == OLD
    assert plan.new_alias == NEW
    assert "10.0.0.1:2004" in plan.physical_path

    rec_id, result = service.apply(
        plan, SessionCredentials("operator01", "oob-secret"),
        ticket_id="CHG-12345", reason="RMA đã được phê duyệt",
    )
    assert result.success
    updated = oob_repo.get(device.id)
    assert updated.mapping_stale
    assert updated.baseline_stale_reason.startswith("CONTROLLED_RECONCILIATION:")
    with db.read() as conn:
        row = conn.execute(
            "SELECT * FROM oob_reconciliation_history WHERE id=?", (rec_id,)
        ).fetchone()
    assert row["operator_username"] == "operator01"
    assert row["ticket_id"] == "CHG-12345"
    assert row["reason"] == "RMA đã được phê duyệt"
    assert row["status"] == "APPLIED_VERIFIED"
    assert row["baseline_refresh_status"] == "PENDING_RESCAN"
    assert "menu OOB text [4] ----> HCM-PE05" in row["applied_commands"]
    assert "oob-secret" not in "|".join(str(row[k] or "") for k in row.keys())


def test_controlled_reconcile_rescan_preserves_other_generation_and_accepts_new_alias(tmp_path):
    (
        _db, oob_repo, target_repo, scan_repo, change_repo, identity_repo,
        reconciliation_repo, lock_repo, device, target,
    ) = _stack(tmp_path)

    class FakeWriteAdapter:
        profile = load_profile("CISCO")
        def reconcile_alias(self, _device, current_target, _credentials, new_alias):
            return ReconciliationResult(
                True, current_target.alias, new_alias,
                verification_code="OK", verification_message="ok",
            )

    service = ReconciliationService(
        oob_repo, target_repo, identity_repo, reconciliation_repo,
        ApplicationSettings(), lock_repo,
        adapter_factory=lambda _d, _s: FakeWriteAdapter(),
    )
    plan = service.build_plan(target.id)
    rec_id, _ = service.apply(
        plan, SessionCredentials("operator01", "secret"),
        ticket_id="CHG-1", reason="approved replacement",
    )

    scan = ScanService(
        oob_repo, target_repo, scan_repo, change_repo, lock_repo,
        ApplicationSettings(),
        adapter_factory=lambda _d, _s: _scan_adapter(NEW),
    ).scan_one(device.id, SessionCredentials("operator01", "secret"), trigger_source="CLI_RECONCILE")
    assert scan.baseline_updated
    service.update_baseline_refresh(rec_id, "RESCAN_BASELINE_UPDATED")
    current_device = oob_repo.get(device.id)
    assert not current_device.mapping_stale
    current = target_repo.list_current(device.id)
    assert len(current) == 1 and current[0].alias == NEW
    # Alias change invalidates the old accepted identity until menu 14 verifies it again.
    assert identity_repo.get_current_for_target(current[0].id) is None


def test_cisco_reconcile_preserves_existing_menu_text_key_and_decoration():
    target = _target()
    command = CiscoOOBAdapter._reconcile_menu_text_command(target, NEW)
    assert command == "menu OOB text [4] ----> HCM-PE05"
    assert "telnet" not in command.casefold()


def test_cisco_reconcile_blocks_busy_before_any_write(monkeypatch):
    adapter = CiscoOOBAdapter(ApplicationSettings(), load_profile("CISCO"))
    target = _target()
    target.id = 9
    target.oob_id = 1
    device = OOBDevice(id=1, name="OOB", host="192.0.2.10", vendor="CISCO")

    class Client:
        def close(self): pass
    class SSH:
        last_host_key_algorithm = ""
        last_host_key_fingerprint = ""
        host_key_policy = "TOFU_PERSISTENT"
        expected_prompt = "OOB#"
        def connect(self, *a, **k): return Client()
        def open_shell(self, *a, **k): return object()
    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda *_: ("OOB#", "NORMAL_CLI"))
    monkeypatch.setattr(adapter, "_prepare_readonly_cli", lambda *_: [])
    monkeypatch.setattr(adapter, "_verify_runtime_mapping_normal_cli", lambda *_: (target, target.mapping_source_command, "ok"))
    busy = _target(); busy.state = "BUSY"; busy.state_confident = True; busy.session_user = "noc02"
    monkeypatch.setattr(adapter, "_resolve_live_target_state", lambda *_: busy)
    monkeypatch.setattr(adapter, "_apply_menu_alias_write", lambda *_: pytest.fail("write must not run"))

    with pytest.raises(InteractiveSessionError) as exc:
        adapter.reconcile_alias(device, target, SessionCredentials("operator01", "secret"), NEW)
    assert exc.value.error_code == "CONSOLE_LINE_BUSY"


def test_vertiv_reconcile_prompt_understands_pending_and_saved_states():
    assert VertivOOBAdapter._reconcile_prompt_state("**:- cas cli->") == "PENDING"
    assert VertivOOBAdapter._reconcile_prompt_state("--:- cas cli->") == "SAVED"
    assert VertivOOBAdapter._parse_cas_port_name("port_name = R1\n--:- cas cli->") == "R1"


def test_failed_write_keeps_mapping_stale_and_requires_rescan(tmp_path):
    (
        db, oob_repo, target_repo, _scan_repo, _change_repo, identity_repo,
        reconciliation_repo, lock_repo, device, target,
    ) = _stack(tmp_path)

    class FailingAdapter:
        profile = load_profile("CISCO")
        def reconcile_alias(self, *_args, **_kwargs):
            exc = InteractiveSessionError(
                "simulated write/readback failure", error_code="RECONCILE_READBACK_FAILED"
            )
            exc.rollback_attempted = True
            exc.rollback_succeeded = True
            raise exc

    service = ReconciliationService(
        oob_repo, target_repo, identity_repo, reconciliation_repo,
        ApplicationSettings(), lock_repo,
        adapter_factory=lambda _d, _s: FailingAdapter(),
    )
    plan = service.build_plan(target.id)
    with pytest.raises(InteractiveSessionError):
        service.apply(
            plan, SessionCredentials("operator01", "super-secret"),
            ticket_id="CHG-FAIL-1", reason="failure-path regression",
        )

    current = oob_repo.get(device.id)
    assert current.mapping_stale
    assert current.baseline_stale_reason.startswith("CONTROLLED_RECONCILIATION:")
    with db.read() as conn:
        row = conn.execute(
            "SELECT * FROM oob_reconciliation_history ORDER BY id DESC LIMIT 1"
        ).fetchone()
    assert row["status"] == "FAILED"
    assert row["baseline_refresh_status"] == "RESCAN_REQUIRED_AFTER_FAILURE"
    assert row["rollback_attempted"] == 1
    assert row["rollback_succeeded"] == 1
    assert "super-secret" not in "|".join(str(row[k] or "") for k in row.keys())


def test_cisco_save_handles_destination_and_confirm_prompts():
    adapter = CiscoOOBAdapter(ApplicationSettings(command_timeout=5), load_profile("CISCO"))

    class Channel:
        def __init__(self):
            self.sent = []
        def send(self, value):
            self.sent.append(value)

    class ScriptedSSH:
        def __init__(self):
            self.chunks = [
                "Destination filename [startup-config]? ",
                "[confirm]",
                "Building configuration...\n[OK]\nOOB#",
            ]
        def drain_channel(self, _channel):
            return ""
        def read_until_state(self, _channel, detector, **_kwargs):
            text = self.chunks.pop(0)
            return text, detector(text)

    channel = Channel()
    adapter.ssh = ScriptedSSH()
    output = adapter._save_running_config(channel)
    assert "[OK]" in output
    assert channel.sent == [
        "copy system:running-config nvram:startup-config\n",
        "\n",
        "\n",
    ]


def test_vertiv_alias_write_helper_is_narrow_and_commits(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), load_profile("VERTIV"))
    calls = []

    def fake_run(_channel, command, *, expected):
        calls.append((command, set(expected)))
        state = "PENDING" if command.startswith("set port_name=") else "SAVED"
        return "--:- cas cli->", state

    monkeypatch.setattr(adapter, "_run_reconcile_command", fake_run)
    applied = adapter._vertiv_set_port_name(object(), 7, "HCM-PE05")
    assert applied == [
        "cd /ports/serial_ports/7/cas",
        "set port_name=HCM-PE05",
        "commit",
    ]
    assert calls[0][0] == "cd /ports/serial_ports/7/cas"
    assert calls[1][0] == "set port_name=HCM-PE05"
    assert calls[2][0] == "commit"


def test_cisco_startup_readback_must_preserve_endpoint_and_new_alias():
    adapter = CiscoOOBAdapter(ApplicationSettings(), load_profile("CISCO"))

    class SSH:
        def run_shell_command(self, _channel, command):
            assert command.startswith("show startup-config")
            return MENU_NEW + "\nOOB#"

    adapter.ssh = SSH()
    output = adapter._verify_startup_menu_alias(object(), _target(), NEW)
    assert NEW in output


def test_reconciliation_audit_is_exported_without_credentials(tmp_path):
    import csv
    from oob_manager.services.export_service import ExportService

    (
        db, oob_repo, target_repo, _scan_repo, _change_repo, identity_repo,
        reconciliation_repo, lock_repo, _device, target,
    ) = _stack(tmp_path)

    class FakeWriteAdapter:
        profile = load_profile("CISCO")
        def reconcile_alias(self, _device, current_target, _credentials, new_alias):
            return ReconciliationResult(
                True, current_target.alias, new_alias,
                verification_code="OK", verification_message="verified",
                applied_commands=["menu OOB text [4] ----> HCM-PE05"],
            )

    settings = ApplicationSettings(export_dir=str(tmp_path / "exports"))
    service = ReconciliationService(
        oob_repo, target_repo, identity_repo, reconciliation_repo,
        settings, lock_repo,
        adapter_factory=lambda _d, _s: FakeWriteAdapter(),
    )
    plan = service.build_plan(target.id)
    service.apply(
        plan, SessionCredentials("operator01", "never-export-this"),
        ticket_id="CHG-EXPORT-1", reason="approved",
    )
    export_dir = ExportService(db, settings).export_all()
    with (export_dir / "oob_reconciliation_history.csv").open(
        encoding="utf-8-sig", newline=""
    ) as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 1
    assert rows[0]["operator_username"] == "operator01"
    assert rows[0]["ticket_id"] == "CHG-EXPORT-1"
    assert "menu OOB text" in rows[0]["applied_commands"]
    assert "never-export-this" not in "|".join(rows[0].values())
