from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter
from oob_manager.vendors.vertiv.parsers import parse_access_show


def test_vertiv_cli_prompt_accepts_official_spacing_variants():
    samples = [
        "--:- / cli->",
        "--:-/ cli->",
        "--:- access cli->",
        "--:-access cli->",
        "--:#- [serial_ports/physical] cli->",
    ]
    for sample in samples:
        assert VertivOOBAdapter._extract_cli_prompt(sample) == sample


def test_vertiv_access_show_official_style_rows():
    raw = """
--:- / cli-> cd access
--:- access cli-> show
name                  port type   status
========================================
HCM-BRAS-02-01        1    serial idle
HCM-PE-05-04          2    serial in use
--:- access cli->
"""
    result = parse_access_show(raw, oob_id=9, oob_host="192.0.2.53")
    assert len(result.targets) == 2
    first, second = result.targets
    assert first.alias == "HCM-BRAS-02-01"
    assert first.console_line == 1
    assert first.command == "connect HCM-BRAS-02-01"
    assert first.state == "AVAILABLE"
    assert second.alias == "HCM-PE-05-04"
    assert second.state == "BUSY_UNKNOWN_USER"
