from __future__ import annotations

import json

import pytest

from oob_manager.config import ApplicationSettings, load_profile
from oob_manager.exceptions import InteractiveSessionError
from oob_manager.models import ConsoleTarget, OOBDevice, SessionCredentials
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter
from oob_manager.vendors.vertiv.parsers import (
    apply_active_sessions,
    parse_access_show,
    parse_active_sessions,
)


ACCESS_SHOW = """\
--:- access cli-> show
name                     port type    status
======================== ==== ======= ======
ACS8048-0011223344
HCM-BRAS-02-01           1    serial  idle
HCM-PE-05-04             2    serial  in use
--:- access cli->
"""

ACTIVE_SESSIONS = """\
--:- active_sessions cli-> show
37
user: operator01
client_ip: 10.0.0.10
creation_time: Tue Jul 26 03:31:01 2026
session_type: console
connection_type: cli
target_name: HCM-PE-05-04
id: 37
parent_id:
--:- active_sessions cli->
"""


class DummyClient:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class DummyChannel:
    def __init__(self):
        self.sent: list[str] = []

    def send(self, value):
        self.sent.append(value.decode() if isinstance(value, bytes) else value)


class DummySSH:
    def __init__(self, reads=None):
        self.client = DummyClient()
        self.channel = DummyChannel()
        self.reads = list(reads or [])
        self.last_host_key_algorithm = "ssh-ed25519"
        self.last_host_key_fingerprint = "SHA256:test"
        self.host_key_policy = "TOFU_PERSISTENT"

    def connect(self, *args, **kwargs):
        return self.client

    def open_shell(self, client, *args, **kwargs):
        return self.channel

    def read_until_quiet(self, *args, **kwargs):
        return self.reads.pop(0) if self.reads else ""

    def drain_channel(self, *args, **kwargs):
        return ""


def _device():
    return OOBDevice(
        id=7,
        name="HCM-Vertiv-OOB-09-01",
        host="172.29.11.53",
        ssh_port=22,
        vendor="VERTIV",
        connection_mode="SSH",
        enabled=True,
    )


def _target(state="AVAILABLE"):
    return ConsoleTarget(
        id=9,
        oob_id=7,
        menu_name="ACCESS",
        menu_item=1,
        alias="HCM-BRAS-02-01",
        command="connect HCM-BRAS-02-01",
        protocol="VERTIV_CLI",
        target_host="172.29.11.53",
        target_port=0,
        console_line=1,
        console_line_source="VERTIV_ACCESS_SHOW",
        state=state,
        state_confident=True,
        state_reason_code="VERTIV_ACCESS_IDLE" if state == "AVAILABLE" else "VERTIV_ACCESS_IN_USE",
        is_complete=True,
    )


def test_parse_access_show_maps_serial_port_and_state():
    parsed = parse_access_show(ACCESS_SHOW, 7, "172.29.11.53")
    assert len(parsed.targets) == 2
    first, second = parsed.targets
    assert first.alias == "HCM-BRAS-02-01"
    assert first.console_line == 1
    assert first.menu_item == 1
    assert first.protocol == "VERTIV_CLI"
    assert first.command == "connect HCM-BRAS-02-01"
    assert first.state == "AVAILABLE"
    assert first.state_confident
    assert first.mapping_source_command == "show"
    assert first.mapping_text_line == "HCM-BRAS-02-01           1    serial  idle"
    assert second.state == "BUSY_UNKNOWN_USER"
    assert second.state_confident


def test_access_show_unsafe_alias_is_incomplete():
    raw = "bad;name 1 serial idle\n--:- access cli->\n"
    parsed = parse_access_show(raw, 1, "10.0.0.1")
    assert len(parsed.targets) == 1
    target = parsed.targets[0]
    assert not target.is_complete
    assert target.command == ""
    assert target.state == "INCOMPLETE"


def test_active_sessions_upgrades_busy_unknown_user_to_busy():
    targets = parse_access_show(ACCESS_SHOW, 7, "172.29.11.53").targets
    sessions = parse_active_sessions(ACTIVE_SESSIONS, [t.alias for t in targets])
    apply_active_sessions(targets, sessions)
    busy = [t for t in targets if t.alias == "HCM-PE-05-04"][0]
    assert busy.state == "BUSY"
    assert busy.session_user == "operator01"
    assert busy.state_reason_code == "VERTIV_ACTIVE_SESSION_MATCHED"


def test_load_profile_enriches_legacy_vertiv_profile_in_memory(tmp_path):
    (tmp_path / "vertiv.json").write_text(
        json.dumps(
            {
                "vendor": "VERTIV",
                "ssh_commands": [],
                "api_scheme": "https",
                "api_port": 443,
                "api_base_path": "",
                "verify_tls": True,
                "status": "NOT_CONFIGURED",
            }
        ),
        encoding="utf-8",
    )
    profile = load_profile("VERTIV", tmp_path)
    assert profile["status"] == "ACS8000_CLI_READ_ONLY"
    assert "cd access" in profile["ssh_commands"]
    assert profile["connect_command"] == "connect"


def test_collect_uses_access_show_as_core_mapping(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV", "cli_family": "ACS8000"})
    adapter.ssh = DummySSH(["initial"])
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_ensure_cli", lambda channel, initial: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_show_access", lambda channel: ACCESS_SHOW)
    monkeypatch.setattr(adapter, "_show_active_sessions", lambda channel: ACTIVE_SESSIONS)

    data = adapter.collect(_device(), SessionCredentials("admin", "secret"))
    assert data.connection_success
    assert len(data.targets) == 2
    assert data.raw_outputs[0].command_name == "menu"
    assert data.raw_outputs[0].is_core
    assert data.targets[1].state == "BUSY"
    assert data.targets[1].session_user == "operator01"
    assert adapter.ssh.client.closed


def test_open_console_live_verifies_then_sends_connect(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    adapter.ssh = DummySSH(["initial", "Type the hot key to suspend the connection: <CTRL>Z>\nlogin:"])
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_ensure_cli", lambda channel, initial: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda channel, target: (_target("AVAILABLE"), ACCESS_SHOW))
    monkeypatch.setattr(adapter, "_goto_access", lambda channel: "--:- access cli->")
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.TerminalBridge.bridge", lambda *a, **k: None)

    result = adapter.open_console(_device(), _target(), SessionCredentials("admin", "secret"))
    assert "connect HCM-BRAS-02-01\n" in adapter.ssh.channel.sent
    assert result.runtime_mapping_verified
    assert result.console_path_verified
    assert result.live_state == "AVAILABLE"
    assert adapter.ssh.client.closed


def test_open_console_blocks_in_use_before_connect(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    adapter.ssh = DummySSH(["initial"])
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)
    monkeypatch.setattr(adapter, "_ensure_cli", lambda channel, initial: ("--:- / cli->", "VERTIV_CLI"))
    monkeypatch.setattr(adapter, "_runtime_verify", lambda channel, target: (_target("BUSY_UNKNOWN_USER"), ACCESS_SHOW))

    with pytest.raises(InteractiveSessionError) as caught:
        adapter.open_console(_device(), _target(), SessionCredentials("admin", "secret"))
    assert caught.value.error_code == "CONSOLE_LINE_BUSY"
    assert not any(value.startswith("connect ") for value in adapter.ssh.channel.sent)


def test_runtime_alias_mismatch_is_blocked():
    adapter = VertivOOBAdapter(ApplicationSettings(), {"vendor": "VERTIV"})
    live = _target()
    live.alias = "OTHER-DEVICE"
    live.command = "connect OTHER-DEVICE"
    with pytest.raises(InteractiveSessionError) as caught:
        adapter._find_runtime_target([live], _target())
    assert caught.value.error_code == "VERTIV_LIVE_MAPPING_ALIAS_MISMATCH"

class ScriptChannel:
    def __init__(self):
        self.sent: list[str] = []
        self.buffer = bytearray()
        self.location = "shell"

    def settimeout(self, value):
        pass

    def send(self, value):
        text = value.decode() if isinstance(value, bytes) else value
        self.sent.append(text)
        cmd = text.strip()
        if cmd == "cli":
            self.location = "root"
            response = "\r\n--:- / cli->"
        elif cmd == "cd /":
            self.location = "root"
            response = "\r\n--:- / cli->"
        elif cmd == "cd access":
            self.location = "access"
            response = "\r\n--:- access cli->"
        elif cmd == "cd active_sessions":
            self.location = "active_sessions"
            response = "\r\n--:- active_sessions cli->"
        elif cmd == "show" and self.location == "access":
            response = ACCESS_SHOW
        elif cmd == "show" and self.location == "active_sessions":
            response = ACTIVE_SESSIONS
        else:
            response = "\r\nInvalid command\r\n--:- / cli->"
        self.buffer.extend(response.encode())

    def recv_ready(self):
        return bool(self.buffer)

    def recv(self, size):
        data = bytes(self.buffer[:size])
        del self.buffer[:size]
        return data


class ScriptSSH(DummySSH):
    def __init__(self, initial):
        super().__init__([initial])
        self.channel = ScriptChannel()

    def drain_channel(self, *args, **kwargs):
        # Adapter consumes complete prompt-terminated responses in each command.
        return ""


def test_real_cli_runner_connection_check_stops_after_verified_cli(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=2), {"vendor": "VERTIV"})
    adapter.ssh = ScriptSSH("[root@HCM-Vertiv-OOB-09-01 ~]#")
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)

    result = adapter.test_connection(_device(), SessionCredentials("admin", "secret"))
    assert result.success
    assert result.login_mode == "VERTIV_ROOT_SHELL_TO_CLI"
    # Connection check proves SSH/auth + ACS CLI only. Inventory navigation is
    # a scan capability and must not turn a valid login into CONNECTION FAIL.
    assert adapter.ssh.channel.sent == ["cli\n"]
    assert adapter.ssh.client.closed


def test_scan_still_runs_access_show_after_verified_cli(monkeypatch):
    adapter = VertivOOBAdapter(ApplicationSettings(command_timeout=2), {"vendor": "VERTIV"})
    adapter.ssh = ScriptSSH("--:- / cli->")
    monkeypatch.setattr("oob_manager.vendors.vertiv.adapter.check_tcp", lambda *a, **k: 0.1)

    data = adapter.collect(_device(), SessionCredentials("admin", "secret"))
    assert data.connection_success is True
    assert data.targets
    # Root ACS CLI can enter Access directly. Avoid redundant ``cd /`` because
    # some real ACS8000 profiles do not redraw a prompt for that no-op.
    assert adapter.ssh.channel.sent[:2] == ["cd access\n", "show\n"]
    assert adapter.ssh.client.closed


def test_schema_v11_persists_vertiv_cli_target(tmp_path):
    from oob_manager.database.connection import DatabaseConnection
    from oob_manager.database.migrations import MigrationManager
    from oob_manager.database.repositories.oob_repository import OOBRepository
    from oob_manager.database.repositories.scan_repository import ScanRepository
    from oob_manager.database.repositories.target_repository import TargetRepository

    db = DatabaseConnection(tmp_path / "vertiv.db")
    MigrationManager(db).migrate()
    oob_repo = OOBRepository(db)
    scan_repo = ScanRepository(db)
    target_repo = TargetRepository(db)
    device = oob_repo.create(_device())
    scan_id = scan_repo.start(device, "1.1.7")
    target = _target()
    target.oob_id = device.id
    target_repo.replace_current(device.id, scan_id, [target])

    with db.read() as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 16
        row = conn.execute("SELECT protocol,console_line,target_port FROM console_targets").fetchone()
        assert row["protocol"] == "VERTIV_CLI"
        assert row["console_line"] == 1
        assert row["target_port"] == 0
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("PRAGMA foreign_key_check").fetchall() == []
