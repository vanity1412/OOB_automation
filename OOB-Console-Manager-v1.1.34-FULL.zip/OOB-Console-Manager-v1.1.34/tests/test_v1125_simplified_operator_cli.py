from __future__ import annotations

from oob_manager.cli.application import CLIApplication
from oob_manager.cli.menus import LEGACY_MENU_COVERAGE, render_main_menu
from oob_manager.cli.prompts import clear_screen
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.target_repository import TargetRepository


def test_all_legacy_menu_functions_are_mapped_to_new_workflows():
    assert set(LEGACY_MENU_COVERAGE) == set(range(1, 19))
    assert "Thêm OOB" in LEGACY_MENU_COVERAGE[1]
    assert "Đồng bộ alias" in LEGACY_MENU_COVERAGE[17]
    assert "theo ngày" in LEGACY_MENU_COVERAGE[18]


def test_main_menu_only_exposes_five_operator_workflows():
    text = render_main_menu()
    for token in ("[1]", "[2]", "[3]", "[4]", "[5]", "[A]", "[H]", "[0]"):
        assert token in text
    assert "OOB & SCAN" in text
    assert "INVENTORY & LỊCH SỬ" in text


def test_clear_screen_is_intentional_noop(capsys):
    clear_screen()
    assert capsys.readouterr().out == ""


def test_workflow_action_sets_cover_all_old_application_actions(tmp_path):
    app = CLIApplication(db_path=tmp_path / "coverage.db", pause_enabled=False)
    # Verify the original 18 actions still exist on the application object.
    names = {
        "add_oob", "list_oobs", "scan_one", "scan_all", "list_targets",
        "search_and_connect", "show_changes", "show_scans", "show_connections",
        "update_oob", "delete_oob", "backup_db", "settings_menu",
        "discover_downstream_identity", "show_device_identities",
        "show_identity_events", "reconcile_oob_alias", "daily_inventory_review",
    }
    assert all(callable(getattr(app, name, None)) for name in names)


def test_smart_token_search_matches_reversed_hyphen_order(tmp_path):
    db = DatabaseConnection(tmp_path / "search.db")
    MigrationManager(db).migrate()
    with db.transaction() as conn:
        conn.execute(
            """
            INSERT INTO oob_devices(
                id,name,host,ssh_port,vendor,device_type,default_username,connection_mode,
                enabled,notes,created_at,updated_at,connection_revision,baseline_revision
            ) VALUES(1,'HCM-OOB-01','192.0.2.1',22,'CISCO','cisco_ios','','SSH',1,'',
                     '2026-07-27T00:00:00+00:00','2026-07-27T00:00:00+00:00',1,1)
            """
        )
        conn.execute(
            """
            INSERT INTO scan_runs(
                id,oob_id,started_at,finished_at,status,mapping_count,complete_count,complete_ratio,
                change_count,warning_count,scanner_version,connection_revision,mapping_quality,baseline_updated
            ) VALUES(20,1,'2026-07-27T00:00:00+00:00','2026-07-27T00:00:01+00:00',
                     'SUCCESS',1,1,1.0,0,0,'1.1.25',1,'ACCEPTED',1)
            """
        )
        conn.execute(
            """
            INSERT INTO console_targets(
                id,oob_id,menu_name,menu_item,alias,command,protocol,target_host,target_port,
                console_line,console_line_source,state,state_confident,state_reason_code,
                state_evidence,source,is_complete,first_seen_at,last_seen_at,last_scan_id
            ) VALUES(10,1,'OOB',1,'HCM-BRAS-CTR-01','telnet 172.28.1.1 2003','TELNET',
                     '172.28.1.1',2003,3,'REVERSE_TELNET_PORT_CONFIRMED','AVAILABLE',1,
                     'LINE_AVAILABLE','{}','CISCO_MENU',1,
                     '2026-07-27T00:00:00+00:00','2026-07-27T00:00:00+00:00',20)
            """
        )
    repo = TargetRepository(db)
    assert len(repo.search("bras-HCM")) == 1
    assert len(repo.search("hcm bras")) == 1
    assert len(repo.search("HCM-BRAS")) == 1
