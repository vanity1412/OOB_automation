from __future__ import annotations

import csv
from pathlib import Path

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings
from oob_manager.models import (
    ConsoleTarget,
    DeviceIdentity,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    IdentityVerification,
    OOBDevice,
    SessionCredentials,
)
from oob_manager.services.export_service import ExportService


def _target(target_id: int, alias: str, port: int, *, state: str = "AVAILABLE", confident: bool = True):
    return ConsoleTarget(
        id=target_id,
        oob_id=1,
        menu_name="OOB",
        menu_item=target_id,
        alias=alias,
        command=f"telnet 172.28.200.11 {port}",
        protocol="TELNET",
        target_host="172.28.200.11",
        target_port=port,
        console_line=port - 2000,
        state=state,
        state_confident=confident,
        is_complete=True,
        last_scan_id=10,
    )


def _result(hostname: str, comparison: str) -> DownstreamDiscoveryResult:
    verification_status = "VERIFIED_MISMATCH" if comparison == "DIFFERENT" else "VERIFIED_MATCH"
    return DownstreamDiscoveryResult(
        identity=DeviceIdentity(
            actual_hostname=hostname,
            vendor="CISCO",
            model="C9300",
            serial_number="SERIAL-1",
            quality="ACCEPTED",
            confidence="HIGH",
            alias_comparison=comparison,
        ),
        verification=IdentityVerification(
            status=verification_status,
            alias_comparison=comparison,
            summary="checked",
        ),
        live_state="AVAILABLE",
        live_state_confident=True,
    )


def test_export_cable_verification_filters_dedicated_mismatch_csv(tmp_path: Path):
    app = CLIApplication(db_path=tmp_path / "export.db", pause_enabled=False)
    service = ExportService(
        app.db,
        ApplicationSettings(export_dir=str(tmp_path / "exports")),
    )
    rows = [
        {
            "detected_at": "2026-07-27T23:00:00+07:00",
            "oob": "HCM-OOB-01",
            "port": "2003",
            "device_a": "DEVICE-A",
            "device_b": "DEVICE-B",
            "status": "MISMATCH",
            "verification_status": "VERIFIED_MISMATCH",
            "identity_quality": "ACCEPTED",
            "alias_comparison": "DIFFERENT",
            "target_id": 1,
            "console_path": "172.28.200.11:2003 / line 3",
            "error_code": "",
            "message": "checked",
        },
        {
            "detected_at": "2026-07-27T23:00:01+07:00",
            "oob": "HCM-OOB-01",
            "port": "2004",
            "device_a": "DEVICE-C",
            "device_b": "DEVICE-C",
            "status": "MATCH",
            "verification_status": "VERIFIED_MATCH",
            "identity_quality": "ACCEPTED",
            "alias_comparison": "EXACT_MATCH",
            "target_id": 2,
            "console_path": "172.28.200.11:2004 / line 4",
            "error_code": "",
            "message": "checked",
        },
    ]
    paths = service.export_cable_verification("HCM-OOB-01", rows)
    assert paths["all"].exists()
    assert paths["mismatch"].exists()
    with paths["mismatch"].open(encoding="utf-8-sig", newline="") as handle:
        mismatch_rows = list(csv.DictReader(handle))
    assert len(mismatch_rows) == 1
    assert list(mismatch_rows[0])[:4] == ["port", "device_a", "device_b", "detected_at"]
    assert mismatch_rows[0]["port"] == "2003"
    assert mismatch_rows[0]["device_a"] == "DEVICE-A"
    assert mismatch_rows[0]["device_b"] == "DEVICE-B"


def test_batch_only_auto_connects_available_confident_targets_and_writes_mismatch(tmp_path: Path):
    app = CLIApplication(db_path=tmp_path / "batch.db", pause_enabled=False)
    app.export_service = ExportService(
        app.db,
        ApplicationSettings(export_dir=str(tmp_path / "exports")),
    )
    device = OOBDevice(
        id=1,
        name="HCM-OOB-01",
        host="192.0.2.1",
        vendor="CISCO",
        connection_revision=1,
        baseline_revision=1,
    )
    available = _target(1, "DEVICE-A", 2003)
    busy = _target(2, "DEVICE-X", 2004, state="BUSY", confident=True)
    unknown = _target(3, "DEVICE-Y", 2005, state="UNKNOWN", confident=False)
    app.target_repo.list_current = lambda _oob_id: [available, busy, unknown]
    app._confirm = lambda _prompt: True
    calls: list[int] = []

    class FakeCableVerificationService:
        def probe(self, target_id, *_args, **_kwargs):
            calls.append(target_id)
            return _result("DEVICE-B", "DIFFERENT")

    app.cable_verification_service = FakeCableVerificationService()
    app._run_batch_cable_verification(
        device,
        SessionCredentials("oob", "secret"),
    )

    assert calls == [1]
    mismatch_files = list((tmp_path / "exports").rglob("cable_mismatch.csv"))
    assert len(mismatch_files) == 1
    with mismatch_files[0].open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 1
    assert rows[0]["port"] == "2003"
    assert rows[0]["device_a"] == "DEVICE-A"
    assert rows[0]["device_b"] == "DEVICE-B"
