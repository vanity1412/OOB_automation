import pytest
from oob_manager.utils.validation import is_valid_host,validate_port,normalize_alias
@pytest.mark.parametrize("host",["192.168.1.1","2001:db8::1","oob-01.example.local"])
def test_valid_host(host):assert is_valid_host(host)
@pytest.mark.parametrize("host",["","bad host","-bad.example","bad_.example"])
def test_invalid_host(host):assert not is_valid_host(host)
def test_port():assert validate_port("22")==22
@pytest.mark.parametrize("p",[0,65536,"x"])
def test_bad_port(p):
 with pytest.raises(Exception):validate_port(p)
def test_alias_normalize():assert normalize_alias("  Router-A   RE0 ")=="router-a re0"
