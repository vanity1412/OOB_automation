from __future__ import annotations

from oob_manager.config import ApplicationSettings
from oob_manager.vendors.vertiv.adapter import VertivOOBAdapter, _clean_terminal_text


def _adapter() -> VertivOOBAdapter:
    return VertivOOBAdapter(ApplicationSettings(command_timeout=1), {"vendor": "VERTIV"})


def test_vertiv_cli_prompt_accepts_ansi_wrapped_prompt():
    adapter = _adapter()
    raw = "\x1b[2J\x1b[HWelcome\r\n\x1b[32m--:- / cli->\x1b[0m"
    assert adapter._extract_cli_prompt(raw) == "--:- / cli->"
    assert adapter._login_state(raw) == "VERTIV_CLI"


def test_vertiv_cli_prompt_accepts_cr_only_terminal_output():
    adapter = _adapter()
    raw = "Welcome to ACS8000\rLast login: today\r--:- access cli->"
    assert adapter._extract_cli_prompt(raw) == "--:- access cli->"
    assert adapter._login_state(raw) == "VERTIV_CLI"


def test_vertiv_busybox_or_bash_root_shell_is_recognized():
    adapter = _adapter()
    for prompt in ("-bash-4.2#", "/ #", "~ #", "sh-5.1$", "[root@acs8000 ~]#"):
        assert adapter._looks_like_shell(prompt), prompt
        assert adapter._login_state(prompt) == "VERTIV_ROOT_SHELL"


def test_login_and_password_prompts_are_not_misclassified_as_shell():
    adapter = _adapter()
    for prompt in ("login:", "Username:", "User Name:", "Password:"):
        assert not adapter._looks_like_shell(prompt), prompt
        assert adapter._login_state(prompt) is None


def test_terminal_cleaner_applies_backspaces_without_corrupting_prompt():
    raw = "garbageX\x08\r\n--:- / cli->"
    assert _clean_terminal_text(raw).splitlines()[-1] == "--:- / cli->"
