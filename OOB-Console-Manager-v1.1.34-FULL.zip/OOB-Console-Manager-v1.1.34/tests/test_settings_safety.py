import pytest

from oob_manager.cli.application import CLIApplication
from oob_manager.exceptions import ValidationError


def test_invalid_setting_is_not_persisted(tmp_path):
    app = CLIApplication(
        db_path=tmp_path / "settings.db",
        input_func=lambda prompt="": "",
        pause_enabled=False,
    )
    with pytest.raises(ValidationError):
        app._save_settings({"connect_timeout": "not-a-number"})
    assert "connect_timeout" not in app.settings_repo.get_all()
