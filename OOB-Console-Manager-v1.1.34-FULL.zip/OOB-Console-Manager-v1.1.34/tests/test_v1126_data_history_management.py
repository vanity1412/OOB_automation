from __future__ import annotations

import re
from pathlib import Path

from oob_manager.cli.application import CLIApplication
from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.services.backup_service import BackupService
from oob_manager.services.export_service import ExportService


def _seed(db: DatabaseConnection) -> None:
    with db.transaction() as conn:
        conn.execute(
            """
            INSERT INTO oob_devices(
                id,name,host,ssh_port,vendor,device_type,default_username,connection_mode,
                enabled,notes,created_at,updated_at,connection_revision,baseline_revision
            ) VALUES(1,'CTO-OOB-02','192.0.2.10',22,'CISCO','cisco_ios','','SSH',1,'',
                     '2026-07-27T06:00:00+00:00','2026-07-27T06:00:00+00:00',1,1)
            """
        )
        conn.execute(
            """
            INSERT INTO scan_runs(
                id,oob_id,started_at,finished_at,status,mapping_count,complete_count,
                complete_ratio,change_count,warning_count,scanner_version,connection_revision,
                mapping_quality,baseline_updated,oob_name_at_scan,oob_host_at_scan,
                oob_ssh_port_at_scan,vendor_at_scan,connection_mode_at_scan,device_type_at_scan
            ) VALUES(10,1,'2026-07-27T06:00:00+00:00','2026-07-27T06:00:05+00:00',
                     'SUCCESS',1,1,1.0,0,0,'1.1.26',1,'ACCEPTED',1,
                     'CTO-OOB-02','192.0.2.10',22,'CISCO','SSH','cisco_ios')
            """
        )
        conn.execute(
            """
            INSERT INTO console_targets(
                id,oob_id,menu_name,menu_item,alias,command,protocol,target_host,target_port,
                console_line,console_line_source,state,state_confident,state_reason_code,
                state_evidence,source,is_complete,first_seen_at,last_seen_at,last_scan_id
            ) VALUES(100,1,'OOB',8,'CTO-BRAS-08','telnet 192.0.2.36 2010','TELNET',
                     '192.0.2.36',2010,10,'REVERSE_TELNET_PORT_CONFIRMED','AVAILABLE',1,
                     'LINE_AVAILABLE','{}','CISCO_MENU',1,
                     '2026-07-27T06:00:05+00:00','2026-07-27T06:00:05+00:00',10)
            """
        )
        conn.execute(
            """
            INSERT INTO console_snapshots(
                target_id,scan_id,oob_id,menu_name,menu_item,alias,command,protocol,
                target_host,target_port,console_line,console_line_source,state,state_confident,
                state_reason_code,state_evidence,source,is_complete,captured_at
            ) VALUES(100,10,1,'OOB',8,'CTO-BRAS-08','telnet 192.0.2.36 2010','TELNET',
                     '192.0.2.36',2010,10,'REVERSE_TELNET_PORT_CONFIRMED','AVAILABLE',1,
                     'LINE_AVAILABLE','{}','CISCO_MENU',1,'2026-07-27T06:00:05+00:00')
            """
        )


def test_v1126_output_tree_is_operator_friendly_and_run_artifacts_do_not_overwrite(tmp_path: Path):
    db = DatabaseConnection(tmp_path / 'db.sqlite')
    MigrationManager(db).migrate()
    _seed(db)
    service = ExportService(db, ApplicationSettings(export_dir=str(tmp_path / 'exports')))

    paths = service.export_after_scan(10)
    assert paths['run_dir'].parent.name == 'runs'
    assert (paths['run_dir'] / 'inventory.csv').exists()
    assert (paths['run_dir'] / 'scan_summary.csv').exists()
    assert (paths['run_dir'] / 'changes.csv').exists()
    assert paths['latest'].parent.name == 'latest'
    assert paths['daily'].parent.name == 'daily'

    second = service.export_scan_run(10)
    assert second != paths['run_dir']
    assert second.exists()

    full1 = service.export_all()
    full2 = service.export_all()
    assert full1.parent.name == 'advanced'
    assert full2.parent.name == 'advanced'
    assert full1 != full2


def test_v1126_target_history_and_scan_id_snapshot(tmp_path: Path):
    db = DatabaseConnection(tmp_path / 'db.sqlite')
    MigrationManager(db).migrate()
    _seed(db)
    service = ExportService(db, ApplicationSettings(export_dir=str(tmp_path / 'exports')))

    candidates = service.search_history_targets('bras-CTO')
    assert len(candidates) == 1
    assert candidates[0]['target_id'] == 100

    history = service.target_history_rows(100)
    assert len(history) == 1
    assert history[0]['scan_id'] == 10
    assert history[0]['console_path'] == '192.0.2.36:2010 / line 10'

    summary = service.get_scan_summary(10)
    assert summary is not None
    assert summary['oob_name'] == 'CTO-OOB-02'
    assert summary['mapping_quality'] == 'ACCEPTED'

    snapshot = service.scan_snapshot_rows(10)
    assert len(snapshot) == 1
    assert snapshot[0]['target_alias'] == 'CTO-BRAS-08'


def test_v1126_backup_is_grouped_by_day(tmp_path: Path):
    db = DatabaseConnection(tmp_path / 'db.sqlite')
    MigrationManager(db).migrate()
    path = BackupService(db, backup_dir=tmp_path / 'backups').create_backup()
    assert path.parent.parent == tmp_path / 'backups'
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}', path.parent.name)
    assert path.name.startswith('oob_manager_')
    assert path.with_suffix(path.suffix + '.sha256').exists()


def test_v1126_vertiv_busy_guide_uses_official_active_sessions_commands(tmp_path: Path, capsys):
    app = CLIApplication(db_path=tmp_path / 'cli.db', pause_enabled=False)
    app._show_vertiv_session_recovery_guide('HCM-BRAS-02-01')
    text = capsys.readouterr().out
    assert 'cd active_sessions' in text
    assert 'kill_session <session_id>' in text
    assert 'cd access' in text
    assert 'connect <port_name>' in text
    assert 'disconnect port5' in text  # explicitly called out as unsupported guidance
    assert 'chưa khớp command set ACS800/8000 chính thức' in text


def test_v1126_session_log_path_is_grouped_by_day(tmp_path: Path, monkeypatch):
    from oob_manager.models import ConsoleOpenResult, ConsoleTarget, OOBDevice, SessionCredentials
    from oob_manager.services.console_service import ConsoleService
    import oob_manager.services.console_service as console_module

    session_root = tmp_path / 'session_logs'
    monkeypatch.setattr(console_module, 'SESSION_LOG_DIR', session_root)

    target = ConsoleTarget(
        id=10, oob_id=1, alias='HCM-BRAS-01', protocol='VERTIV_CLI',
        console_line=1, state='AVAILABLE', state_confident=True, is_complete=True,
        last_scan_id=5,
    )
    device = OOBDevice(id=1, name='HCM-ACS-01', host='192.0.2.50', vendor='VERTIV')

    class OOBRepo:
        def get(self, _id): return device
        def sync_profile_fingerprint(self, _id, _fp): return device

    class TargetRepo:
        def get(self, _id): return target
        def verify_open_provenance(self, _id): return True, 'OK', 'ok'

    class ConnectionRepo:
        def __init__(self): self.path = ''
        def start(self, *args, **kwargs): return 77
        def set_session_log_path(self, _id, path): self.path = path
        def update_ssh_host_key(self, *args, **kwargs): pass
        def finish(self, *args, **kwargs): pass

    class Adapter:
        profile = {}
        def open_console(self, *args, **kwargs):
            assert Path(self.session_log_path).parent.parent == session_root
            return ConsoleOpenResult()

    connection_repo = ConnectionRepo()
    service = ConsoleService(
        OOBRepo(), TargetRepo(), connection_repo, ApplicationSettings(),
        adapter_factory=lambda *_args, **_kwargs: Adapter(),
    )
    service.open(10, SessionCredentials('u', 'p'))
    assert re.fullmatch(r'session_logs/\d{4}-\d{2}-\d{2}/conn_77_HCM-BRAS-01\.log', connection_repo.path)
