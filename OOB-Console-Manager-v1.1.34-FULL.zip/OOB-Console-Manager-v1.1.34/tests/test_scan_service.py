from pathlib import Path
from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.database.repositories.target_repository import TargetRepository
from oob_manager.database.repositories.scan_repository import ScanRepository
from oob_manager.database.repositories.change_repository import ChangeRepository
from oob_manager.database.repositories.scan_lock_repository import ScanLockRepository
from oob_manager.models import OOBDevice,ConsoleTarget,SessionCredentials,VendorScanData,RawCommandOutput
from oob_manager.services.scan_service import ScanService
class FakeAdapter:
 def __init__(self,targets,optional_fail=False):self.targets=targets;self.optional_fail=optional_fail
 def collect(self,d,c):return VendorScanData(True,"NORMAL_CLI",self.targets,[RawCommandOutput("menu","show", "menu OOB text [1] X",True,is_core=True),RawCommandOutput("users","show users","",not self.optional_fail,is_core=False)])
def target(i):return ConsoleTarget(menu_name="OOB",menu_item=i,alias=f"R{i}",command=f"telnet 10.0.0.1 {2000+i}",protocol="TELNET",target_host="10.0.0.1",target_port=2000+i,is_complete=True,state="AVAILABLE")
def setup(tmp_path):
 db=DatabaseConnection(tmp_path/"x.db");MigrationManager(db).migrate();or_=OOBRepository(db);tr=TargetRepository(db);sr=ScanRepository(db);cr=ChangeRepository(db);lr=ScanLockRepository(db);d=or_.create(OOBDevice(name="OOB1",host="127.0.0.1"));return db,or_,tr,sr,cr,lr,d
def test_scan_success(tmp_path):
 db,o,t,s,c,l,d=setup(tmp_path);svc=ScanService(o,t,s,c,l,ApplicationSettings(),adapter_factory=lambda dev,sett:FakeAdapter([target(i) for i in range(1,17)]));r=svc.scan_one(d.id,SessionCredentials("u","p"));assert r.status=="SUCCESS";assert len(t.list_current(d.id))==16
def test_drop_rejected_keeps_baseline(tmp_path):
 db,o,t,s,c,l,d=setup(tmp_path);settings=ApplicationSettings();svc=ScanService(o,t,s,c,l,settings,adapter_factory=lambda dev,sett:FakeAdapter([target(i) for i in range(1,17)]));assert svc.scan_one(d.id,SessionCredentials("u","p")).status=="SUCCESS"
 svc.adapter_factory=lambda dev,sett:FakeAdapter([target(1),target(2)]);r=svc.scan_one(d.id,SessionCredentials("u","p"));assert r.status=="REJECTED";assert len(t.list_current(d.id))==16
 with db.read() as conn:assert conn.execute("SELECT COUNT(*) FROM change_events WHERE event_code='CONSOLE_TARGET_MISSING'").fetchone()[0]==0
