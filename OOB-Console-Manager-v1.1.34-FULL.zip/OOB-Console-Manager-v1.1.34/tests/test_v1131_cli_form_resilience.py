from __future__ import annotations

from pathlib import Path

from oob_manager.cli.application import CLIApplication
from oob_manager.models import ConnectionTestResult, OOBDevice


def _create_device(app: CLIApplication, *, name="HCM-OOB-01", vendor="CISCO", enabled=True):
    return app.oob_service.create(
        OOBDevice(
            name=name,
            host="192.0.2.10",
            ssh_port=22,
            vendor=vendor,
            device_type="cisco_ios" if vendor == "CISCO" else "vertiv",
            default_username="noc-net",
            connection_mode="SSH",
            notes="keep-note",
            enabled=enabled,
        )
    )


def test_update_oob_invalid_vendor_and_enabled_retry_without_losing_form(tmp_path, monkeypatch):
    answers = iter([
        "",            # name: keep
        "",            # host: keep
        "",            # port: keep
        "3",           # invalid vendor -> retry
        "2",           # VERTIV
        "",            # username keep
        "updated-note",# notes
        "yy",          # invalid enabled -> retry
        "n",           # disable
    ])
    app = CLIApplication(
        db_path=tmp_path / "update-retry.db",
        input_func=lambda _p="": next(answers),
        pause_enabled=False,
    )
    device = _create_device(app)
    monkeypatch.setattr(app, "_select_oob", lambda _include_disabled=True: device)

    app.update_oob()

    saved = app.oob_service.get(device.id)
    assert saved is not None
    assert saved.name == "HCM-OOB-01"
    assert saved.host == "192.0.2.10"
    assert saved.vendor == "VERTIV"
    assert saved.device_type == "vertiv"
    assert saved.notes == "updated-note"
    assert saved.enabled is False


def test_delete_oob_confirmation_trims_outer_whitespace_but_stays_case_sensitive(tmp_path, monkeypatch):
    app = CLIApplication(db_path=tmp_path / "delete-trim.db", pause_enabled=False)
    device = _create_device(app, name="HCM-OOB-DELETE")
    monkeypatch.setattr(app, "_select_oob", lambda _include_disabled=True: device)
    answers = iter(["2", "HCM-OOB-DELETE   "])
    app._input_func = lambda _p="": next(answers)
    app.input = app._safe_input
    monkeypatch.setattr(app.backup_service, "create_backup", lambda: Path("backup.db"))

    app.delete_oob()
    assert app.oob_service.get(device.id) is None

    # Case-sensitive confirmation remains intentional.
    device2 = _create_device(app, name="HCM-OOB-CASE")
    monkeypatch.setattr(app, "_select_oob", lambda _include_disabled=True: device2)
    answers2 = iter(["2", "hcm-oob-case"])
    app._input_func = lambda _p="": next(answers2)
    app.input = app._safe_input
    app.delete_oob()
    assert app.oob_service.get(device2.id) is not None


def test_add_oob_connection_failure_can_retry_same_credentials_without_reentering_form(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "LAB-OOB", "192.0.2.20", "", "1", "noc-net", "note",
        "1",       # test then save
        "",        # username -> default noc-net
        "1",       # failure recovery: retry same credential
        "c",       # verified -> save
        "n",       # do not set session default
    ])
    passwords = iter(["secret", "enable"])
    app = CLIApplication(
        db_path=tmp_path / "add-retry.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    calls = []

    class Adapter:
        def test_connection(self, device, credentials):
            calls.append((device.host, credentials.username, credentials.password))
            if len(calls) == 1:
                return ConnectionTestResult(False, "NORMAL_CLI", "temporary timeout")
            return ConnectionTestResult(True, "NORMAL_CLI", "verified")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()

    assert len(calls) == 2
    assert calls[0] == calls[1]
    saved = app.oob_service.list_all()[0]
    assert saved.name == "LAB-OOB"
    assert saved.notes == "note"
    assert saved.default_username == "noc-net"


def test_add_oob_connection_failure_can_replace_credentials_and_store_verified_username(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "LAB-OOB", "192.0.2.21", "", "1", "noc-net", "",
        "1",       # test then save
        "",        # first username noc-net
        "2",       # failure recovery: new credential
        "lab-admin",# replacement username
        "c",       # save after success
        "n",       # don't set session default
    ])
    passwords = iter([
        "bad-pass", "bad-enable",
        "good-pass", "good-enable",
    ])
    app = CLIApplication(
        db_path=tmp_path / "add-new-cred.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    seen = []

    class Adapter:
        def test_connection(self, device, credentials):
            seen.append(credentials.username)
            if len(seen) == 1:
                return ConnectionTestResult(False, "NORMAL_CLI", "auth failed")
            return ConnectionTestResult(True, "NORMAL_CLI", "verified")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()

    assert seen == ["noc-net", "lab-admin"]
    saved = app.oob_service.list_all()[0]
    assert saved.default_username == "lab-admin"


def test_add_oob_connection_failure_can_edit_connection_without_reentering_form(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "VERTIV-OOB", "192.0.2.30", "", "2", "noc-net", "preserved-note",
        "1",       # test then save
        "",        # username default
        "3",       # recovery: edit connection
        "192.0.2.31", # new host
        "",        # keep port
        "",        # keep vendor
        "c",       # save after success
        "n",       # don't set session default
    ])
    passwords = iter(["secret"])
    app = CLIApplication(
        db_path=tmp_path / "add-edit.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    hosts = []

    class Adapter:
        def test_connection(self, device, credentials):
            hosts.append(device.host)
            if len(hosts) == 1:
                return ConnectionTestResult(False, "ACS_CLI", "refused")
            return ConnectionTestResult(True, "ACS_CLI", "verified")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()

    assert hosts == ["192.0.2.30", "192.0.2.31"]
    saved = app.oob_service.list_all()[0]
    assert saved.host == "192.0.2.31"
    assert saved.vendor == "VERTIV"
    assert saved.notes == "preserved-note"


def test_add_oob_failed_test_can_save_unverified_without_promoting_failed_credentials(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "UNVERIFIED-OOB", "192.0.2.40", "", "1", "noc-net", "",
        "1",       # test then save
        "",        # username
        "4",       # save unverified
    ])
    passwords = iter(["bad-pass", "bad-enable"])
    app = CLIApplication(
        db_path=tmp_path / "add-unverified.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )

    class Adapter:
        def test_connection(self, device, credentials):
            return ConnectionTestResult(False, "NORMAL_CLI", "auth failed")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()

    rows = app.oob_service.list_all()
    assert len(rows) == 1
    assert rows[0].name == "UNVERIFIED-OOB"
    assert not app.session_credentials.has_any()
    assert app.scan_repo.list_recent() == []


def test_add_oob_failed_test_cancel_creates_nothing(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "CANCEL-OOB", "192.0.2.41", "", "1", "noc-net", "",
        "1", "", "0",
    ])
    passwords = iter(["bad-pass", "bad-enable"])
    app = CLIApplication(
        db_path=tmp_path / "add-cancel.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )

    class Adapter:
        def test_connection(self, device, credentials):
            return ConnectionTestResult(False, "NORMAL_CLI", "failed")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()
    assert app.oob_service.list_all() == []


def test_runtime_cli_messages_do_not_use_personal_second_person_language():
    root = Path(__file__).resolve().parents[1] / "oob_manager"
    offenders = []
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8").casefold()
        if "bạn" in text or "hãy " in text:
            offenders.append(str(path.relative_to(root.parent)))
    assert offenders == []


def test_add_oob_adapter_exception_enters_recovery_loop_and_can_retry(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "EXCEPTION-OOB", "192.0.2.50", "", "2", "noc-net", "",
        "1", "", "1", "c", "n",
    ])
    passwords = iter(["secret"])
    app = CLIApplication(
        db_path=tmp_path / "add-exception.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    calls = 0

    class Adapter:
        def test_connection(self, device, credentials):
            nonlocal calls
            calls += 1
            if calls == 1:
                raise RuntimeError("simulated transport failure")
            return ConnectionTestResult(True, "ACS_CLI", "verified")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()
    assert calls == 2
    assert app.oob_service.list_all()[0].name == "EXCEPTION-OOB"


def test_add_oob_edit_vendor_reprompts_vendor_appropriate_credentials(tmp_path, monkeypatch):
    import oob_manager.vendors.factory as factory

    answers = iter([
        "CHANGE-VENDOR", "192.0.2.60", "", "2", "noc-net", "",
        "1", "",       # initial Vertiv credential username
        "3",             # edit connection after failure
        "", "", "1",  # keep host/port, change to Cisco
        "",              # Cisco credential username
        "c", "n",
    ])
    passwords = iter([
        "vertiv-pass",
        "cisco-pass", "cisco-enable",
    ])
    app = CLIApplication(
        db_path=tmp_path / "add-change-vendor.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    seen = []

    class Adapter:
        def test_connection(self, device, credentials):
            seen.append((device.vendor, credentials.password, credentials.enable_password))
            if len(seen) == 1:
                return ConnectionTestResult(False, "ACS_CLI", "wrong endpoint type")
            return ConnectionTestResult(True, "NORMAL_CLI", "verified")

    monkeypatch.setattr(factory, "create_vendor_adapter", lambda _d, _s: Adapter())
    app.add_oob()

    assert seen == [
        ("VERTIV", "vertiv-pass", None),
        ("CISCO", "cisco-pass", "cisco-enable"),
    ]
    saved = app.oob_service.list_all()[0]
    assert saved.vendor == "CISCO"
    assert saved.device_type == "cisco_ios"
