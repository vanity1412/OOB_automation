# v1.1.33 - Live Hostname Verification Hardening

Mục tiêu: không dùng alias trong cấu hình OOB làm hostname thật. Verify phải đi qua đúng console path và thu identity trực tiếp từ downstream.

## Thay đổi chính

- Verify-All không hỏi credential downstream từ đầu batch.
- Cisco flow: SSH OOB -> live verify mapping/show line/show users -> reverse Telnet đúng IP:port -> đọc CLI/login prompt thật.
- Nếu console đã ở CLI, tool chạy whitelist identity command ngay, không gửi username/password.
- Chỉ khi downstream thật sự trả `User Name:`, `Username:`, `login:` hoặc `Password:` mới hỏi credential, ngay trong cùng console session.
- Hỗ trợ prompt có ANSI/NUL/backspace và Huawei `<hostname>`, `[hostname]`, `[~hostname]`.
- Huawei đọc thêm read-only `display current-configuration | include sysname` để có hostname evidence độc lập với prompt.
- Cisco/Juniper hostname từ command output được đối chiếu với hostname từ prompt. Nếu hai nguồn mâu thuẫn, identity bị REJECTED/INCONCLUSIVE; không tạo MATCH giả.
- Cisco Identity/Verify-All dùng controlled stale-line recovery khi reverse Telnet trả `Connection refused`: fresh live check, đúng line được show-line xác nhận, AVAILABLE, operator confirm + reason, `clear line <N>`, hậu kiểm, retry Telnet đúng 1 lần.
- Không bao giờ dùng `clear line *`; BUSY/UNKNOWN không được clear.
- Credential downstream nhập on-demand chỉ nằm trong RAM; password động được bổ sung vào secret-redaction set. Username không bí mật được cập nhật vào identity-run audit khi thực sự sử dụng.
- Verification CSV có thêm `hostname_source` và `hostname_conflict`.

## Safety

- Không tự sửa alias OOB.
- Không tự clear line.
- Không clear BUSY/UNKNOWN.
- Không suy hostname từ configured alias.
- Không promote identity khi prompt và command hostname mâu thuẫn.
- Không lưu downstream password vào DB/log/CSV.

## Verification

- Python compileall: PASS
- Pytest: 307 PASS
- DB schema: v16 (không migration)
- SQLite integrity_check: ok
- foreign_key_check: 0
