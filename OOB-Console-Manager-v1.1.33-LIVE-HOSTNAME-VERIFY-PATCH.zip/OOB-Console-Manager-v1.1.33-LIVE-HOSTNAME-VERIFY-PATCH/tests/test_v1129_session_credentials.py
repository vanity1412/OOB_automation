from __future__ import annotations

from oob_manager.cli.application import CLIApplication
from oob_manager.cli.menus import render_main_menu, render_title
from oob_manager.cli.session_credentials import SessionCredentialStore
from oob_manager.config import ApplicationSettings
from oob_manager.database.connection import DatabaseConnection
from oob_manager.database.migrations import MigrationManager
from oob_manager.database.repositories.oob_repository import OOBRepository
from oob_manager.models import OOBDevice, ScanResult, SessionCredentials
from oob_manager.services.oob_service import OOBService
from oob_manager.services.scan_service import ScanService
from oob_manager.utils.datetime_utils import utc_now


def test_v1129_main_menu_exposes_ram_credential_session():
    assert "[C]" in render_main_menu()
    assert "Credential phiên" in render_main_menu()
    assert "1.1.33" in render_title()


def test_v1129_session_store_precedence_and_vertiv_drops_enable():
    store = SessionCredentialStore()
    cisco = OOBDevice(id=1, vendor="CISCO")
    vertiv = OOBDevice(id=2, vendor="VERTIV")

    store.set_default(SessionCredentials("shared", "pw-shared", "enable-shared"))
    cred, source = store.resolve(vertiv)
    assert source == "SESSION_DEFAULT"
    assert cred.username == "shared"
    assert cred.password == "pw-shared"
    assert cred.enable_password is None

    store.set_vendor("CISCO", SessionCredentials("cisco", "pw-cisco", "enable-cisco"))
    cred, source = store.resolve(cisco)
    assert source == "VENDOR_CISCO"
    assert cred.username == "cisco"
    assert cred.enable_password == "enable-cisco"

    store.set_oob(1, "CISCO", SessionCredentials("special", "pw-special", "enable-special"))
    cred, source = store.resolve(cisco)
    assert source == "OOB_OVERRIDE"
    assert cred.username == "special"
    assert cred.password == "pw-special"


def test_v1129_default_username_persists_but_password_never_enters_oob_row(tmp_path):
    db = DatabaseConnection(tmp_path / "username.db")
    MigrationManager(db).migrate()
    service = OOBService(OOBRepository(db))
    saved = service.create(
        OOBDevice(
            name="OOB-USER",
            host="192.0.2.10",
            vendor="CISCO",
            default_username="noc-net",
        )
    )
    loaded = service.get(saved.id)
    assert loaded.default_username == "noc-net"

    with db.read() as conn:
        row = conn.execute("SELECT * FROM oob_devices WHERE id=?", (saved.id,)).fetchone()
        serialized = "|".join(str(value) for value in row)
    assert "noc-net" in serialized
    assert "password-A" not in serialized


def test_v1129_credentials_use_session_without_prompt_and_vertiv_ignores_enable(tmp_path):
    def no_input(_prompt=""):
        raise AssertionError("Không được hỏi input khi credential session đã đủ")

    def no_getpass(_prompt=""):
        raise AssertionError("Không được hỏi password khi credential session đã đủ")

    app = CLIApplication(
        db_path=tmp_path / "cli.db",
        input_func=no_input,
        getpass_func=no_getpass,
        pause_enabled=False,
    )
    app.session_credentials.set_default(
        SessionCredentials("noc-net", "shared-secret", "enable-secret")
    )

    cisco = OOBDevice(id=1, vendor="CISCO", default_username="saved-user")
    vertiv = OOBDevice(id=2, vendor="VERTIV", default_username="saved-user")
    cisco_cred = app._credentials(cisco)
    vertiv_cred = app._credentials(vertiv)

    assert cisco_cred.username == "noc-net"
    assert cisco_cred.password == "shared-secret"
    assert cisco_cred.enable_password == "enable-secret"
    assert vertiv_cred.username == "noc-net"
    assert vertiv_cred.password == "shared-secret"
    assert vertiv_cred.enable_password is None


def test_v1129_prompt_uses_saved_default_username(tmp_path):
    answers = iter([""])
    passwords = iter(["ssh-secret", ""])
    app = CLIApplication(
        db_path=tmp_path / "prompt.db",
        input_func=lambda _p="": next(answers),
        getpass_func=lambda _p="": next(passwords),
        pause_enabled=False,
    )
    cred = app._prompt_credentials(
        OOBDevice(vendor="CISCO", default_username="noc-saved")
    )
    assert cred.username == "noc-saved"
    assert cred.password == "ssh-secret"
    assert cred.enable_password is None


def test_v1129_scan_all_with_loaded_session_never_prompts_credentials(tmp_path, monkeypatch):
    app = CLIApplication(db_path=tmp_path / "batch.db", pause_enabled=False)
    devices = [
        OOBDevice(id=1, name="CISCO-1", host="192.0.2.1", vendor="CISCO"),
        OOBDevice(id=2, name="VERTIV-1", host="192.0.2.2", vendor="VERTIV"),
    ]
    monkeypatch.setattr(app.oob_service, "list_all", lambda include_disabled=False: devices)
    app.session_credentials.set_default(SessionCredentials("noc", "pw", "enable"))
    seen = []

    def fake_scan_all(provider, *, trigger_source, auth_failure_handler=None):
        for device in devices:
            seen.append((device.vendor, provider(device)))
        return [
            ScanResult(None, 1, "SUCCESS", finished_at=utc_now()),
            ScanResult(None, 2, "SUCCESS", finished_at=utc_now()),
        ]

    monkeypatch.setattr(app.scan_service, "scan_all", fake_scan_all)
    monkeypatch.setattr(
        app,
        "_read_menu_token",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("Không được hỏi credential mode")),
    )
    app.scan_all()

    assert seen[0][1].username == "noc"
    assert seen[0][1].enable_password == "enable"
    assert seen[1][1].username == "noc"
    assert seen[1][1].enable_password is None


class _Repo:
    def __init__(self, devices):
        self.devices = devices

    def list_all(self, include_disabled=False):
        return self.devices


class _Dummy:
    pass


def _minimal_scan_service(devices):
    return ScanService(
        _Repo(devices),
        _Dummy(),
        _Dummy(),
        _Dummy(),
        _Dummy(),
        ApplicationSettings(),
        change_service=_Dummy(),
    )


def test_v1129_scan_service_auth_retry_only_retries_current_oob(monkeypatch):
    devices = [
        OOBDevice(id=1, name="NORMAL-1", vendor="CISCO"),
        OOBDevice(id=2, name="LAB-1", vendor="CISCO"),
        OOBDevice(id=3, name="NORMAL-2", vendor="CISCO"),
    ]
    service = _minimal_scan_service(devices)
    calls = []

    def fake_scan_one(oob_id, credentials, *, trigger_source):
        calls.append((oob_id, credentials.username, credentials.password))
        if oob_id == 2 and credentials.username == "shared":
            return ScanResult(
                None, oob_id, "FAILED", error_code="SSH_AUTHENTICATION_FAILED",
                error_message="auth failed", finished_at=utc_now()
            )
        return ScanResult(None, oob_id, "SUCCESS", finished_at=utc_now())

    monkeypatch.setattr(service, "scan_one", fake_scan_one)
    shared = SessionCredentials("shared", "pw-A", "enable-A")
    special = SessionCredentials("lab-admin", "pw-B", "enable-B")

    def provider(_device):
        return shared

    def handler(device, _current, _result):
        assert device.id == 2
        return "RETRY", special

    results = service.scan_all(provider, auth_failure_handler=handler)
    assert [r.status for r in results] == ["SUCCESS", "SUCCESS", "SUCCESS"]
    assert calls == [
        (1, "shared", "pw-A"),
        (2, "shared", "pw-A"),
        (2, "lab-admin", "pw-B"),
        (3, "shared", "pw-A"),
    ]


def test_v1129_scan_service_auth_skip_continues_and_cancel_stops(monkeypatch):
    devices = [
        OOBDevice(id=1, name="OOB-1", vendor="CISCO"),
        OOBDevice(id=2, name="OOB-2", vendor="CISCO"),
        OOBDevice(id=3, name="OOB-3", vendor="CISCO"),
    ]
    shared = SessionCredentials("shared", "wrong")

    service = _minimal_scan_service(devices)
    calls = []

    def fake_scan_one(oob_id, credentials, *, trigger_source):
        calls.append(oob_id)
        if oob_id in {1, 2}:
            return ScanResult(None, oob_id, "FAILED", error_code="SSH_AUTHENTICATION_FAILED")
        return ScanResult(None, oob_id, "SUCCESS")

    monkeypatch.setattr(service, "scan_one", fake_scan_one)
    decisions = iter([("SKIP", None), ("CANCEL", None)])
    results = service.scan_all(
        lambda _device: shared,
        auth_failure_handler=lambda *_args: next(decisions),
    )
    assert [r.status for r in results] == ["FAILED", "CANCELLED"]
    assert calls == [1, 2]


def test_v1129_session_clear_removes_all_references():
    store = SessionCredentialStore()
    store.set_default(SessionCredentials("a", "secret"))
    store.set_vendor("CISCO", SessionCredentials("b", "secret2"))
    store.set_oob(9, "VERTIV", SessionCredentials("c", "secret3"))
    assert store.has_any()
    store.clear()
    assert not store.has_any()
    assert store.status_rows() == []


def test_v1129_cisco_enable_auth_failure_uses_same_retry_path(monkeypatch):
    device = OOBDevice(id=7, name="CISCO-ENABLE", vendor="CISCO")
    service = _minimal_scan_service([device])
    calls = []

    def fake_scan_one(oob_id, credentials, *, trigger_source):
        calls.append(credentials.enable_password)
        if credentials.enable_password != "right-enable":
            return ScanResult(
                77,
                oob_id,
                "FAILED",
                error_code="ENABLE_FAILED",
                error_message="enable rejected",
                finished_at=utc_now(),
            )
        return ScanResult(78, oob_id, "SUCCESS", finished_at=utc_now())

    monkeypatch.setattr(service, "scan_one", fake_scan_one)
    results = service.scan_all(
        lambda _device: SessionCredentials("noc", "ssh", "wrong-enable"),
        auth_failure_handler=lambda *_args: (
            "RETRY",
            SessionCredentials("noc", "ssh", "right-enable"),
        ),
    )
    assert [r.status for r in results] == ["SUCCESS"]
    assert calls == ["wrong-enable", "right-enable"]
