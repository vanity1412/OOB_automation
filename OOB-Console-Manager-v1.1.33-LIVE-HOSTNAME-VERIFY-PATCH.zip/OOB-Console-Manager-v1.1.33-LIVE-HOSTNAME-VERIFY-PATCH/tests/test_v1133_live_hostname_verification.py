from __future__ import annotations

from types import SimpleNamespace

import pytest

from oob_manager.config import ApplicationSettings
from oob_manager.downstream.collector import DownstreamIdentityCollector
from oob_manager.downstream.parsers import hostname_from_prompt, parse_identity
from oob_manager.models import (
    ConsoleTarget,
    DownstreamCredentials,
    DownstreamDiscoveryResult,
    OOBDevice,
    SessionCredentials,
)
from oob_manager.vendors.cisco.adapter import CiscoOOBAdapter


class _LazyLoginChannel:
    def __init__(self):
        self.sent: list[str] = []
        self.queue: list[bytes] = []

    def send(self, value: str):
        self.sent.append(value)
        command = value.strip()
        if value == "\n":
            self.queue.append(b"\x1b[32mUser Name:\x1b[0m")
        elif command == "down-user":
            self.queue.append(b"Password:")
        elif command == "down-pass":
            self.queue.append(b"\r\n\x1b[32mHCM-CDNLeaf-Quan9-10G-01#\x1b[0m")
        elif command == "show version":
            self.queue.append(
                b"show version\r\nCisco IOS XE Software, Version 17.09.04a\r\n"
                b"HCM-CDNLeaf-Quan9-10G-01 uptime is 5 days\r\n"
                b"Processor board ID FDO1234ABCD\r\n"
                b"\x1b[32mHCM-CDNLeaf-Quan9-10G-01#\x1b[0m"
            )
        elif command == "show inventory":
            self.queue.append(
                b"show inventory\r\nNAME: \"Chassis\", DESCR: \"Cisco Chassis\"\r\n"
                b"PID: N9K-C93180YC-FX, VID: V01, SN: FDO1234ABCD\r\n"
                b"\x1b[32mHCM-CDNLeaf-Quan9-10G-01#\x1b[0m"
            )
        return len(value)

    def recv_ready(self):
        return bool(self.queue)

    def recv(self, _size: int):
        return self.queue.pop(0) if self.queue else b""


class _LazyLoginSSH:
    def read_until_state(self, channel, detector, timeout=None, settle=None, initial=""):
        text = initial or ""
        state = detector(text)
        if state:
            return text, state
        while channel.queue:
            text += channel.recv(65535).decode("utf-8", errors="replace")
            state = detector(text)
            if state:
                return text, state
        return text, detector(text)

    def read_until_quiet(self, channel, timeout=None, quiet=None):
        chunks = []
        while channel.queue:
            chunks.append(channel.recv(65535).decode("utf-8", errors="replace"))
        return "".join(chunks)

    def drain_channel(self, channel):
        return self.read_until_quiet(channel)


def test_real_console_prompt_detection_handles_ansi_user_name_and_huawei_views():
    collector = DownstreamIdentityCollector(_LazyLoginSSH(), command_timeout=1)
    assert collector._authentication_state("\x1b[33mUser Name:\x1b[0m") == "USERNAME"
    assert collector.extract_device_prompt("\x1b[32mHCM-CDNLeaf-01#\x1b[0m") == "HCM-CDNLeaf-01#"
    assert collector.extract_device_prompt("\x00[~PE-HN-0X\b1]") == "[~PE-HN-01]"
    assert hostname_from_prompt("[~PE-HN-01]", "HUAWEI") == "PE-HN-01"


def test_lazy_downstream_credential_is_requested_inside_same_console_session_and_hostname_is_collected():
    channel = _LazyLoginChannel()
    collector = DownstreamIdentityCollector(_LazyLoginSSH(), command_timeout=1)
    provider_calls = []

    def provider(context):
        provider_calls.append(dict(context))
        return DownstreamCredentials("down-user", "down-pass")

    result = collector.collect(
        channel,
        "Trying 172.28.200.11, 2003 ... Open\r\n",
        DownstreamCredentials(),
        "HCM-CDNLeaf-Quan9-10G-01",
        credential_provider=provider,
    )

    assert len(provider_calls) == 1
    assert provider_calls[0]["required"] == "USERNAME"
    assert result.login_method == "USERNAME_PASSWORD"
    assert result.downstream_prompt == "HCM-CDNLeaf-Quan9-10G-01#"
    assert result.identity.actual_hostname == "HCM-CDNLeaf-Quan9-10G-01"
    assert result.identity.source_evidence["actual_hostname"] == "show_version"
    assert result.identity.serial_number == "FDO1234ABCD"
    assert result.identity.quality == "ACCEPTED"
    assert channel.sent[:3] == ["\n", "down-user\n", "down-pass\n"]


def test_hostname_conflict_between_prompt_and_command_is_rejected_not_false_match():
    identity = parse_identity(
        "CISCO",
        {
            "show_version": (
                "Cisco IOS XE Software, Version 17.09.04a\n"
                "REAL-DEVICE-B uptime is 1 day\n"
                "Processor board ID SERIAL-B\n"
            ),
            "show_inventory": (
                'NAME: "Chassis", DESCR: "Cisco Chassis"\n'
                "PID: C9300-48P, VID: V01, SN: SERIAL-B\n"
            ),
        },
        "DEVICE-A#",
        "DEVICE-A",
    )
    assert identity.actual_hostname == "REAL-DEVICE-B"
    assert "hostname_conflict" in identity.source_evidence
    assert identity.quality == "REJECTED"
    assert identity.alias_comparison == "DIFFERENT"


def test_huawei_sysname_is_independent_hostname_evidence_and_must_match_prompt():
    identity = parse_identity(
        "HUAWEI",
        {
            "display_version": (
                "Huawei Versatile Routing Platform Software\n"
                "VRP (R) software, Version 8.220 (CE6865 V200R022)\n"
                "HUAWEI CE6865 uptime is 3 days\n"
            ),
            "display_sysname": "sysname HCM-CDNLeaf-Quan9-10G-01\n",
            "display_esn": "ESN : 2102352ABC10XYZ00001\n",
        },
        "[~HCM-CDNLeaf-Quan9-10G-01]",
        "HCM-CDNLeaf-Quan9-10G-01",
    )
    assert identity.actual_hostname == "HCM-CDNLeaf-Quan9-10G-01"
    assert identity.source_evidence["actual_hostname"] == "display_sysname"
    assert "hostname_conflict" not in identity.source_evidence
    assert identity.quality == "ACCEPTED"


def test_configured_alias_is_never_used_as_actual_hostname_without_live_evidence():
    identity = parse_identity("UNKNOWN", {}, "", "CONFIGURED-ALIAS")
    assert identity.actual_hostname == ""
    assert identity.alias_comparison == "UNKNOWN"
    assert identity.quality == "REJECTED"


def test_cisco_identity_connection_refused_uses_controlled_clear_line_recovery(monkeypatch):
    settings = ApplicationSettings(command_timeout=1, connect_timeout=1)
    adapter = CiscoOOBAdapter(settings, {"vendor": "CISCO"})
    target = ConsoleTarget(
        id=1,
        oob_id=1,
        menu_name="OOB",
        menu_item=1,
        alias="R1",
        command="telnet 172.28.200.11 2003",
        protocol="TELNET",
        target_host="172.28.200.11",
        target_port=2003,
        console_line=3,
        state="AVAILABLE",
        state_confident=True,
        is_complete=True,
    )
    device = OOBDevice(id=1, name="OOB1", host="192.0.2.10", vendor="CISCO")

    class Client:
        def close(self):
            pass

    class Channel:
        def send(self, _value):
            return 1

    class SSH:
        last_host_key_algorithm = "ssh-ed25519"
        last_host_key_fingerprint = "SHA256:test"
        host_key_policy = "TOFU_PERSISTENT"
        expected_prompt = "OOB1#"

        def connect(self, *_a, **_k): return Client()
        def open_shell(self, *_a, **_k): return Channel()

    adapter.ssh = SSH()
    monkeypatch.setattr("oob_manager.vendors.cisco.adapter.check_tcp", lambda *_a, **_k: 0.1)
    monkeypatch.setattr(adapter, "_read_login_state", lambda _ch: ("OOB1#", "NORMAL_CLI"))
    monkeypatch.setattr(adapter, "_prepare_readonly_cli", lambda *_a: [])
    monkeypatch.setattr(
        adapter,
        "_verify_runtime_mapping_normal_cli",
        lambda *_a: (target, target.command, "mapping ok"),
    )
    live = ConsoleTarget(**{name: getattr(target, name) for name in target.__dataclass_fields__})
    live.console_line_source = "REVERSE_TELNET_PORT_CONFIRMED"
    monkeypatch.setattr(adapter, "_resolve_live_target_state", lambda *_a: live)
    monkeypatch.setattr(adapter, "_read_console_transition", lambda *_a, **_k: ("% Connection refused by remote host", "ERROR"))

    recovered = {"called": 0}

    def recover(*_a, **_k):
        recovered["called"] += 1
        return (
            "R1#", "TARGET_EVIDENCE", live,
            True, True, 3, "stale session", "CLEAR_SUCCEEDED_TELNET_RETRY",
        )

    monkeypatch.setattr(adapter, "_recover_refused_reverse_telnet", recover)
    monkeypatch.setattr(
        "oob_manager.vendors.cisco.adapter.DownstreamIdentityCollector.collect",
        lambda *_a, **_k: DownstreamDiscoveryResult(
            identity=parse_identity(
                "CISCO",
                {
                    "show_version": "Cisco IOS XE Software, Version 17.9\nR1 uptime is 1 day\nProcessor board ID S1\n",
                    "show_inventory": 'NAME: "Chassis"\nPID: C9300, VID: V01, SN: S1\n',
                },
                "R1#",
                "R1",
            ),
            downstream_prompt="R1#",
        ),
    )

    result = adapter.discover_downstream_identity(
        device,
        target,
        SessionCredentials("oob", "oob-pass", "enable"),
        DownstreamCredentials(),
    )
    assert recovered["called"] == 1
    assert result.metadata["clear_line_recovery_used"] is True
    assert result.metadata["clear_line_number"] == 3
    assert result.identity.actual_hostname == "R1"
