from __future__ import annotations

import re

from oob_manager.models.device_identity import DeviceIdentity
from oob_manager.utils.validation import normalize_alias


_CISCO_HINTS = (
    "cisco ios",
    "ios xe",
    "nx-os",
    "nxos:",
    "cisco adaptive security appliance",
)
_JUNIPER_HINTS = ("junos", "juniper networks", "junos os")
_HUAWEI_HINTS = ("huawei", "versatile routing platform", "vrp (r) software")


def detect_vendor(show_version: str = "", display_version: str = "") -> str:
    combined = f"{show_version}\n{display_version}".casefold()
    if any(hint in combined for hint in _CISCO_HINTS):
        return "CISCO"
    if any(hint in combined for hint in _JUNIPER_HINTS):
        return "JUNIPER"
    if any(hint in combined for hint in _HUAWEI_HINTS):
        return "HUAWEI"
    return "UNKNOWN"


def hostname_from_prompt(prompt: str, vendor: str = "UNKNOWN") -> str:
    value = prompt.strip()
    if not value:
        return ""
    if value.startswith("<") and value.endswith(">"):
        return value[1:-1].strip()
    if value.startswith("[") and value.endswith("]"):
        # Huawei VRP system/config prompt, e.g. [PE-HN-01] / [~PE-HN-01].
        return value[1:-1].strip().lstrip("~").strip()
    if value.endswith(("#", ">")):
        core = value[:-1].strip()
        if "@" in core:
            core = core.rsplit("@", 1)[-1]
        # Cisco config-mode prompt should never occur in this read-only collector,
        # but stripping '(...)' avoids storing a mode suffix as hostname if the
        # console was already left in a non-config submode by someone else.
        core = re.sub(r"\([^()]*\)$", "", core).strip()
        return core
    return ""


def _first_match(patterns: list[str], text: str, flags: int = 0) -> str:
    for pattern in patterns:
        match = re.search(pattern, text, flags)
        if match:
            value = match.group(1).strip()
            if value:
                return value
    return ""


def _parse_cisco(outputs: dict[str, str], prompt: str) -> DeviceIdentity:
    version = outputs.get("show_version", "")
    inventory = outputs.get("show_inventory", "")
    command_hostname = _first_match(
        [
            r"(?mi)^([A-Za-z0-9_.:-]+)\s+uptime is\b",
            r"(?mi)^\s*Device name:\s*([A-Za-z0-9_.:-]+)\s*$",
        ],
        version,
    )
    prompt_hostname = hostname_from_prompt(prompt, "CISCO")
    hostname = command_hostname or prompt_hostname

    software_version = _first_match(
        [
            r"(?i)Cisco IOS XE Software,\s*Version\s+([^,\s]+)",
            r"(?i)Cisco IOS Software,.*?\bVersion\s+([^,\s]+)",
            r"(?i)NXOS:\s*version\s+([^\s,]+)",
            r"(?i)Cisco Adaptive Security Appliance Software Version\s+([^\s,]+)",
        ],
        version,
        re.S,
    )

    model = ""
    serial = ""

    # show inventory may contain dozens of modules/transceivers. Never take the
    # first PID/SN blindly: prefer a chassis/system block so a PSU/SFP serial is
    # not promoted as the device serial. If no trustworthy chassis block exists,
    # fall back to the platform/processor-board identity from show version.
    inventory_blocks = re.split(r"(?mi)(?=^\s*NAME:\s*)", inventory)
    for block in inventory_blocks:
        name_match = re.search(r'(?mi)^\s*NAME:\s*"?([^"\r\n,]+)', block)
        if not name_match:
            continue
        name = name_match.group(1).strip().casefold()
        if not any(token in name for token in ("chassis", "system", "switch 1", "slot 1")):
            continue
        inv_match = re.search(
            r"(?mi)^\s*PID:\s*([^,\s]+)\s*,.*?\bSN:\s*([^,\s]+)",
            block,
        )
        if inv_match:
            model = inv_match.group(1).strip()
            serial = inv_match.group(2).strip()
            break

    if not model:
        model = _first_match(
            [
                r"(?mi)^\s*Model Number\s*:\s*(\S+)",
                r"(?mi)^\s*Hardware:\s*([^,\s]+)",
                r"(?mi)^cisco\s+(\S+)\s+\(.+?\)\s+processor",
            ],
            version,
        )
    if not serial:
        serial = _first_match(
            [
                r"(?mi)^\s*Processor board ID\s+(\S+)",
                r"(?mi)^\s*System serial number\s*:\s*(\S+)",
                r"(?mi)^\s*Serial Number\s*:\s*(\S+)",
            ],
            version,
        )

    sources: dict[str, str] = {}
    if hostname:
        sources["actual_hostname"] = "show_version" if command_hostname else "prompt"
    if (
        command_hostname
        and prompt_hostname
        and normalize_alias(command_hostname) != normalize_alias(prompt_hostname)
    ):
        sources["hostname_conflict"] = f"show_version={command_hostname};prompt={prompt_hostname}"
    if software_version:
        sources["software_version"] = "show_version"
    if model:
        sources["model"] = "show_inventory_or_show_version"
    if serial:
        sources["serial_number"] = "show_inventory_or_show_version"
    return DeviceIdentity(
        actual_hostname=hostname,
        vendor="CISCO",
        platform_family="IOS_FAMILY",
        model=model,
        serial_number=serial,
        software_version=software_version,
        source_evidence=sources,
    )


def _parse_juniper(outputs: dict[str, str], prompt: str) -> DeviceIdentity:
    version = outputs.get("show_version", "")
    hardware = outputs.get("show_chassis_hardware", "")
    command_hostname = _first_match([r"(?mi)^\s*Hostname:\s*(\S+)"], version)
    prompt_hostname = hostname_from_prompt(prompt, "JUNIPER")
    hostname = command_hostname or prompt_hostname
    model = _first_match([r"(?mi)^\s*Model:\s*(\S+)"], version)
    software_version = _first_match(
        [
            r"(?mi)^\s*Junos:\s*(\S+)",
            r"(?mi)^\s*JUNOS .*?\[(.*?)\]",
        ],
        version,
    )
    serial = ""
    for raw_line in hardware.splitlines():
        line = raw_line.strip()
        if not line.casefold().startswith("chassis"):
            continue
        tokens = line.split()
        # Header is filtered because token 2 would be "Version"/"Part".
        if len(tokens) >= 2 and tokens[1].casefold() not in {"version", "part", "serial"}:
            serial = tokens[1]
            break

    sources: dict[str, str] = {}
    if hostname:
        sources["actual_hostname"] = "show_version" if command_hostname else "prompt"
    if (
        command_hostname
        and prompt_hostname
        and normalize_alias(command_hostname) != normalize_alias(prompt_hostname)
    ):
        sources["hostname_conflict"] = f"show_version={command_hostname};prompt={prompt_hostname}"
    if model:
        sources["model"] = "show_version"
    if software_version:
        sources["software_version"] = "show_version"
    if serial:
        sources["serial_number"] = "show_chassis_hardware"
    return DeviceIdentity(
        actual_hostname=hostname,
        vendor="JUNIPER",
        platform_family="JUNOS",
        model=model,
        serial_number=serial,
        software_version=software_version,
        source_evidence=sources,
    )


def _parse_huawei(outputs: dict[str, str], prompt: str) -> DeviceIdentity:
    version = outputs.get("display_version", "")
    esn = outputs.get("display_esn", "")
    sysname_output = outputs.get("display_sysname", "")
    command_hostname = _first_match(
        [r"(?mi)^\s*sysname\s+([A-Za-z0-9_.:-]+)\s*$"],
        sysname_output,
    )
    prompt_hostname = hostname_from_prompt(prompt, "HUAWEI")
    hostname = command_hostname or prompt_hostname
    software_version = _first_match(
        [r"(?mi)^\s*VRP\s*\(R\)\s*software,\s*Version\s+(.+?)\s*$"],
        version,
    )
    model = _first_match(
        [
            # Huawei commonly prints the full product name immediately before
            # "uptime is". Capture the complete product string (for example
            # "NetEngine 8000 F1A"), not only its first token.
            r"(?mi)^\s*HUAWEI\s+(.+?)\s+uptime is\b",
            r"(?mi)^\s*((?:NE\d+\S*|CE\d+\S*|S\d+\S*|AR\d+\S*|ATN\d+\S*))\s+uptime is\b",
            r"(?i)Version\s+[^\r\n]*\(([^()\r\n]+)\)",
        ],
        version,
    )
    serial = _first_match(
        [
            r"(?mi)^\s*ESN(?:\s+of[^:]*)?\s*:\s*([A-Za-z0-9._-]+)",
            r"(?mi)^\s*Electronic Serial Number\s*:\s*([A-Za-z0-9._-]+)",
        ],
        esn,
    )

    sources: dict[str, str] = {}
    if hostname:
        sources["actual_hostname"] = "display_sysname" if command_hostname else "prompt"
    if (
        command_hostname
        and prompt_hostname
        and normalize_alias(command_hostname) != normalize_alias(prompt_hostname)
    ):
        sources["hostname_conflict"] = f"display_sysname={command_hostname};prompt={prompt_hostname}"
    if software_version:
        sources["software_version"] = "display_version"
    if model:
        sources["model"] = "display_version"
    if serial:
        sources["serial_number"] = "display_esn"
    return DeviceIdentity(
        actual_hostname=hostname,
        vendor="HUAWEI",
        platform_family="VRP",
        model=model,
        serial_number=serial,
        software_version=software_version,
        source_evidence=sources,
    )


def _finalize(identity: DeviceIdentity, configured_alias: str) -> DeviceIdentity:
    hostname_conflict = str(identity.source_evidence.get("hostname_conflict", "") or "")
    populated = sum(
        bool(value)
        for value in (
            identity.actual_hostname,
            identity.model,
            identity.serial_number,
            identity.software_version,
        )
    )

    # A current "verified identity" must include a stable hardware identifier.
    # Hostname + software version alone can describe a CLI, but cannot reliably
    # prove which physical device is connected to the console cable. Keep such
    # evidence as PARTIAL rather than promoting it to current identity.
    if hostname_conflict:
        # Never promote an identity when the stable CLI prompt and an independent
        # read-only hostname source disagree. This is exactly the situation where
        # using the configured OOB alias as truth would create a false MATCH.
        identity.quality = "REJECTED"
    elif (
        identity.vendor != "UNKNOWN"
        and identity.actual_hostname
        and identity.serial_number
    ):
        identity.quality = "ACCEPTED"
    elif identity.vendor != "UNKNOWN" and populated >= 1:
        identity.quality = "PARTIAL"
    else:
        identity.quality = "REJECTED"

    if hostname_conflict:
        identity.confidence = "LOW"
    elif identity.actual_hostname and identity.model and identity.serial_number:
        identity.confidence = "HIGH"
    elif identity.actual_hostname and identity.serial_number:
        identity.confidence = "MEDIUM"
    elif identity.actual_hostname and (identity.model or identity.software_version):
        identity.confidence = "LOW"
    else:
        identity.confidence = "LOW"

    if identity.actual_hostname and configured_alias.strip():
        identity.alias_comparison = (
            "EXACT_MATCH"
            if normalize_alias(identity.actual_hostname) == normalize_alias(configured_alias)
            else "DIFFERENT"
        )
    else:
        identity.alias_comparison = "UNKNOWN"
    return identity


def parse_identity(
    vendor: str,
    outputs: dict[str, str],
    prompt: str,
    configured_alias: str,
) -> DeviceIdentity:
    vendor = vendor.upper()
    if vendor == "CISCO":
        identity = _parse_cisco(outputs, prompt)
    elif vendor == "JUNIPER":
        identity = _parse_juniper(outputs, prompt)
    elif vendor == "HUAWEI":
        identity = _parse_huawei(outputs, prompt)
    else:
        identity = DeviceIdentity(vendor="UNKNOWN")
    return _finalize(identity, configured_alias)
