from __future__ import annotations

import re
import time
from collections.abc import Callable

from oob_manager.exceptions import CommandExecutionError, InteractiveSessionError
from oob_manager.models import DownstreamCredentials, DownstreamDiscoveryResult, RawCommandOutput
from oob_manager.downstream.parsers import detect_vendor, parse_identity

ANSI_RE = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")
USERNAME_PROMPT_RE = re.compile(
    r"(?im)(?:^|\n)\s*(?:(?:user\s*name|username)\s*:|(?:\S+\s+)?login\s*:)\s*$"
)
PASSWORD_PROMPT_RE = re.compile(r"(?im)(?:^|\n)\s*password\s*:\s*$")
AUTH_FAILURE_RE = re.compile(
    r"(?i)(authentication\s+failed|login\s+(?:invalid|incorrect)|access\s+denied|"
    r"incorrect\s+password|bad\s+password|permission\s+denied)"
)
DEVICE_PROMPT_PATTERNS = (
    # Cisco/IOS/NX-OS and Junos operational prompts. Whitespace is deliberately
    # rejected so banner text such as ``Enter selection >`` cannot be promoted
    # to a device prompt.
    re.compile(r"^\S{1,120}[#>]\s*$"),
    # Huawei VRP user view.
    re.compile(r"^<[^<>\r\n]{1,120}>\s*$"),
    # Huawei VRP system/config views, e.g. ``[PE-HN-01]`` or
    # ``[~PE-HN-01]``. These are stable CLI prompts; only read-only ``display``
    # commands are ever issued by this collector.
    re.compile(r"^\[~?[^\[\]\r\n]{1,120}\]\s*$"),
)
PAGER_RE = re.compile(
    r"(?i)(--\s*more\s*--|<---\s*more\s*--->|----\s*more\s*----|"
    r"press\s+(?:any\s+key|return)\s+to\s+continue)"
)
CLI_ERROR_RE = re.compile(
    r"(?i)(%\s*invalid input|%\s*incomplete command|%\s*ambiguous command|"
    r"unknown\s+command|unrecognized\s+command|error:\s*unrecognized|"
    r"error:\s*wrong parameter|authorization failed|command authorization failed|"
    r"error:\s*too many parameters|\^\s*$)"
)


class DownstreamIdentityCollector:
    """Thu thập identity read-only từ CLI phía sau console.

    Collector chỉ dùng một whitelist command cố định. Nó không nhận command tự do
    từ user/database, không vào configuration mode và không ghi password xuống raw
    output. Paging được xử lý bằng Space để giữ nguyên ngữ nghĩa read-only.
    """

    MAX_OUTPUT_CHARS = 2_000_000
    MAX_PAGER_CONTINUES = 200

    def __init__(self, ssh_wrapper, command_timeout: int = 20) -> None:
        self.ssh = ssh_wrapper
        self.command_timeout = command_timeout

    @staticmethod
    def _terminal_text(value: str) -> str:
        """Normalize terminal control noise for semantic prompt detection only.

        Raw evidence is never rewritten; this helper is used only while deciding
        whether bytes received from the console represent Username/Password/CLI.
        ANSI CSI/OSC sequences, NUL bytes and backspace editing are common on
        physical serial consoles and must not make a valid hostname prompt appear
        ``UNVERIFIED``.
        """
        text = ANSI_RE.sub("", str(value or "")).replace("\x00", "")
        out: list[str] = []
        for ch in text:
            if ch == "\b":
                if out and out[-1] not in {"\n", "\r"}:
                    out.pop()
                continue
            out.append(ch)
        return "".join(out).replace("\r\n", "\n").replace("\r", "\n")

    @classmethod
    def extract_device_prompt(cls, value: str) -> str | None:
        normalized = cls._terminal_text(value)
        lines = [line.strip() for line in normalized.split("\n") if line.strip()]
        if not lines:
            return None
        candidate = lines[-1]
        if any(pattern.fullmatch(candidate) for pattern in DEVICE_PROMPT_PATTERNS):
            return candidate
        return None

    @classmethod
    def _authentication_state(cls, value: str) -> str | None:
        normalized = cls._terminal_text(value)
        if AUTH_FAILURE_RE.search(normalized):
            return "AUTH_FAILURE"
        if cls.extract_device_prompt(normalized):
            return "PROMPT"
        # Check username before password. Some login banners can contain the word
        # password in prose, while these patterns require a terminal prompt line.
        # ``User Name:`` is intentionally supported because it is common on real
        # network-device console AAA banners.
        if USERNAME_PROMPT_RE.search(normalized):
            return "USERNAME"
        if PASSWORD_PROMPT_RE.search(normalized):
            return "PASSWORD"
        return None

    def _read_auth_transition(
        self,
        channel,
        *,
        timeout: float | None = None,
        initial: str = "",
    ) -> tuple[str, str | None]:
        """Wait for a semantic downstream login/CLI state.

        Real routers and switches may pause after console banners or AAA messages.
        A short quiet period therefore cannot be used as proof that a login step
        completed.  v1.1.19 waits until username/password/device-prompt/failure
        evidence is observed or the configured command deadline expires.
        """

        reader = getattr(self.ssh, "read_until_state", None)
        if callable(reader):
            return reader(
                channel,
                self._authentication_state,
                timeout=timeout or self.command_timeout,
                settle=0.2,
                initial=initial,
            )
        output = initial + self.ssh.read_until_quiet(
            channel, timeout=timeout or self.command_timeout, quiet=0.35
        )
        return output, self._authentication_state(output)

    def _read_after_send(self, channel, timeout: float | None = None, quiet: float = 0.35) -> str:
        # Retained for compatibility in non-authentication paths/test doubles.
        return self.ssh.read_until_quiet(channel, timeout=timeout or self.command_timeout, quiet=quiet)

    def _authenticate(
        self,
        channel,
        initial_output: str,
        credentials: DownstreamCredentials,
        *,
        credential_provider: Callable[[dict[str, str]], DownstreamCredentials] | None = None,
        configured_alias: str = "",
    ) -> tuple[str, str]:
        transcript = initial_output or ""
        # Work on a copy so lazy credential collection cannot mutate a caller's
        # shared credential object unexpectedly.
        effective = DownstreamCredentials(credentials.username, credentials.password)
        username_sent = False
        password_sent = False
        newline_sent = False

        def request_credentials(required: str) -> None:
            nonlocal effective
            if not callable(credential_provider):
                return
            supplied = credential_provider({
                "required": required,
                "configured_alias": configured_alias,
                "current_username": effective.username,
            })
            if not isinstance(supplied, DownstreamCredentials):
                raise InteractiveSessionError(
                    "Credential provider downstream trả dữ liệu không hợp lệ.",
                    error_code="DOWNSTREAM_CREDENTIAL_PROVIDER_INVALID",
                )
            effective = DownstreamCredentials(
                supplied.username or effective.username,
                supplied.password or effective.password,
            )

        # Evaluate any evidence already received before typing.  If the serial
        # target is silent, send a single Enter and then wait for a semantic state.
        for _ in range(10):
            state = self._authentication_state(transcript)
            if state == "AUTH_FAILURE":
                raise InteractiveSessionError(
                    "Thiết bị downstream từ chối đăng nhập.",
                    error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
                )
            if state == "PROMPT":
                prompt = self.extract_device_prompt(transcript)
                if not prompt:
                    break
                if username_sent and password_sent:
                    method = "USERNAME_PASSWORD"
                elif username_sent:
                    method = "USERNAME_ONLY"
                elif password_sent:
                    method = "PASSWORD_ONLY"
                else:
                    method = "EXISTING_CLI"
                return prompt, method

            if state == "USERNAME":
                if username_sent:
                    raise InteractiveSessionError(
                        "Thiết bị downstream hỏi username lặp lại; đăng nhập không thành công.",
                        error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
                    )
                if not effective.username:
                    request_credentials("USERNAME")
                if not effective.username:
                    raise InteractiveSessionError(
                        "Thiết bị downstream yêu cầu username nhưng chưa được cung cấp.",
                        error_code="DOWNSTREAM_USERNAME_REQUIRED",
                    )
                channel.send(effective.username + "\n")
                username_sent = True
                transcript, _ = self._read_auth_transition(channel)
                continue

            if state == "PASSWORD":
                if password_sent:
                    raise InteractiveSessionError(
                        "Thiết bị downstream hỏi password lặp lại; đăng nhập không thành công.",
                        error_code="DOWNSTREAM_AUTHENTICATION_FAILED",
                    )
                if not effective.password:
                    request_credentials("PASSWORD")
                if not effective.password:
                    raise InteractiveSessionError(
                        "Thiết bị downstream yêu cầu password nhưng chưa được cung cấp.",
                        error_code="DOWNSTREAM_PASSWORD_REQUIRED",
                    )
                channel.send(effective.password + "\n")
                password_sent = True
                transcript, _ = self._read_auth_transition(channel)
                continue

            if not newline_sent:
                # Only one Enter is sent to wake a quiet serial console.  The
                # semantic reader then waits through slow banner/AAA gaps.
                channel.send("\n")
                newline_sent = True
                transcript, _ = self._read_auth_transition(channel)
                continue

            # No semantic state arrived by the configured deadline. Do not send
            # additional text into an unknown terminal state.
            break

        raise InteractiveSessionError(
            "Không xác định được login prompt/CLI prompt của thiết bị downstream.",
            error_code="DOWNSTREAM_PROMPT_UNVERIFIED",
        )

    def _run_readonly_command(self, channel, command: str, expected_prompt: str) -> str:
        self.ssh.drain_channel(channel)
        channel.send(command + "\n")
        deadline = time.monotonic() + self.command_timeout
        chunks: list[str] = []
        pager_count = 0
        prompt_seen_at: float | None = None
        last_pager_position = -1

        while time.monotonic() < deadline:
            if channel.recv_ready():
                data = channel.recv(65535)
                if not data:
                    break
                chunks.append(data.decode("utf-8", errors="replace"))
                joined = "".join(chunks)
                if len(joined) > self.MAX_OUTPUT_CHARS:
                    exc = CommandExecutionError(
                        f"Output downstream vượt giới hạn an toàn: {command}",
                        error_code="DOWNSTREAM_OUTPUT_TOO_LARGE",
                    )
                    exc.raw_output = joined[: self.MAX_OUTPUT_CHARS]
                    raise exc

                pager_matches = list(PAGER_RE.finditer(joined))
                if pager_matches:
                    latest = pager_matches[-1]
                    if latest.start() != last_pager_position:
                        pager_count += 1
                        last_pager_position = latest.start()
                        if pager_count > self.MAX_PAGER_CONTINUES:
                            exc = CommandExecutionError(
                                f"Downstream paging vượt giới hạn: {command}",
                                error_code="DOWNSTREAM_PAGING_LIMIT",
                            )
                            exc.raw_output = joined
                            raise exc
                        channel.send(" ")

                normalized_joined = self._terminal_text(joined)
                lines = [line.strip() for line in normalized_joined.split("\n") if line.strip()]
                prompt_seen_at = (
                    time.monotonic()
                    if lines and lines[-1] == expected_prompt.strip()
                    else None
                )
            elif prompt_seen_at is not None and time.monotonic() - prompt_seen_at >= 0.2:
                break
            else:
                time.sleep(0.04)

        output = "".join(chunks)
        normalized_output = self._terminal_text(output)
        lines = [line.strip() for line in normalized_output.split("\n") if line.strip()]
        if not lines or lines[-1] != expected_prompt.strip():
            exc = CommandExecutionError(
                f"Downstream command không trở về đúng prompt: {command}",
                error_code="DOWNSTREAM_COMMAND_TIMEOUT",
            )
            exc.raw_output = output
            raise exc
        return output

    @staticmethod
    def _append_raw(
        raw: list[RawCommandOutput],
        name: str,
        command: str,
        output: str,
        success: bool,
        error: str = "",
    ) -> None:
        raw.append(
            RawCommandOutput(
                command_name=name,
                command_text=command,
                raw_output=output,
                success=success,
                error_message=error,
                is_core=True,
                redaction_applied=False,
            )
        )

    def _try_command(
        self,
        channel,
        raw: list[RawCommandOutput],
        name: str,
        command: str,
        prompt: str,
    ) -> str:
        try:
            output = self._run_readonly_command(channel, command, prompt)
            ok = not bool(CLI_ERROR_RE.search(output))
            self._append_raw(raw, name, command, output, ok, "CLI error" if not ok else "")
            return output if ok else ""
        except CommandExecutionError as exc:
            # A timeout/output-limit/paging failure means we no longer know that
            # the channel is synchronized at the expected CLI prompt. Continuing
            # with another command could send text into an unfinished pager or
            # command context, so fail closed. Preserve the partial evidence.
            partial = str(getattr(exc, "raw_output", "") or "")
            self._append_raw(raw, name, command, partial, False, str(exc))
            exc.raw_outputs = list(raw)
            raise
        except Exception as exc:
            partial = str(getattr(exc, "raw_output", "") or "")
            self._append_raw(raw, name, command, partial, False, str(exc))
            error = InteractiveSessionError(
                f"Downstream command channel mất đồng bộ khi chạy {command}.",
                error_code="DOWNSTREAM_COMMAND_CHANNEL_ERROR",
            )
            error.raw_outputs = list(raw)
            raise error from exc

    def collect(
        self,
        channel,
        initial_output: str,
        credentials: DownstreamCredentials,
        configured_alias: str,
        *,
        credential_provider: Callable[[dict[str, str]], DownstreamCredentials] | None = None,
    ) -> DownstreamDiscoveryResult:
        prompt, login_method = self._authenticate(
            channel,
            initial_output,
            credentials,
            credential_provider=credential_provider,
            configured_alias=configured_alias,
        )
        raw: list[RawCommandOutput] = []
        outputs: dict[str, str] = {}

        # Detection uses only read-only commands. show version is valid on Cisco/
        # Juniper; display version is tried only when show version cannot identify.
        show_version = self._try_command(channel, raw, "show_version", "show version", prompt)
        outputs["show_version"] = show_version
        vendor = detect_vendor(show_version=show_version)

        if vendor == "UNKNOWN":
            display_version = self._try_command(channel, raw, "display_version", "display version", prompt)
            outputs["display_version"] = display_version
            vendor = detect_vendor(show_version=show_version, display_version=display_version)

        if vendor == "CISCO":
            outputs["show_inventory"] = self._try_command(
                channel, raw, "show_inventory", "show inventory", prompt
            )
        elif vendor == "JUNIPER":
            outputs["show_chassis_hardware"] = self._try_command(
                channel,
                raw,
                "show_chassis_hardware",
                "show chassis hardware | no-more",
                prompt,
            )
        elif vendor == "HUAWEI":
            # ``sysname`` is a stronger hostname source than the prompt alone and
            # remains read-only. Failure/authorization denial is tolerated by
            # _try_command and the parser falls back to the verified prompt.
            outputs["display_sysname"] = self._try_command(
                channel, raw, "display_sysname",
                "display current-configuration | include sysname", prompt
            )
            outputs["display_esn"] = self._try_command(
                channel, raw, "display_esn", "display esn", prompt
            )

        identity = parse_identity(vendor, outputs, prompt, configured_alias)
        if identity.quality == "REJECTED":
            error = InteractiveSessionError(
                "Đã vào CLI downstream nhưng không thu thập được identity đủ tin cậy.",
                error_code="DOWNSTREAM_IDENTITY_REJECTED",
            )
            error.raw_outputs = raw
            error.identity = identity
            error.downstream_prompt = prompt
            error.login_method = login_method
            raise error

        return DownstreamDiscoveryResult(
            identity=identity,
            raw_outputs=raw,
            login_method=login_method,
            downstream_prompt=prompt,
        )
