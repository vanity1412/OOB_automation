@echo off
setlocal EnableExtensions

rem OOB Console Manager v1.1.33 - Windows UAT stability launcher
rem - Khong clear man hinh: giu toan bo output de scroll/debug.
rem - Tao .venv rieng, kiem tra Python cua .venv, ep dung dependency da pin.
rem - Neu .venv bi cu/hong/sai Python, tu tao lai vi .venv khong chua du lieu tool.

chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"

echo ==============================================================================
echo                 OOB CONSOLE MANAGER v1.1.33 - WINDOWS UAT
echo ==============================================================================
echo Thu muc : %CD%
echo.

if not exist "main.py" (
    echo [LOI] Khong tim thay main.py trong thu muc hien tai.
    echo Hay dat run_windows.bat tai thu muc goc cua OOB Console Manager.
    pause
    exit /b 10
)

if not exist "requirements.txt" (
    echo [LOI] Khong tim thay requirements.txt.
    pause
    exit /b 11
)

set "BOOT_PY="
where py >nul 2>nul
if not errorlevel 1 (
    rem Uu tien Python 3.12/3.13 cho UAT, sau do moi dung Python 3 bat ky >=3.10.
    py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
    if not errorlevel 1 set "BOOT_PY=py -3.12"
    if not defined BOOT_PY (
        py -3.13 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
        if not errorlevel 1 set "BOOT_PY=py -3.13"
    )
    if not defined BOOT_PY (
        py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
        if not errorlevel 1 set "BOOT_PY=py -3"
    )
)

if not defined BOOT_PY (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
        if not errorlevel 1 set "BOOT_PY=python"
    )
)

if not defined BOOT_PY (
    echo [LOI] Can Python 3.10 tro len. Khuyen nghi Python 3.12 hoac 3.13.
    echo Khi cai Python tren Windows, nho chon "Add Python to PATH".
    pause
    exit /b 12
)

%BOOT_PY% -c "import sys; print('[OK] Bootstrap Python', sys.version.split()[0])"
if errorlevel 1 (
    echo [LOI] Khong khoi chay duoc Python.
    pause
    exit /b 13
)

set "RECREATE_VENV=0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
    if errorlevel 1 set "RECREATE_VENV=1"
) else (
    set "RECREATE_VENV=1"
)

if "%RECREATE_VENV%"=="1" (
    if exist ".venv" (
        echo [1/5] .venv cu/khong hop le. Dang tao lai...
        rmdir /s /q ".venv"
        if exist ".venv" (
            echo [LOI] Khong xoa duoc .venv cu. Dong cac terminal/python dang dung .venv va thu lai.
            pause
            exit /b 19
        )
    ) else (
        echo [1/5] Tao virtual environment .venv ...
    )
    %BOOT_PY% -m venv .venv
    if errorlevel 1 (
        echo [LOI] Tao .venv that bai.
        pause
        exit /b 20
    )
) else (
    echo [1/5] .venv hop le.
)

set "VENV_PY=%CD%\.venv\Scripts\python.exe"

"%VENV_PY%" -m pip --version >nul 2>nul
if errorlevel 1 (
    echo [2/5] Khoi tao pip trong .venv ...
    "%VENV_PY%" -m ensurepip --upgrade
    if errorlevel 1 (
        echo [LOI] Khong khoi tao duoc pip.
        pause
        exit /b 21
    )
) else (
    echo [2/5] pip san sang.
)

rem Khong chi check import: ep dung dung version release da test.
"%VENV_PY%" -c "import importlib.metadata as m,sys; sys.exit(0 if m.version('paramiko')=='3.5.1' and m.version('colorama')=='0.4.6' else 1)" >nul 2>nul
if errorlevel 1 (
    echo [3/5] Dependency thieu hoac sai version. Dang dong bo requirements.txt ...
    "%VENV_PY%" -m pip install --upgrade -r requirements.txt
    if errorlevel 1 (
        echo [LOI] Cai dependency that bai.
        echo Kiem tra Internet/proxy/PyPI. Tool can paramiko==3.5.1 va colorama==0.4.6.
        pause
        exit /b 30
    )
) else (
    echo [3/5] Dependency dung version release.
)

"%VENV_PY%" -c "import paramiko,colorama; print('[OK] paramiko=' + paramiko.__version__ + ' | colorama=' + colorama.__version__)"
if errorlevel 1 (
    echo [LOI] Dependency import that bai sau khi cai dat.
    pause
    exit /b 31
)

echo [4/5] Environment check ...
"%VENV_PY%" main.py --check
if errorlevel 1 (
    echo.
    echo [LOI] Environment check khong dat.
    echo Khong mo tool de tranh UAT trong trang thai chua san sang.
    echo Xem thong bao phia tren va logs neu co.
    pause
    exit /b 40
)

echo [5/5] San sang khoi dong.
echo.
echo ==============================================================================
echo [OK] Moi truong san sang. Dang mo OOB Console Manager...
echo Ghi chu: launcher KHONG clear man hinh; co the scroll len de xem lai output.
echo ==============================================================================
echo.

"%VENV_PY%" main.py
set "APP_EXIT=%ERRORLEVEL%"

echo.
echo ==============================================================================
if "%APP_EXIT%"=="0" (
    echo Tool da dong binh thuong.
) else (
    echo [CANH BAO] Tool ket thuc voi ma loi %APP_EXIT%.
    echo Xem logs\oob_manager.log va output phia tren de dieu tra.
)
echo ==============================================================================
pause
exit /b %APP_EXIT%
